package test.example;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Test code. It holds, unchanged, the first positive case of each of ten rules (SR-PERF-REGEX-IN-LOOP-001, -KEYSET-GET-001,
 * -LIST-SEARCH-001, -STRING-CONCAT-001, -QUERY-IN-LOOP-001, SR-JAVA-EMPTY-CATCH-001, -INTERRUPT-001, -RESOURCE-LEAK-001,
 * -DEFAULT-CHARSET-001 and -SHARED-FORMAT-001). The rules leave test code out of their scope, so none of them runs here: the cases of
 * their suites that select these members say execution NOT_APPLICABLE.
 */
class TestFolderCases {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy/MM/dd");

    int numbers(List<String> values) {
        int n = 0;
        for (String v : values) {
            if (Pattern.compile("[0-9]+").matcher(v).matches()) {
                n++;
            }
        }
        return n;
    }

    int total(Map<String, Integer> counts) {
        int total = 0;
        for (String key : counts.keySet()) {
            total += counts.get(key);
        }
        return total;
    }

    List<String> distinct(List<String> codes) {
        List<String> out = new ArrayList<>();
        for (String code : codes) {
            if (!out.contains(code)) {
                out.add(code);
            }
        }
        return out;
    }

    String csv(List<String> rows) {
        String out = "";
        for (String row : rows) {
            out += row;
            out += "\r\n";
        }
        return out;
    }

    List<String> names(Connection c, List<Long> ids) throws SQLException {
        List<String> out = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement("select name from customer where id = ?")) {
            for (Long id : ids) {
                ps.setLong(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        out.add(rs.getString(1));
                    }
                }
            }
        }
        return out;
    }

    int quantity(String text) {
        int qty = 0;
        try {
            qty = Integer.parseInt(text);
        } catch (NumberFormatException e) {
        }
        return qty;
    }

    void loggedInterrupt() { try { Thread.sleep(1); } catch (InterruptedException e) { System.out.println(e); } }

    String firstLine(File file) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(file));
        return reader.readLine();
    }

    byte[] encode(String name) {
        return name.getBytes();
    }
}
