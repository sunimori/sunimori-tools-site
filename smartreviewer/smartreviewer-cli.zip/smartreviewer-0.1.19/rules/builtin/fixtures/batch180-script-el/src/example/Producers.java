package example;

import javax.enterprise.inject.Produces;
import javax.inject.Named;

public class Producers {
    @Produces
    @Named("produced")
    public int produced() {
        return 0;
    }
}
