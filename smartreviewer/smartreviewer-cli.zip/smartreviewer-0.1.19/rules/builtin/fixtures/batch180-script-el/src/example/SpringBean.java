package example;

import org.springframework.stereotype.Component;

@Component("spr")
public class SpringBean {
    public int getCount() {
        return 0;
    }
}
