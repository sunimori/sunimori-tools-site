package example;

public class Item {
    public long getId() {
        return 1;
    }

    public String getTitle() {
        return "";
    }

    public int getQuantity() {
        return 0;
    }

    public Status getStatus() {
        return Status.NEW;
    }
}
