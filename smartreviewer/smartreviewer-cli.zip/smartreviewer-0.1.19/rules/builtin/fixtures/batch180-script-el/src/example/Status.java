package example;

public enum Status {
    NEW, DONE
}
