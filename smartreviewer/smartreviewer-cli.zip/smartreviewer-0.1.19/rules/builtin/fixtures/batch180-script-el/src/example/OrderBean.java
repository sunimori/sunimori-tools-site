package example;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.inject.Named;

@Named("order")
public class OrderBean {
    public int getCount() {
        return 0;
    }

    public long getId() {
        return 0;
    }

    public Integer getBoxed() {
        return 0;
    }

    public double getPrice() {
        return 0;
    }

    public BigDecimal getAmount() {
        return BigDecimal.ZERO;
    }

    public boolean isActive() {
        return true;
    }

    public Boolean getFlag() {
        return Boolean.TRUE;
    }

    public Status getStatus() {
        return Status.NEW;
    }

    public List<Status> getStatuses() {
        return List.of();
    }

    public String getName() {
        return "";
    }

    public String getComment() {
        return "";
    }

    public char getInitial() {
        return 'a';
    }

    public Date getDate() {
        return null;
    }

    public java.time.LocalDate getDay() {
        return null;
    }

    public java.time.LocalDateTime getMoment() {
        return null;
    }

    public java.util.UUID getUuid() {
        return null;
    }

    public java.util.Calendar getCalendar() {
        return null;
    }

    public List<Item> getItems() {
        return List.of();
    }

    public Item getFirst() {
        return null;
    }

    public List<Integer> getNumbers() {
        return List.of();
    }

    public java.util.Optional<Integer> getMaybe() {
        return java.util.Optional.empty();
    }

    public Map<String, String> getLabels() {
        return Map.of();
    }
}
