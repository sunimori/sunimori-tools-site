package org.springframework.stereotype;

/** Stub (fixture only). */
public @interface Component {
    String value() default "";
}
