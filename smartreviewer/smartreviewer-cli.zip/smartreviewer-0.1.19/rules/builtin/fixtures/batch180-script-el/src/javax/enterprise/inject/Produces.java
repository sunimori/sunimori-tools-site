package javax.enterprise.inject;

/** Stub (fixture only). */
public @interface Produces {
}
