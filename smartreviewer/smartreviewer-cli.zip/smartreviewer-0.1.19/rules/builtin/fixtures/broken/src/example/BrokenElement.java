package example;

/** B20: one element is damaged: the others are still compared, and the damaged one is reported as a limitation. */
final class BrokenElement {
    Object[] element(Integer a, Integer b) {
        return new Object[] {a, b +, a};
    }
}
