package example;

/** B17: two elements are left after the damage, fewer than minElements: the rule reports nothing; the file itself has a syntax error. */
final class BrokenTwo {
    Object[] two(Integer a, Integer b) {
        return new Object[] {a, a,, };
    }
}
