package example;

/** B18: a comma is missing, so the parser sees one element: the rule reports nothing; the file itself has a syntax error. */
final class BrokenNoComma {
    Object[] noComma(Integer a, Integer b) {
        return new Object[] {a b a};
    }
}
