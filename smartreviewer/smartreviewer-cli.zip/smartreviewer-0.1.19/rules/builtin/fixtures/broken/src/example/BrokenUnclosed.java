package example;

/** B19: the closing brace is missing: the parser makes no array initializer of it, the rule reports nothing; the file itself has a syntax error. */
final class BrokenUnclosed {
    Object[] unclosed(Integer a, Integer b) {
        return new Object[] {a, b, a;
    }
}
