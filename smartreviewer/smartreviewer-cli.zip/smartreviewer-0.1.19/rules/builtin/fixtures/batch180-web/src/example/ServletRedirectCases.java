package example;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * More cases of SR-WEB-EXEC-AFTER-REDIRECT-001 in a servlet: the servlet log, loop bodies, writes through a variable that holds the
 * writer of the response, assignments and the session. The method names are unique in this file, so that every suite case can select
 * one of them.
 */
class ServletRedirectCases extends HttpServlet {
    private ServletContext servletContext;
    private boolean done;

    private void doMore() { }

    // ------------------------------------------------------------------ the servlet log is logging, not code that runs

    void servletLogAfter(HttpServletResponse response) throws IOException {
        response.sendRedirect("/a");
        log("redirected");
    }

    void thisLogAfter(HttpServletResponse response) throws IOException {
        response.sendRedirect("/a");
        this.log("redirected", new IllegalStateException());
    }

    void contextLogAfter(HttpServletResponse response) throws IOException {
        response.sendRedirect("/a");
        getServletContext().log("redirected");
    }

    void fieldContextLogAfter(HttpServletResponse response) throws IOException {
        response.sendRedirect("/a");
        servletContext.log("redirected");
    }

    void configContextLogAfter(ServletConfig config, HttpServletResponse response) throws IOException {
        response.sendRedirect("/a");
        config.getServletContext().log("redirected");
    }

    void superLogAfter(HttpServletResponse response) throws IOException {
        response.sendRedirect("/a");
        super.log("redirected");
    }

    /** Logging first, then work: the work is what runs. */
    void logThenWork(HttpServletResponse response) throws IOException {
        response.sendRedirect("/a");
        log("redirected");
        doMore();
    }

    // ------------------------------------------------------------------ a loop body: the rest of the iteration runs

    void forEachThenMore(HttpServletResponse response, String[] urls) throws IOException {
        for (String url : urls) {
            response.sendRedirect(url);
            doMore();
        }
    }

    void forThenMore(HttpServletResponse response, String[] urls) throws IOException {
        for (int i = 0; i < urls.length; i++) {
            response.sendRedirect(urls[i]);
            doMore();
        }
    }

    void whileThenMore(HttpServletResponse response, String[] urls) throws IOException {
        int i = 0;
        while (i < urls.length) {
            response.sendRedirect(urls[i++]);
            doMore();
        }
    }

    void doWhileThenMore(HttpServletResponse response, String[] urls) throws IOException {
        int i = 0;
        do {
            response.sendRedirect(urls[i]);
            doMore();
        } while (++i < urls.length);
    }

    /** The redirect ends the body: the next iteration and what follows the loop are not followed. */
    void loopBodyEndsWithRedirect(HttpServletResponse response, String[] urls) throws IOException {
        for (String url : urls) {
            response.sendRedirect(url);
        }
        doMore();
    }

    // ------------------------------------------------------------------ a write through the writer of the response

    void writerVariableAfter(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        response.sendRedirect("/a");
        out.print("x");
    }

    void streamVariableAfter(HttpServletResponse response) throws IOException {
        ServletOutputStream out = response.getOutputStream();
        response.sendRedirect("/a");
        out.print("x");
    }

    void tryWithWriterAfter(HttpServletResponse response) throws IOException {
        try (PrintWriter out = response.getWriter()) {
            response.sendRedirect("/a");
            out.println("x");
        }
    }

    /** A writer of unknown origin is a call like any other. */
    void otherWriterAfter(HttpServletResponse response, PrintWriter file) throws IOException {
        response.sendRedirect("/a");
        file.print("x");
    }

    /** Closing the writer is clean-up. */
    void writerClosedAfter(HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        response.sendRedirect("/a");
        out.close();
    }

    // ------------------------------------------------------------------ an assignment is code, and so is the session

    void assignmentAfter(HttpServletResponse response) throws IOException {
        response.sendRedirect("/a");
        done = true;
    }

    void invalidateAfter(HttpServletResponse response, HttpSession session) throws IOException {
        response.sendRedirect("/login");
        session.invalidate();
    }

    /** The usual logout order: invalidate first, redirect last. */
    void invalidateBefore(HttpServletResponse response, HttpSession session) throws IOException {
        session.invalidate();
        response.sendRedirect("/login");
    }
}
