package javax.servlet;

public interface ServletConfig {
    ServletContext getServletContext();
}
