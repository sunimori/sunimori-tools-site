package example;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;
import javax.servlet.FilterChain;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

/**
 * Cases of SR-WEB-EXEC-AFTER-REDIRECT-001 (servlet API: the small stubs of this fixture project). The method names are unique in this
 * file, so that every suite case can select one of them.
 */
public class RedirectCases {
    private static final Logger LOG = Logger.getLogger("redirects");
    private int redirects;

    /** A project class that has a sendRedirect of its own. */
    static class Portal {
        void sendRedirect(String url) { }
    }

    private void count() {
        redirects++;
    }

    private void audit(String what) { }

    private boolean loggedIn(HttpServletRequest request) {
        return request.getSession(false) != null;
    }

    // ------------------------------------------------------------------ the code goes on after the redirect

    void filterMissingReturn(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        if (!loggedIn(request)) {
            response.sendRedirect("/login");
        }
        chain.doFilter(req, res);
    }

    void filterStraightThrough(HttpServletResponse response, ServletRequest req, FilterChain chain) throws IOException, ServletException {
        response.sendRedirect("/maintenance");
        chain.doFilter(req, response);
    }

    void doMoreAfterRedirect(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect("/done");
        count();
    }

    void nestedIfsFallThrough(HttpServletRequest request, HttpServletResponse response, boolean a, boolean b) throws IOException {
        if (a) {
            if (b) {
                response.sendRedirect("/b");
            }
        }
        audit("after");
    }

    void forwardThenWrite(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.getRequestDispatcher("/page.jsp").forward(request, response);
        PrintWriter out = response.getWriter();
        out.println("done");
    }

    void forwardThenChain(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        request.getRequestDispatcher("/denied.jsp").forward(request, response);
        chain.doFilter(request, response);
    }

    void redirectThenRedirect(HttpServletResponse response) throws IOException {
        response.sendRedirect("/a");
        response.sendRedirect("/b");
    }

    void redirectInTryThenChain(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {
            response.sendRedirect("/login");
        } catch (IOException e) {
            LOG.warning(e.toString());
        }
        chain.doFilter(request, response);
    }

    void redirectInCatchThenProcess(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            audit(request.getRequestURI());
        } catch (RuntimeException e) {
            response.sendRedirect("/error");
        }
        count();
    }

    void switchBreakThenChain(String action, HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        switch (action) {
            case "login":
                response.sendRedirect("/login");
                break;
            case "logout":
                audit("logout");
                break;
            default:
                break;
        }
        chain.doFilter(request, response);
    }

    void elseBranchRedirects(HttpServletRequest request, HttpServletResponse response, boolean ok) throws IOException {
        if (ok) {
            count();
        } else {
            response.sendRedirect("/denied");
        }
        audit("finished");
    }

    void wrapperRedirects(HttpServletResponseWrapper wrapper) throws IOException {
        wrapper.sendRedirect("/w");
        count();
    }

    void dispatcherVariable(RequestDispatcher dispatcher, ServletRequest request, ServletResponse response) throws IOException, ServletException {
        dispatcher.forward(request, response);
        count();
    }

    void redirectInSynchronized(HttpServletResponse response) throws IOException {
        synchronized (this) {
            response.sendRedirect("/s");
        }
        count();
    }

    void loggedThenChain(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        response.sendRedirect("/login");
        LOG.info("redirected");
        chain.doFilter(request, response);
    }

    void switchCaseFallsThrough(int mode, HttpServletResponse response) throws IOException {
        switch (mode) {
            case 1:
                response.sendRedirect("/one");
            case 2:
                count();
                break;
            default:
                break;
        }
    }

    // ------------------------------------------------------------------ nothing runs after the redirect

    void returnAfterRedirect(HttpServletResponse response) throws IOException {
        response.sendRedirect("/x");
        return;
    }

    void throwAfterRedirect(HttpServletResponse response) throws IOException, ServletException {
        response.sendRedirect("/x");
        throw new ServletException("redirected");
    }

    void lastStatement(HttpServletResponse response) throws IOException {
        count();
        response.sendRedirect("/x");
    }

    void redirectOrChain(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (!loggedIn(request)) {
            response.sendRedirect("/login");
        } else {
            chain.doFilter(request, response);
        }
    }

    void guardWithReturn(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (!loggedIn(request)) {
            response.sendRedirect("/login");
            return;
        }
        chain.doFilter(request, response);
    }

    void everyPathLeaves(HttpServletRequest request, HttpServletResponse response, FilterChain chain, boolean ajax) throws IOException, ServletException {
        if (!loggedIn(request)) {
            response.sendRedirect("/login");
            if (ajax) {
                return;
            } else {
                return;
            }
        }
        chain.doFilter(request, response);
    }

    void onlyLoggingAfter(HttpServletResponse response) throws IOException {
        response.sendRedirect("/x");
        LOG.info("redirected to /x");
        System.out.println("redirected");
    }

    void cleanUpAfter(HttpServletResponse response, PrintWriter out) throws IOException {
        response.sendRedirect("/x");
        out.flush();
        out.close();
        response.flushBuffer();
    }

    void guardOnlyAfter(HttpServletResponse response, boolean done) throws IOException {
        response.sendRedirect("/x");
        if (done) {
            return;
        }
    }

    void finallyIsCleanUp(HttpServletResponse response) throws IOException {
        try {
            response.sendRedirect("/x");
        } finally {
            audit("done");
        }
    }

    void returnInTryWithFinally(HttpServletResponse response) throws IOException {
        try {
            response.sendRedirect("/x");
            return;
        } finally {
            audit("done");
        }
    }

    void insideLambda(HttpServletResponse response) {
        Runnable later = () -> {
            try {
                response.sendRedirect("/x");
                count();
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        };
        later.run();
    }

    void insideLoop(HttpServletResponse response, String[] urls) throws IOException {
        for (String url : urls) {
            if (url.startsWith("/")) {
                response.sendRedirect(url);
            }
        }
    }

    String returnsAForward(HttpServletResponse response) throws IOException {
        response.sendRedirect("/x");
        return "redirected";
    }

    void switchReturns(int mode, HttpServletResponse response) throws IOException {
        switch (mode) {
            case 1:
                response.sendRedirect("/one");
                return;
            default:
                count();
        }
    }

    void projectClassRedirect(Portal portal) {
        portal.sendRedirect("/x");
        count();
    }

    void helperRedirects(HttpServletResponse response, FilterChain chain, ServletRequest request) throws IOException, ServletException {
        redirectTo(response, "/login");
        chain.doFilter(request, response);
    }

    private void redirectTo(HttpServletResponse response, String url) throws IOException {
        response.sendRedirect(url);
    }

    // ------------------------------------------------------------------ boundaries

    void tryFinallyThenChain(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {
            response.sendRedirect("/login");
        } finally {
            audit("redirected");
        }
        chain.doFilter(request, response);
    }

    void redirectInFinally(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            audit("x");
        } finally {
            response.sendRedirect("/x");
        }
        count();
    }

    void arrowSwitchThenCode(int mode, HttpServletResponse response) throws IOException {
        switch (mode) {
            case 1 -> response.sendRedirect("/one");
            default -> count();
        }
        audit("after the switch");
    }
}
