package jakarta.servlet;

public class ServletException extends Exception {
    public ServletException(String message) { super(message); }
}
