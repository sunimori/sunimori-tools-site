package jakarta.servlet;

public abstract class ServletOutputStream extends java.io.OutputStream {
    public void print(String s) throws java.io.IOException { }
}
