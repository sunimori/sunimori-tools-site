package javax.servlet.http;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletRequest;

public interface HttpServletRequest extends ServletRequest {
    RequestDispatcher getRequestDispatcher(String path);
    HttpSession getSession(boolean create);
    String getRequestURI();
}
