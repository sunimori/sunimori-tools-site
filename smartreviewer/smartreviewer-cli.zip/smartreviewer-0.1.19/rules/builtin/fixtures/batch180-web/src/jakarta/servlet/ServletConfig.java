package jakarta.servlet;

public interface ServletConfig {
    ServletContext getServletContext();
}
