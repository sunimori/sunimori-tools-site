package example;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Redirects nested deeply: the flow after the call is followed up to the end of the method, however many levels it takes (an else-if
 * ladder of thirty branches is thirty levels). The method names are unique in this file, so that every suite case can select one of them.
 */
class DeepRedirectCases {
    void doMore() { }

    /** An else-if ladder of thirty branches that each redirect, and code after the ladder: every branch is reported. */
    void ladderOfThirty(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String action = request.getParameter("action");
        if ("a1".equals(action)) {
            response.sendRedirect("/n1");
        } else if ("a2".equals(action)) {
            response.sendRedirect("/n2");
        } else if ("a3".equals(action)) {
            response.sendRedirect("/n3");
        } else if ("a4".equals(action)) {
            response.sendRedirect("/n4");
        } else if ("a5".equals(action)) {
            response.sendRedirect("/n5");
        } else if ("a6".equals(action)) {
            response.sendRedirect("/n6");
        } else if ("a7".equals(action)) {
            response.sendRedirect("/n7");
        } else if ("a8".equals(action)) {
            response.sendRedirect("/n8");
        } else if ("a9".equals(action)) {
            response.sendRedirect("/n9");
        } else if ("a10".equals(action)) {
            response.sendRedirect("/n10");
        } else if ("a11".equals(action)) {
            response.sendRedirect("/n11");
        } else if ("a12".equals(action)) {
            response.sendRedirect("/n12");
        } else if ("a13".equals(action)) {
            response.sendRedirect("/n13");
        } else if ("a14".equals(action)) {
            response.sendRedirect("/n14");
        } else if ("a15".equals(action)) {
            response.sendRedirect("/n15");
        } else if ("a16".equals(action)) {
            response.sendRedirect("/n16");
        } else if ("a17".equals(action)) {
            response.sendRedirect("/n17");
        } else if ("a18".equals(action)) {
            response.sendRedirect("/n18");
        } else if ("a19".equals(action)) {
            response.sendRedirect("/n19");
        } else if ("a20".equals(action)) {
            response.sendRedirect("/n20");
        } else if ("a21".equals(action)) {
            response.sendRedirect("/n21");
        } else if ("a22".equals(action)) {
            response.sendRedirect("/n22");
        } else if ("a23".equals(action)) {
            response.sendRedirect("/n23");
        } else if ("a24".equals(action)) {
            response.sendRedirect("/n24");
        } else if ("a25".equals(action)) {
            response.sendRedirect("/n25");
        } else if ("a26".equals(action)) {
            response.sendRedirect("/n26");
        } else if ("a27".equals(action)) {
            response.sendRedirect("/n27");
        } else if ("a28".equals(action)) {
            response.sendRedirect("/n28");
        } else if ("a29".equals(action)) {
            response.sendRedirect("/n29");
        } else if ("a30".equals(action)) {
            response.sendRedirect("/n30");
        }
        doMore();
    }

    /** Twenty nested ifs around the redirect and code after the outermost one: reported. */
    void twentyNestedIfs(HttpServletResponse response, boolean b) throws IOException {
        if (b) {
            if (b) {
                if (b) {
                    if (b) {
                        if (b) {
                            if (b) {
                                if (b) {
                                    if (b) {
                                        if (b) {
                                            if (b) {
                                                if (b) {
                                                    if (b) {
                                                        if (b) {
                                                            if (b) {
                                                                if (b) {
                                                                    if (b) {
                                                                        if (b) {
                                                                            if (b) {
                                                                                if (b) {
                                                                                    if (b) {
                                                                                        response.sendRedirect("/deep");
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        doMore();
    }

    /** Twenty nested blocks around the redirect and code after the outermost one: reported. */
    void twentyNestedBlocks(HttpServletResponse response, boolean b) throws IOException {
        {
            {
                {
                    {
                        {
                            {
                                {
                                    {
                                        {
                                            {
                                                {
                                                    {
                                                        {
                                                            {
                                                                {
                                                                    {
                                                                        {
                                                                            {
                                                                                {
                                                                                    {
                                                                                        response.sendRedirect("/deep");
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        doMore();
    }

    /** Twenty nested try statements around the redirect and code after the outermost one: reported. */
    void twentyNestedTries(HttpServletResponse response, boolean b) throws IOException {
        try {
            try {
                try {
                    try {
                        try {
                            try {
                                try {
                                    try {
                                        try {
                                            try {
                                                try {
                                                    try {
                                                        try {
                                                            try {
                                                                try {
                                                                    try {
                                                                        try {
                                                                            try {
                                                                                try {
                                                                                    try {
                                                                                        response.sendRedirect("/deep");
                                                                                    } catch (IllegalStateException e) {
                                                                                        throw e;
                                                                                    }
                                                                                } catch (IllegalStateException e) {
                                                                                    throw e;
                                                                                }
                                                                            } catch (IllegalStateException e) {
                                                                                throw e;
                                                                            }
                                                                        } catch (IllegalStateException e) {
                                                                            throw e;
                                                                        }
                                                                    } catch (IllegalStateException e) {
                                                                        throw e;
                                                                    }
                                                                } catch (IllegalStateException e) {
                                                                    throw e;
                                                                }
                                                            } catch (IllegalStateException e) {
                                                                throw e;
                                                            }
                                                        } catch (IllegalStateException e) {
                                                            throw e;
                                                        }
                                                    } catch (IllegalStateException e) {
                                                        throw e;
                                                    }
                                                } catch (IllegalStateException e) {
                                                    throw e;
                                                }
                                            } catch (IllegalStateException e) {
                                                throw e;
                                            }
                                        } catch (IllegalStateException e) {
                                            throw e;
                                        }
                                    } catch (IllegalStateException e) {
                                        throw e;
                                    }
                                } catch (IllegalStateException e) {
                                    throw e;
                                }
                            } catch (IllegalStateException e) {
                                throw e;
                            }
                        } catch (IllegalStateException e) {
                            throw e;
                        }
                    } catch (IllegalStateException e) {
                        throw e;
                    }
                } catch (IllegalStateException e) {
                    throw e;
                }
            } catch (IllegalStateException e) {
                throw e;
            }
        } catch (IllegalStateException e) {
            throw e;
        }
        doMore();
    }

    /** Twenty nested ifs, but the method returns after them: nothing runs after the redirect. */
    void twentyNestedIfsThenReturn(HttpServletResponse response, boolean b) throws IOException {
        if (b) {
            if (b) {
                if (b) {
                    if (b) {
                        if (b) {
                            if (b) {
                                if (b) {
                                    if (b) {
                                        if (b) {
                                            if (b) {
                                                if (b) {
                                                    if (b) {
                                                        if (b) {
                                                            if (b) {
                                                                if (b) {
                                                                    if (b) {
                                                                        if (b) {
                                                                            if (b) {
                                                                                if (b) {
                                                                                    if (b) {
                                                                                        response.sendRedirect("/deep");
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return;
    }

}
