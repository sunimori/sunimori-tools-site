package javax.servlet;

public interface ServletContext {
    void log(String message);
    void log(String message, Throwable cause);
}
