package javax.servlet;

public abstract class GenericServlet implements ServletConfig {
    public ServletContext getServletContext() {
        return null;
    }

    public void log(String message) { }

    public void log(String message, Throwable cause) { }
}
