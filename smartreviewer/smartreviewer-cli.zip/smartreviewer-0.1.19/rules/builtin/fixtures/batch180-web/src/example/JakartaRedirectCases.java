package example;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;
import jakarta.servlet.FilterChain;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;

/**
 * Cases of SR-WEB-EXEC-AFTER-REDIRECT-001 (servlet API: the small stubs of this fixture project). The method names are unique in this
 * file, so that every suite case can select one of them.
 */
public class JakartaRedirectCases {
    private static final Logger LOG = Logger.getLogger("redirects");
    private int redirects;

    /** A project class that has a sendRedirect of its own. */
    static class Portal {
        void sendRedirect(String url) { }
    }

    private void count() {
        redirects++;
    }

    private void audit(String what) { }

    private boolean loggedIn(HttpServletRequest request) {
        return request.getSession(false) != null;
    }

    // ------------------------------------------------------------------ jakarta.servlet: the same

    void filterMissingReturn(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        if (!loggedIn(request)) {
            response.sendRedirect("/login");
        }
        chain.doFilter(req, res);
    }

    void filterStraightThrough(HttpServletResponse response, ServletRequest req, FilterChain chain) throws IOException, ServletException {
        response.sendRedirect("/maintenance");
        chain.doFilter(req, response);
    }

    void forwardThenWrite(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        request.getRequestDispatcher("/page.jsp").forward(request, response);
        PrintWriter out = response.getWriter();
        out.println("done");
    }

    void returnAfterRedirect(HttpServletResponse response) throws IOException {
        response.sendRedirect("/x");
        return;
    }

    void throwAfterRedirect(HttpServletResponse response) throws IOException, ServletException {
        response.sendRedirect("/x");
        throw new ServletException("redirected");
    }

    void guardWithReturn(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (!loggedIn(request)) {
            response.sendRedirect("/login");
            return;
        }
        chain.doFilter(request, response);
    }

}

