package jakarta.servlet.http;

import java.io.IOException;
import java.io.PrintWriter;

public class HttpServletResponseWrapper implements HttpServletResponse {
    @Override public void sendRedirect(String location) throws IOException { }
    @Override public void sendError(int status) throws IOException { }
    @Override public void setStatus(int status) { }
    @Override public PrintWriter getWriter() throws IOException { return null; }
    @Override public void flushBuffer() throws IOException { }
    @Override public boolean isCommitted() { return false; }
}
