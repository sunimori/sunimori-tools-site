package jakarta.servlet.http;

public abstract class HttpServlet extends jakarta.servlet.GenericServlet { }
