package javax.servlet.http;

import java.io.IOException;
import javax.servlet.ServletResponse;

public interface HttpServletResponse extends ServletResponse {
    void sendRedirect(String location) throws IOException;
    void sendError(int status) throws IOException;
    void setStatus(int status);
}
