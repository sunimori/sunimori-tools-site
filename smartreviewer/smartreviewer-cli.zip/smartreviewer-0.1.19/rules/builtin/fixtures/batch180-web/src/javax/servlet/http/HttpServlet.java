package javax.servlet.http;

public abstract class HttpServlet extends javax.servlet.GenericServlet { }
