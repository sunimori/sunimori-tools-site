package jakarta.servlet.http;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletRequest;

public interface HttpServletRequest extends ServletRequest {
    RequestDispatcher getRequestDispatcher(String path);
    HttpSession getSession(boolean create);
    String getRequestURI();
}
