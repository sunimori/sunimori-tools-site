package example;

import java.io.File;
import java.nio.file.FileSystems;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Replacement strings that Matcher.appendReplacement rejects (SR-JAVA-REGEX-REPLACEMENT-001), and the ones it accepts. */
public class ReplacementCases {
    static final String BACKSLASH = "\\";
    static final String CURRENCY = "US" + "$";
    static final Pattern WORD = Pattern.compile("(\\w+)");
    static final String SEPARATOR = File.separator;

    // ----- illegal: the exception comes as soon as the regex matches

    /** The classic: a single backslash is an escape character with nothing to escape. */
    String slashesToBackslashes(String path) {
        return path.replaceAll("/", "\\");
    }

    /** The call over several lines is shown on one line. */
    String callOverSeveralLines(String path) {
        return path
                .replaceAll(
                        "/", "\\");
    }

    /** A text block is shown as three quotes around an ellipsis; its dollar sign is followed by the line end. */
    String replacementAsATextBlock(String text) {
        return text.replaceAll("a", """
                price: 5$
                """);
    }

    /** A dollar sign that is no group reference. */
    String dollarAtTheEnd(String price) {
        return price.replaceFirst("USD", "$");
    }

    String dollarBeforeALetter(String text) {
        return text.replaceAll("dollars", "US$x");
    }

    /** The regex has no group 1. */
    String groupTheRegexLacks(String text) {
        return text.replaceAll("[0-9]+", "<$1>");
    }

    /** The regex has no group named name. */
    String nameTheRegexLacks(String template) {
        return template.replaceAll("\\{name\\}", "${name}");
    }

    String unclosedGroupName(String text) {
        return text.replaceAll("a", "${a");
    }

    String constantReplacement(String path) {
        return path.replaceAll("/", BACKSLASH);
    }

    String concatenatedConstant(String text) {
        return text.replaceAll("dollars", CURRENCY);
    }

    String finalLocal(String path) {
        final String separator = "\\";
        return path.replaceAll("/", separator);
    }

    String localThatNothingChanges(String path) {
        String separator = "\\" + "";
        return path.replaceAll("/", separator);
    }

    String matcherReplaceAll(String text) {
        return Pattern.compile("(a)").matcher(text).replaceAll("$2");
    }

    String groupOfAFieldPattern(String text) {
        return WORD.matcher(text).replaceAll("[$2]");
    }

    String appendReplacementLoop(String text) {
        Matcher matcher = Pattern.compile("a").matcher(text);
        StringBuilder out = new StringBuilder();
        while (matcher.find()) {
            matcher.appendReplacement(out, "x\\");
        }
        return matcher.appendTail(out).toString();
    }

    /** Both arguments are wrong: the regex (SR-JAVA-REGEX-LITERAL-001) and the replacement (this rule) each get a finding. */
    String bothArguments(String text) {
        return text.replaceAll("*", "\\");
    }

    String insideALambda(List<String> paths) {
        return paths.stream().map(p -> p.replaceAll("/", "\\")).findFirst().orElse("");
    }

    // ----- legal

    String escapedBackslash(String path) {
        return path.replaceAll("/", "\\\\");
    }

    String quotedReplacement(String path) {
        return path.replaceAll("/", Matcher.quoteReplacement("\\"));
    }

    String groupReferences(String text) {
        return text.replaceAll("(a)(b)", "$2$1");
    }

    String wholeMatch(String text) {
        return text.replaceAll("a", "[$0]");
    }

    String escapedDollar(String price) {
        return price.replaceAll("USD", "\\$");
    }

    String replacementFromTheCaller(String path, String replacement) {
        return path.replaceAll("/", replacement);
    }

    String plainTextReplace(String path) {
        return path.replace("/", "\\");
    }

    /** With one group $10 is group 1 followed by the character 0. */
    String groupFollowedByDigit(String text) {
        return text.replaceAll("(a)", "[$10]");
    }

    String namedGroupThatExists(String text) {
        return text.replaceAll("(?<year>[0-9]{4})", "${year}年");
    }

    /** The regex is computed, so what it has for groups is not known. */
    String groupOfAComputedRegex(String text, String regex) {
        return text.replaceAll(regex, "$1");
    }

    /** Not a constant: File.separator is a backslash on Windows, so this fails there and works on Linux and macOS. */
    String platformSeparator(String path) {
        return path.replaceAll("/", File.separator);
    }

    String platformSeparatorQuoted(String path) {
        return path.replaceAll("/", Matcher.quoteReplacement(File.separator));
    }

    String platformSeparatorFirst(String path) {
        return path.replaceFirst("/", File.separator);
    }

    String platformSeparatorAppend(String text) {
        Matcher matcher = Pattern.compile("/").matcher(text);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            matcher.appendReplacement(out, File.separator);
        }
        return matcher.appendTail(out).toString();
    }

    String platformSeparatorFromAField(String path) {
        return path.replaceAll("/", SEPARATOR);
    }

    String platformSeparatorInAFinalLocal(String path) {
        final String separator = File.separator;
        return path.replaceAll("/", separator);
    }

    String platformSeparatorOfTheFileSystem(String path) {
        return path.replaceAll("/", FileSystems.getDefault().getSeparator());
    }

    String platformSeparatorProperty(String path) {
        return path.replaceAll("/", System.getProperty("file.separator"));
    }

    String platformSeparatorAtTheEnd(String path) {
        return path.replaceAll("/", "dir" + File.separator);
    }

    /** The separator in front of a letter is an escaped letter: legal on both platforms. */
    String platformSeparatorBeforeText(String path) {
        return path.replaceAll("/", File.separator + "dir");
    }

    String pathSeparator(String path) {
        return path.replaceAll(",", File.pathSeparator);
    }

    String localThatIsChanged(String path, boolean windows) {
        String separator = "\\";
        if (!windows) {
            separator = "/";
        }
        return path.replaceAll("/", separator);
    }

    String replacementFunction(String text) {
        return Pattern.compile("a").matcher(text).replaceAll(match -> "$");
    }
}
