package example;

import com.example.missing.Formatter;

/** The receiver's type is not on the class path: the rule cannot tell what replaceAll is. */
public class UnresolvedReceiver {
    String format(Formatter formatter) {
        return formatter.replaceAll("/", "\\");
    }

    String harmless(Formatter formatter) {
        return formatter.replaceAll("/", "-");
    }
}
