package example;

import java.util.List;

/** The main of this class takes an int: it is no entry point, and the loop is reported. */
final class CounterJob {
    private OrderDao orderDao;

    static void main(int rounds) {
    }

    void countAll(List<Long> ids) {
        for (Long id : ids) {
            orderDao.updateStatus(id, "COUNTED");
        }
    }
}
