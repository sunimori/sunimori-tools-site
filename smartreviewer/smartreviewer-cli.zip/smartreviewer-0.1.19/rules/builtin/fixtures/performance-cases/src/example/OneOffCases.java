package example;

import java.util.List;

/**
 * Cases for SR-PERF-QUERY-IN-LOOP-001 in one-off code: installer, migration and upgrade classes, and one class that is none of them.
 * Every class does the same thing: one update per id of a list that the caller hands in. (The classes with a main method are in
 * PriceTool.java, VarargsTool.java and CounterJob.java: the rule tests of a method see no other method of the file.)
 */
final class OneOffCases {
    private OneOffCases() {
    }
}

/** No main and no telling word in the name: the loop is reported as ever. */
final class OrderImporter {
    private OrderDao orderDao;

    void importAll(List<Long> ids) {
        for (Long id : ids) {
            orderDao.updateStatus(id, "IMPORTED");
        }
    }
}

/** N: migration code runs once per release. */
final class OrderMigration {
    private OrderDao orderDao;

    void migrateAll(List<Long> ids) {
        for (Long id : ids) {
            orderDao.updateStatus(id, "MIGRATED");
        }
    }
}

/** N: an installer runs once per installation. */
final class StockInstaller {
    private OrderDao orderDao;

    void installAll(List<Long> ids) {
        for (Long id : ids) {
            orderDao.updateStatus(id, "INSTALLED");
        }
    }
}

/** A business class with one of the words in its name is excused as well (by default; the parameter lists the words). */
final class MembershipUpgradeService {
    private OrderDao orderDao;

    void upgradeAll(List<Long> ids) {
        for (Long id : ids) {
            orderDao.updateStatus(id, "UPGRADED");
        }
    }
}
