package example;

import java.util.List;

/** A command-line tool: it runs once, and so does every loop in it. */
final class PriceTool {
    private OrderDao orderDao;

    public static void main(String[] args) {
        new PriceTool().closeAll(List.of(1L, 2L, 3L));
    }

    /** N: the loop of the class that declares main. */
    void closeAll(List<Long> ids) {
        for (Long id : ids) {
            orderDao.updateStatus(id, "CLOSED");
        }
    }

    /** N: a class inside the program counts with it. */
    static final class Worker {
        private OrderDao orderDao;

        void runAll(List<Long> ids) {
            for (Long id : ids) {
                orderDao.updateStatus(id, "DONE");
            }
        }
    }
}
