package example;

import java.util.List;

/** A main that takes its arguments as varargs is an entry point too, and a main with another parameter is not. */
final class VarargsTool {
    private OrderDao orderDao;

    public static void main(String... args) {
    }

    void touchAll(List<Long> ids) {
        for (Long id : ids) {
            orderDao.updateStatus(id, "TOUCHED");
        }
    }
}
