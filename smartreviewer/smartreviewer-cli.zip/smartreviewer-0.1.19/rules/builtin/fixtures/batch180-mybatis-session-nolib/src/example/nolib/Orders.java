package example.nolib;

import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public class Orders {
    private SqlSessionFactory factory;

    /** MyBatis is not among the project's types: the rule reads the names. */
    public void insertWithoutCommit(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.insert("example.Orders.add", order);
        }
    }

    public void batchWithoutCommit(Object order) {
        try (SqlSession session = factory.openSession(ExecutorType.BATCH)) {
            session.update("example.Orders.change", order);
        }
    }

    public void committed(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.insert("example.Orders.add", order);
            session.commit();
        }
    }

    public void autoCommit(Object order) {
        try (SqlSession session = factory.openSession(true)) {
            session.insert("example.Orders.add", order);
        }
    }

    public void unknownFactory(Object order) {
        try (SqlSession session = other.openSession()) {
            session.insert("example.Orders.add", order);
        }
    }

    private Object other;
}
