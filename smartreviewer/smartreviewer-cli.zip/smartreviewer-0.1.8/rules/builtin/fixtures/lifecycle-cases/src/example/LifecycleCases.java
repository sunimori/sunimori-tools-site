package example;
import java.util.*;
import java.util.stream.*;
import java.util.concurrent.locks.*;
import jakarta.servlet.http.HttpServletRequest;
public class LifecycleCases {
    final Lock lock = new ReentrantLock();
    final Lock other = new ReentrantLock();
    final ReentrantLock reentrant = new ReentrantLock();
    final ReadWriteLock rw = new ReentrantReadWriteLock();
    final ThreadLocal<String> local = new ThreadLocal<>();
    void work() { }
    void loggedInterrupt() { try { Thread.sleep(1); } catch (InterruptedException e) { System.out.println(e); } }
    void restoredInterrupt() { try { Thread.sleep(1); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }
    void conditionalInterrupt(boolean flag) { try { Thread.sleep(1); } catch (InterruptedException e) { if (flag) Thread.currentThread().interrupt(); } }
    void rethrownInterrupt() throws InterruptedException { try { Thread.sleep(1); } catch (InterruptedException e) { throw e; } }
    void finallyInterrupt() { try { Thread.sleep(1); } catch (InterruptedException e) { try { return; } finally { Thread.currentThread().interrupt(); } } }
    void badLock() { lock.lock(); work(); lock.unlock(); }
    void goodLock() { lock.lock(); try { work(); } finally { lock.unlock(); } }
    void earlyLock(boolean flag) { lock.lock(); if(flag) return; lock.unlock(); }
    void goodTryLock() { if(lock.tryLock()) { try { work(); } finally { lock.unlock(); } } }
    void goodGuardLock() { if(!lock.tryLock()) return; try { work(); } finally { lock.unlock(); } }
    void wrongLock() { lock.lock(); try { work(); } finally { other.unlock(); } }
    void lateUnlock() { lock.lock(); try { work(); } finally { work(); lock.unlock(); } }
    void readWriteLock() { rw.writeLock().lock(); try { work(); } finally { rw.writeLock().unlock(); } }
    void wrongReadWriteLock() { rw.writeLock().lock(); try { work(); } finally { rw.readLock().unlock(); } }
    boolean storedTryLock() { boolean locked = lock.tryLock(); if (!locked) return false; try { work(); return true; } finally { lock.unlock(); } }
    void guardedUnlock() { boolean locked = false; try { locked = lock.tryLock(); if (!locked) return; work(); } finally { if (locked) lock.unlock(); } }
    void heldUnlock() { reentrant.lock(); try { work(); } finally { if (reentrant.isHeldByCurrentThread()) reentrant.unlock(); } }
    void fixedAdd() { List<String> a = Arrays.asList("a"); List<String> b = a; b.add("b"); }
    void copiedAdd() { List<String> a = new ArrayList<>(Arrays.asList("a")); a.add("b"); }
    void fixedSet() { List<String> a = Arrays.asList("a"); a.set(0,"b"); }
    void reassignedAdd() { List<String> a = Arrays.asList("a"); a = new ArrayList<>(); a.add("b"); }
    void reusedStream() { Stream<String> a = Stream.of("a"); Stream<String> b = a; a.count(); b.findFirst(); }
    void freshStream() { Stream<String> a = Stream.of("a"); a.count(); a = Stream.of("b"); a.count(); }
    void branchStream(boolean flag) { Stream<String> a = Stream.of("a"); if(flag) a.count(); else a.findFirst(); }
    void earlyStream(boolean flag) { Stream<String> a = Stream.of("a"); if(flag) { a.count(); return; } a.findFirst(); }
    void chainedStream() { Stream<String> a = Stream.of("a"); Stream<String> b = a.filter(x -> true); b.count(); a.findFirst(); }
    void requestLocal(HttpServletRequest request) { local.set(request.getParameter("user")); work(); }
    void cleanedLocal(HttpServletRequest request) { try { local.set(request.getParameter("user")); work(); } finally { local.remove(); } }
    void persistentLocal() { local.set("process context"); }
    void lateLocal(HttpServletRequest request) { local.set(request.getParameter("user")); work(); local.remove(); }
}
