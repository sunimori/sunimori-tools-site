package javax.faces.bean;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** Stub (fixture only). */
@Retention(RetentionPolicy.RUNTIME)
public @interface ManagedProperty {
    String value();
}
