package javax.servlet;

import java.util.Map;

/** Stub (fixture only). */
public interface ServletRequest {
    String getParameter(String name);

    String[] getParameterValues(String name);

    Map<String, String[]> getParameterMap();

    Object getAttribute(String name);

    void setAttribute(String name, Object value);

    RequestDispatcher getRequestDispatcher(String path);
}
