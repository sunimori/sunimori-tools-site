package jakarta.servlet;

/** Stub (fixture only). */
public class ServletException extends Exception {
}
