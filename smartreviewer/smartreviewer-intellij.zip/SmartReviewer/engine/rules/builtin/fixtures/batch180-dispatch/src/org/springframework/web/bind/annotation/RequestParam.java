package org.springframework.web.bind.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** Stub (fixture only). */
@Retention(RetentionPolicy.RUNTIME)
public @interface RequestParam {
    String value() default "";

    String name() default "";
}
