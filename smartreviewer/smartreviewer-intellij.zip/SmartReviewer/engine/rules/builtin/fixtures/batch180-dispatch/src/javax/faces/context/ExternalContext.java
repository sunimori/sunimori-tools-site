package javax.faces.context;

import java.io.IOException;
import java.util.Map;

/** Stub (fixture only). */
public abstract class ExternalContext {
    public abstract Map<String, String> getRequestParameterMap();

    public abstract void dispatch(String path) throws IOException;

    public abstract void redirect(String url) throws IOException;
}
