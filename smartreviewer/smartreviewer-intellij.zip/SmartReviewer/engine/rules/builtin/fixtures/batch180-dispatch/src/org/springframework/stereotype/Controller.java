package org.springframework.stereotype;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** Stub (fixture only). */
@Retention(RetentionPolicy.RUNTIME)
public @interface Controller {
}
