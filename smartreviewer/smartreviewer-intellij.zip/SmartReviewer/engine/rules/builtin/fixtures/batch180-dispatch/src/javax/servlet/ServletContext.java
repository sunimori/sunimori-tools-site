package javax.servlet;

/** Stub (fixture only). */
public interface ServletContext {
    RequestDispatcher getRequestDispatcher(String path);

    RequestDispatcher getNamedDispatcher(String name);

    String getRealPath(String path);
}
