package example;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Forms written while hunting for defects of SR-SEC-DISPATCH-001 (checks, defaults, loops and helpers). The expected result of each method is a case of its suite.
 */
public class ProbeDispatchB extends HttpServlet {
    static final Set<String> VIEWS = Set.of("a", "b");
    static final String BASE = "/WEB-INF/views/";
    static final Map<String, String> BY_ROLE = Map.of("admin", "/admin.jsp", "user", "/user.jsp");
    HttpServletRequest request;

    void log(String s) {
    }

    void validatePage(String p) {
        if (!VIEWS.contains(p)) {
            throw new IllegalArgumentException(p);
        }
    }

    void q01(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (VIEWS.contains(p)) {
            log(p);
        }
        rq.getRequestDispatcher("/v/" + p).forward(rq, rs);
    }

    void q02(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (!VIEWS.contains(p)) {
            p = "a";
        }
        rq.getRequestDispatcher("/v/" + p).forward(rq, rs);
    }

    void q03() throws ServletException, IOException {
        request.getRequestDispatcher("/v/" + request.getParameter("p")).forward(request, null);
    }

    void q04(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(BASE + "list.jsp").forward(rq, rs);
    }

    void q05(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String[] paths = rq.getParameterValues("p");
        rq.getRequestDispatcher(paths[0]).forward(rq, rs);
    }

    void q06(HttpServletRequest rq, HttpServletResponse rs) {
        Arrays.stream(rq.getParameterValues("p")).forEach(x -> {
            try {
                rq.getRequestDispatcher(x).include(rq, rs);
            } catch (ServletException | IOException e) {
                throw new IllegalStateException(e);
            }
        });
    }

    void q07(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = "a";
        for (int i = 0; i < 3; i++) {
            p = "b";
        }
        rq.getRequestDispatcher("/v/" + p).forward(rq, rs);
    }

    void q08(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p;
        try {
            p = rq.getParameter("p");
        } finally {
            log("done");
        }
        rq.getRequestDispatcher(p).forward(rq, rs);
    }

    void q09(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String role = (String) rq.getAttribute("role");
        rq.getRequestDispatcher(BY_ROLE.get(role)).forward(rq, rs);
    }

    void q10(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p == null || p.isEmpty()) {
            p = "index";
        }
        rq.getRequestDispatcher("/" + p).forward(rq, rs);
    }

    void q11(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher("/" + Objects.requireNonNullElse(rq.getParameter("p"), "index")).forward(rq, rs);
    }

    void q12(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        validatePage(p);
        rq.getRequestDispatcher("/v/" + p).forward(rq, rs);
    }

    void q13(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        switch (p) {
            case "a", "b" -> rq.getRequestDispatcher("/v/" + p).forward(rq, rs);
            default -> rs.sendRedirect("/error");
        }
    }

    void q14(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (!"a".equals(p) && !"b".equals(p)) {
            rs.sendRedirect("/error");
            return;
        }
        rq.getRequestDispatcher("/v/" + p).forward(rq, rs);
    }

    void q15(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if ("a".equals(p) || "b".equals(p)) {
            log("known");
        }
        rq.getRequestDispatcher("/v/" + p).forward(rq, rs);
    }
}
