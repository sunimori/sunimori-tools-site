package javax.servlet;

/** Stub (fixture only). */
public class ServletException extends Exception {
}
