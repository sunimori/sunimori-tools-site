package example;

import java.io.IOException;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * Forms written while hunting for defects of SR-SEC-DISPATCH-001 (servlet and Spring forms). The expected result of each method is a case of its suite.
 */
public class ProbeDispatchA extends HttpServlet {
    static final Set<String> VIEWS = Set.of("a", "b");
    static final String FORWARD = "forward:";
    String target;

    void p01(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(rq.getParameter("p").trim()).forward(rq, rs);
    }

    void p02(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p != null && !p.equals("")) {
            rq.getRequestDispatcher(p).forward(rq, rs);
        }
    }

    void p03(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p.endsWith(".jsp")) {
            rq.getRequestDispatcher("/WEB-INF/" + p).forward(rq, rs);
        }
    }

    void p04(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = Optional.ofNullable(rq.getParameter("p")).orElse("home");
        rq.getRequestDispatcher("/v/" + p).forward(rq, rs);
    }

    void p05(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String v = switch (rq.getParameter("p")) {
            case "a" -> "/a.jsp";
            case "b" -> "/b.jsp";
            default -> "/err.jsp";
        };
        rq.getRequestDispatcher(v).forward(rq, rs);
    }

    void p06(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String page = rq.getParameter("p");
        rq.getRequestDispatcher("""
                /WEB-INF/%s.jsp""".formatted(page)).forward(rq, rs);
    }

    void p07(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(String.join("/", "/WEB-INF", rq.getParameter("p"))).forward(rq, rs);
    }

    void p08(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(viewPath(rq.getParameter("p"))).forward(rq, rs);
    }

    static String viewPath(String p) {
        return "/WEB-INF/" + p;
    }

    void p09(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(sanitizeView(rq.getParameter("p"))).forward(rq, rs);
    }

    static String sanitizeView(String p) {
        return VIEWS.contains(p) ? p : "a";
    }

    void p10(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        this.target = rq.getParameter("p");
        rq.getRequestDispatcher(target).forward(rq, rs);
    }

    void p11(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String[] parts = rq.getParameter("p").split("/");
        rq.getRequestDispatcher("/" + parts[0]).forward(rq, rs);
    }

    void p12(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(rq.getContextPath() + "/x").forward(rq, rs);
    }

    void p13(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher((String) rq.getAttribute("view")).forward(rq, rs);
    }

    void p14(HttpServletRequest rq, HttpServletResponse rs) {
        try {
            rq.getRequestDispatcher(rq.getParameter("p")).forward(rq, rs);
        } catch (Exception e) {
            // ignored
        }
    }

    void p15(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        RequestDispatcher rd = dispatcherFor(rq, rq.getParameter("p"));
        rd.forward(rq, rs);
    }

    RequestDispatcher dispatcherFor(HttpServletRequest rq, String path) {
        return rq.getRequestDispatcher(path);
    }

    void p16(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String uri = rq.getRequestURI();
        rq.getRequestDispatcher("/WEB-INF/pages" + uri.substring(rq.getContextPath().length()) + ".jsp").forward(rq, rs);
    }

    void p17(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher("/dispatch?path=" + rq.getPathInfo()).forward(rq, rs);
    }

    void p18(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String u = rq.getParameter("u");
        if (u.startsWith("/") && !u.startsWith("//")) {
            rq.getRequestDispatcher(u).forward(rq, rs);
        }
    }

    void p19(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        boolean ok = VIEWS.contains(p);
        if (ok) {
            rq.getRequestDispatcher("/v/" + p).forward(rq, rs);
        }
    }

    void p20(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        String v = VIEWS.contains(p) ? p : "home";
        rq.getRequestDispatcher("/v/" + v).forward(rq, rs);
    }

    void p21(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        for (String k : rq.getParameterMap().keySet()) {
            rq.getRequestDispatcher("/" + k).include(rq, rs);
        }
    }

    void p22(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        ServletContext ctx = getServletContext();
        String path = rq.getParameter("p");
        RequestDispatcher rd = ctx.getRequestDispatcher(path);
        if (rd != null) {
            rd.forward(rq, rs);
        }
    }

    void p23(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        getServletContext().getRealPath(p);
        rq.getRequestDispatcher(p).forward(rq, rs);
    }

    void p24(HttpServletRequest rq, HttpServletResponse rs) throws IOException {
        rs.sendRedirect(rq.getParameter("next"));
    }

    void p25(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        rs.sendRedirect(p);
        rq.getRequestDispatcher(p).forward(rq, rs);
    }

    @Controller
    public static class C {
        @GetMapping("/a")
        public String s01(@RequestParam String p) {
            return "forward:" + p.toLowerCase();
        }

        @GetMapping("/b")
        public String s02(@RequestParam String p) {
            String view = "forward:/pages/";
            return view + p;
        }

        @GetMapping("/c")
        public String s03(@RequestParam String p) {
            final String prefix = "forward:";
            return prefix + p;
        }

        @GetMapping("/d")
        public String s04(@RequestParam String p) {
            return FORWARD + p;
        }

        @GetMapping("/e")
        public ModelAndView s05(@RequestParam String p) {
            return new ModelAndView("forward:" + p, "m", new Object());
        }

        @GetMapping("/f")
        public String s06(@RequestParam String p) {
            return "redirect:" + p;
        }

        @GetMapping("/g")
        public String s07(@RequestParam String p) {
            return "forward:" + Integer.parseInt(p);
        }

        @GetMapping("/h")
        public String s08(@RequestParam String p) {
            if (!VIEWS.contains(p)) {
                throw new IllegalArgumentException(p);
            }
            return "forward:/v/" + p;
        }

        @GetMapping("/i")
        public String s09(@RequestParam String p, @RequestParam boolean flag) {
            StringBuilder sb = new StringBuilder("forward:/WEB-INF/");
            sb.append(p);
            return sb.toString();
        }
    }
}
