package org.springframework.web.servlet;

/** Stub (fixture only). */
public class ModelAndView {
    public ModelAndView() {
    }

    public ModelAndView(String viewName) {
    }

    public ModelAndView(String viewName, String modelName, Object modelObject) {
    }

    public void setViewName(String viewName) {
    }
}
