package example;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * The forms an independent verifier found after the first round: request text that follows a fixed question mark however the text is
 * built, checks that were not recognised (indexOf, a for-each over the accepted values, a number parsed in a try, every character
 * a letter or digit), and what the texts of the rule say about calls of the project's own methods.
 */
public class ProbeDispatchD extends HttpServlet {
    static final String SHOW = "/show.jsp";
    static final String[] ARR = {"a", "b"};
    static final List<String> ALLOWED = List.of("a", "b");
    static final String VIEWS = "list,detail";

    enum Color { RED, GREEN }

    // ------------------------------------------------------------------ the question mark comes first

    /** N: a local that starts with the question mark and gets the parameter appended with +=. */
    void queryPlusAssign(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String url = "/show.jsp?";
        url += "id=" + rq.getParameter("id");
        rq.getRequestDispatcher(url).forward(rq, rs);
    }

    /** N: the same with url = url + .. */
    void querySelfAppend(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String url = "/show.jsp?id=";
        url = url + rq.getParameter("id");
        rq.getRequestDispatcher(url).forward(rq, rs);
    }

    /** N: a StringBuilder that starts with the question mark; two parameters are appended. */
    void queryBuilder(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        StringBuilder url = new StringBuilder("/show.jsp?");
        url.append("id=").append(rq.getParameter("id"));
        url.append("&x=").append(rq.getParameter("x"));
        rq.getRequestDispatcher(url.toString()).forward(rq, rs);
    }

    /** N: and a StringBuffer. */
    void queryBuffer(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        StringBuffer url = new StringBuffer("/show.jsp?");
        url.append(rq.getParameter("id"));
        rq.getRequestDispatcher(url.toString()).forward(rq, rs);
    }

    /** N: a chain of appends from the creation, the question mark is appended as a literal. */
    void queryBuilderChain(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(new StringBuilder("/show.jsp").append("?id=").append(rq.getParameter("id")).toString()).forward(rq, rs);
    }

    /** N: concat on a literal that has the question mark. */
    void queryConcat(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher("/show.jsp?id=".concat(rq.getParameter("id"))).forward(rq, rs);
    }

    /** N: two literals in front of the parameter (the compiler keeps them as a node of their own). */
    void queryTwoLiterals(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String id = rq.getParameter("id");
        rq.getRequestDispatcher("/show.jsp" + "?id=" + id).forward(rq, rs);
    }

    /** N: three literals. */
    void queryThreeLiterals(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher("/show" + ".jsp" + "?id=" + rq.getParameter("id")).forward(rq, rs);
    }

    /** N: a constant and a literal in front of the parameter. */
    void queryConstantAndLiteral(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(SHOW + "?id=" + rq.getParameter("id") + "&x=1").forward(rq, rs);
    }

    /** N: the question mark and the parameter in one literal after a literal. */
    void queryLiteralsThenText(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher("/show.jsp?" + "id=" + rq.getParameter("id")).forward(rq, rs);
    }

    /** N: String.formatted. */
    void queryFormatted(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher("/show.jsp?id=%s".formatted(rq.getParameter("id"))).forward(rq, rs);
    }

    /** N: the question mark is the value of a local that is set once, before the parameter. */
    void queryQuestionInLocal(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String separator = "?";
        rq.getRequestDispatcher("/show.jsp" + separator + rq.getParameter("id")).forward(rq, rs);
    }

    /** N: the start has no question mark, the text that is appended brings it before the parameter. */
    void queryAppendedLater(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String url = "/show.jsp";
        url += "?id=" + rq.getParameter("id");
        rq.getRequestDispatcher(url).forward(rq, rs);
    }

    /** N: the start has no question mark; the same assignment appends the question mark and then the parameter. */
    void querySelfAppendLater(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String url = "/show.jsp";
        url = url + "?id=" + rq.getParameter("id");
        rq.getRequestDispatcher(url).forward(rq, rs);
    }

    /** N: a loop appends more parameters to a start that has the question mark. */
    void queryInLoop(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String url = "/show.jsp?";
        for (String name : rq.getParameterValues("names")) {
            url += name + "=" + rq.getParameter(name) + "&";
        }
        rq.getRequestDispatcher(url).forward(rq, rs);
    }

    /** N: either branch has the question mark before the parameter. */
    void queryConditional(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String id = rq.getParameter("id");
        rq.getRequestDispatcher(id.isEmpty() ? "/a.jsp?x=" + id : "/b.jsp?y=" + id).forward(rq, rs);
    }

    /** N: the question mark is behind a start that is itself built from a local. */
    void queryThroughLocals(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String base = "/show.jsp?";
        String url = base + "id=";
        String full = url + rq.getParameter("id");
        rq.getRequestDispatcher(full).forward(rq, rs);
    }

    /** P: the parameter is appended before the question mark. */
    void pathAppendedBeforeQuery(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String url = "/pages/";
        url += rq.getParameter("p");
        url += "?x=1";
        rq.getRequestDispatcher(url).forward(rq, rs);
    }

    /** P: the same with a StringBuilder. */
    void pathBuilderBeforeQuery(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        StringBuilder url = new StringBuilder("/pages/");
        url.append(rq.getParameter("p")).append("?x=1");
        rq.getRequestDispatcher(url.toString()).forward(rq, rs);
    }

    /** P: the question mark is in a variable that comes after the request text: the text is in the path. */
    void pathQuestionInLaterVariable(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String separator = "?";
        rq.getRequestDispatcher("/show.jsp" + rq.getParameter("id") + separator).forward(rq, rs);
    }

    /** P: one of two separators is a question mark: before the request text it is not certain. */
    void pathOneSeparatorMayBeAQuestionMark(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String separator = rq.getParameter("again") == null ? "?" : "&";
        rq.getRequestDispatcher("/show.jsp" + separator + rq.getParameter("id")).forward(rq, rs);
    }

    /** P: the parameter is appended first and the question mark after it, in two statements. */
    void pathSelfAppendEarly(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String url = "/show";
        url = url + rq.getParameter("p") + "?x=1";
        rq.getRequestDispatcher(url).forward(rq, rs);
    }

    /** P: the builder starts with request text. */
    void pathBuilderStartsWithRequest(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(new StringBuilder(rq.getParameter("base")).append("?id=1").toString()).forward(rq, rs);
    }

    /** P: text is put in front of the question mark of a builder. */
    void pathBuilderInsert(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        StringBuilder url = new StringBuilder("/show.jsp?");
        url.insert(0, rq.getParameter("p"));
        rq.getRequestDispatcher(url.toString()).forward(rq, rs);
    }

    /** P: concat with the request text first. */
    void pathConcatFirst(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(rq.getParameter("p").concat("?x=1")).forward(rq, rs);
    }

    /** P: the local is set to request text in one branch. */
    void pathOneBranch(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String url = "/show.jsp?id=";
        if (rq.getParameter("raw") != null) {
            url = rq.getParameter("raw");
        }
        rq.getRequestDispatcher(url).forward(rq, rs);
    }

    /** P: request text in front of the question mark of the text that is put in front of a local. */
    void pathPrepended(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String url = "/show.jsp?id=1";
        url = rq.getParameter("dir") + url;
        rq.getRequestDispatcher(url).forward(rq, rs);
    }

    // ------------------------------------------------------------------ checks that are recognised

    /** N: indexOf finds none of the three: a plain file name. */
    void indexOfAllThree(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p.indexOf("..") < 0 && p.indexOf('/') < 0 && p.indexOf('\\') < 0) {
            rq.getRequestDispatcher("/WEB-INF/" + p).forward(rq, rs);
        }
    }

    /** N: and as a guard clause. */
    void indexOfGuardClause(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p.indexOf("..") >= 0 || p.indexOf('/') >= 0 || p.indexOf('\\') >= 0) {
            return;
        }
        rq.getRequestDispatcher("/WEB-INF/" + p).forward(rq, rs);
    }

    /** N: lastIndexOf says the same. */
    void lastIndexOfAllThree(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p.lastIndexOf("..") == -1 && p.lastIndexOf("/") == -1 && p.lastIndexOf("\\") == -1) {
            rq.getRequestDispatcher("/WEB-INF/" + p).forward(rq, rs);
        }
    }

    /** N: the value is looked for in a text that lists the accepted values (this form was a check before the indexOf checks for names). */
    void foundInATextOfValues(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (VIEWS.indexOf(p) >= 0) {
            rq.getRequestDispatcher("/pages/" + p + ".jsp").forward(rq, rs);
        }
    }

    /** P: only the slash is looked for. */
    void indexOfSlashOnly(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p.indexOf("/") < 0) {
            rq.getRequestDispatcher("/WEB-INF/" + p).forward(rq, rs);
        }
    }

    /** P: a value without line breaks is only safe for a mail header: for a path it is no check. */
    void noLineBreaksIsNoCheckForAPath(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p.contains("\r") || p.contains("\n")) {
            return;
        }
        rq.getRequestDispatcher("/WEB-INF/" + p).forward(rq, rs);
    }

    /** N: the parameter is used in the branch where it equals a listed value (the array). */
    void listedArray(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        for (String a : ARR) {
            if (a.equals(p)) {
                rq.getRequestDispatcher("/pages/" + p + ".jsp").forward(rq, rs);
                return;
            }
        }
    }

    /** N: the same with the list and the arguments the other way round. */
    void listedList(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        for (String a : ALLOWED) {
            if (p.equals(a)) {
                rq.getRequestDispatcher("/pages/" + p + ".jsp").forward(rq, rs);
            }
        }
    }

    /** P: the loop goes over request values: they do not list what is accepted. */
    void loopOverRequest(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        for (String a : rq.getParameterValues("others")) {
            if (a.equals(p)) {
                rq.getRequestDispatcher("/pages/" + p + ".jsp").forward(rq, rs);
            }
        }
    }

    /** P: the match is only noted, the dispatch is outside of the branch. */
    void listedButUsedOutside(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        boolean found = false;
        for (String a : ARR) {
            if (a.equals(p)) {
                found = true;
            }
        }
        rq.getRequestDispatcher("/pages/" + p + ".jsp").forward(rq, rs);
    }

    /** N: Integer.parseInt in a try whose catch leaves. */
    void parsedInTry(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        try {
            Integer.parseInt(p);
        } catch (NumberFormatException e) {
            return;
        }
        rq.getRequestDispatcher("/page" + p).forward(rq, rs);
    }

    /** N: the catch throws. */
    void parsedInTryThrows(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        try {
            Long.parseLong(p.trim());
        } catch (NumberFormatException e) {
            throw new ServletException("not a number", e);
        }
        rq.getRequestDispatcher("/page" + p).forward(rq, rs);
    }

    /** N: the number is kept, assigned in the try. */
    void parsedAndAssigned(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        int n;
        try {
            n = Integer.parseInt(p);
        } catch (NumberFormatException e) {
            return;
        }
        rq.getRequestDispatcher("/page" + p + "/" + n).forward(rq, rs);
    }

    /** N: the name of an enum constant. */
    void enumInTry(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        try {
            Color.valueOf(p);
        } catch (IllegalArgumentException e) {
            return;
        }
        rq.getRequestDispatcher("/colors/" + p).forward(rq, rs);
    }

    /** P: the catch goes on, so the code after the try is also reached without a number. */
    void parsedButCatchGoesOn(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        try {
            Integer.parseInt(p);
        } catch (NumberFormatException e) {
            rq.setAttribute("error", "not a number"); // and on
        }
        rq.getRequestDispatcher("/page" + p).forward(rq, rs);
    }

    /** P: the parse is in a branch of the try body. */
    void parsedInBranch(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        try {
            if (rq.getParameter("check") != null) {
                Integer.parseInt(p);
            }
        } catch (NumberFormatException e) {
            return;
        }
        rq.getRequestDispatcher("/page" + p).forward(rq, rs);
    }

    /** P: Double.parseDouble trims white space and accepts text like 1e5: it proves little. */
    void parsedDouble(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        try {
            Double.parseDouble(p);
        } catch (NumberFormatException e) {
            return;
        }
        rq.getRequestDispatcher("/page" + p).forward(rq, rs);
    }

    /** P: the variable gets a new value after the parse. */
    void parsedThenAssigned(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        try {
            Integer.parseInt(p);
            p = rq.getParameter("q");
        } catch (NumberFormatException e) {
            return;
        }
        rq.getRequestDispatcher("/page" + p).forward(rq, rs);
    }

    /** N: every character is a letter or a digit. */
    void charsAllMatch(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p.chars().allMatch(Character::isLetterOrDigit)) {
            rq.getRequestDispatcher("/pages/" + p + ".jsp").forward(rq, rs);
        }
    }

    /** N: and with a lambda that also lets an underscore and a hyphen through. */
    void charsAllMatchLambda(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p.chars().allMatch(c -> Character.isLetterOrDigit(c) || c == '_' || c == '-')) {
            rq.getRequestDispatcher("/pages/" + p + ".jsp").forward(rq, rs);
        }
    }

    /** N: as a guard clause. */
    void charsNotAllMatch(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (!p.chars().allMatch(Character::isLetterOrDigit)) {
            return;
        }
        rq.getRequestDispatcher("/pages/" + p + ".jsp").forward(rq, rs);
    }

    /** P: a dot may pass. */
    void charsAllowDot(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p.chars().allMatch(c -> Character.isLetterOrDigit(c) || c == '.')) {
            rq.getRequestDispatcher("/pages/" + p + ".jsp").forward(rq, rs);
        }
    }

    /** P: white space is not a letter or a digit test. */
    void charsAllWhitespace(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        if (p.chars().allMatch(Character::isWhitespace)) {
            rq.getRequestDispatcher("/pages/" + p + ".jsp").forward(rq, rs);
        }
    }

    // ------------------------------------------------------------------ calls of the project's own methods

    /** P: a method of the project is not followed; what it returns for a request value is still request text. */
    void ownMethodResult(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(resolveView(rq.getParameter("p"))).forward(rq, rs);
    }

    /** N: a method whose name says it sanitizes is taken at its word. */
    void ownSanitizer(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(sanitizeView(rq.getParameter("p"))).forward(rq, rs);
    }

    /** M: getServletPath() is not request data for any of the taint rules (the shared source table): documented, not reported. */
    void servletPath(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher("/WEB-INF/views" + rq.getServletPath() + ".jsp").forward(rq, rs);
    }

    /** M: and getPathTranslated(). */
    void pathTranslated(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(rq.getPathTranslated()).forward(rq, rs);
    }

    /** P: getPathInfo() is request data, so a front controller that dispatches on it is reported. */
    void pathInfo(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher("/WEB-INF/views" + rq.getPathInfo() + ".jsp").forward(rq, rs);
    }

    /** M: the dispatcher is made by a method reference: not followed (a known limit). */
    void methodReference(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        java.util.function.Function<String, javax.servlet.RequestDispatcher> make = rq::getRequestDispatcher;
        make.apply(rq.getParameter("p")).forward(rq, rs);
    }

    /** M: a StringJoiner builds the target: not followed (a known limit). */
    void joiner(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        java.util.StringJoiner path = new java.util.StringJoiner("/");
        path.add("pages");
        path.add(rq.getParameter("p"));
        rq.getRequestDispatcher(path.toString()).forward(rq, rs);
    }

    private String resolveView(String name) {
        return name;
    }

    private String sanitizeView(String name) {
        return name;
    }

    /** Spring handlers whose view names are not followed (known limits, see the description of the rule). */
    @Controller
    public static class Views {
        /** M: the view name is trimmed after it was joined. */
        @GetMapping("/trimmed")
        public String trimmedView(@RequestParam String p) {
            return ("forward:" + p).trim();
        }

        /** M: a StringBuilder as the whole of the text after "forward:". */
        @GetMapping("/builder")
        public String builderObjectView(@RequestParam String p) {
            StringBuilder sb = new StringBuilder("/pages/");
            sb.append(p);
            return "forward:" + sb;
        }

        /** M: the prefix is in a local that is set again. */
        @GetMapping("/prefix")
        public String prefixLocalView(@RequestParam String p) {
            String view = "forward:/pages/";
            view = view + p;
            return view;
        }
    }

    /** M: a field initializer is not followed (a known limit). */
    static class FieldInitializer {
        HttpServletRequest rq;
        javax.servlet.RequestDispatcher fld = rq.getRequestDispatcher(rq.getParameter("p"));
    }
}
