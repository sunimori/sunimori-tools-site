package javax.servlet.http;

import java.io.IOException;

import javax.servlet.ServletResponse;

/** Stub (fixture only). */
public interface HttpServletResponse extends ServletResponse {
    void sendRedirect(String location) throws IOException;
}
