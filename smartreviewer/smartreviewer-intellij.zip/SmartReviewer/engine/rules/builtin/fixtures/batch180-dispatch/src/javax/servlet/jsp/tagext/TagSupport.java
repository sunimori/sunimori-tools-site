package javax.servlet.jsp.tagext;

import javax.servlet.jsp.PageContext;

/** Stub (fixture only). */
public class TagSupport {
    protected PageContext pageContext;
}
