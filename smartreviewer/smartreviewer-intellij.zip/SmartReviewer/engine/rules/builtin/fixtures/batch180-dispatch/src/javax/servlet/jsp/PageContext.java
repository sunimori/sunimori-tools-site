package javax.servlet.jsp;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;

/** Stub (fixture only). */
public abstract class PageContext {
    public abstract void forward(String relativeUrlPath) throws ServletException, IOException;

    public abstract void include(String relativeUrlPath) throws ServletException, IOException;

    public abstract void include(String relativeUrlPath, boolean flush) throws ServletException, IOException;

    public abstract ServletRequest getRequest();
}
