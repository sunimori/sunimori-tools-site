package jakarta.servlet.http;

import java.io.IOException;

import jakarta.servlet.ServletResponse;

/** Stub (fixture only). */
public interface HttpServletResponse extends ServletResponse {
    void sendRedirect(String location) throws IOException;
}
