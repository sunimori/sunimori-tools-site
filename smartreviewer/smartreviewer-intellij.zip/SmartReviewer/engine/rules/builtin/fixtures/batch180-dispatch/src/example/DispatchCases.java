package example;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

/**
 * Servlet cases for SR-SEC-DISPATCH-001: request text that decides the target of getRequestDispatcher. P = reported, N = not
 * reported, B = a form near the edge (the expected result is in the suite).
 */
public class DispatchCases extends HttpServlet {
    private static final String ERROR_VIEW = "/WEB-INF/views/error.jsp";
    private static final Set<String> VIEWS = Set.of("list", "detail", "edit");
    private static final Map<String, String> TARGETS = Map.of("list", "/WEB-INF/views/list.jsp", "detail", "/WEB-INF/views/detail.jsp");
    private final String homeView = "/WEB-INF/views/home.jsp";
    private String configuredView;

    // ------------------------------------------------------------------ P: the target comes from the request

    /** P: the parameter is the path. */
    void forwardParam(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher(request.getParameter("page")).forward(request, response);
    }

    /** P: a fixed directory and extension do not help, ../ climbs out of both. */
    void forwardInDirectory(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        request.getRequestDispatcher("/WEB-INF/views/" + page + ".jsp").forward(request, response);
    }

    /** P: the servlet context's dispatcher, include. */
    void includeFromContext(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContext context = getServletContext();
        RequestDispatcher dispatcher = context.getRequestDispatcher(request.getParameter("fragment"));
        dispatcher.include(request, response);
    }

    /** P: the extra path of a front controller: /app/WEB-INF/web.xml is served by the controller, not refused by the container. */
    void frontController(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher(request.getPathInfo()).forward(request, response);
    }

    /** P: the path is built in a local first. */
    void viaLocal(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        String path = "/pages/" + page;
        RequestDispatcher rd = request.getRequestDispatcher(path);
        rd.forward(request, response);
    }

    /** P: StringBuilder. */
    void viaBuilder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        StringBuilder sb = new StringBuilder("/WEB-INF/");
        sb.append(request.getParameter("dir")).append("/index.jsp");
        request.getRequestDispatcher(sb.toString()).forward(request, response);
    }

    /** P: String.format with the placeholder in the path. */
    void viaFormat(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher(String.format("/WEB-INF/%s.jsp", request.getParameter("page"))).forward(request, response);
    }

    /** P: a ternary with a default for a missing parameter: the other branch is the request text. */
    void withDefault(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        String target = page == null ? "/index.jsp" : "/" + page;
        request.getRequestDispatcher(target).forward(request, response);
    }

    /** P: a default assigned in one branch does not check the other. */
    void nullDefault(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        if (page == null) {
            page = "/index.jsp";
        }
        request.getRequestDispatcher(page).forward(request, response);
    }

    /** P: the check holds in the branch that does not dispatch with the request text. */
    void checkedInOtherBranch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        if ("list".equals(page)) {
            request.getRequestDispatcher("/WEB-INF/views/list.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("/WEB-INF/views/" + page + ".jsp").forward(request, response);
        }
    }

    /** P: the request path as the dispatch target in a loop body. */
    void inLoop(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        for (String page : request.getParameterValues("page")) {
            request.getRequestDispatcher("/WEB-INF/" + page).include(request, response);
        }
    }

    /** P: a header value is request data too. */
    void fromHeader(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher(request.getHeader("X-View")).forward(request, response);
    }

    /** P: inside a lambda. */
    void inLambda(HttpServletRequest request, HttpServletResponse response) {
        Runnable r = () -> {
            try {
                request.getRequestDispatcher(request.getParameter("page")).forward(request, response);
            } catch (ServletException | IOException e) {
                throw new IllegalStateException(e);
            }
        };
        r.run();
    }

    /** P: in an anonymous class. */
    void inAnonymousClass(HttpServletRequest request, HttpServletResponse response) {
        String page = request.getParameter("page");
        new Thread() {
            @Override
            public void run() {
                try {
                    request.getRequestDispatcher(page).forward(request, response);
                } catch (ServletException | IOException e) {
                    throw new IllegalStateException(e);
                }
            }
        }.start();
    }

    /** P: the unknown request path is part of the target before a query string. */
    void pathBeforeQuery(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/" + request.getParameter("servlet") + "?mode=list").forward(request, response);
    }

    // ------------------------------------------------------------------ N: fixed or checked targets

    /** N: a literal. */
    void literal(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/list.jsp").forward(request, response);
    }

    /** N: constants, one of them joined with a plus. */
    void constants(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher(ERROR_VIEW).forward(request, response);
        request.getRequestDispatcher("/WEB-INF/" + "views/" + "x.jsp").include(request, response);
        request.getRequestDispatcher(homeView).forward(request, response);
    }

    /** N: a configured field is not request data. */
    void configured(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher(configuredView).forward(request, response);
    }

    /** N: a value of a fixed table selected by the request (the key does not carry its text). */
    void table(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String view = TARGETS.getOrDefault(request.getParameter("page"), ERROR_VIEW);
        request.getRequestDispatcher(view).forward(request, response);
    }

    /** N: a table lookup without a default. */
    void tableGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher(TARGETS.get(request.getParameter("page"))).forward(request, response);
    }

    /** N: the request text is checked against a set first (a guard clause that leaves). */
    void allowList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        if (!VIEWS.contains(page)) {
            response.sendRedirect("/error");
            return;
        }
        request.getRequestDispatcher("/WEB-INF/views/" + page + ".jsp").forward(request, response);
    }

    /** N: the check guards the branch. */
    void allowListBranch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        if (VIEWS.contains(page)) {
            request.getRequestDispatcher("/WEB-INF/views/" + page + ".jsp").forward(request, response);
        }
    }

    /** N: a switch maps the request text to literals. */
    void switchMapping(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String view;
        switch (request.getParameter("page")) {
            case "list":
                view = "/WEB-INF/views/list.jsp";
                break;
            case "detail":
                view = "/WEB-INF/views/detail.jsp";
                break;
            default:
                view = ERROR_VIEW;
        }
        request.getRequestDispatcher(view).forward(request, response);
    }

    /** N: a full-match pattern. */
    void pattern(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        if (!page.matches("[a-z]{1,20}")) {
            return;
        }
        request.getRequestDispatcher("/WEB-INF/views/" + page + ".jsp").forward(request, response);
    }

    /** N: alphanumeric only. */
    void alphanumeric(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        if (StringUtils.isAlphanumeric(page)) {
            request.getRequestDispatcher("/WEB-INF/views/" + page + ".jsp").forward(request, response);
        }
    }

    /** N: a number made of the parameter is no text. */
    void number(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        request.getRequestDispatcher("/WEB-INF/items/" + id + ".jsp").forward(request, response);
    }

    /** N: only the file name of the parameter is used (FilenameUtils.getName). */
    void fileNameOnly(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = FilenameUtils.getName(request.getParameter("page"));
        request.getRequestDispatcher("/WEB-INF/views/" + name).forward(request, response);
    }

    /** N: a parameter of the method is whoever calls it, not the request. */
    void parameterOfTheMethod(HttpServletRequest request, HttpServletResponse response, String view) throws ServletException, IOException {
        request.getRequestDispatcher(view).forward(request, response);
    }

    /** N: the request text is a parameter of a fixed path. */
    void queryParameter(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/show.jsp?id=" + request.getParameter("id")).forward(request, response);
    }

    /** N: the same, through a local. */
    void queryParameterLocal(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        String target = "/show?mode=" + request.getParameter("mode") + "&id=" + id;
        request.getRequestDispatcher(target).forward(request, response);
    }

    /** N: and with String.format. */
    void queryParameterFormat(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher(String.format("/show?id=%s", request.getParameter("id"))).forward(request, response);
    }

    /** N: and with MessageFormat. */
    void queryParameterMessageFormat(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher(MessageFormat.format("/show?id={0}", request.getParameter("id"))).forward(request, response);
    }

    /** N: the name of a File made of the parameter has no directory part. */
    void fileOfName(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = new File(request.getParameter("page")).getName();
        request.getRequestDispatcher("/WEB-INF/views/" + name).forward(request, response);
    }

    /** N: not a dispatcher at all: the context path is read, the real path is another rule's. */
    void notADispatch(HttpServletRequest request, ServletContext context) {
        String real = context.getRealPath(request.getParameter("file"));
        request.setAttribute("real", real);
    }

    /** N: the named dispatcher is not covered. */
    void named(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        getServletContext().getNamedDispatcher(request.getParameter("servlet")).forward(request, response);
    }

    // ------------------------------------------------------------------ B: near the edge

    /** B: startsWith does not make the text safe: /WEB-INF/views/../../web.xml starts with it. */
    void startsWithOnly(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        if (page.startsWith("/WEB-INF/views/")) {
            request.getRequestDispatcher(page).forward(request, response);
        }
    }

    /** B: ../ is refused but a slash is not: the whole tree below the context is still reachable. */
    void dotDotOnly(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        if (page.contains("..")) {
            return;
        }
        request.getRequestDispatcher("/WEB-INF/" + page).forward(request, response);
    }

    /** B: a plain file name: no dots pair, no slash, no backslash. */
    void plainName(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        if (page.contains("..") || page.contains("/") || page.contains("\\")) {
            return;
        }
        request.getRequestDispatcher("/WEB-INF/views/" + page + ".jsp").forward(request, response);
    }

    /** B: the path stays inside the views directory after normalize(). */
    void insideBase(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Path base = Paths.get("/WEB-INF/views");
        Path target = base.resolve(request.getParameter("page")).normalize();
        if (!target.startsWith(base)) {
            return;
        }
        request.getRequestDispatcher(target.toString()).forward(request, response);
    }

    /** B: a prefix that is reassigned before the dispatch: the query-only reading must not apply. */
    void reassigned(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String target = "/show?id=" + request.getParameter("id");
        target = request.getParameter("page");
        request.getRequestDispatcher(target).forward(request, response);
    }

    /** B: the question mark is in the request text itself, not in the constant. */
    void questionMarkInRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher(request.getParameter("page") + "?x=1").forward(request, response);
    }

    /** B: the request text appears before and after the question mark: the first one is in the path. */
    void bothSides(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = request.getParameter("page");
        request.getRequestDispatcher("/" + page + "?next=" + page).forward(request, response);
    }

    /** B: ServletRequest, not HttpServletRequest. */
    void plainServletRequest(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher(request.getParameter("page")).forward(request, response);
    }

    /** B: one call reports once, however many dispatch calls follow it. */
    void twice(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher rd = request.getRequestDispatcher(request.getParameter("page"));
        rd.include(request, response);
        rd.forward(request, response);
    }

    /** B: a file path is the path rule's, not this one's: the real path of the parameter. */
    void resourceStream(HttpServletRequest request) {
        getServletContext().getRealPath("/WEB-INF/" + request.getParameter("page"));
    }
}
