package javax.servlet.http;

/** Stub (fixture only). */
public class Cookie {
    public String getName() {
        return null;
    }

    public String getValue() {
        return null;
    }
}
