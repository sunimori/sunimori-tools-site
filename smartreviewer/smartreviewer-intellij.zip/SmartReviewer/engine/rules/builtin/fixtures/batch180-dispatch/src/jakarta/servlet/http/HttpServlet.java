package jakarta.servlet.http;

import jakarta.servlet.ServletContext;

/** Stub (fixture only). */
public abstract class HttpServlet {
    public ServletContext getServletContext() {
        return null;
    }
}
