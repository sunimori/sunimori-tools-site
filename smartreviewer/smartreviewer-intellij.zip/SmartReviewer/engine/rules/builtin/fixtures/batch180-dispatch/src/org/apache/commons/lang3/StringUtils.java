package org.apache.commons.lang3;

/** Stub (fixture only). */
public final class StringUtils {
    private StringUtils() {
    }

    public static boolean isAlphanumeric(CharSequence cs) {
        return false;
    }

    public static boolean isNumeric(CharSequence cs) {
        return false;
    }
}
