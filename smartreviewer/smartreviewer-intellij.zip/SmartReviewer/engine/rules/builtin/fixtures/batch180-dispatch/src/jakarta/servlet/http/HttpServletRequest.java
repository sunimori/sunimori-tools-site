package jakarta.servlet.http;

import jakarta.servlet.ServletRequest;

/** Stub (fixture only). */
public interface HttpServletRequest extends ServletRequest {
    String getHeader(String name);

    Cookie[] getCookies();

    String getPathInfo();

    String getServletPath();

    String getQueryString();

    String getRequestURI();

    String getContextPath();
}
