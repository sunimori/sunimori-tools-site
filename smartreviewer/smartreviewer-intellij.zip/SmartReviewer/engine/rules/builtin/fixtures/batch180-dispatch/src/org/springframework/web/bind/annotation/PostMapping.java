package org.springframework.web.bind.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** Stub (fixture only). */
@Retention(RetentionPolicy.RUNTIME)
public @interface PostMapping {
    String[] value() default {};
}
