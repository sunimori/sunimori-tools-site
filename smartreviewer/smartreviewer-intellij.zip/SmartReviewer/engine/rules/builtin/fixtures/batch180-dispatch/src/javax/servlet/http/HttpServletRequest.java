package javax.servlet.http;

import javax.servlet.ServletRequest;

/** Stub (fixture only). */
public interface HttpServletRequest extends ServletRequest {
    String getHeader(String name);

    Cookie[] getCookies();

    String getPathInfo();

    String getServletPath();

    String getPathTranslated();

    String getQueryString();

    String getRequestURI();

    String getContextPath();
}
