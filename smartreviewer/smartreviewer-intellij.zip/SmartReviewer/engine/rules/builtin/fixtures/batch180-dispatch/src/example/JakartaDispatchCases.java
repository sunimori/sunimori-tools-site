package example;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/** Jakarta servlet cases for SR-SEC-DISPATCH-001: the package name is the only difference. */
public class JakartaDispatchCases extends HttpServlet {
    /** P: the parameter is the path. */
    void forwardParam(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/" + request.getParameter("page")).forward(request, response);
    }

    /** P: the servlet context's dispatcher. */
    void contextInclude(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        getServletContext().getRequestDispatcher(request.getParameter("page")).include(request, response);
    }

    /** N: a literal. */
    void literal(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/list.jsp").forward(request, response);
    }
}
