package javax.servlet.http;

import javax.servlet.ServletContext;

/** Stub (fixture only). */
public abstract class HttpServlet {
    public ServletContext getServletContext() {
        return null;
    }
}
