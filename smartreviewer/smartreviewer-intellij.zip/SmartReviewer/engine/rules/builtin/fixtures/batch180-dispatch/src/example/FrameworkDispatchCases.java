package example;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.tagext.TagSupport;

import com.opensymphony.xwork2.ActionSupport;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * Spring, Struts 2, JSF and JSP cases for SR-SEC-DISPATCH-001. A view name that begins with "forward:" is a dispatch; one that
 * begins with "redirect:" is an external redirect and belongs to SR-SEC-OPEN-REDIRECT-001.
 */
public class FrameworkDispatchCases {
    private static final Set<String> VIEWS = Set.of("list", "detail");
    private static final Map<String, String> TABLE = Map.of("list", "forward:/WEB-INF/views/list.jsp");

    /** Spring MVC handlers. */
    @Controller
    public static class Handlers {
        /** P: "forward:" and the request text. */
        @GetMapping("/go")
        public String forwardParam(@RequestParam("page") String page) {
            return "forward:" + page;
        }

        /** P: a fixed directory does not help. */
        @GetMapping("/view")
        public String forwardDirectory(@RequestParam("page") String page) {
            return "forward:/WEB-INF/views/" + page + ".jsp";
        }

        /** P: a parameter bound without an annotation. */
        @GetMapping("/bound")
        public String forwardBound(String page) {
            return "forward:" + page;
        }

        /** P: String.format. */
        @GetMapping("/fmt")
        public String forwardFormat(@RequestParam String page) {
            return String.format("forward:/WEB-INF/%s.jsp", page);
        }

        /** P: the view name is made in a local first. */
        @GetMapping("/local")
        public String forwardLocal(@RequestParam String page) {
            String view = "forward:/WEB-INF/" + page;
            return view;
        }

        /** P: a conditional expression. */
        @GetMapping("/ternary")
        public String forwardTernary(@RequestParam(required = false) String page) {
            return page == null ? "forward:/WEB-INF/views/home.jsp" : "forward:/WEB-INF/views/" + page + ".jsp";
        }

        /** P: new ModelAndView(...). */
        @GetMapping("/mav")
        public ModelAndView forwardModelAndView(@RequestParam String page) {
            return new ModelAndView("forward:" + page);
        }

        /** P: ModelAndView.setViewName. */
        @GetMapping("/mavset")
        public ModelAndView forwardSetViewName(@RequestParam String page) {
            ModelAndView mav = new ModelAndView();
            mav.setViewName("forward:/WEB-INF/" + page);
            return mav;
        }

        /** P: a path variable. */
        @GetMapping("/p/{page}")
        public String forwardPathVariable(@PathVariable String page) {
            return "forward:/WEB-INF/views/" + page + ".jsp";
        }

        /** P: the servlet request of the handler. */
        @GetMapping("/raw")
        public String forwardFromRequest(HttpServletRequest request) {
            return "forward:" + request.getParameter("page");
        }

        /** P: a servlet request dispatcher in a handler. */
        @GetMapping("/disp")
        public void dispatchInHandler(@RequestParam String page, HttpServletRequest request, HttpServletResponse response)
                throws ServletException, IOException {
            request.getRequestDispatcher(page).forward(request, response);
        }

        /** N: a literal. */
        @GetMapping("/lit")
        public String literal() {
            return "forward:/WEB-INF/views/list.jsp";
        }

        /** N: a request parameter in the query of a fixed forward. */
        @GetMapping("/query")
        public String forwardQuery(@RequestParam String id) {
            return "forward:/orders/show?id=" + id;
        }

        /** N: the view name comes from a table, selected by the parameter. */
        @GetMapping("/table")
        public String table(@RequestParam String page) {
            return TABLE.getOrDefault(page, "forward:/WEB-INF/views/error.jsp");
        }

        /** N: the redirect is another rule's (SR-SEC-OPEN-REDIRECT-001). */
        @GetMapping("/back")
        public String redirect(@RequestParam String next) {
            return "redirect:" + next;
        }

        /** N: a plain view name is resolved by the view resolver, not forwarded to a path chosen by the request. */
        @GetMapping("/plain")
        public String plainView(@RequestParam String page) {
            return "views/" + page;
        }

        /** N: checked against the allowed views. */
        @GetMapping("/checked")
        public String forwardChecked(@RequestParam String page) {
            if (!VIEWS.contains(page)) {
                return "forward:/WEB-INF/views/error.jsp";
            }
            return "forward:/WEB-INF/views/" + page + ".jsp";
        }

        /** N: a number. */
        @GetMapping("/num")
        public String forwardNumber(@RequestParam long id) {
            return "forward:/orders/" + id;
        }

        /** N: a path variable that is a number. */
        @GetMapping("/n/{id}")
        public String forwardNumberPath(@PathVariable Long id) {
            return "forward:/orders/" + id;
        }

        /** B: the check is in the other branch. */
        @GetMapping("/other")
        public String forwardOtherBranch(@RequestParam String page) {
            if (VIEWS.contains(page)) {
                return "forward:/WEB-INF/views/" + page + ".jsp";
            }
            return "forward:/WEB-INF/views/" + page;
        }

        /** B: a prefix that is not forward: is no dispatch. */
        @GetMapping("/fwd")
        public String similarPrefix(@RequestParam String page) {
            return "forwarded:" + page;
        }
    }

    /** A Struts 2 action: text properties are filled from the request, the service the container injects is not. */
    public static class ViewAction extends ActionSupport {
        private ViewResolver resolver;
        private String page;

        public void setResolver(ViewResolver resolver) {
            this.resolver = resolver;
        }

        public void setPage(String page) {
            this.page = page;
        }

        /** P: the property is request data. */
        public String showPage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            request.getRequestDispatcher("/WEB-INF/views/" + page).forward(request, response);
            return SUCCESS;
        }

        /** N: the injected service decides. */
        public String showResolved(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            request.getRequestDispatcher(resolver.viewFor("home")).forward(request, response);
            return SUCCESS;
        }

        /** N: the property is checked first. */
        public String showChecked(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            if (!VIEWS.contains(page)) {
                return "input";
            }
            request.getRequestDispatcher("/WEB-INF/views/" + page + ".jsp").forward(request, response);
            return SUCCESS;
        }
    }

    /** What a Struts 2 action gets from the container. */
    public interface ViewResolver {
        String viewFor(String name);
    }

    /** A JSF backing bean. */
    @ManagedBean
    public static class ViewBean {
        @ManagedProperty("#{param.view}")
        private String view;
        @ManagedProperty("#{viewResolver}")
        private ViewResolver resolver;

        public void setView(String view) {
            this.view = view;
        }

        public void setResolver(ViewResolver resolver) {
            this.resolver = resolver;
        }

        /** P: dispatch to the view of the request parameter. */
        public void open() throws IOException {
            FacesContext.getCurrentInstance().getExternalContext().dispatch(view);
        }

        /** P: the request parameter map. */
        public void openFromMap() throws IOException {
            ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
            ec.dispatch("/WEB-INF/" + ec.getRequestParameterMap().get("view"));
        }

        /** N: the resolver bean is no request data. */
        public void openResolved() throws IOException {
            FacesContext.getCurrentInstance().getExternalContext().dispatch(resolver.viewFor("home"));
        }

        /** N: a literal. */
        public void openHome() throws IOException {
            FacesContext.getCurrentInstance().getExternalContext().dispatch("/home.xhtml");
        }

        /** N: the redirect is another rule's. */
        public void leave() throws IOException {
            FacesContext.getCurrentInstance().getExternalContext().redirect(view);
        }
    }

    /** A JSP tag handler. */
    public static class ForwardTag extends TagSupport {
        /** P: the page forwards to a path of the request. */
        public int doStartTag() throws ServletException, IOException {
            pageContext.forward(pageContext.getRequest().getParameter("target"));
            return 0;
        }

        /** P: include. */
        public int doEndTag() throws ServletException, IOException {
            pageContext.include("/WEB-INF/tags/" + pageContext.getRequest().getParameter("tag") + ".jsp", false);
            return 0;
        }

        /** N: a literal. */
        public int doAfterBody() throws ServletException, IOException {
            pageContext.include("/WEB-INF/tags/footer.jsp");
            return 0;
        }
    }
}
