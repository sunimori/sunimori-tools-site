package example;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** More forms for SR-SEC-DISPATCH-001 that a developer writes: switch with arrow bodies, collections, loops, locks, formats. */
public class ProbeDispatchC extends HttpServlet {
    static final Set<String> VIEWS = Set.of("a", "b");

    void a01(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String p = rq.getParameter("p");
        switch (rq.getParameter("m")) {
            case "x" -> rq.getRequestDispatcher(p).forward(rq, rs);
            default -> { }
        }
    }

    void b01(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        List<String> paths = new ArrayList<>();
        paths.add(rq.getParameter("p"));
        rq.getRequestDispatcher(paths.get(0)).forward(rq, rs);
    }

    void e01(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        rq.getRequestDispatcher(String.format("/%s/%s.jsp", rq.getParameter("d"), "index")).forward(rq, rs);
    }

    void f01(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        for (String p : rq.getParameterValues("p")) {
            if (!VIEWS.contains(p)) {
                continue;
            }
            rq.getRequestDispatcher("/v/" + p).forward(rq, rs);
        }
    }

    void f02(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        String found = "a";
        for (String p : rq.getParameterValues("p")) {
            if (VIEWS.contains(p)) {
                found = p;
                break;
            }
        }
        rq.getRequestDispatcher("/v/" + found).forward(rq, rs);
    }

    void g01(HttpServletRequest rq, HttpServletResponse rs) throws ServletException, IOException {
        synchronized (this) {
            String p = rq.getParameter("p");
            rq.getRequestDispatcher(p).forward(rq, rs);
        }
    }
}
