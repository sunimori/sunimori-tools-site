package javax.faces.context;

/** Stub (fixture only). */
public abstract class FacesContext {
    public static FacesContext getCurrentInstance() {
        return null;
    }

    public abstract ExternalContext getExternalContext();
}
