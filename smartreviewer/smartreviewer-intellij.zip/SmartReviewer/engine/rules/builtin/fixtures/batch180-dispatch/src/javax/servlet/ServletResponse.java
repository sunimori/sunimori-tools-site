package javax.servlet;

import java.io.IOException;
import java.io.PrintWriter;

/** Stub (fixture only). */
public interface ServletResponse {
    PrintWriter getWriter() throws IOException;
}
