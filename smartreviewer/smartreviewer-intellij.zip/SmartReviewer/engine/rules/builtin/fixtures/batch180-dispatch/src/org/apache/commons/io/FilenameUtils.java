package org.apache.commons.io;

/** Stub (fixture only). */
public final class FilenameUtils {
    private FilenameUtils() {
    }

    public static String getName(String path) {
        return path;
    }
}
