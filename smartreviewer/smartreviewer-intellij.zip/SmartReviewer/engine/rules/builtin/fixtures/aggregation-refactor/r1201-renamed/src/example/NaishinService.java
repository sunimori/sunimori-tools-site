package example;

/** S03: value8 was renamed to technologyScore (same position and type); nothing is missing. */
final class NaishinService {
    Object[] aggregate(Integer value1, Integer value2, Integer value3, Integer value4, Integer value5,
                        Integer value6, Integer value7, Integer technologyScore, Integer value9) {
        Object[] values = {
            value1, value2, value3,
            value4, value5, value6,
            value7, technologyScore, value9
        };
        return values;
    }
}
