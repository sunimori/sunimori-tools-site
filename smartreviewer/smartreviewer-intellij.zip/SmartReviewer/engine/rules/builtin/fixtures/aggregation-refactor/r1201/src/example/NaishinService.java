package example;

/** r1201 (illustrative): the sum became an Object[]; value7 was copied into the eighth position. */
final class NaishinService {
    Object[] aggregate(Integer value1, Integer value2, Integer value3, Integer value4, Integer value5,
                        Integer value6, Integer value7, Integer value8, Integer value9) {
        Object[] values = {
            value1, value2, value3,
            value4, value5, value6,
            value7, value7, value9
        };
        return values;
    }
}
