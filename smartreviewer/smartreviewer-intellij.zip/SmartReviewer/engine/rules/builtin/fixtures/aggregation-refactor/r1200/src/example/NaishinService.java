package example;

/** r1200 (illustrative): nine subject scores summed as Integer. */
final class NaishinService {
    Object[] aggregate(Integer value1, Integer value2, Integer value3, Integer value4, Integer value5,
                        Integer value6, Integer value7, Integer value8, Integer value9) {
        Integer total = value1 + value2 + value3
                + value4 + value5 + value6
                + value7 + value8 + value9;
        return new Object[] {total};
    }
}
