package example;

/** S04: the sum was split into two overlapping groups; no unique old/new association exists. */
final class NaishinService {
    Object[] aggregate(Integer value1, Integer value2, Integer value3, Integer value4, Integer value5,
                        Integer value6, Integer value7, Integer value8, Integer value9) {
        Object[] first = {value1, value2, value3, value4, value5, value7, value7};
        Object[] second = {value3, value4, value5, value6, value7, value9};
        return new Object[] {first, second};
    }
}
