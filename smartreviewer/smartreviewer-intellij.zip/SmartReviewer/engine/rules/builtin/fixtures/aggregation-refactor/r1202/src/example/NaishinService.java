package example;

/** r1202 (illustrative): the duplicated reference was fixed. */
final class NaishinService {
    Object[] aggregate(Integer value1, Integer value2, Integer value3, Integer value4, Integer value5,
                        Integer value6, Integer value7, Integer value8, Integer value9) {
        Object[] values = {
            value1, value2, value3,
            value4, value5, value6,
            value7, value8, value9
        };
        return values;
    }
}
