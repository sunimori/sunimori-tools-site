package example;

import com.vendor.AbstractRemote;
import jakarta.inject.Named;

/** Its superclass is outside the project, so its members are not fully known. */
@Named
public class RemoteBean extends AbstractRemote {
}
