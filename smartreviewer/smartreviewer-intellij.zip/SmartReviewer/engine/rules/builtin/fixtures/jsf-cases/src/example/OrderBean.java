package example;

import java.util.List;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/** CDI bean with an explicit EL name. */
@Named("orders")
@RequestScoped
public class OrderBean extends BaseBean {
    private int total;
    private List<String> items;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public boolean isPaid() {
        return total > 0;
    }

    public List<String> getItems() {
        return items;
    }

    public String save() {
        return "saved";
    }
}
