package example;

/** Declared as a managed bean in faces-config.xml (no annotation). */
public class LegacyBean {
    public String getName() {
        return "legacy";
    }
}
