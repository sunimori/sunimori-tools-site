package example;

/** Superclass inside the project: its properties are inherited by OrderBean. */
public abstract class BaseBean {
    public String getLocale() {
        return "ja";
    }
}
