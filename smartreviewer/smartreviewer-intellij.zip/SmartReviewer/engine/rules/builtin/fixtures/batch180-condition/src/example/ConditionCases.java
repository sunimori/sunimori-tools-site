package example;

/** Conditions whose comparisons of one operand exclude each other or cover every value (SR-JAVA-CONDITION-CONTRADICTION-001). */
public class ConditionCases {
    static final int FIRST_MONTH = 1;
    static final int LAST_MONTH = 12;

    enum Status { OPEN, CLOSED, ARCHIVED }

    static class Order {
        int quantity;
        Status status;
    }

    int retries;
    int[] limits = new int[2];
    volatile int generation;
    Order order = new Order();

    boolean refresh() {
        retries++;
        return true;
    }

    int currentType() {
        return retries;
    }

    // ----- always true: an || chain that covers every value

    /** Every value differs from at least one of them. */
    boolean notOneOrTwo(int type) {
        return type != 1 || type != 2;
    }

    /** The range was meant to be written with &&. */
    boolean rangeWrittenWithOr(int hour) {
        return hour >= 0 || hour <= 23;
    }

    boolean overlappingBounds(int score) {
        return score < 60 || score >= 50;
    }

    boolean characterRange(char letter) {
        return letter >= 'a' || letter <= 'z';
    }

    boolean statusNotEither(Status status) {
        return status != Status.OPEN || status != Status.CLOSED;
    }

    boolean fieldNotEither() {
        return this.retries != 0 || retries != 1;
    }

    boolean fieldOfAFieldNotEither() {
        return order.quantity != 1 || order.quantity != 2;
    }

    boolean boxedNotEither(Integer type) {
        return type != 1 || type != 2;
    }

    boolean inAWhile(int type) {
        int tries = 0;
        while (type != 1 || type != 2) {
            if (++tries > 3) {
                break;
            }
        }
        return tries > 0;
    }

    // ----- never true: an && chain whose comparisons exclude each other

    /** Out of range was meant to be written with ||. */
    boolean monthOutOfRange(int month) {
        return month < FIRST_MONTH && month > LAST_MONTH;
    }

    boolean bothValues(int type) {
        return type == 1 && type == 2;
    }

    boolean valueAndNotTheValue(int code) {
        return code == 7 && code != 7;
    }

    boolean nullAndNotNull(String name) {
        return name == null && name != null;
    }

    boolean flagAndNotFlag(boolean ready) {
        return ready && !ready;
    }

    boolean ratioOutOfRange(double ratio) {
        return ratio < 0.0 && ratio > 1.0;
    }

    boolean arrayElement() {
        return limits[0] > 10 && limits[0] < 5;
    }

    boolean longAgainstInt(long total) {
        return total < 10 && total > 20L;
    }

    boolean insideAnIf(int type) {
        if (type == 1 && type == 2) {
            return true;
        }
        return false;
    }

    /** The other operands cannot rescue the contradiction. */
    boolean withOtherOperands(int type, boolean active, int count) {
        return active && type == 1 && count > 0 && type == 2;
    }

    boolean negatedRange(int x) {
        return !(x < 5 || x > 10) && x == 3;
    }

    boolean statusBothValues(Status status) {
        return status == Status.OPEN && status == Status.CLOSED;
    }

    boolean noIntegerBetween(int x) {
        return x > 3 && x < 4;
    }

    // ----- not constant

    boolean notBothValues(int type) {
        return type != 1 && type != 2;
    }

    boolean eitherValue(int type) {
        return type == 1 || type == 2;
    }

    boolean outsideTheRange(int month) {
        return month < FIRST_MONTH || month > LAST_MONTH;
    }

    boolean insideTheRange(int month) {
        return month >= FIRST_MONTH && month <= LAST_MONTH;
    }

    boolean differentVariables(int a, int b) {
        return a == 1 && b == 2;
    }

    boolean comparedWithVariables(int x, int a, int b) {
        return x != a || x != b;
    }

    boolean getterCalls() {
        return currentType() != 1 || currentType() != 2;
    }

    boolean stringsAreCompared(String text) {
        return text.equals("a") && text.equals("b");
    }

    boolean sameComparisonTwice(int type) {
        return type == 1 && type == 1;
    }

    // ----- boundary

    /** A call between the two comparisons may change the field. */
    boolean callBetween() {
        return retries == 1 && refresh() && retries == 2;
    }

    boolean incrementBetween(int type) {
        return type == 1 && type++ > 0 && type == 2;
    }

    boolean volatileField() {
        return generation != 1 || generation != 2;
    }

    /** NaN is neither smaller than 0.5 nor at least 0.5. */
    boolean notANumberEscapes(double ratio) {
        return ratio < 0.5 || ratio >= 0.5;
    }

    boolean notANumberEscapesToo(double ratio) {
        return ratio >= 0.5 || ratio < 0.5;
    }

    /** A byte is never 200: that is the type's range, not a contradiction between the comparisons. */
    boolean byteAgainstTwoHundred(byte value) {
        return value == 200 && value == 1;
    }

    boolean byteBelowTwoHundred(byte value) {
        return value < 200 || value == 1;
    }

    /** 16777217 is no float: the comparison converts it to 16777216f, so a float can equal both. */
    boolean floatConstantsThatRoundToOneFloat(float price) {
        return price == 16777216 && price == 16777217;
    }

    /** A boxed Boolean can be null; only a primitive boolean is judged. */
    boolean boxedFlag(Boolean flag) {
        return flag && !flag;
    }

    /** Chains nested in parentheses deeper than the rule follows (40 levels): nothing is found, and the rule says that it did not look at all of it. */
    boolean chainNestedTooDeep(int level) {
        return level != 0 && (level != 1 && (level != 2 && (level != 3 && (level != 4 && (level != 5 && (level != 6 && (level != 7 && (level != 8 && (level != 9 && (level != 10 && (level != 11 && (level != 12 && (level != 13 && (level != 14 && (level != 15 && (level != 16 && (level != 17 && (level != 18 && (level != 19 && (level != 20 && (level != 21 && (level != 22 && (level != 23 && (level != 24 && (level != 25 && (level != 26 && (level != 27 && (level != 28 && (level != 29 && (level != 30 && (level != 31 && (level != 32 && (level != 33 && (level != 34 && (level != 35 && (level != 36 && (level != 37 && (level != 38 && (level != 39 && (level != 40 && (level != 41 && (level != 42 && (level != 43 && (level != 44 && (level > 5 || level < 3)))))))))))))))))))))))))))))))))))))))))))));
    }
}
