package example;

import com.example.missing.Account;

/** The type of the operand is not on the class path: the comparisons still look contradictory. */
public class UnresolvedOperand {
    boolean statusNotEither(Account account) {
        return account.status != 1 || account.status != 2;
    }

    boolean statusEither(Account account) {
        return account.status == 1 || account.status == 2;
    }
}
