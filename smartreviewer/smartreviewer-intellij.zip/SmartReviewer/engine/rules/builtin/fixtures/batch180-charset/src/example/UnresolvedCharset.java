package example;

import com.example.missing.Exporter;

/** The receiver's type is not on the class path: the rule cannot tell that getBytes takes a charset name. */
public class UnresolvedCharset {
    byte[] export(Exporter exporter) throws Exception {
        return exporter.getBytes("SJIS");
    }

    byte[] exportAsWindows(Exporter exporter) throws Exception {
        return exporter.getBytes("MS932");
    }
}
