package example;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;

/** Charset names that select the JIS standard Shift_JIS where Windows-31J (MS932) is meant (SR-JAVA-CHARSET-NAME-001). */
public class CharsetCases {
    static final String FILE_ENCODING = "Shift_JIS";
    static final String WINDOWS_ENCODING = "MS932";

    // ----- the name of the JIS standard mapping

    String decodeShiftJis(byte[] bytes) throws UnsupportedEncodingException {
        return new String(bytes, "Shift_JIS");
    }

    String decodeRange(byte[] bytes, int length) throws UnsupportedEncodingException {
        return new String(bytes, 0, length, "SJIS");
    }

    byte[] encodeSjis(String text) throws UnsupportedEncodingException {
        return text.getBytes("sjis");
    }

    Reader readerMsKanji(InputStream in) throws UnsupportedEncodingException {
        return new InputStreamReader(in, "MS_Kanji");
    }

    Writer writerXSjis(OutputStream out) throws UnsupportedEncodingException {
        return new OutputStreamWriter(out, "x-sjis");
    }

    Charset charsetByName() {
        return Charset.forName("Shift_JIS");
    }

    String urlEncode(String text) throws UnsupportedEncodingException {
        return URLEncoder.encode(text, "Shift_JIS");
    }

    String urlDecode(String text) throws UnsupportedEncodingException {
        return URLDecoder.decode(text, "SJIS");
    }

    String bufferToString(ByteArrayOutputStream buffer) throws UnsupportedEncodingException {
        return buffer.toString("Shift_JIS");
    }

    PrintStream printStream(OutputStream out) throws UnsupportedEncodingException {
        return new PrintStream(out, true, "SJIS");
    }

    PrintWriter printWriter() throws UnsupportedEncodingException, java.io.FileNotFoundException {
        return new PrintWriter("out.txt", "SJIS");
    }

    Scanner scanner(InputStream in) {
        return new Scanner(in, "SJIS");
    }

    byte[] nameFromAConstant(String text) throws UnsupportedEncodingException {
        return text.getBytes(FILE_ENCODING);
    }

    byte[] nameFromAFinalLocal(String text) throws UnsupportedEncodingException {
        final String name = "csShiftJIS";
        return text.getBytes(name);
    }

    byte[] nameFromAConcatenation(String text) throws UnsupportedEncodingException {
        return text.getBytes("Shift" + "_JIS");
    }

    Reader channelReader(ReadableByteChannel in) {
        return Channels.newReader(in, "Shift_JIS");
    }

    Writer channelWriter(WritableByteChannel out) {
        return Channels.newWriter(out, "SJIS");
    }

    void transformerEncoding(Transformer transformer) {
        transformer.setOutputProperty(OutputKeys.ENCODING, "Shift_JIS");
    }

    /** One of the two names is the JIS standard one. */
    byte[] nameFromAConditional(String text, boolean legacy) throws UnsupportedEncodingException {
        return text.getBytes(legacy ? "Shift_JIS" : "UTF-8");
    }

    // ----- the Windows variant, other charsets, and what is no constant

    byte[] windows31j(String text) throws UnsupportedEncodingException {
        return text.getBytes("Windows-31J");
    }

    byte[] ms932(String text) throws UnsupportedEncodingException {
        return text.getBytes("MS932");
    }

    byte[] ms932FromAConstant(String text) throws UnsupportedEncodingException {
        return text.getBytes(WINDOWS_ENCODING);
    }

    byte[] utf8(String text) throws UnsupportedEncodingException {
        return text.getBytes("UTF-8");
    }

    byte[] charsetObject(String text) {
        return text.getBytes(StandardCharsets.UTF_8);
    }

    /** No charset at all: SR-JAVA-DEFAULT-CHARSET-001. */
    byte[] noCharset(String text) {
        return text.getBytes();
    }

    byte[] nameFromTheCaller(String text, String name) throws UnsupportedEncodingException {
        return text.getBytes(name);
    }

    byte[] nameThatIsChanged(String text, boolean windows) throws UnsupportedEncodingException {
        String name = "SJIS";
        if (windows) {
            name = "MS932";
        }
        return text.getBytes(name);
    }

    byte[] nameFromAConditionalOfSafeNames(String text, boolean legacy) throws UnsupportedEncodingException {
        return text.getBytes(legacy ? "MS932" : "UTF-8");
    }

    void transformerOtherProperty(Transformer transformer) {
        transformer.setOutputProperty(OutputKeys.METHOD, "SJIS");
    }

    boolean onlyAskedWhetherSupported() {
        return Charset.isSupported("Shift_JIS");
    }

    String justAText() {
        return "Shift_JIS";
    }

    // ----- EUC-JP: reported only with includeEucJp

    String decodeEucJp(byte[] bytes) throws UnsupportedEncodingException {
        return new String(bytes, "EUC-JP");
    }
}
