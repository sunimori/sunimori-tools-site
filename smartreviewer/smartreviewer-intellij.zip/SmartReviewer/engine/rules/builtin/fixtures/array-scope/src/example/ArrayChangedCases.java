package example;

/**
 * Used by ArrayRuleEndToEndTest for reviews of changed code only: which initializers are reported when some lines are marked as
 * changed (q and w are declared nowhere, on purpose).
 */
final class ArrayChangedCases {
    Object[] untouched(Integer a, Integer b) {
        return new Object[] {a, b, a};
    }

    Object[] multiLine(Integer a, Integer b, Integer c) {
        return new Object[] {
            a,
            b,
            c,
            a
        };
    }

    Object[] unresolved() {
        return new Object[] {q, w, q};
    }
}
