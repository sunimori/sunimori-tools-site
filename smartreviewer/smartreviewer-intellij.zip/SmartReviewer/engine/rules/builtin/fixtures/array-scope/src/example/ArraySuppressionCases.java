package example;

/**
 * Cases su01 to su13 of rules/builtin/tests/SR-JAVA-ARRAY-001/suite.yaml: where an inline suppression has to stand for a finding of
 * SR-JAVA-ARRAY-001 (above the line of its location, at the end of that line, above the line of the brace), what it covers, and when it
 * does not apply (not above the second occurrence, no reason, a date that has passed).
 */
final class ArraySuppressionCases {
    /** su01: the marker above the line where the brace of the initializer stands suppresses the finding at the second x (line 4 of the array). */
    Object[] aboveBrace(Integer x, Integer y, Integer z) {
        // smartreviewer:disable-next-line SR-JAVA-ARRAY-001 reason="x marks the start and the end" until=2099-12-31
        return new Object[] {
            x,
            y,
            z,
            x
        };
    }

    /** su02: a marker above the first x does not suppress: the finding is at the second x. */
    Object[] aboveFirstOccurrence(Integer x, Integer y, Integer z) {
        return new Object[] {
            // smartreviewer:disable-next-line SR-JAVA-ARRAY-001 reason="x marks the start and the end" until=2099-12-31
            x,
            y,
            z,
            x
        };
    }

    /** su03: a marker whose date has passed is no longer in force. */
    Object[] expired(Integer x, Integer y) {
        // smartreviewer:disable-next-line SR-JAVA-ARRAY-001 reason="x marks the start and the end" until=2020-01-01
        return new Object[] {x, y, x};
    }

    /** su04: the date is optional (without a team policy; see the Java test of the engine). */
    Object[] noDate(Integer x, Integer y) {
        // smartreviewer:disable-next-line SR-JAVA-ARRAY-001 reason="x marks the start and the end"
        return new Object[] {x, y, x};
    }

    /** su05: the marker stands above the line of the second x, where the finding is located, not above the brace: it applies. */
    Object[] aboveSecondOccurrence(Integer x, Integer y, Integer z) {
        return new Object[] {
            x,
            y,
            z,
            // smartreviewer:disable-next-line SR-JAVA-ARRAY-001 reason="x marks the start and the end" until=2099-12-31
            x
        };
    }

    /** su06: disable-line at the end of the line of the second x applies. */
    Object[] lineMarkerOnSecond(Integer x, Integer y, Integer z) {
        return new Object[] {
            x,
            y,
            z,
            x // smartreviewer:disable-line SR-JAVA-ARRAY-001 reason="x marks the start and the end" until=2099-12-31
        };
    }

    /** su07: two findings (a and b); the marker above the second b covers the finding of b and not the one of a. */
    Object[] markerOnOnePrimary(Integer a, Integer b, Integer c) {
        return new Object[] {
            a,
            b,
            // smartreviewer:disable-next-line SR-JAVA-ARRAY-001 reason="b is intended" until=2099-12-31
            b,
            a,
            c
        };
    }

    /** su08: two findings; the marker above the line of the brace covers every finding of the initializer. */
    Object[] aboveBraceTwoFindings(Integer a, Integer b, Integer c) {
        // smartreviewer:disable-next-line SR-JAVA-ARRAY-001 reason="both are intended" until=2099-12-31
        return new Object[] {
            a,
            b,
            b,
            a,
            c
        };
    }

    /** su09: a marker without a reason does not apply. */
    Object[] noReason(Integer x, Integer y) {
        // smartreviewer:disable-next-line SR-JAVA-ARRAY-001
        return new Object[] {x, y, x};
    }

    /** su10: neither does a marker with an empty reason. */
    Object[] emptyReason(Integer x, Integer y) {
        // smartreviewer:disable-next-line SR-JAVA-ARRAY-001 reason=""
        return new Object[] {x, y, x};
    }

    /** su11: the brace stands alone on its own line: a marker above the return line is not above the brace line, it does not apply. */
    Object[] braceOnOwnLine(Integer x, Integer y) {
        // smartreviewer:disable-next-line SR-JAVA-ARRAY-001 reason="x marks the start and the end" until=2099-12-31
        return new Object[]
        {
            x, y, x
        };
    }

    /** su13: disable-line at the end of the line where the brace stands covers the finding at the second x (line 4 of the array). */
    Object[] lineMarkerOnBraceLine(Integer x, Integer y, Integer z) {
        return new Object[] { // smartreviewer:disable-line SR-JAVA-ARRAY-001 reason="x marks the start and the end" until=2099-12-31
            x,
            y,
            z,
            x
        };
    }

    /** su12: the marker above the line of that brace applies. */
    Object[] aboveBraceOnOwnLine(Integer x, Integer y) {
        return new Object[]
        // smartreviewer:disable-next-line SR-JAVA-ARRAY-001 reason="x marks the start and the end" until=2099-12-31
        {
            x, y, x
        };
    }
}
