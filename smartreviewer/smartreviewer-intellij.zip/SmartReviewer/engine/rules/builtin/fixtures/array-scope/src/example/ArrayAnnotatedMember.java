package example;

/** B16M: an undeclared name repeated in the value of an annotation of a member of an annotation type. */
@interface ArrayAnnotatedMember {
    @ArrayNames(names = {U, V, U})
    String member();
}
