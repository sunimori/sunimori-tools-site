package example;

/** B16R: an undeclared name repeated in the value of an annotation of a record component. */
record ArrayAnnotatedRecord(@ArrayNames(names = {U, V, U}) Integer component) {
}
