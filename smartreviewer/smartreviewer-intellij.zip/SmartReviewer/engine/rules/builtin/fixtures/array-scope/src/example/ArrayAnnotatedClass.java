package example;

/** B16K: an undeclared name repeated in the value of an annotation of a class. */
@ArrayNames(names = {U, V, U})
final class ArrayAnnotatedClass {
}
