package example;

/**
 * Receivers of field reads for SR-JAVA-ARRAY-001 (cases P14 to P16, P15B, N15, N17 to N17E and N18 of rules/builtin/tests/SR-JAVA-ARRAY-001/suite.yaml):
 * the ones it can prove to be the same object at every read, and the ones it cannot.
 */
final class ArrayReceiverCases {
    Integer x;
    Holder h;

    static final class Holder {
        Integer value;
        Holder inner;
    }

    static class Base {
        protected Integer sx;
    }

    static final class Derived extends Base {
        /** P15: super.sx is the inherited field. */
        Object[] superField(Integer z) {
            return new Object[] {super.sx, z, super.sx};
        }

        /** P15: sx, super.sx and this.sx are one field. */
        Object[] threeSpellings(Integer z) {
            return new Object[] {sx, super.sx, this.sx};
        }
    }

    /** P14: from an inner class, the simple name x and ArrayReceiverCases.this.x are the same field of the outer class. */
    class Inner {
        Object[] outerThis(Integer z) {
            return new Object[] {x, z, ArrayReceiverCases.this.x};
        }
    }

    /** N15: the inner class has a field x of its own; ArrayReceiverCases.this.x is a different declaration. */
    class Shadowing {
        Integer x;

        Object[] bothFields(Integer z) {
            return new Object[] {x, ArrayReceiverCases.this.x, z};
        }
    }

    /** P16: a local variable as the receiver, not reassigned. */
    Object[] localReceiver(Integer b) {
        Holder local = new Holder();
        return new Object[] {local.value, b, local.value};
    }

    /** N17: a field chain through a parameter: the receiver cannot be proven to be the same object at both reads. */
    Object[] unprovenChain(Holder p, Integer z) {
        return new Object[] {p.inner.value, z, p.inner.value};
    }

    /** N17B: a field chain through this. */
    Object[] unprovenThroughThis(Integer z) {
        return new Object[] {this.h.value, z, this.h.value};
    }

    /** N17C: a field used as the receiver. */
    Object[] unprovenFieldAsReceiver(Integer z) {
        return new Object[] {h.value, z, h.value};
    }

    /** N17D: the result of a method call as the receiver. */
    Object[] unprovenCallAsReceiver(Integer z) {
        return new Object[] {get().value, z, get().value};
    }

    /** N17E: a cast as the receiver. */
    Object[] unprovenCastAsReceiver(Object o, Integer z) {
        return new Object[] {((Holder) o).value, z, ((Holder) o).value};
    }

    /** N18: one read through an array element is enough to be recorded. */
    Object[] singleUnproven(Holder[] hs, Integer z, Integer y) {
        return new Object[] {hs[0].value, z, y};
    }

    Holder get() {
        return h;
    }
}
