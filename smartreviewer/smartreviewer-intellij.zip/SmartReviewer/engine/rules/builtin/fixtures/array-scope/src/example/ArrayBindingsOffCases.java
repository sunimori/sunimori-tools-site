package example;

/**
 * What a read of each kind of variable gives when the project setting switches the type bindings off (cases B25A to B25I of
 * rules/builtin/tests/SR-JAVA-ARRAY-001/suite.yaml, all with resolveBindings: false). Every method has one shape and nothing else that
 * could raise a limitation: the other elements are literals, which are never compared.
 */
final class ArrayBindingsOffCases extends ArrayBindingsOffBase {
    enum Color { RED, GREEN }

    static final class Holder {
        Integer value;
    }

    static Integer sf;
    static final int SC = 5;
    Integer own;
    Holder h;

    /** B25A: an instance field the file declares, read once: syntax-level identity, a limitation although nothing is repeated. */
    Object[] instanceField() {
        return new Object[] {own, 2, 1};
    }

    /** B25B: a final local initialized with a constant expression is no constant at the syntax level: three limitations. */
    Object[] constantExpression() {
        final int sum = 2 + 3;
        return new Object[] {sum, sum, sum};
    }

    /** B25C: a field inherited from the base class (declared in another file), read twice by its simple name. */
    Object[] inheritedRepeated() {
        return new Object[] {inh, inh, 1};
    }

    /** B25D: super.sx read twice. */
    Object[] superRepeated() {
        return new Object[] {super.sx, 2, super.sx};
    }

    /** B25E: a static field qualified by its class, read twice. */
    Object[] qualifiedStatic() {
        return new Object[] {ArrayBindingsOffCases.sf, ArrayBindingsOffCases.sf, 1};
    }

    /** B25F: a constant (static final) qualified by its class, read three times: it is no exception here. */
    Object[] qualifiedConstant() {
        return new Object[] {ArrayBindingsOffCases.SC, ArrayBindingsOffCases.SC, ArrayBindingsOffCases.SC};
    }

    /** B25G: an enum constant, read twice. */
    Object[] enumConstant() {
        return new Object[] {Color.RED, Color.RED, 1};
    }

    /** B25H: a field chain (a field as the receiver), read twice. */
    Object[] fieldChain() {
        return new Object[] {h.value, h.value, 1};
    }

    /** B25I: each of the shapes of B25C to B25H read once, every text different: nothing is recorded. */
    Object[] eachReadOnce() {
        return new Object[] {inh, super.sx, ArrayBindingsOffCases.sf, ArrayBindingsOffCases.SC, Color.RED, h.value};
    }
}
