package example;

import java.util.List;
import java.util.function.Function;

/**
 * Names and types SR-JAVA-ARRAY-001 cannot resolve (cases B15 to B15G, B16, B16C, B16P, B16L and N19 of
 * rules/builtin/tests/SR-JAVA-ARRAY-001/suite.yaml). Unknown and U are declared nowhere, on purpose.
 */
final class ArrayUnresolvedCases {
    static final String X = "x";
    static final String Y = "y";

    /** B15: the lambda cannot be typed (the type of svc is unknown), so neither can the names read inside it (the type bindings are on). */
    void lambdaOfUnknownType(Unknown svc, Integer o) {
        svc.each(x -> {
            Object[] r = {x, o, x};
        });
    }

    /** B15B: the same with the parameter of the lambda read once: nothing is repeated and a limitation is reported all the same. */
    void lambdaOfUnknownTypeOnce(Unknown svc) {
        svc.each(x -> {
            Object[] r = {x, 2, 1};
        });
    }

    /** B15C: writing the type of the parameter does not help: the lambda is passed to a method of an unknown type and still cannot be typed. */
    void lambdaWithExplicitType(Unknown svc, Integer o) {
        svc.each((Integer x) -> {
            Object[] r = {x, o, x};
        });
    }

    /** B15D: the target type is known, only the type of the parameter is not: the lambda is typed, the names are resolved, the repetition is reported. */
    void lambdaOfKnownTargetType(Integer o) {
        Function<Unknown, Object[]> g = u -> new Object[] {u, o, u};
    }

    /** B15E: a parameter of the method that the untypable lambda reads (once) has only a syntax-level identity too. */
    void lambdaReadsAParameterOfTheMethod(Unknown svc, Integer o) {
        svc.each(x -> {
            Object[] r = {o, 2, 1};
        });
    }

    /** B15F: a local variable declared inside the untypable lambda has only a syntax-level identity too (read once). */
    void lambdaReadsItsOwnLocal(Unknown svc) {
        svc.each(x -> {
            Integer local = 1;
            Object[] r = {local, 2, 1};
        });
    }

    /** B15G: the lambda is passed to a method whose type arguments come from an unknown type (a List of Unknown): it cannot be typed either. */
    void lambdaOverListOfUnknown(List<Unknown> list, Integer o) {
        list.forEach(y -> {
            Object[] r = {y, o, y};
        });
    }

    /** N19: the values of an annotation are constants: no finding. */
    @ArrayNames(names = {X, Y, X})
    void constantNames() {
    }

    /** B16: an undeclared name repeated in the value of an annotation of a method. */
    @ArrayNames(names = {U, V, U})
    void annotatedMethod() {
    }

    /** B16C: the same on a constructor. */
    @ArrayNames(names = {U, V, U})
    ArrayUnresolvedCases() {
    }

    /** B16P: the same on a parameter. */
    void annotatedParameter(@ArrayNames(names = {U, V, U}) Object x) {
    }

    /** B16L: the same on a local variable. */
    void annotatedLocal() {
        @ArrayNames(names = {U, V, U}) Object local = null;
    }
}

@interface ArrayNames {
    String[] names();
}
