package example;

import java.util.Arrays;
import java.util.List;

/**
 * Cases behind the scope statement of SR-JAVA-ARRAY-001 (its "detection" block): the forms it reports and the forms it leaves out.
 * See rules/builtin/tests/SR-JAVA-ARRAY-001/suite.yaml.
 */
final class ArrayScopeCases {
    static final class Holder {
        Integer value;
    }

    /** P05: the declaration form is an array initializer too. */
    Integer[] p05(Integer a, Integer b) {
        Integer[] r = {a, b, a};
        return r;
    }

    /** B08: a nested initializer is checked on its own: the first inner array repeats a. */
    Object[][] b08(Integer a, Integer b, Integer c) {
        return new Object[][] {{a, b, a}, {a, b, c}};
    }

    /** N09: the same variable among call arguments, and arrays filled element by element, are no array initializers. */
    Object[] n09(Integer a, Integer b) {
        List<Integer> list = Arrays.asList(a, b, a);
        List<Integer> immutable = List.of(a, b, a);
        use(a, b, a);
        Object[] r = new Object[3];
        r[0] = a;
        r[1] = b;
        r[2] = a;
        return r;
    }

    /** N10: casts and operator expressions are not direct variable reads. */
    Object[] n10(Integer a, int b, int c) {
        Object[] casts = {(Object) a, (Object) a, c};
        int[] sums = {b + 1, b + 1, c};
        return casts;
    }

    /** N11: left is assigned inside the initializer, so left.value is not proven to be the same field at each read. */
    Object[] n11(Holder left, Holder right) {
        return new Object[] {left.value, (left = right).value, left.value};
    }

    /** N12: the same variable in two different initializers, and a copy of it in a third, are no repetition. */
    Object[][] n12(Integer a, Integer b, Integer c, Integer d) {
        Integer copy = a;
        Object[] x = {a, b, c};
        Object[] y = {a, b, d};
        Object[] z = {a, copy, d};
        return new Object[][] {x, y, z};
    }

    private static void use(Object... values) {
    }
}
