package example;

/** B13: the base class cannot be resolved (UnknownBase is declared nowhere, on purpose), so inherited is no known field. */
final class ArrayMixedSpelling extends UnknownBase {
    Object[] mixedSpelling(Integer o) {
        return new Object[] {inherited, o, this.inherited};
    }
}
