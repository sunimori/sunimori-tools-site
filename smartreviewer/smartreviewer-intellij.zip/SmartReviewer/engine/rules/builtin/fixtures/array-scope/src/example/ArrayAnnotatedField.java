package example;

/** B16F: an undeclared name repeated in the value of an annotation of a field. */
final class ArrayAnnotatedField {
    @ArrayNames(names = {U, V, U})
    Object annotatedField;
}
