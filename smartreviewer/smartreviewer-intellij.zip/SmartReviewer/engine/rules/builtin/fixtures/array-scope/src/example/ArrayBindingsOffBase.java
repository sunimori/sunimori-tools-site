package example;

/**
 * The base class of ArrayBindingsOffCases, in a file of its own on purpose: without type bindings the review reads the file of a case
 * alone, so the fields declared here are not known there.
 */
class ArrayBindingsOffBase {
    protected Integer inh;
    protected Integer sx;
}
