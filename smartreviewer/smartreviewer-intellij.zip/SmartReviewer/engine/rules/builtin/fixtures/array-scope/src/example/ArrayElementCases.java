package example;

/**
 * Elements SR-JAVA-ARRAY-001 leaves out or treats in a special way, and the false positives that follow from it (cases N13, N14,
 * N16, B09, B11, B12, B21 to B25 and pm02 of rules/builtin/tests/SR-JAVA-ARRAY-001/suite.yaml).
 */
final class ArrayElementCases {
    enum Color { RED, GREEN }

    static int counter;
    static final Object LOCK = new Object();
    static final int BASE = 2;

    final int ic = 7;
    final int derived = BASE + 3;
    int count;

    /**
     * N13: compile-time constants that are not static, with a literal or a constant expression as the initializer: final locals and
     * final fields (default settings: no finding; pm02 switches the exclusion off: four findings).
     */
    int[] constants() {
        final int k = 3;
        final int sum = 2 + 3;
        int[] local = {k, k, k};
        int[] field = {ic, ic, ic};
        int[] localExpression = {sum, sum, sum};
        int[] fieldExpression = {derived, derived, derived};
        return local;
    }

    /** B21: elements that are not a direct read of a variable; the last array is the control (a is read directly twice). */
    Object[] skippedKinds(Integer[] row, boolean c, Integer a, Integer b, Object o, String s, int n) {
        Object[] arrayReads = {row[0], row[1], row[0]};
        Object[] conditionals = {c ? a : b, c ? a : b, o};
        Object[] creations = {new Object(), new Object(), o};
        Object[] selves = {this, this, o};
        Object[] classLiterals = {String.class, String.class, o};
        Runnable[] lambdas = {() -> { }, () -> { }, null};
        Object[] instanceOfs = {o instanceof String, o instanceof String, s};
        Object[] concatenations = {s + "x", s + "x", o};
        Object[] negations = {-n, -n, o};
        Object[] control = {a, c ? a : b, a};
        return control;
    }

    /** N14: another direct element increments or assigns the variable. */
    int[] changedShapes(int n, int m) {
        int[] prefix = {n, ++n, n};
        int[] decrement = {n, --n, n};
        int[] postfixDecrement = {n, n--, n};
        int[] assignment = {n, n = m, n};
        int[] compound = {n, n += 2, n};
        int[] changedLast = {n, n, n++};
        int[] changedFirst = {n++, n, n};
        return prefix;
    }

    /** N16: static fields in the spellings one might expect to be compared. */
    Object[] staticForms(ArrayElementCases other, Integer o) {
        Object[] qualified = {ArrayElementCases.counter, ArrayElementCases.counter, o};
        Object[] enumerators = {Color.RED, Color.RED, o};
        Object[] finalObject = {LOCK, LOCK, o};
        Object[] viaInstance = {other.counter, other.counter, o};
        return qualified;
    }

    /** B09: the findings come in the order of the variables' first occurrence (a before b), not of the second occurrence. */
    Object[] order(Integer a, Integer b, Integer c) {
        return new Object[] {a, b, b, a, c};
    }

    /** B11: a literal counts as an element, so this initializer is examined. */
    Object[] literalCounts(Integer a) {
        return new Object[] {a, a, 0};
    }

    /** B12: a trailing comma is no element, so this initializer is not examined. */
    Object[] trailingComma(Integer a) {
        return new Object[] {a, a, };
    }

    /** B22: next() changes count between the two reads; the rule does not see calls change a variable. */
    int[] changedByCall() {
        return new int[] {count, next(), count};
    }

    /** B23: a change hidden in a call, an index, a conditional, an operation or parentheses is not recognised. */
    int[] hiddenChanges(int n, int m, int[] xs, boolean c) {
        int[] viaCall = {n, id(n++), n};
        int[] viaIndex = {n, xs[n++], n};
        int[] viaConditional = {n, c ? n++ : 0, n};
        int[] viaOperation = {n, (n = 5) + 1, n};
        int[] viaParentheses = {n, (n++), n};
        int[] assignedInParentheses = {n, (n = m), n};
        return viaCall;
    }

    /** B24: a local that is never changed but is not final is no constant. */
    int[] notFinal() {
        int k = 3;
        return new int[] {k, k, k};
    }

    /**
     * B25: with the type bindings off none of these raises a limitation: a static field by its simple name, a final local and a final
     * field initialized with a literal, a variable another element changes (see ArrayBindingsOffCases for the shapes that do).
     */
    int[] exceptionsWithoutBindings(int n) {
        final int k = 3;
        int[] staticField = {counter, counter, counter};
        int[] constant = {k, k, k};
        int[] constantField = {ic, ic, ic};
        int[] changed = {n, n++, n};
        return staticField;
    }

    private int next() {
        return ++count;
    }

    private static int id(int v) {
        return v;
    }
}
