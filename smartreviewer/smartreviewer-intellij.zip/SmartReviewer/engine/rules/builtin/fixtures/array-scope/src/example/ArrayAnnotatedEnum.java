package example;

/** B16E: an undeclared name repeated in the value of an annotation of an enum constant. */
enum ArrayAnnotatedEnum {
    @ArrayNames(names = {U, V, U})
    FIRST
}
