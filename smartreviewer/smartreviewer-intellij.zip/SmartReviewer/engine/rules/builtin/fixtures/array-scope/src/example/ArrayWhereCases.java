package example;

import java.util.function.Supplier;

/**
 * Where SR-JAVA-ARRAY-001 looks for array initializers (cases P06 to P13 and P17 of rules/builtin/tests/SR-JAVA-ARRAY-001/suite.yaml):
 * every body a rule can reach, a variable declared in the method body, and every array type.
 */
final class ArrayWhereCases {
    Integer fx;
    Integer fy;

    /** P06: a constructor. */
    ArrayWhereCases(Integer a, Integer b) {
        Object[] t = {a, b, a};
    }

    /** P07: an instance initializer block. */
    {
        Integer x = 1;
        Integer y = 2;
        Object[] t = {x, y, x};
    }

    /** P08: a static initializer block. */
    static {
        Integer x = 1;
        Integer y = 2;
        Object[] t = {x, y, x};
    }

    /** P09: a field initializer. */
    Object[] fieldInit = {fx, fy, fx};

    /** P10: a lambda body. */
    Supplier<Object[]> lambda(Integer a, Integer b) {
        return () -> new Object[] {a, b, a};
    }

    /** P11: a method of an anonymous class. */
    Runnable anonymous(Integer a, Integer b) {
        return new Runnable() {
            @Override
            public void run() {
                Object[] t = {a, b, a};
            }
        };
    }

    /** P12: an initializer that is an argument of a call. */
    void callArgument(Integer a, Integer b) {
        use(new Object[] {a, b, a});
    }

    /** P13: a local variable declared in the body of the method (P01 and P02 read parameters). */
    Object[] localVariable(Integer b) {
        Integer l = Integer.valueOf(1);
        return new Object[] {l, b, l};
    }

    /** P17: an array of a primitive type. */
    int[] primitive(int a, int b) {
        return new int[] {a, b, a};
    }

    private static void use(Object o) {
    }
}
