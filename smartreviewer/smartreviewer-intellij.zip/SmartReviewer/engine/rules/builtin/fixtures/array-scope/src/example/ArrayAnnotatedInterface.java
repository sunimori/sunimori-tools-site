package example;

/** B16I: an undeclared name repeated in the value of an annotation of a method of an interface. */
interface ArrayAnnotatedInterface {
    @ArrayNames(names = {U, V, U})
    void annotated();
}
