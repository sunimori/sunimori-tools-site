package example;

/** B16D: an undeclared name repeated in the default value of a member of an annotation type. */
@interface ArrayAnnotatedDefault {
    String[] names() default {U, V, U};
}
