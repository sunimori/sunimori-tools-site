package example;

/**
 * Cases B10A and B10B of rules/builtin/tests/SR-JAVA-ARRAY-001/suite.yaml: the identity of a finding (and with it its fingerprint)
 * contains the number of the array initializer among the initializers of the same method.
 */
final class ArrayFingerprintCases {
    /** B10A: the only initializer of the method has the number 0. */
    Object[] single(Integer a, Integer b) {
        return new Object[] {a, b, a};
    }

    /** B10B: the same initializer after another one in the same method has the number 1. */
    Object[] second(Integer a, Integer b) {
        Object[] unrelated = {1, 2, 3};
        return new Object[] {a, b, a};
    }
}
