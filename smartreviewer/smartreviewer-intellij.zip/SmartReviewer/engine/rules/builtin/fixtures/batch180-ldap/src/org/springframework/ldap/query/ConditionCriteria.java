package org.springframework.ldap.query;

/** Stub (fixture only). */
public interface ConditionCriteria {
    ContainerCriteria is(String value);

    ContainerCriteria like(String value);
}
