package org.springframework.ldap.filter;

/** Stub (fixture only). */
public class AndFilter implements Filter {
    public AndFilter and(Filter query) {
        return this;
    }

    public String encode() {
        return "";
    }
}
