package org.owasp.esapi;

/** Stub (fixture only). */
public interface Encoder {
    String encodeForLDAP(String input);

    String encodeForDN(String input);

    String encodeForHTML(String input);
}
