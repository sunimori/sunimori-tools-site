package org.springframework.ldap.filter;

/** Stub (fixture only): the value is encoded for filters. */
public class EqualsFilter implements Filter {
    public EqualsFilter(String attribute, String value) {
    }

    public String encode() {
        return "";
    }
}
