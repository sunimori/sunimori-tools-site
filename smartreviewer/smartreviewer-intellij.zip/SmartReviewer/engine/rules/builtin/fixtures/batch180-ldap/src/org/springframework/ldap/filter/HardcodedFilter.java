package org.springframework.ldap.filter;

/** Stub (fixture only): the text is not encoded. */
public class HardcodedFilter implements Filter {
    public HardcodedFilter(String filter) {
    }

    public String encode() {
        return "";
    }
}
