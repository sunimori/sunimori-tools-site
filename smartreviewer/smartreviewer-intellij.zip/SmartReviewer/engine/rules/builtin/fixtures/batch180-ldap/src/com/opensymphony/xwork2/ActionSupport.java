package com.opensymphony.xwork2;

/** Stub of Struts 2 (fixture only). */
public class ActionSupport {
    public static final String SUCCESS = "success";
}
