package org.springframework.ldap.core;

/** Stub (fixture only). */
public interface ContextMapper<T> {
    T mapFromContext(Object ctx);
}
