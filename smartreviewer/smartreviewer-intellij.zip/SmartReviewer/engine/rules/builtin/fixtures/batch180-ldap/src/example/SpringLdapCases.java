package example;

import java.util.List;

import javax.naming.directory.SearchControls;
import javax.servlet.http.HttpServletRequest;

import com.unboundid.ldap.sdk.Filter;
import com.unboundid.ldap.sdk.LDAPException;

import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.ContextMapper;
import org.springframework.ldap.core.LdapOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.filter.HardcodedFilter;
import org.springframework.ldap.query.LdapQuery;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.ldap.support.LdapEncoder;
import org.springframework.security.ldap.SpringSecurityLdapTemplate;

/** Spring LDAP, Spring Security LDAP and UnboundID cases for SR-SEC-LDAP-INJECTION-001. */
public class SpringLdapCases {
    private LdapTemplate template;
    private LdapOperations operations;
    private SpringSecurityLdapTemplate securityTemplate;
    private AttributesMapper<String> names;
    private ContextMapper<String> contexts;

    // ------------------------------------------------------------------ P

    /** P: the filter of LdapTemplate.search. */
    List<String> templateFilter(HttpServletRequest request) {
        return template.search("", "(uid=" + request.getParameter("uid") + ")", names);
    }

    /** P: the base of the search. */
    List<String> templateBase(HttpServletRequest request) {
        return template.search("ou=" + request.getParameter("ou"), "(objectClass=person)", names);
    }

    /** P: the interface. */
    List<String> operationsFilter(HttpServletRequest request) {
        return operations.search("", "(cn=" + request.getParameter("cn") + ")", SearchControls.SUBTREE_SCOPE, names);
    }

    /** P: authenticate: the filter is injectable, the password is only checked by the bind. */
    boolean templateAuthenticate(HttpServletRequest request) {
        return template.authenticate("", "(uid=" + request.getParameter("uid") + ")", request.getParameter("password"));
    }

    /** P: searchForObject. */
    String templateSearchForObject(HttpServletRequest request) {
        return template.searchForObject("", String.format("(uid=%s)", request.getParameter("uid")), contexts);
    }

    /** P: Spring Security's template: the base and the filter are text, the arguments of the array are escaped. */
    Object securityTemplateFilter(HttpServletRequest request) {
        return securityTemplate.searchForSingleEntry("ou=people", "(uid=" + request.getParameter("uid") + ")", new Object[0]);
    }

    /** P: Spring Security's attribute search helper. */
    Object securityTemplateAttributes(HttpServletRequest request) {
        return securityTemplate.searchForSingleAttributeValues("ou=people", "(uid=" + request.getParameter("uid") + ")", new Object[0], "mail");
    }

    /** P: a hardcoded filter of the query builder. */
    LdapQuery builderFilter(HttpServletRequest request) {
        return LdapQueryBuilder.query().filter("(uid=" + request.getParameter("uid") + ")");
    }

    /** P: the format string of filter(format, params) is not escaped, only the params are. */
    LdapQuery builderFormat(HttpServletRequest request) {
        return LdapQueryBuilder.query().filter("(" + request.getParameter("attribute") + "={0})", "x");
    }

    /** P: the base of the query. */
    LdapQueryBuilder builderBase(HttpServletRequest request) {
        return LdapQueryBuilder.query().base("ou=" + request.getParameter("ou"));
    }

    /** P: Spring's HardcodedFilter is not encoded. */
    Object hardcodedFilter(HttpServletRequest request) {
        return new HardcodedFilter("(uid=" + request.getParameter("uid") + ")");
    }

    /** P: UnboundID parses the string. */
    Filter unboundIdCreate(HttpServletRequest request) throws LDAPException {
        return Filter.create("(uid=" + request.getParameter("uid") + ")");
    }

    /** P: a filter encoded for names is no filter encoding. */
    List<String> templateWrongEncoding(HttpServletRequest request) {
        return template.search("", "(uid=" + LdapEncoder.nameEncode(request.getParameter("uid")) + ")", names);
    }

    // ------------------------------------------------------------------ N

    /** N: the query builder encodes the value of is(). */
    List<String> builderIs(HttpServletRequest request) {
        return template.search(LdapQueryBuilder.query().where("uid").is(request.getParameter("uid")), names);
    }

    /** N: filter(format, params) encodes its params with LdapEncoder.filterEncode. */
    LdapQuery builderFormatParams(HttpServletRequest request) {
        return LdapQueryBuilder.query().filter("(&(objectClass=person)(uid={0}))", request.getParameter("uid"));
    }

    /** N: EqualsFilter and AndFilter encode their values. */
    List<String> filterObjects(HttpServletRequest request) {
        AndFilter filter = new AndFilter();
        filter.and(new EqualsFilter("objectClass", "person")).and(new EqualsFilter("uid", request.getParameter("uid")));
        return template.search("", filter.encode(), names);
    }

    /** N: the filter encoding for filters. */
    List<String> templateEncoded(HttpServletRequest request) {
        return template.search("", "(uid=" + LdapEncoder.filterEncode(request.getParameter("uid")) + ")", names);
    }

    /** N: Spring's name encoding for a name. */
    List<String> templateNameEncoded(HttpServletRequest request) {
        return template.search("cn=" + LdapEncoder.nameEncode(request.getParameter("cn")), "(objectClass=*)", names);
    }

    /** N: constants. */
    List<String> templateConstants() {
        return template.search("ou=people", "(objectClass=person)", names);
    }

    /** N: the password is the only request value of authenticate. */
    boolean templateAuthenticateFixed(HttpServletRequest request) {
        return template.authenticate("ou=people", "(uid=admin)", request.getParameter("password"));
    }

    /** N: the query object is built elsewhere. */
    List<String> templateQuery(LdapQuery query) {
        return template.search(query, names);
    }

    /** N: UnboundID's equality filter takes the value as it is. */
    Filter unboundIdEquality(HttpServletRequest request) {
        return Filter.createEqualityFilter("uid", request.getParameter("uid"));
    }

    /** N: Spring Security's array arguments are escaped. */
    Object securityTemplateParams(HttpServletRequest request) {
        return securityTemplate.searchForSingleEntry("ou=people", "(uid={0})", new Object[] {request.getParameter("uid")});
    }

    /** N: a parameter of the method. */
    List<String> templateFromParameter(String uid) {
        return template.search("", "(uid=" + uid + ")", names);
    }

    // ------------------------------------------------------------------ B

    /** B: the find method takes a Filter object, which is not text. */
    List<String> templateFindWithFilter(HttpServletRequest request) {
        return template.find(null, new HardcodedFilter("(uid=" + request.getParameter("uid") + ")"), new SearchControls(), String.class);
    }
}
