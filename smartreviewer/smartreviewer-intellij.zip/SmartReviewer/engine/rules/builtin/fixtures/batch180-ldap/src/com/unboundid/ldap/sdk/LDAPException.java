package com.unboundid.ldap.sdk;

/** Stub (fixture only). */
public class LDAPException extends Exception {
}
