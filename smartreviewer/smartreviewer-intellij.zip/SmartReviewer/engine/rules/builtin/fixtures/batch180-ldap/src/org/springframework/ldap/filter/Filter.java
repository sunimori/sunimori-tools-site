package org.springframework.ldap.filter;

/** Stub (fixture only). */
public interface Filter {
    String encode();
}
