package org.springframework.ldap.core;

import java.util.List;

import javax.naming.Name;
import javax.naming.directory.SearchControls;

import org.springframework.ldap.filter.Filter;
import org.springframework.ldap.query.LdapQuery;

/** Stub (fixture only). */
public interface LdapOperations {
    <T> List<T> search(String base, String filter, AttributesMapper<T> mapper);

    <T> List<T> search(Name base, String filter, AttributesMapper<T> mapper);

    <T> List<T> search(String base, String filter, int searchScope, AttributesMapper<T> mapper);

    <T> List<T> search(LdapQuery query, AttributesMapper<T> mapper);

    <T> T searchForObject(String base, String filter, ContextMapper<T> mapper);

    boolean authenticate(String base, String filter, String password);

    boolean authenticate(LdapQuery query, String password);

    <T> List<T> find(Name base, Filter filter, SearchControls searchControls, Class<T> clazz);

    <T> T lookup(String dn, AttributesMapper<T> mapper);
}
