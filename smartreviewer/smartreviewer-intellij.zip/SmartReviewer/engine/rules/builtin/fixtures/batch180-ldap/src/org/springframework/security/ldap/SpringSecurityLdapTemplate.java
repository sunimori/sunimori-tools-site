package org.springframework.security.ldap;

import org.springframework.ldap.core.LdapTemplate;

/** Stub (fixture only). */
public class SpringSecurityLdapTemplate extends LdapTemplate {
    public Object searchForSingleEntry(String base, String filter, Object[] params) {
        return null;
    }

    public java.util.Set<String> searchForSingleAttributeValues(String base, String filter, Object[] params, String attributeName) {
        return null;
    }
}
