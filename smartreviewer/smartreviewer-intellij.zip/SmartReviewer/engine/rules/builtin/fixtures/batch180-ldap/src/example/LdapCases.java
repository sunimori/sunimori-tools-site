package example;

import java.util.Map;
import java.util.Set;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.springframework.ldap.support.LdapEncoder;

/**
 * JNDI cases for SR-SEC-LDAP-INJECTION-001: request text in the filter or the base name of DirContext.search. P = reported,
 * N = not reported, B = near the edge (the expected result is in the suite).
 */
public class LdapCases {
    private static final String BASE = "ou=people,dc=example,dc=com";
    private static final Set<String> DEPARTMENTS = Set.of("sales", "dev");
    private static final Map<String, String> FILTERS = Map.of("staff", "(employeeType=staff)", "admin", "(employeeType=admin)");
    private final SearchControls controls = new SearchControls();
    private DirContext ctx;
    private LdapContext ldap;
    private String configuredFilter;

    // ------------------------------------------------------------------ P: request text in the filter or the base

    /** P: concatenation into the filter. */
    NamingEnumeration<SearchResult> filterConcat(HttpServletRequest request) throws NamingException {
        return ctx.search(BASE, "(uid=" + request.getParameter("uid") + ")", controls);
    }

    /** P: a filter built in a local first. */
    NamingEnumeration<SearchResult> filterLocal(HttpServletRequest request) throws NamingException {
        String uid = request.getParameter("uid");
        String filter = "(&(objectClass=person)(uid=" + uid + "))";
        return ctx.search(BASE, filter, controls);
    }

    /** P: String.format. */
    NamingEnumeration<SearchResult> filterFormat(HttpServletRequest request) throws NamingException {
        return ctx.search(BASE, String.format("(&(objectClass=person)(cn=%s))", request.getParameter("cn")), controls);
    }

    /** P: StringBuilder. */
    NamingEnumeration<SearchResult> filterBuilder(HttpServletRequest request) throws NamingException {
        StringBuilder filter = new StringBuilder("(&(objectClass=person)");
        filter.append("(sn=").append(request.getParameter("sn")).append("))");
        return ctx.search(BASE, filter.toString(), controls);
    }

    /** P: the base of the search is a name built from the request. */
    NamingEnumeration<SearchResult> baseName(HttpServletRequest request) throws NamingException {
        return ctx.search("ou=" + request.getParameter("dept") + ",dc=example,dc=com", "(objectClass=person)", controls);
    }

    /** P: both the base and the filter hold request text: one call, one finding. */
    NamingEnumeration<SearchResult> baseAndFilter(HttpServletRequest request) throws NamingException {
        return ctx.search("ou=" + request.getParameter("dept") + ",dc=example,dc=com", "(uid=" + request.getParameter("uid") + ")", controls);
    }

    /** P: LdapContext. */
    NamingEnumeration<SearchResult> ldapContext(HttpServletRequest request) throws NamingException {
        return ldap.search(BASE, "(mail=" + request.getParameter("mail") + ")", controls);
    }

    /** P: a context made in the method. */
    NamingEnumeration<SearchResult> initialContext(HttpServletRequest request) throws NamingException {
        DirContext local = new InitialLdapContext();
        return local.search(BASE, "(telephoneNumber=" + request.getParameter("tel") + ")", controls);
    }

    /** P: InitialDirContext used by its class. */
    NamingEnumeration<SearchResult> initialDirContext(HttpServletRequest request) throws NamingException {
        InitialDirContext local = new InitialDirContext();
        return local.search("", "(uid=" + request.getParameter("uid") + ")", controls);
    }

    /** P: the one-argument-less overload with a filter and controls through a path variable-like header. */
    NamingEnumeration<SearchResult> fromHeader(HttpServletRequest request) throws NamingException {
        return ctx.search(BASE, "(uid=" + request.getHeader("X-User") + ")", controls);
    }

    /** P: the search is in a loop. */
    void inLoop(HttpServletRequest request) throws NamingException {
        for (String uid : request.getParameterValues("uid")) {
            ctx.search(BASE, "(uid=" + uid + ")", controls);
        }
    }

    /** P: wrong escape: Rdn.escapeValue is for names, a filter value keeps * ( ). */
    NamingEnumeration<SearchResult> nameEscapeInFilter(HttpServletRequest request) throws NamingException {
        return ctx.search(BASE, "(uid=" + Rdn.escapeValue(request.getParameter("uid")) + ")", controls);
    }

    /** P: wrong escape: the filter encoding leaves commas and equal signs of a name. */
    NamingEnumeration<SearchResult> filterEscapeInName(HttpServletRequest request) throws NamingException {
        return ctx.search("uid=" + LdapEncoder.filterEncode(request.getParameter("uid")) + "," + BASE, "(objectClass=*)", controls);
    }

    /** P: a default for a missing parameter does not check the value that is there. */
    NamingEnumeration<SearchResult> withDefault(HttpServletRequest request) throws NamingException {
        String uid = request.getParameter("uid");
        if (uid == null) {
            uid = "guest";
        }
        return ctx.search(BASE, "(uid=" + uid + ")", controls);
    }

    /** P: the check holds in the other branch only. */
    NamingEnumeration<SearchResult> checkedInOtherBranch(HttpServletRequest request) throws NamingException {
        String dept = request.getParameter("dept");
        if (DEPARTMENTS.contains(dept)) {
            return ctx.search(BASE, "(ou=" + dept + ")", controls);
        }
        return ctx.search(BASE, "(ou=" + dept + ")", controls);
    }

    /** P: the filter is passed through a lambda. */
    void inLambda(HttpServletRequest request) {
        Runnable r = () -> {
            try {
                ctx.search(BASE, "(uid=" + request.getParameter("uid") + ")", controls);
            } catch (NamingException e) {
                throw new IllegalStateException(e);
            }
        };
        r.run();
    }

    // ------------------------------------------------------------------ N: the value is escaped, bound, fixed or checked

    /** N: the parameterized search: the provider escapes the arguments. */
    NamingEnumeration<SearchResult> parameterized(HttpServletRequest request) throws NamingException {
        return ctx.search(BASE, "(&(objectClass=person)(uid={0}))", new Object[] {request.getParameter("uid")}, controls);
    }

    /** N: the same for the base name that is a constant and two arguments. */
    NamingEnumeration<SearchResult> parameterizedTwo(HttpServletRequest request) throws NamingException {
        Object[] args = {request.getParameter("sn"), request.getParameter("givenName")};
        return ldap.search(BASE, "(&(sn={0})(givenName={1}))", args, controls);
    }

    /** N: constants. */
    NamingEnumeration<SearchResult> constants() throws NamingException {
        return ctx.search(BASE, "(objectClass=person)", controls);
    }

    /** N: a configured field. */
    NamingEnumeration<SearchResult> configured() throws NamingException {
        return ctx.search(BASE, configuredFilter, controls);
    }

    /** N: filter encoding. */
    NamingEnumeration<SearchResult> filterEncoded(HttpServletRequest request) throws NamingException {
        return ctx.search(BASE, "(uid=" + LdapEncoder.filterEncode(request.getParameter("uid")) + ")", controls);
    }

    /** N: name escaping where the text is a name. */
    NamingEnumeration<SearchResult> nameEscaped(HttpServletRequest request) throws NamingException {
        return ctx.search("uid=" + Rdn.escapeValue(request.getParameter("uid")) + "," + BASE, "(objectClass=*)", controls);
    }

    /** N: Spring's name encoding where the text is a name. */
    NamingEnumeration<SearchResult> nameEncoded(HttpServletRequest request) throws NamingException {
        return ctx.search("cn=" + LdapEncoder.nameEncode(request.getParameter("cn")) + "," + BASE, "(objectClass=*)", controls);
    }

    /** N: ESAPI for the filter. */
    NamingEnumeration<SearchResult> esapiFilter(HttpServletRequest request) throws NamingException {
        return ctx.search(BASE, "(uid=" + ESAPI.encoder().encodeForLDAP(request.getParameter("uid")) + ")", controls);
    }

    /** N: ESAPI for the name. */
    NamingEnumeration<SearchResult> esapiName(HttpServletRequest request) throws NamingException {
        return ctx.search("ou=" + ESAPI.encoder().encodeForDN(request.getParameter("dept")) + "," + BASE, "(objectClass=*)", controls);
    }

    /** N: the project's own escape function, known by its name. */
    NamingEnumeration<SearchResult> ownEscape(HttpServletRequest request) throws NamingException {
        return ctx.search(BASE, "(uid=" + escapeLdapValue(request.getParameter("uid")) + ")", controls);
    }

    /** N: a guard clause against a fixed set. */
    NamingEnumeration<SearchResult> allowList(HttpServletRequest request) throws NamingException {
        String dept = request.getParameter("dept");
        if (!DEPARTMENTS.contains(dept)) {
            return null;
        }
        return ctx.search(BASE, "(ou=" + dept + ")", controls);
    }

    /** N: letters and digits only. */
    NamingEnumeration<SearchResult> alphanumeric(HttpServletRequest request) throws NamingException {
        String uid = request.getParameter("uid");
        if (StringUtils.isAlphanumeric(uid)) {
            return ctx.search(BASE, "(uid=" + uid + ")", controls);
        }
        return null;
    }

    /** N: a full-match pattern. */
    NamingEnumeration<SearchResult> pattern(HttpServletRequest request) throws NamingException {
        String uid = request.getParameter("uid");
        if (!uid.matches("[A-Za-z0-9._-]{1,32}")) {
            throw new IllegalArgumentException("uid");
        }
        return ctx.search(BASE, "(uid=" + uid + ")", controls);
    }

    /** N: a number made of the parameter is no text. */
    NamingEnumeration<SearchResult> number(HttpServletRequest request) throws NamingException {
        int employeeNumber = Integer.parseInt(request.getParameter("no"));
        return ctx.search(BASE, "(employeeNumber=" + employeeNumber + ")", controls);
    }

    /** N: the filter is chosen from a table by the request (the key does not carry its text). */
    NamingEnumeration<SearchResult> table(HttpServletRequest request) throws NamingException {
        return ctx.search(BASE, FILTERS.getOrDefault(request.getParameter("type"), "(objectClass=person)"), controls);
    }

    /** N: the matching attributes form of search: the provider builds the filter and escapes the values. */
    NamingEnumeration<SearchResult> matchingAttributes(HttpServletRequest request) throws NamingException {
        BasicAttributes attributes = new BasicAttributes("uid", request.getParameter("uid"));
        return ctx.search(BASE, attributes);
    }

    /** N: a parameter of the method is whoever calls it. */
    NamingEnumeration<SearchResult> parameterOfTheMethod(String filter) throws NamingException {
        return ctx.search(BASE, filter, controls);
    }

    /** N: a Name object is built with the escaping of Rdn; its text is not followed. */
    NamingEnumeration<SearchResult> nameObject(HttpServletRequest request) throws Exception {
        LdapName name = new LdapName(BASE);
        name.add(new Rdn("uid", request.getParameter("uid")));
        return ctx.search(name, "(objectClass=*)", controls);
    }

    // ------------------------------------------------------------------ B: near the edge

    /** B: the check is a prefix test: it proves nothing. */
    NamingEnumeration<SearchResult> startsWithOnly(HttpServletRequest request) throws NamingException {
        String uid = request.getParameter("uid");
        if (uid.startsWith("u")) {
            return ctx.search(BASE, "(uid=" + uid + ")", controls);
        }
        return null;
    }

    /** B: an emptiness test is no check. */
    NamingEnumeration<SearchResult> notEmpty(HttpServletRequest request) throws NamingException {
        String uid = request.getParameter("uid");
        if (uid != null && !uid.isEmpty()) {
            return ctx.search(BASE, "(uid=" + uid + ")", controls);
        }
        return null;
    }

    /** B: only some of the request text is escaped: the other part still reaches the filter. */
    NamingEnumeration<SearchResult> halfEscaped(HttpServletRequest request) throws NamingException {
        String filter = "(&(uid=" + LdapEncoder.filterEncode(request.getParameter("uid")) + ")(ou=" + request.getParameter("ou") + "))";
        return ctx.search(BASE, filter, controls);
    }

    /** B: the filter value is escaped on one path only. */
    NamingEnumeration<SearchResult> escapedOnOnePath(HttpServletRequest request, boolean strict) throws NamingException {
        String uid = request.getParameter("uid");
        String value = strict ? LdapEncoder.filterEncode(uid) : uid;
        return ctx.search(BASE, "(uid=" + value + ")", controls);
    }

    /** B: the same value escaped for the base and used raw in the filter: the filter is reported. */
    NamingEnumeration<SearchResult> escapedForNameOnly(HttpServletRequest request) throws NamingException {
        String dept = request.getParameter("dept");
        return ctx.search("ou=" + Rdn.escapeValue(dept) + "," + BASE, "(ou=" + dept + ")", controls);
    }

    /** N: everything but letters and digits is removed: no special character is left for a filter or a name. */
    NamingEnumeration<SearchResult> cleanedToAlphanumeric(HttpServletRequest request) throws NamingException {
        String uid = request.getParameter("uid").replaceAll("[^a-zA-Z0-9]", "");
        return ctx.search("uid=" + uid + "," + BASE, "(uid=" + uid + ")", controls);
    }

    /** N: the characters of a filter are all removed. */
    NamingEnumeration<SearchResult> cleanedFilterCharacters(HttpServletRequest request) throws NamingException {
        String uid = request.getParameter("uid").replaceAll("[*()\\\\\\x00]", "");
        return ctx.search(BASE, "(uid=" + uid + ")", controls);
    }

    /** B: the backslash is left, and it escapes the next character of a filter. */
    NamingEnumeration<SearchResult> cleanedPartly(HttpServletRequest request) throws NamingException {
        String uid = request.getParameter("uid").replaceAll("[*()]", "");
        return ctx.search(BASE, "(uid=" + uid + ")", controls);
    }

    /** B: the characters of a name are removed, those of a filter are not. */
    NamingEnumeration<SearchResult> cleanedForNameOnly(HttpServletRequest request) throws NamingException {
        String uid = request.getParameter("uid").replaceAll("[,+\"<>;=\\\\]", "");
        return ctx.search("uid=" + uid + "," + BASE, "(uid=" + uid + ")", controls);
    }

    private static String escapeLdapValue(String value) {
        return value.replace("*", "\\2a").replace("(", "\\28").replace(")", "\\29").replace("\\", "\\5c");
    }
}
