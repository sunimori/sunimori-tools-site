package org.springframework.ldap.core;

import java.util.List;

import javax.naming.Name;
import javax.naming.directory.SearchControls;

import org.springframework.ldap.filter.Filter;
import org.springframework.ldap.query.LdapQuery;

/** Stub (fixture only). */
public class LdapTemplate implements LdapOperations {
    public <T> List<T> search(String base, String filter, AttributesMapper<T> mapper) {
        return null;
    }

    public <T> List<T> search(Name base, String filter, AttributesMapper<T> mapper) {
        return null;
    }

    public <T> List<T> search(String base, String filter, int searchScope, AttributesMapper<T> mapper) {
        return null;
    }

    public <T> List<T> search(LdapQuery query, AttributesMapper<T> mapper) {
        return null;
    }

    public <T> T searchForObject(String base, String filter, ContextMapper<T> mapper) {
        return null;
    }

    public boolean authenticate(String base, String filter, String password) {
        return false;
    }

    public boolean authenticate(LdapQuery query, String password) {
        return false;
    }

    public <T> List<T> find(Name base, Filter filter, SearchControls searchControls, Class<T> clazz) {
        return null;
    }

    public <T> T lookup(String dn, AttributesMapper<T> mapper) {
        return null;
    }
}
