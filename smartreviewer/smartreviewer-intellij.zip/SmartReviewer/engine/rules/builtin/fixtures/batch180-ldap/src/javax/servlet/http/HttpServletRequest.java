package javax.servlet.http;

import javax.servlet.ServletRequest;

/** Stub (fixture only). */
public interface HttpServletRequest extends ServletRequest {
    String getHeader(String name);

    String getPathInfo();
}
