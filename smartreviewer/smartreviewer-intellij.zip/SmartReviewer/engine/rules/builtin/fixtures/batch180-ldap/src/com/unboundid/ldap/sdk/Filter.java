package com.unboundid.ldap.sdk;

/** Stub (fixture only). */
public final class Filter {
    private Filter() {
    }

    public static Filter create(String filterString) throws LDAPException {
        return null;
    }

    public static Filter createEqualityFilter(String attributeName, String assertionValue) {
        return null;
    }
}
