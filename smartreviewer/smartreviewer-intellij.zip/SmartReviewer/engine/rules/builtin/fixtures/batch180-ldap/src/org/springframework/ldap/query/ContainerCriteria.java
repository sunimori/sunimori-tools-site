package org.springframework.ldap.query;

/** Stub (fixture only). */
public interface ContainerCriteria extends LdapQuery {
    ConditionCriteria and(String attribute);
}
