package example;

import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;

import com.opensymphony.xwork2.ActionSupport;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/** Spring MVC, Struts 2 and JSF cases for SR-SEC-LDAP-INJECTION-001. */
public class FrameworkLdapCases {
    private static final String BASE = "ou=people,dc=example,dc=com";

    /** Directory access the container injects. */
    public interface DirectoryService {
        String userFilter(String name);
    }

    /** Spring MVC handlers. */
    @Controller
    public static class Handlers {
        private DirContext ctx;
        private final SearchControls controls = new SearchControls();

        /** P: a request parameter in the filter. */
        @GetMapping("/find")
        public Object find(@RequestParam("uid") String uid) throws NamingException {
            return ctx.search(BASE, "(uid=" + uid + ")", controls);
        }

        /** P: a parameter bound without an annotation name. */
        @GetMapping("/bound")
        public Object bound(@RequestParam String cn) throws NamingException {
            return ctx.search(BASE, "(cn=" + cn + ")", controls);
        }

        /** N: the parameterized search. */
        @GetMapping("/safe")
        public Object parameterized(@RequestParam String uid) throws NamingException {
            return ctx.search(BASE, "(uid={0})", new Object[] {uid}, controls);
        }

        /** N: a number. */
        @GetMapping("/num")
        public Object number(@RequestParam long employeeNumber) throws NamingException {
            return ctx.search(BASE, "(employeeNumber=" + employeeNumber + ")", controls);
        }
    }

    /** A Struts 2 action: text properties are filled from the request, the injected service is not. */
    public static class SearchAction extends ActionSupport {
        private DirectoryService directory;
        private DirContext ctx;
        private String uid;

        public void setDirectory(DirectoryService directory) {
            this.directory = directory;
        }

        public void setUid(String uid) {
            this.uid = uid;
        }

        /** P: the property is request data. */
        public String byProperty() throws NamingException {
            ctx.search(BASE, "(uid=" + uid + ")", new SearchControls());
            return SUCCESS;
        }

        /** N: the service decides. */
        public String byService() throws NamingException {
            ctx.search(BASE, directory.userFilter("admin"), new SearchControls());
            return SUCCESS;
        }
    }

    /** A JSF bean. */
    @ManagedBean
    public static class SearchBean {
        @ManagedProperty("#{param.uid}")
        private String uid;
        @ManagedProperty("#{directoryService}")
        private DirectoryService directory;
        private DirContext ctx;

        public void setUid(String uid) {
            this.uid = uid;
        }

        public void setDirectory(DirectoryService directory) {
            this.directory = directory;
        }

        /** P: the request parameter of @ManagedProperty. */
        public Object search() throws NamingException {
            return ctx.search(BASE, "(uid=" + uid + ")", new SearchControls());
        }

        /** N: the injected bean. */
        public Object searchWithService() throws NamingException {
            return ctx.search(BASE, directory.userFilter("x"), new SearchControls());
        }
    }
}
