package example;

import java.text.MessageFormat;
import java.util.Optional;
import java.util.Objects;
import java.util.Set;
import java.util.Hashtable;

import javax.naming.CompositeName;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.servlet.http.HttpServletRequest;

import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;

/**
 * Forms written while hunting for defects of SR-SEC-LDAP-INJECTION-001 (builders, formats, character removal, helpers and other calls). The expected result of each method is a case of its suite.
 */
public class ProbeLdapA {
    static final Set<String> USERS = Set.of("a", "b");
    DirContext ctx;
    LdapTemplate template;
    AttributesMapper<String> mapper;
    SearchControls sc = new SearchControls();

    void l01(HttpServletRequest rq) throws NamingException {
        String uid = Optional.ofNullable(rq.getParameter("u")).orElse("guest");
        ctx.search("", "(uid=" + uid + ")", sc);
    }

    void l02(HttpServletRequest rq) throws NamingException {
        StringBuilder f = new StringBuilder("(|");
        for (String u : rq.getParameterValues("u")) {
            f.append("(uid=").append(u).append(")");
        }
        f.append(")");
        ctx.search("", f.toString(), sc);
    }

    void l03(HttpServletRequest rq) throws NamingException {
        ctx.search("", MessageFormat.format("(uid={0})", rq.getParameter("u")), sc);
    }

    void l04(HttpServletRequest rq) throws NamingException {
        String uid = rq.getParameter("u").replace("*", "");
        ctx.search("", "(uid=" + uid + ")", sc);
    }

    void l05(HttpServletRequest rq) throws NamingException {
        String uid = rq.getParameter("u").replace("*", "").replace("(", "").replace(")", "");
        ctx.search("", "(uid=" + uid + ")", sc);
    }

    void l06(HttpServletRequest rq) throws NamingException {
        String uid = rq.getParameter("u").replaceAll("[^a-zA-Z0-9]", "");
        ctx.search("", "(uid=" + uid + ")", sc);
    }

    void l07(HttpServletRequest rq) throws NamingException {
        String uid = rq.getParameter("u").replaceAll("\\W", "_");
        ctx.search("", "(uid=" + uid + ")", sc);
    }

    void l08(HttpServletRequest rq) throws NamingException {
        String uid = rq.getParameter("u").trim().toLowerCase();
        ctx.search("", "(uid=" + uid + ")", sc);
    }

    void l09(HttpServletRequest rq) throws NamingException {
        String v = switch (rq.getParameter("t")) {
            case "staff" -> "(employeeType=staff)";
            case "admin" -> "(employeeType=admin)";
            default -> "(objectClass=none)";
        };
        ctx.search("", v, sc);
    }

    void l10(HttpServletRequest rq) throws NamingException {
        ctx.search("", "(uid=" + Objects.requireNonNullElse(rq.getParameter("u"), "guest") + ")", sc);
    }

    void l11(HttpServletRequest rq) throws NamingException {
        String u = rq.getParameter("u");
        String f = USERS.contains(u) ? "(uid=" + u + ")" : "(objectClass=none)";
        ctx.search("", f, sc);
    }

    void l12(HttpServletRequest rq) throws NamingException {
        String u = (String) rq.getAttribute("user");
        ctx.search("", "(uid=" + u + ")", sc);
    }

    void l13(HttpServletRequest rq) throws NamingException {
        helper("(uid=" + rq.getParameter("u") + ")");
    }

    void helper(String filter) throws NamingException {
        ctx.search("", filter, sc);
    }

    void l14(HttpServletRequest rq) throws NamingException {
        ctx.search(new CompositeName("ou=" + rq.getParameter("o")), "(objectClass=*)", sc);
    }

    void l15(HttpServletRequest rq) throws NamingException {
        String u = rq.getParameter("u");
        ctx.search("", "(objectClass=*)", sc);
        ctx.search("", "(uid=" + u + ")", sc);
    }

    void l16(HttpServletRequest rq) throws NamingException {
        String u = rq.getParameter("u");
        String f = u != null ? "(uid=" + u + ")" : "(objectClass=*)";
        ctx.search("", f, sc);
    }

    void l17(HttpServletRequest rq) throws NamingException {
        ctx.lookup("uid=" + rq.getParameter("u") + ",ou=people");
    }

    void l18(HttpServletRequest rq) throws NamingException {
        Hashtable<String, String> env = new Hashtable<>();
        env.put(Context.SECURITY_PRINCIPAL, "uid=" + rq.getParameter("u") + ",ou=people");
        new InitialDirContext(env);
    }

    void l19(HttpServletRequest rq) {
        template.search("", String.valueOf("(uid=" + rq.getParameter("u") + ")"), mapper);
    }

    void l20(HttpServletRequest rq) throws NamingException {
        String u = rq.getParameter("u");
        try {
            ctx.search("", "(uid=" + u + ")", sc);
        } finally {
            ctx.close();
        }
    }

    void l21(HttpServletRequest rq) throws NamingException {
        String u = rq.getParameter("u");
        if (!u.matches("[a-z]+")) {
            return;
        }
        ctx.search("", "(uid=" + u + ")", sc);
    }

    void l22(HttpServletRequest rq) throws NamingException {
        String u = rq.getParameter("u");
        if (u.matches("[a-z]+")) {
            ctx.search("", "(uid=" + u + ")", sc);
        } else {
            ctx.search("", "(uid=" + u + ")", sc);
        }
    }

    void l23(HttpServletRequest rq) throws NamingException {
        String[] parts = rq.getParameter("dn").split(",");
        ctx.search(parts[0] + ",dc=example", "(objectClass=*)", sc);
    }
}
