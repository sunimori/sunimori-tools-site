package example;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchResult;
import javax.servlet.http.HttpServletRequest;

/**
 * What an independent verifier found in the text of SR-SEC-LDAP-INJECTION-001: the matching-attributes form of search does not
 * report the attribute values (the provider builds the filter and escapes them), but its first argument is the search base, and a
 * base that comes from the request is reported like in every other form.
 */
public class ProbeLdapD {
    private static final String BASE = "ou=people,dc=example,dc=com";
    private DirContext ctx;

    /** N: the values are the request's, the base is fixed. */
    NamingEnumeration<SearchResult> attributesWithFixedBase(HttpServletRequest request) throws NamingException {
        return ctx.search(BASE, new BasicAttributes("uid", request.getParameter("uid")));
    }

    /** P: the base is the request's, the attributes are fixed. */
    NamingEnumeration<SearchResult> attributesWithRequestBase(HttpServletRequest request) throws NamingException {
        return ctx.search(request.getParameter("base"), new BasicAttributes("objectClass", "person"));
    }

    /** P: the base is built from the request, the values too: the base is the one that is reported. */
    NamingEnumeration<SearchResult> attributesWithBuiltBase(HttpServletRequest request) throws NamingException {
        return ctx.search("ou=" + request.getParameter("dept") + ",dc=example,dc=com", new BasicAttributes("uid", request.getParameter("uid")));
    }
}
