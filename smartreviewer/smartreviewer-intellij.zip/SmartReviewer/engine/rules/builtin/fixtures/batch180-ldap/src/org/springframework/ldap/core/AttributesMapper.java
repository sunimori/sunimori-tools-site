package org.springframework.ldap.core;

import javax.naming.directory.Attributes;

/** Stub (fixture only). */
public interface AttributesMapper<T> {
    T mapFromAttributes(Attributes attributes);
}
