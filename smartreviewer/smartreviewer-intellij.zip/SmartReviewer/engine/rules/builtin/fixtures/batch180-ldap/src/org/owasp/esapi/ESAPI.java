package org.owasp.esapi;

/** Stub (fixture only). */
public final class ESAPI {
    private ESAPI() {
    }

    public static Encoder encoder() {
        return null;
    }
}
