package org.springframework.ldap.query;

import javax.naming.Name;

import org.springframework.ldap.filter.Filter;

/** Stub (fixture only). */
public class LdapQueryBuilder implements LdapQuery {
    public static LdapQueryBuilder query() {
        return new LdapQueryBuilder();
    }

    public LdapQueryBuilder base(String baseDn) {
        return this;
    }

    public LdapQueryBuilder base(Name baseDn) {
        return this;
    }

    public ConditionCriteria where(String attribute) {
        return null;
    }

    public LdapQuery filter(String hardcodedFilter) {
        return this;
    }

    public LdapQuery filter(String filterFormat, Object... params) {
        return this;
    }

    public LdapQuery filter(Filter filter) {
        return this;
    }
}
