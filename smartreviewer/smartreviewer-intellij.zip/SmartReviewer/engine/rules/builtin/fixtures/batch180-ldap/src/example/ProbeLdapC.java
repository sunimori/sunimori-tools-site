package example;

import java.util.HashMap;
import java.util.Map;

import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.servlet.http.HttpServletRequest;

/** More forms for SR-SEC-LDAP-INJECTION-001: arrow switch bodies, maps, records, anonymous classes, fully qualified types. */
public class ProbeLdapC {
    DirContext ctx;
    javax.naming.directory.DirContext fqCtx;
    SearchControls sc = new SearchControls();

    record Q(String uid) {
    }

    void a02(HttpServletRequest rq) throws NamingException {
        String u = rq.getParameter("u");
        switch (rq.getParameter("m")) {
            case "x" -> ctx.search("", "(uid=" + u + ")", sc);
            default -> { }
        }
    }

    void b02(HttpServletRequest rq) throws NamingException {
        Map<String, String> m = new HashMap<>();
        m.put("uid", rq.getParameter("u"));
        ctx.search("", "(uid=" + m.get("uid") + ")", sc);
    }

    void b03(HttpServletRequest rq) throws NamingException {
        Map<String, String> m = Map.of("a", "(x=1)");
        ctx.search("", m.get(rq.getParameter("k")), sc);
    }

    void d01(HttpServletRequest rq) throws NamingException {
        Q q = new Q(rq.getParameter("u"));
        ctx.search("", "(uid=" + q.uid() + ")", sc);
    }

    void e02(HttpServletRequest rq) throws NamingException {
        fqCtx.search("", new StringBuilder().append("(uid=").append(rq.getParameter("u")).append(")").toString(), sc);
    }

    void h01(HttpServletRequest rq) throws NamingException {
        new Object() {
            void run() throws NamingException {
                ctx.search("", "(uid=" + rq.getParameter("u") + ")", sc);
            }
        }.run();
    }
}
