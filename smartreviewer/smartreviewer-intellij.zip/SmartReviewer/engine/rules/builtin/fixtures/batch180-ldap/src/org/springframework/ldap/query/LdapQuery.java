package org.springframework.ldap.query;

/** Stub (fixture only). */
public interface LdapQuery {
}
