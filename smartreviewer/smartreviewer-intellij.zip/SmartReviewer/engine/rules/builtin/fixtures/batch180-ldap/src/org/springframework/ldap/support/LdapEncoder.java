package org.springframework.ldap.support;

/** Stub (fixture only). */
public final class LdapEncoder {
    private LdapEncoder() {
    }

    public static String filterEncode(String value) {
        return value;
    }

    public static String nameEncode(String value) {
        return value;
    }
}
