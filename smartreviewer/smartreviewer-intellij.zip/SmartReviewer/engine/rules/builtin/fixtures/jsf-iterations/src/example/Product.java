package example;

import java.math.BigDecimal;

/** A record: every value is exactly a Product, so a member it lacks is reported. */
public record Product(String name, BigDecimal price, String code) {
}
