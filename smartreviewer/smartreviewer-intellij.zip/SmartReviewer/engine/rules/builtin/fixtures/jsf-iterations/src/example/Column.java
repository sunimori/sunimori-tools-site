package example;

/** The model of a dynamic column (p:columns). */
public record Column(String title, String key) {
}
