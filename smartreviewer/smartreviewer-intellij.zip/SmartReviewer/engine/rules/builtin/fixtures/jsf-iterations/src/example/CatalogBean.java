package example;

import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/** Values the pages iterate with keys and indexes, and the rows and columns of PrimeFaces tables. */
@Named("catalog")
@RequestScoped
public class CatalogBean {
    public String getCategory() {
        return "books";
    }

    public Map<String, List<Product>> getByCategory() {
        return Map.of();
    }

    public List<List<Product>> getPages() {
        return List.of();
    }

    public Product[][] getGrid() {
        return new Product[0][];
    }

    public Map<String, Product> getFeatured() {
        return Map.of();
    }

    public List<Product> getProducts() {
        return List.of();
    }

    public List<Column> getColumns() {
        return List.of();
    }

    public Set<String> getTags() {
        return Set.of();
    }

    public List<Product> find(int page) {
        return List.of();
    }
}
