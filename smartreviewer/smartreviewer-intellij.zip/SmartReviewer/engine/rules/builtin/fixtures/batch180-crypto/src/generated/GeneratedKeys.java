package generated;

/** Source that a generator wrote: the credential rule does not read the folders called generated. */
public final class GeneratedKeys {
    private GeneratedKeys() { }

    public static final String SECRET_KEY = "abcdefghijklmnop";
}
