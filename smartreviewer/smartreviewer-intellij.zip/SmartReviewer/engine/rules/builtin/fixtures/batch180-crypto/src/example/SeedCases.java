package example;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Date;
import java.util.Random;
import java.util.UUID;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

/** Seeds of SecureRandom: the SHA1PRNG that a predictable seed turns into a function of that seed (the rule reports) and every other seeding. */
public class SeedCases {
    private static final long SEED = 20240101L;
    private static final String PASSPHRASE = "correct horse battery staple";
    static final SecureRandom SHARED;

    static {
        SecureRandom random;
        try {
            random = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
        random.setSeed(SEED);
        SHARED = random;
    }

    // ---- SHA1PRNG with a constant or the clock before the first output: reported --------------------------------------------
    public int constantLong() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(12345L);
        return random.nextInt();
    }

    public int constantField() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(SEED);
        return random.nextInt();
    }

    public byte[] constantBytes() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "SUN");
        random.setSeed(PASSPHRASE.getBytes());
        byte[] token = new byte[16];
        random.nextBytes(token);
        return token;
    }

    public SecretKey keyFromAConstantSeed() throws Exception {
        KeyGenerator generator = KeyGenerator.getInstance("AES");
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed("not so secret".getBytes());
        generator.init(128, random);
        return generator.generateKey();
    }

    public int clockMillis() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(System.currentTimeMillis());
        return random.nextInt();
    }

    public int clockNanos() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(System.nanoTime());
        return random.nextInt();
    }

    public int clockDate() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(new Date().getTime());
        return random.nextInt();
    }

    public int clockAsText() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(String.valueOf(System.currentTimeMillis()).getBytes());
        return random.nextInt();
    }

    public int sunProviderObject() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG", Security.getProvider("SUN"));
        random.setSeed(12345L);
        return random.nextInt();
    }

    public int seedAfterAZeroSeed() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(0L);
        random.setSeed(77L);
        return random.nextInt();
    }

    public int fallbackInTheCatch() {
        SecureRandom random;
        try {
            random = SecureRandom.getInstance("SHA1PRNG");
        } catch (NoSuchAlgorithmException e) {
            random = new SecureRandom();
        }
        random.setSeed(7L);
        return random.nextInt();
    }

    public SecureRandom seededFactory() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(99L);
        return random;
    }

    // ---- everything else: not reported ----------------------------------------------------------------------------------------
    public int defaultGenerator() {
        SecureRandom random = new SecureRandom();
        random.setSeed(12345L);
        return random.nextInt();
    }

    public int seedInTheConstructor() {
        return new SecureRandom(new byte[] {1, 2, 3}).nextInt();
    }

    public int clockSeedInTheConstructor() {
        return new SecureRandom(String.valueOf(System.nanoTime()).getBytes()).nextInt();
    }

    public int constructorSeedFromAParameter(byte[] seed) {
        return new SecureRandom(seed).nextInt();
    }

    public int constructorSeedThenTheSystemsSeed() {
        SecureRandom random = new SecureRandom(new byte[] {1, 2, 3});
        random.setSeed(random.generateSeed(16));
        return random.nextInt();
    }

    public int zeroSeed() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(0);
        return random.nextInt();
    }

    public int zeroSeedFromConstants() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(SEED - SEED);
        return random.nextInt();
    }

    public int otherProviderObject() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG", Security.getProvider("SunJCE"));
        random.setSeed(1L);
        return random.nextInt();
    }

    public int nativeGenerator() throws Exception {
        SecureRandom random = SecureRandom.getInstance("NativePRNG");
        random.setSeed(12345L);
        return random.nextInt();
    }

    public int drbgGenerator() throws Exception {
        SecureRandom random = SecureRandom.getInstance("DRBG");
        random.setSeed(12345L);
        return random.nextInt();
    }

    public int noSeed() throws Exception {
        return SecureRandom.getInstance("SHA1PRNG").nextInt();
    }

    public int seedAfterTheFirstOutput() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        int first = random.nextInt();
        random.setSeed(12345L);
        return first;
    }

    public int strongSeed() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(random.generateSeed(20));
        return random.nextInt();
    }

    public int constantThenStrongSeed() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(1L);
        random.setSeed(random.generateSeed(20));
        return random.nextInt();
    }

    public int seedFromAParameter(long seed) throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(seed);
        return random.nextInt();
    }

    public int seedFromAPassword(String password) throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(password.getBytes());
        return random.nextInt();
    }

    // ---- boundary: looks similar, is judged by what it really is -------------------------------------------------------------------
    public int seedFromAnotherGenerator() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(new Random().nextLong());
        return random.nextInt();
    }

    public int seedFromRandomUuid() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(UUID.randomUUID().getMostSignificantBits());
        return random.nextInt();
    }

    public int clockWithSomethingUnknown(long salt) throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(System.currentTimeMillis() ^ salt);
        return random.nextInt();
    }

    public void handedOnBeforeTheSeed(KeyGenerator generator) throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        generator.init(128, random);
        random.setSeed(1L);
    }

    public Runnable seededInALambda() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        return () -> random.setSeed(1L);
    }

    public int otherProvider() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "BC");
        random.setSeed(1L);
        return random.nextInt();
    }

    public int utilRandom() {
        Random random = new Random();
        random.setSeed(1L);
        return random.nextInt();
    }

    public int algorithmFromAParameter(String algorithm) throws Exception {
        SecureRandom random = SecureRandom.getInstance(algorithm);
        random.setSeed(1L);
        return random.nextInt();
    }
}
