package example;

/** A class whose file name ends in Test.java: the credential rule does not read it, whatever it holds. */
public final class KeyHolderTest {
    private KeyHolderTest() { }

    public static final String SECRET_KEY = "ponmlkjihgfedcba";
}
