package javax.xml.bind;

/** A stub of the JAXB class that Java 8 projects use to decode hex and base64 text. */
public final class DatatypeConverter {
    private DatatypeConverter() { }
    public static byte[] parseHexBinary(String text) { return new byte[text.length() / 2]; }
    public static byte[] parseBase64Binary(String text) { return new byte[text.length() * 3 / 4]; }
}
