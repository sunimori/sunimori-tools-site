package example;

import java.io.UnsupportedEncodingException;
import java.security.SecureRandom;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Keys and passwords that are assigned in more than one place: the static initializer, the constructors, the two branches of an
 * {@code if}, and the {@code try} that older code needs around {@code getBytes("UTF-8")}. The names of the variables say nothing
 * about a secret, so the credential rule leaves them to this one.
 */
public class HardcodedKeyAssignedCases {
    private static final byte[] STATIC_BLOCK_BYTES;
    private static final byte[] LEGACY_STATIC_BYTES;
    private static final char[] STATIC_BLOCK_CHARS;
    private static final byte[] RANDOM_STATIC_BYTES;

    static {
        STATIC_BLOCK_BYTES = new byte[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
        try {
            LEGACY_STATIC_BYTES = "0123456789abcdef".getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
        STATIC_BLOCK_CHARS = "changeit".toCharArray();
        RANDOM_STATIC_BYTES = new byte[16];
        new SecureRandom().nextBytes(RANDOM_STATIC_BYTES);
    }

    private final byte[] material;
    private final byte[] givenMaterial;

    public HardcodedKeyAssignedCases() {
        material = "fedcba9876543210".getBytes();
        givenMaterial = new byte[16];
    }

    public HardcodedKeyAssignedCases(byte[] given) {
        material = "fedcba9876543210".getBytes();
        givenMaterial = given;
    }

    // ---- written in the source: reported -----------------------------------------------------------------------------
    public SecretKeySpec staticBlockKey() {
        return new SecretKeySpec(STATIC_BLOCK_BYTES, "AES");
    }

    public SecretKeySpec staticBlockTryKey() {
        return new SecretKeySpec(LEGACY_STATIC_BYTES, "AES");
    }

    public PBEKeySpec staticBlockPassword() {
        return new PBEKeySpec(STATIC_BLOCK_CHARS);
    }

    public SecretKeySpec constructorKey() {
        return new SecretKeySpec(material, "AES");
    }

    public SecretKeySpec legacyLocalKey() {
        byte[] bytes;
        try {
            bytes = "0123456789abcdef".getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
        return new SecretKeySpec(bytes, "AES");
    }

    public SecretKeySpec branchKey(boolean legacy) {
        String text;
        if (legacy) {
            text = "0123456789abcdef";
        } else {
            text = "fedcba9876543210";
        }
        return new SecretKeySpec(text.getBytes(), "AES");
    }

    // ---- can change: not reported ------------------------------------------------------------------------------------
    public SecretKeySpec randomStaticBlockKey() {
        return new SecretKeySpec(RANDOM_STATIC_BYTES, "AES");
    }

    public SecretKeySpec constructorParameterKey() {
        return new SecretKeySpec(givenMaterial, "AES");
    }

    public SecretKeySpec branchWithParameterKey(boolean given, String text) {
        String chosen;
        if (given) {
            chosen = text;
        } else {
            chosen = "fedcba9876543210";
        }
        return new SecretKeySpec(chosen.getBytes(), "AES");
    }

    // ---- boundary: shapes the check does not follow ------------------------------------------------------------------
    public SecretKeySpec stringBuilderKey() {
        return new SecretKeySpec(new StringBuilder("0123456789abcdef").toString().getBytes(), "AES");
    }

    public SecretKeySpec loopFilledKey() {
        byte[] bytes = new byte[16];
        for (int i = 0; i < bytes.length; i++) {
            bytes[i] = (byte) i;
        }
        return new SecretKeySpec(bytes, "AES");
    }
}
