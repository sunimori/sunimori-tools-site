package example;

import java.security.SecureRandom;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.SSLContext;

/**
 * Values from a library that is not on the class path (Vault, Config and Time exist nowhere in this project). The rules cannot see what
 * these values are; they say so (the review of the file is incomplete for the rule) instead of staying silent as if they had looked.
 */
public class UnresolvedCases {
    public IvParameterSpec unresolvedIv() {
        return new IvParameterSpec(Vault.iv());
    }

    public SecretKeySpec unresolvedKey() {
        return new SecretKeySpec(Vault.key(), "AES");
    }

    public SSLContext unresolvedProtocol() throws Exception {
        return SSLContext.getInstance(Config.protocol());
    }

    public int unresolvedSeed() throws Exception {
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        random.setSeed(Time.now());
        return random.nextInt();
    }
}
