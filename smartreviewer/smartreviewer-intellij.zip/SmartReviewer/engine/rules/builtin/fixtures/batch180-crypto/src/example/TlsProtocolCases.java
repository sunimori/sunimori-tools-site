package example;

import java.security.SecureRandom;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Supplier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;

/** The protocol versions of SSL and TLS that code selects: the deprecated ones (the rule reports) and the current ones (it does not). */
public class TlsProtocolCases {
    private static final String LEGACY = "TLSv1";
    private static final String[] OLD_AND_NEW = {"TLSv1", "TLSv1.1", "TLSv1.2"};
    public static final SSLParameters LEGACY_PARAMETERS = new SSLParameters(null, new String[] {"TLSv1.1"});

    // ---- deprecated: reported ---------------------------------------------------------------------------------------------
    public SSLContext contextTlsV1(TrustManager[] trust) throws Exception {
        SSLContext context = SSLContext.getInstance("TLSv1");
        context.init(null, trust, new SecureRandom());
        return context;
    }

    public SSLContext contextTlsV11() throws Exception {
        return SSLContext.getInstance("TLSv1.1");
    }

    public SSLContext contextSslV3() throws Exception {
        return SSLContext.getInstance("SSLv3");
    }

    public SSLContext contextFromConstant() throws Exception {
        return SSLContext.getInstance(LEGACY);
    }

    public void enabledOnSocket(SSLSocket socket) {
        socket.setEnabledProtocols(new String[] {"SSLv3", "TLSv1"});
    }

    public void enabledOnServerSocket(SSLServerSocket socket) {
        socket.setEnabledProtocols(OLD_AND_NEW);
    }

    public void enabledOnEngine(SSLEngine engine) {
        engine.setEnabledProtocols(new String[] {"TLSv1.2", "TLSv1.1"});
    }

    public SSLParameters parametersConstructor() {
        return new SSLParameters(null, new String[] {"TLSv1"});
    }

    public void parametersSetter(SSLParameters parameters) {
        parameters.setProtocols(new String[] {"SSLv2Hello", "TLSv1.2"});
    }

    public void httpsProtocolsProperty() {
        System.setProperty("https.protocols", "TLSv1,TLSv1.1");
    }

    public void clientProtocolsProperty() {
        System.setProperty("jdk.tls.client.protocols", "TLSv1.2, TLSv1.1");
    }

    public void systemPropertiesPut() {
        System.getProperties().put("https.protocols", "TLSv1,TLSv1.2");
    }

    public Properties mailSmtpProtocols() {
        Properties props = new Properties();
        props.setProperty("mail.smtp.ssl.protocols", "TLSv1 TLSv1.1");
        return props;
    }

    public Properties mailSmtpsProtocols() {
        Properties props = new Properties();
        props.put("mail.smtps.ssl.protocols", "SSLv3 TLSv1.2");
        return props;
    }

    public Map<String, String> mailImapsInMapLiteral() {
        return Map.of("mail.imaps.ssl.protocols", "TLSv1", "mail.imaps.ssl.trust", "*");
    }

    public Supplier<SSLContext> inLambda() {
        return () -> {
            try {
                return SSLContext.getInstance("TLSv1");
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        };
    }

    // ---- current: not reported ----------------------------------------------------------------------------------------------
    public SSLContext contextTls() throws Exception {
        return SSLContext.getInstance("TLS");
    }

    public SSLContext contextTls12() throws Exception {
        return SSLContext.getInstance("TLSv1.2");
    }

    public SSLContext contextTls13() throws Exception {
        return SSLContext.getInstance("TLSv1.3");
    }

    public SSLContext contextDefault() throws Exception {
        return SSLContext.getDefault();
    }

    public void enabledCurrent(SSLSocket socket) {
        socket.setEnabledProtocols(new String[] {"TLSv1.3", "TLSv1.2"});
    }

    public SSLParameters parametersCurrent() {
        return new SSLParameters(null, new String[] {"TLSv1.2"});
    }

    public void propertyCurrent() {
        System.setProperty("https.protocols", "TLSv1.2,TLSv1.3");
    }

    // ---- boundary: looks similar, is judged by what it really is ------------------------------------------------------------
    /** SSL is a name, not a version: SunJSSE maps it to the TLS context (TLS 1.3 and 1.2 enabled by default), so it is not reported. */
    public SSLContext contextSsl() throws Exception {
        return SSLContext.getInstance("SSL");
    }

    public SSLContext protocolFromConfiguration() throws Exception {
        return SSLContext.getInstance(System.getProperty("app.tls.protocol", "TLSv1"));
    }

    public SSLContext protocolFromParameter(String protocol) throws Exception {
        return SSLContext.getInstance(protocol);
    }

    public void enabledFromParameter(SSLSocket socket, String[] protocols) {
        socket.setEnabledProtocols(protocols);
    }

    public void enabledEverythingSupported(SSLSocket socket) {
        socket.setEnabledProtocols(socket.getSupportedProtocols());
    }

    public void enabledFromCollection(SSLSocket socket, List<String> protocols) {
        socket.setEnabledProtocols(protocols.toArray(new String[0]));
    }

    public void enabledWithUnknownNames(SSLSocket socket, String first, String second) {
        socket.setEnabledProtocols(new String[] {first, second});
    }

    public void enabledListThatIsChanged(SSLSocket socket, String other) {
        String[] protocols = {"TLSv1.2"};
        protocols[0] = other;
        socket.setEnabledProtocols(protocols);
    }

    public void cipherSuitesAreNoProtocols(SSLSocket socket) {
        socket.setEnabledCipherSuites(new String[] {"TLSv1"});
    }

    public void unrelatedProperty() {
        System.setProperty("http.agent", "TLSv1");
    }

    public Properties mailCurrentProtocols() {
        Properties props = new Properties();
        props.setProperty("mail.smtp.ssl.protocols", "TLSv1.2 TLSv1.3");
        return props;
    }

    public void systemPropertiesCurrent() {
        System.getProperties().setProperty("https.protocols", "TLSv1.2,TLSv1.3");
    }

    public Properties mailPropertyFromVariable(String protocols) {
        Properties props = new Properties();
        props.setProperty("mail.smtp.ssl.protocols", protocols);
        return props;
    }

    // ---- boundary: forms that are not read ----------------------------------------------------------------------------------
    public void systemPropertiesKeptInALocal() {
        Properties system = System.getProperties();
        system.setProperty("https.protocols", "TLSv1");
    }

    public void joinedProtocolsProperty() {
        System.setProperty("https.protocols", String.join(",", "TLSv1", "TLSv1.2"));
    }

    public SSLContext contextNamedByToString() throws Exception {
        return SSLContext.getInstance("TLSv1".toString());
    }

    public void splitProtocols(SSLSocket socket) {
        socket.setEnabledProtocols("TLSv1,TLSv1.2".split(","));
    }

    public void clonedProtocols(SSLSocket socket) {
        socket.setEnabledProtocols(OLD_AND_NEW.clone());
    }

    public void asListProtocols(SSLSocket socket) {
        socket.setEnabledProtocols(List.of("TLSv1", "TLSv1.2").toArray(new String[0]));
    }

    public Properties mailKeyFromVariable(Properties props, String key) {
        props.put(key, "TLSv1");
        return props;
    }

    public void propertyFromVariable(String value) {
        System.setProperty("https.protocols", value);
    }
}
