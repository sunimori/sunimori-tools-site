package example;

/** Constants of another class: an array initializer in a different file is not followed, only compile-time constants are. */
public final class Settings {
    private Settings() { }

    public static final byte[] IV = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
    public static final String AES_KEY_TEXT = "0123456789abcdef";
    public static final String SECRET_KEY = "fedcba9876543210";

    public static byte[] fetchKey() {
        return new byte[16];
    }
}
