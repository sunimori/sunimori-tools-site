package example;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.List;
import javax.crypto.spec.IvParameterSpec;

/**
 * Initialization vectors that are assigned in more than one place: the static initializer, the constructors, the two branches of an
 * {@code if}, and the {@code try} that older code needs around {@code getBytes("UTF-8")}. The fixed ones are reported, the ones that
 * can change are not, and what the check does not follow stays silent.
 */
public class StaticIvAssignedCases {
    private static final byte[] STATIC_BLOCK_IV;
    private static final byte[] LEGACY_STATIC_IV;
    private static final byte[] RANDOM_STATIC_IV;

    static {
        STATIC_BLOCK_IV = new byte[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
        try {
            LEGACY_STATIC_IV = "0123456789abcdef".getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
        RANDOM_STATIC_IV = new byte[16];
        new SecureRandom().nextBytes(RANDOM_STATIC_IV);
    }

    private final byte[] constructorIv;
    private final byte[] givenIv;

    public StaticIvAssignedCases() {
        constructorIv = "fedcba9876543210".getBytes();
        givenIv = new byte[16];
    }

    public StaticIvAssignedCases(byte[] iv) {
        constructorIv = "fedcba9876543210".getBytes();
        givenIv = iv;
    }

    // ---- fixed: reported -------------------------------------------------------------------------------------------
    public IvParameterSpec staticBlockIv() {
        return new IvParameterSpec(STATIC_BLOCK_IV);
    }

    public IvParameterSpec staticBlockTryIv() {
        return new IvParameterSpec(LEGACY_STATIC_IV);
    }

    public IvParameterSpec constructorIvSpec() {
        return new IvParameterSpec(constructorIv);
    }

    public IvParameterSpec legacyLocalIv() {
        byte[] iv;
        try {
            iv = "0123456789abcdef".getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException(e);
        }
        return new IvParameterSpec(iv);
    }

    public IvParameterSpec branchIv(boolean legacy) {
        String iv;
        if (legacy) {
            iv = "0123456789abcdef";
        } else {
            iv = "fedcba9876543210";
        }
        return new IvParameterSpec(iv.getBytes());
    }

    public IvParameterSpec appendedEmptyIv() {
        String iv = "0123456789abcdef";
        iv = iv + "";
        return new IvParameterSpec(iv.getBytes());
    }

    /** A class of its own: two constructors, each with a constant. */
    static final class Nested {
        private final byte[] twoConstructorsIv;

        Nested() {
            twoConstructorsIv = "0123456789abcdef".getBytes();
        }

        Nested(int version) {
            twoConstructorsIv = "fedcba9876543210".getBytes();
        }

        IvParameterSpec twoConstructorsIvSpec() {
            return new IvParameterSpec(twoConstructorsIv);
        }
    }

    // ---- can change: not reported ----------------------------------------------------------------------------------
    public IvParameterSpec randomStaticBlockIv() {
        return new IvParameterSpec(RANDOM_STATIC_IV);
    }

    public IvParameterSpec constructorParameterIv() {
        return new IvParameterSpec(givenIv);
    }

    public IvParameterSpec legacyLocalRandomIv() {
        byte[] iv;
        try {
            iv = new byte[16];
            SecureRandom.getInstance("SHA1PRNG").nextBytes(iv);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
        return new IvParameterSpec(iv);
    }

    public IvParameterSpec branchWithParameterIv(boolean given, String text) {
        String iv;
        if (given) {
            iv = text;
        } else {
            iv = "fedcba9876543210";
        }
        return new IvParameterSpec(iv.getBytes());
    }

    public IvParameterSpec loopAppendsIv(List<String> parts) {
        String iv = "0123456789abcdef";
        for (String part : parts) {
            iv = iv + part;
        }
        return new IvParameterSpec(iv.getBytes());
    }

    // ---- boundary: shapes the check does not follow ----------------------------------------------------------------
    public IvParameterSpec stringBuilderIv() {
        return new IvParameterSpec(new StringBuilder("0123456789abcdef").toString().getBytes());
    }

    public IvParameterSpec loopFilledIv() {
        byte[] iv = new byte[16];
        for (int i = 0; i < iv.length; i++) {
            iv[i] = (byte) i;
        }
        return new IvParameterSpec(iv);
    }

    public IvParameterSpec conditionalIv(boolean legacy) {
        return new IvParameterSpec((legacy ? "0123456789abcdef" : "fedcba9876543210").getBytes());
    }
}
