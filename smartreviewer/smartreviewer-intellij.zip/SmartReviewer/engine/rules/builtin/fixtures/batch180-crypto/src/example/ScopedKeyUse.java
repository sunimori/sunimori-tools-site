package example;

import javax.crypto.spec.SecretKeySpec;

/**
 * Keys that are named like a secret and declared in another file. The credential rule reports the literal where it is declared, but
 * only in the files it reads; for a constant in a file it does not read, the key rule reports the key where it is used.
 */
public class ScopedKeyUse {
    public SecretKeySpec generatedConstant() {
        return new SecretKeySpec(generated.GeneratedKeys.SECRET_KEY.getBytes(), "AES");
    }

    public SecretKeySpec testClassConstant() {
        return new SecretKeySpec(KeyHolderTest.SECRET_KEY.getBytes(), "AES");
    }
}
