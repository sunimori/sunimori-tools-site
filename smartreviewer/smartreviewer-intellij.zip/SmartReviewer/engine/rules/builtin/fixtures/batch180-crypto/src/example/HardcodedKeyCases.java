package example;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.function.Supplier;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

/** Keys and passwords: written in the source (the rule reports) and obtained at run time (it does not). */
public class HardcodedKeyCases {
    private static final String AES_KEY = "0123456789abcdef";
    private static final String MASTER = "0123456789abcdef0123456789abcdef";
    private static final String SECRET_KEY = "fedcba9876543210";
    private static final String SALT_TEXT = "pepper";
    public static final SecretKeySpec SHARED_KEY = new SecretKeySpec("abcdefghijklmnop".getBytes(), "AES");

    // ---- written in the source: reported -----------------------------------------------------------------------------
    public SecretKeySpec literalKey() {
        return new SecretKeySpec("0123456789abcdef".getBytes(StandardCharsets.UTF_8), "AES");
    }

    public SecretKeySpec constantKey() {
        return new SecretKeySpec(AES_KEY.getBytes(), "AES");
    }

    public SecretKeySpec localKey() {
        String key = "0123456789abcdef";
        return new SecretKeySpec(key.getBytes(), "AES");
    }

    public SecretKeySpec bytesLiteral() {
        return new SecretKeySpec(new byte[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16}, "AES");
    }

    public SecretKeySpec base64Key() {
        return new SecretKeySpec(Base64.getDecoder().decode("MDEyMzQ1Njc4OWFiY2RlZg=="), "AES");
    }

    public SecretKeySpec hexKey() {
        return new SecretKeySpec(DatatypeConverter.parseHexBinary("30313233343536373839616263646566"), "AES");
    }

    public SecretKeySpec derivedFromMaster() {
        return new SecretKeySpec(MASTER.substring(0, 16).getBytes(), "AES");
    }

    public SecretKeySpec window() {
        return new SecretKeySpec(MASTER.getBytes(), 0, 16, "AES");
    }

    public SecretKeySpec hmacKey() {
        return new SecretKeySpec("signing-secret-2024".getBytes(), "HmacSHA256");
    }

    public SecretKeySpec zeroAesKey() {
        return new SecretKeySpec(new byte[16], "AES");
    }

    public DESKeySpec zeroDesKeySpec() throws Exception {
        return new DESKeySpec(new byte[8]);
    }

    public SecretKeySpec constantOfAnotherClass() {
        return new SecretKeySpec(Settings.AES_KEY_TEXT.getBytes(), "AES");
    }

    public javax.crypto.SecretKey desKey() throws Exception {
        return SecretKeyFactory.getInstance("DES").generateSecret(new DESKeySpec("12345678".getBytes()));
    }

    public javax.crypto.SecretKey tripleDesKey() throws Exception {
        return SecretKeyFactory.getInstance("DESede").generateSecret(new DESedeKeySpec(MASTER.substring(0, 24).getBytes()));
    }

    public SecretKey passwordBasedKey() throws Exception {
        PBEKeySpec spec = new PBEKeySpec("changeit".toCharArray(), SALT_TEXT.getBytes(), 10000, 256);
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec);
    }

    public Supplier<SecretKeySpec> inLambda() {
        return () -> new SecretKeySpec("0123456789abcdef".getBytes(), "AES");
    }

    // ---- obtained at run time: not reported ---------------------------------------------------------------------------
    public SecretKey generated() throws Exception {
        KeyGenerator generator = KeyGenerator.getInstance("AES");
        generator.init(128);
        return generator.generateKey();
    }

    public SecretKeySpec fromParameter(byte[] key) {
        return new SecretKeySpec(key, "AES");
    }

    public SecretKeySpec fromEnvironment() {
        return new SecretKeySpec(System.getenv("APP_ENCRYPTION_KEY").getBytes(), "AES");
    }

    public SecretKeySpec propertyWithDefault() {
        return new SecretKeySpec(System.getProperty("app.key", "default-key-0123456").getBytes(), "AES");
    }

    public SecretKey fromKeyStore(KeyStore store, char[] storePassword) throws Exception {
        return (SecretKey) store.getKey("app", storePassword);
    }

    public SecretKeySpec randomBytes() {
        byte[] key = new byte[32];
        new SecureRandom().nextBytes(key);
        return new SecretKeySpec(key, "AES");
    }

    public SecretKey passwordFromInput(char[] password, byte[] salt) throws Exception {
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(new PBEKeySpec(password, salt, 10000, 256));
    }

    public SecretKeySpec fromAnotherMethod() {
        return new SecretKeySpec(Settings.fetchKey(), "AES");
    }

    // ---- boundary: looks similar, is judged by what it really is ---------------------------------------------------------------
    public SecretKeySpec hkdfZeroSalt() {
        return new SecretKeySpec(new byte[32], "HmacSHA256");
    }

    public SecretKeySpec zeroTlsSecret() {
        return new SecretKeySpec(new byte[32], "TlsEarlySecret");
    }

    public SecretKeySpec zeroUnknownAlgorithm(String algorithm) {
        return new SecretKeySpec(new byte[32], algorithm);
    }

    public SecretKeySpec placeholder() {
        return new SecretKeySpec("${crypto.key}".getBytes(), "AES");
    }

    public PBEKeySpec emptyPassword(byte[] salt) {
        return new PBEKeySpec("".toCharArray(), salt, 1000, 128);
    }

    public SecretKeySpec namedLikeASecret() {
        String secretKey = "0123456789abcdef";
        return new SecretKeySpec(secretKey.getBytes(), "AES");
    }

    public SecretKeySpec constantNamedLikeASecret() {
        return new SecretKeySpec(SECRET_KEY.getBytes(), "AES");
    }

    public SecretKeySpec secretConstantOfAnotherClass() {
        return new SecretKeySpec(Settings.SECRET_KEY.getBytes(), "AES");
    }

    public PBEKeySpec passwordVariable(byte[] salt) {
        char[] password = "changeit".toCharArray();
        return new PBEKeySpec(password, salt, 1000, 128);
    }

    public SecretKeySpec arrayOfAnotherClass() {
        return new SecretKeySpec(Settings.IV, "AES");
    }

    public SecretKeySpec hashOfAConstant() throws Exception {
        return new SecretKeySpec(MessageDigest.getInstance("SHA-256").digest("passphrase".getBytes()), "AES");
    }

    public SecretKeySpec windowAtUnknownOffset(int offset) {
        return new SecretKeySpec(MASTER.getBytes(), offset, 16, "AES");
    }

    public SecretKeySpec replacedByInput(String input) {
        String key = "0123456789abcdef";
        key = input;
        return new SecretKeySpec(key.getBytes(), "AES");
    }
}
