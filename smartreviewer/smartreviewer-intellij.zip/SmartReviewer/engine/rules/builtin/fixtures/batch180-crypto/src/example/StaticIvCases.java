package example;

import java.io.DataInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import java.util.function.Supplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

/** Initialization vectors and nonces: fixed ones (the rule reports) and the ways to get a different one for every message (it does not). */
public class StaticIvCases {
    private static final String IV_TEXT = "0123456789abcdef";
    private static final byte[] IV_BYTES = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16};
    private static final byte[] ZERO_IV = new byte[16];
    private static final String MASTER = "0123456789abcdef0123456789abcdef";
    private final SecureRandom random = new SecureRandom();
    public static final IvParameterSpec SHARED_SPEC = new IvParameterSpec("fedcba9876543210".getBytes(StandardCharsets.UTF_8));

    // ---- fixed: reported -------------------------------------------------------------------------------------------
    public byte[] literalString(SecretKey key, byte[] data) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec("0123456789abcdef".getBytes(StandardCharsets.UTF_8)));
        return cipher.doFinal(data);
    }

    public byte[] constantField(SecretKey key, byte[] data) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CTR/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key, new IvParameterSpec(IV_TEXT.getBytes()));
        return cipher.doFinal(data);
    }

    public IvParameterSpec literalBytes() {
        return new IvParameterSpec(IV_BYTES);
    }

    public IvParameterSpec zeroInline() {
        return new IvParameterSpec(new byte[16]);
    }

    public IvParameterSpec zeroLocal() {
        byte[] iv = new byte[16];
        return new IvParameterSpec(iv);
    }

    public IvParameterSpec zeroField() {
        return new IvParameterSpec(ZERO_IV);
    }

    public IvParameterSpec derivedFromKey() {
        return new IvParameterSpec(MASTER.substring(0, 16).getBytes());
    }

    public IvParameterSpec copyOfConstant() {
        return new IvParameterSpec(Arrays.copyOf(MASTER.getBytes(), 16));
    }

    public IvParameterSpec base64Constant() {
        return new IvParameterSpec(Base64.getDecoder().decode("AAECAwQFBgcICQoLDA0ODw=="));
    }

    public IvParameterSpec hexConstant() {
        return new IvParameterSpec(DatatypeConverter.parseHexBinary("000102030405060708090a0b0c0d0e0f"));
    }

    public GCMParameterSpec gcmString() {
        return new GCMParameterSpec(128, "123456789012".getBytes());
    }

    public GCMParameterSpec gcmZero() {
        byte[] nonce = new byte[12];
        return new GCMParameterSpec(128, nonce);
    }

    public Supplier<IvParameterSpec> inLambda() {
        return () -> new IvParameterSpec("0123456789abcdef".getBytes());
    }

    // ---- a different IV for every message, or one that the code cannot know: not reported --------------------------------
    public IvParameterSpec randomLocal() {
        byte[] iv = new byte[16];
        new SecureRandom().nextBytes(iv);
        return new IvParameterSpec(iv);
    }

    public IvParameterSpec randomField() {
        byte[] iv = new byte[16];
        random.nextBytes(iv);
        return new IvParameterSpec(iv);
    }

    public GCMParameterSpec gcmRandom() {
        byte[] nonce = new byte[12];
        random.nextBytes(nonce);
        return new GCMParameterSpec(128, nonce);
    }

    public IvParameterSpec fromParameter(byte[] iv) {
        return new IvParameterSpec(iv);
    }

    public IvParameterSpec fromCipher(Cipher cipher) {
        return new IvParameterSpec(cipher.getIV());
    }

    public IvParameterSpec prefixOfMessage(byte[] message) {
        return new IvParameterSpec(Arrays.copyOfRange(message, 0, 16));
    }

    public IvParameterSpec copiedFromMessage(byte[] message) {
        byte[] iv = new byte[16];
        System.arraycopy(message, 0, iv, 0, iv.length);
        return new IvParameterSpec(iv);
    }

    public IvParameterSpec readFromStream(DataInputStream in) throws IOException {
        byte[] iv = new byte[16];
        in.readFully(iv);
        return new IvParameterSpec(iv);
    }

    public IvParameterSpec counterIv(long counter) {
        byte[] iv = new byte[16];
        for (int i = 0; i < 8; i++) {
            iv[15 - i] = (byte) (counter >>> (8 * i));
        }
        return new IvParameterSpec(iv);
    }

    public IvParameterSpec fromConfiguration() {
        return new IvParameterSpec(System.getProperty("app.iv").getBytes());
    }

    public IvParameterSpec decodedInput(String header) {
        return new IvParameterSpec(Base64.getDecoder().decode(header));
    }

    // ---- boundary: looks similar, is judged by what it really is -----------------------------------------------------------
    public SecretKeySpec keyIsNotAnIv() {
        return new SecretKeySpec("0123456789abcdef".getBytes(), "AES");
    }

    public IvParameterSpec emptyArray() {
        return new IvParameterSpec(new byte[0]);
    }

    public IvParameterSpec unknownConstant() {
        return new IvParameterSpec(Settings.IV);
    }

    public IvParameterSpec helperFills() {
        byte[] iv = new byte[16];
        fill(iv);
        return new IvParameterSpec(iv);
    }

    public IvParameterSpec windowAtUnknownOffset(int offset) {
        return new IvParameterSpec(MASTER.getBytes(), offset, 16);
    }

    public IvParameterSpec replacedByInput(String input) {
        String iv = "0123456789abcdef";
        iv = input;
        return new IvParameterSpec(iv.getBytes());
    }

    private static void fill(byte[] target) {
        new SecureRandom().nextBytes(target);
    }
}
