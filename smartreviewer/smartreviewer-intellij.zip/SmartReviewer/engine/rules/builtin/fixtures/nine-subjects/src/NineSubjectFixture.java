final class NineSubjectFixture {
    static Object[] bad(Integer value1, Integer value2, Integer value3,
                        Integer value4, Integer value5, Integer value6,
                        Integer value7, Integer value8, Integer value9) {
        return new Object[] {
            value1, value2, value3, value4, value5, value6,
            value7, value7, value9
        };
    }

    static Object[] good(Integer value1, Integer value2, Integer value3,
                         Integer value4, Integer value5, Integer value6,
                         Integer value7, Integer value8, Integer value9) {
        return new Object[] {
            value1, value2, value3, value4, value5, value6,
            value7, value8, value9
        };
    }
}
