package example;

/** B06: a damaged initializer must yield a parse failure or partial result, never a clean pass. */
final class Broken {
    Object[] broken(Integer a, Integer b) {
        return new Object[] {a, b, a,, };
    }
}
