package example;

import java.util.Iterator;

/** SR-JAVA-DUP-CONDITION-001 cases. */
public class DuplicateConditionCases {
    /** P01: a code value copied without changing it. */
    String subject(String kbn) {
        if ("1".equals(kbn)) {
            return "国語";
        } else if ("2".equals(kbn)) {
            return "数学";
        } else if ("1".equals(kbn)) {
            return "英語";
        }
        return "";
    }

    /** P02: a numeric threshold repeated. */
    int grade(int score) {
        if (score >= 80) {
            return 5;
        } else if (score >= 60) {
            return 4;
        } else if (score >= 80) {
            return 3;
        }
        return 1;
    }

    /** N01: distinct conditions. */
    String distinct(String kbn) {
        if ("1".equals(kbn)) {
            return "a";
        } else if ("2".equals(kbn)) {
            return "b";
        }
        return "";
    }

    /** B01: conditions with side effects may differ between evaluations. */
    boolean read(Iterator<String> it) {
        if (it.hasNext() && "x".equals(it.next())) {
            return true;
        } else if (it.hasNext() && "x".equals(it.next())) {
            return false;
        }
        return false;
    }

    /** B02: a nested if is not part of an else-if chain. */
    int nested(int a) {
        if (a > 0) {
            if (a > 0) {
                return 1;
            }
        }
        return 0;
    }
}
