package org.apache.struts.action;

/** Stand-in for the Struts 1 form bean. */
public abstract class ActionForm {
}
