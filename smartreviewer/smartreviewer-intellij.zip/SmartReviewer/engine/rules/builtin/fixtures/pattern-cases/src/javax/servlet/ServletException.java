package javax.servlet;

/** Stand-in for the servlet API's exception. */
public class ServletException extends Exception {
    public ServletException(String message) {
        super(message);
    }
}
