package example;

import java.math.BigDecimal;
import java.time.LocalDate;

/** SR-JAVA-IGNORED-RESULT-001 cases. */
public class IgnoredResultCases {
    /** P01: the BigDecimal total never increases. */
    BigDecimal total(BigDecimal[] amounts) {
        BigDecimal total = BigDecimal.ZERO;
        for (BigDecimal a : amounts) {
            total.add(a);
        }
        return total;
    }

    /** P02: the trimmed value is discarded. */
    String clean(String s) {
        s.trim();
        return s;
    }

    /** P03: the date is not advanced. */
    LocalDate next(LocalDate d) {
        d.plusDays(1);
        return d;
    }

    /** N01: the result is assigned. */
    BigDecimal add(BigDecimal t, BigDecimal a) {
        t = t.add(a);
        return t;
    }

    /** N02: StringBuilder is mutable. */
    String build(StringBuilder sb) {
        sb.append("x");
        return sb.toString();
    }

    /** B01: a discarded result of another type is not this rule's concern. */
    void length(String s) {
        s.length();
    }
}
