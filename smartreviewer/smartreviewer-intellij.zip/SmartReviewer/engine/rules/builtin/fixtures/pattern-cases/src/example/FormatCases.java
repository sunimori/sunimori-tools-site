package example;

import java.io.PrintStream;
import java.util.Date;
import java.util.Locale;

/** Format strings and their arguments (SR-JAVA-FORMAT-ARGS-001). */
public class FormatCases {
    /** Two specifiers, one argument: MissingFormatArgumentException. */
    String missing(String name) {
        return String.format("%s: %s", name);
    }

    /** One specifier, two arguments: the age is never printed. */
    String extra(String name, int age) {
        return String.format("%s", name, age);
    }

    void printMissing(PrintStream out, String code) {
        out.printf("%s %d%n", code);
    }

    String localeMissing(int done) {
        return String.format(Locale.JAPAN, "%d / %d", done);
    }

    String exact(String key, int percent) {
        return String.format("%s = %d%%%n", key, percent);
    }

    String numbered(String name) {
        return String.format("%1$s and %1$s", name);
    }

    String previous(Date date) {
        return String.format("%tY-%<tm-%<td", date);
    }

    /** An Object[] passed as the whole argument list: not counted. */
    String array(Object[] values) {
        return String.format("%s %s", values);
    }
}
