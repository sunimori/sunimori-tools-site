package org.apache.logging.log4j;

/** Stand-in for the Log4j 2 logger interface, with only the methods the fixtures call. */
public interface Logger {
    void info(String message, Object... params);

    void error(String message, Throwable t);

    void log(Level level, String message, Object... params);
}
