package example;

/** SR-JAVA-SELF-ASSIGN-001 cases. */
public class SelfAssignCases {
    private String name;
    private int count;
    private final int[] values = new int[3];

    /** P01: the parameter hides the field, so the field is never set. */
    public void setName(String name) {
        name = name;
    }

    /** P02: a field assigned to itself. */
    public void touch() {
        this.count = this.count;
    }

    /** P03: an array element assigned to itself. */
    public void keep(int i) {
        values[i] = values[i];
    }

    /** P04: a local variable assigned to itself. */
    public int local(int x) {
        int y = x;
        y = y;
        return y;
    }

    /** N01: the usual setter. */
    public void rename(String name) {
        this.name = name;
    }

    /** N02: different array elements. */
    public void copyNext(int i) {
        values[i] = values[i + 1];
    }

    /** B01: a side effect on the right-hand side is out of scope (count = count++ is a different mistake). */
    public void advance() {
        count = count++;
    }
}
