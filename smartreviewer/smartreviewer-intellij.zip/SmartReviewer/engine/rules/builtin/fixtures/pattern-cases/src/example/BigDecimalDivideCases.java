package example;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** BigDecimal.divide without rounding (SR-JAVA-BIGDECIMAL-DIVIDE-001). */
public class BigDecimalDivideCases {
    BigDecimal average(BigDecimal total, BigDecimal count) {
        return total.divide(count);
    }

    BigDecimal third(BigDecimal amount) {
        return amount.divide(new BigDecimal("3"));
    }

    BigDecimal roundedAverage(BigDecimal total, BigDecimal count) {
        return total.divide(count, 2, RoundingMode.HALF_UP);
    }

    BigDecimal percent(BigDecimal amount) {
        return amount.divide(BigDecimal.valueOf(100));
    }

    /** 0.25 = 1/4: every quotient is finite. */
    BigDecimal quarter(BigDecimal amount) {
        return amount.divide(new BigDecimal("0.25"));
    }

    BigDecimal tenth(BigDecimal amount) {
        return amount.divide(BigDecimal.TEN);
    }
}
