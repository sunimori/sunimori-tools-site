package example;

/** Branches with the same statements (SR-JAVA-IDENTICAL-BRANCHES-001). */
public class IdenticalBranchesCases {
    /** P01: both branches the same: the member condition changes nothing. */
    int charge(boolean member, int amount) {
        int rate;
        if (member) {
            rate = 10;
            amount -= amount * rate / 100;
        } else {
            rate = 10;
            amount -= amount * rate / 100;
        }
        return amount;
    }

    /** P02: an else-if chain ending with else, every branch the same (reported once). */
    String label(int kind) {
        String label;
        if (kind == 1) {
            label = "A";
        } else if (kind == 2) {
            label = "A";
        } else {
            label = "A";
        }
        return label;
    }

    /** N01: the branches differ. */
    int differ(boolean member, int amount) {
        int rate;
        if (member) {
            rate = 10;
        } else {
            rate = 0;
        }
        return amount - amount * rate / 100;
    }

    /** N02: two of three branches the same, the same handling for two cases (reported only with branches ANY). */
    String kindName(int kind) {
        String name;
        if (kind == 1) {
            name = "normal";
        } else if (kind == 2) {
            name = "normal";
        } else {
            name = "special";
        }
        return name;
    }

    /** N03: without else. */
    int bonus(boolean member, int points) {
        if (member) {
            points += 10;
        }
        return points;
    }

    /** B01: branches that only return are left out. */
    boolean valid(int x) {
        if (x > 10) {
            return false;
        } else {
            return false;
        }
    }

    /** B02: comments and layout differ, the statements do not (8 % was meant to differ). */
    int tax(boolean reduced, int price) {
        int tax;
        if (reduced) {
            // reduced rate
            tax = price * 8 / 100;
        } else {
            tax = price*8/100; // standard rate
        }
        return tax;
    }
}
