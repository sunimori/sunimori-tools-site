package example;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Objects;

/** equals() that cannot mean what it says: SR-JAVA-EQUALS-TYPES-001, SR-JAVA-ARRAY-EQUALS-001, SR-JAVA-BIGDECIMAL-EQUALS-001. */
public class EqualsTypeCases {
    /** A String compared with the number 1 (an Integer): always false. */
    boolean isOne(String kbn) {
        return kbn.equals(1);
    }

    boolean sameId(Long id, Integer other) {
        return id.equals(other);
    }

    boolean sameText(String text, StringBuilder buffer) {
        return text.equals(buffer);
    }

    boolean sameNumbers(Integer a, Long b) {
        return Objects.equals(a, b);
    }

    boolean sameKbn(String kbn) {
        return "1".equals(kbn);
    }

    /** The argument is an Object: it may be a String. */
    boolean sameValue(Object value, String text) {
        return text.equals(value);
    }

    /** int boxes to Integer: the same type. */
    boolean sameNumber(Integer a, int b) {
        return a.equals(b);
    }

    boolean sameCodes(String[] a, String[] b) {
        return a.equals(b);
    }

    boolean sameBytes(byte[] a, byte[] b) {
        return Objects.equals(a, b);
    }

    boolean sameCodesByContent(String[] a, String[] b) {
        return Arrays.equals(a, b);
    }

    boolean isZero(BigDecimal amount) {
        return amount.equals(BigDecimal.ZERO);
    }

    boolean sameAmount(BigDecimal a, BigDecimal b) {
        return Objects.equals(a, b);
    }

    boolean isZeroByValue(BigDecimal amount) {
        return amount.compareTo(BigDecimal.ZERO) == 0;
    }

    /** The argument is not known to be a BigDecimal. */
    boolean sameObject(BigDecimal amount, Object other) {
        return amount.equals(other);
    }

    /** A value class: its equals() compares the amount with the scale on purpose, as its hashCode() does. */
    static final class Price {
        private final BigDecimal amount;

        Price(BigDecimal amount) {
            this.amount = amount;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Price && Objects.equals(amount, ((Price) o).amount);
        }

        @Override
        public int hashCode() {
            return Objects.hashCode(amount);
        }
    }
}
