package org.apache.logging.log4j;

/** Stand-in for the Log4j 2 log manager. */
public final class LogManager {
    private LogManager() {
    }

    public static Logger getLogger(Class<?> type) {
        throw new UnsupportedOperationException("fixture stand-in");
    }
}
