package example;

import java.util.Objects;

/** SR-JAVA-EQUALS-HASHCODE-001 N01: both methods. */
public class EqualsAndHashCode {
    protected final String code;

    public EqualsAndHashCode(String code) {
        this.code = code;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof EqualsAndHashCode other && Objects.equals(code, other.code);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(code);
    }
}
