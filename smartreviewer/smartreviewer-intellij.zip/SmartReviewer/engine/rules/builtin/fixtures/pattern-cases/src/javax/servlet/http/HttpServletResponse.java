package javax.servlet.http;

import javax.servlet.ServletResponse;

/** Stand-in for the HTTP servlet response. */
public interface HttpServletResponse extends ServletResponse {
}
