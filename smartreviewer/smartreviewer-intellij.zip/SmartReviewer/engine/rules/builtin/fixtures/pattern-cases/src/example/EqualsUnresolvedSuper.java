package example;

/** SR-JAVA-EQUALS-HASHCODE-001 B02: the superclass cannot be resolved, so it may well implement hashCode. */
public class EqualsUnresolvedSuper extends com.example.missing.BaseEntity {
    private String code;

    @Override
    public boolean equals(Object o) {
        return o instanceof EqualsUnresolvedSuper other && code.equals(other.code);
    }
}
