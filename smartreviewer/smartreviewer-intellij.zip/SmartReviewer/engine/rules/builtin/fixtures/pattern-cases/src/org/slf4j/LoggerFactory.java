package org.slf4j;

/** Stand-in for the SLF4J logger factory. */
public final class LoggerFactory {
    private LoggerFactory() {
    }

    public static Logger getLogger(Class<?> type) {
        throw new UnsupportedOperationException("fixture stand-in");
    }
}
