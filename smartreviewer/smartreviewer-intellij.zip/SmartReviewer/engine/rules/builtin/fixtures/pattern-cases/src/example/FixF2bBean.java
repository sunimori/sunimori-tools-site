package example;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** A bean of another file: its collections are created here (used by FixF2bCases). */
public class FixF2bBean {
    private final List<String> tags = new ArrayList<>();
    private final Map<String, String> cache = new ConcurrentHashMap<>();
    private final Map<String, String> filled;

    public FixF2bBean() {
        filled = new ConcurrentHashMap<>();
    }

    public List<String> getTags() {
        return tags;
    }

    public Map<String, String> getCache() {
        return cache;
    }

    public Map<String, String> getFilled() {
        return filled;
    }

    /** Created in the superclass, read by the subclass of FixF2bCases. */
    public static class Registry {
        protected final Map<String, Long> lastSeen = new ConcurrentHashMap<>();
        protected final List<String> names = new ArrayList<>();
    }
}
