package example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * SR-JAVA-RESOURCE-LEAK-001 in a file with more than 100 other JDT warnings (raw types, unchecked calls) before the leaks. JDT keeps
 * 100 problems of a file by default: the leaks after them were lost, and those on the line at the cut changed from run to run.
 */
public class NoisyResourceLeakCases {
    void fill(List rows) {
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
        rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null); rows.add(null);
    }

    /** B11: both statements stay open at the early return. */
    String name(Connection con, int id) throws SQLException {
        PreparedStatement byId = con.prepareStatement("select name from customer where id = ?");
        PreparedStatement byCode = con.prepareStatement("select name from customer where code = ?");
        if (id < 0) {
            return null;
        }
        byId.setInt(1, id);
        byCode.setInt(1, id);
        String name = null;
        try (ResultSet rs = byId.executeQuery()) {
            if (rs.next()) {
                name = rs.getString(1);
            }
        }
        byId.close();
        byCode.close();
        return name;
    }
}
