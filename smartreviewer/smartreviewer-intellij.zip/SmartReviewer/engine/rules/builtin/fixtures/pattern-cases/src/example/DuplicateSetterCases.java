package example;

/** The same setter twice in a run of setter statements (SR-JAVA-DUP-SETTER-001). */
public class DuplicateSetterCases {
    static class Customer {
        private String name;
        private String kana;
        private int age;
        private boolean active;

        void setName(String name) {
            this.name = name;
        }

        void setKana(String kana) {
            this.kana = kana;
        }

        void setAge(int age) {
            this.age = age;
        }

        void setActive(boolean active) {
            this.active = active;
        }

        String getName() {
            return name;
        }
    }

    /** A setter that does more than store a field: each call is a step. */
    static class Job {
        private final StringBuilder log = new StringBuilder();

        void setState(String state) {
            log.append(state).append(';');
        }
    }

    /** An API: setters declared by an interface may do more than store the value. */
    interface Settings {
        void setMode(String mode);
    }

    static class Order {
        private String code;
        private String note;

        void setCode(String code) {
            this.code = code;
        }

        void setNote(String note) {
            this.note = note;
        }

        /** P02: the implicit receiver: the note is never set. */
        void fill(String c, String n) {
            setCode(c);
            setCode(n);
        }
    }

    /** P01: the second setName was meant to be setKana; the kana is never set. */
    Customer register(String name, String kana, int age) {
        Customer c = new Customer();
        c.setName(name);
        c.setAge(age);
        c.setName(kana);
        return c;
    }

    /** N01: different setters. */
    Customer distinct(String name, String kana) {
        Customer c = new Customer();
        c.setName(name);
        c.setKana(kana);
        return c;
    }

    /** N02: the second value reads the first: deliberate. */
    Customer trimmed(String name) {
        Customer c = new Customer();
        c.setName(name);
        c.setName(c.getName().trim());
        return c;
    }

    /** N03: another statement in between ends the run. */
    Customer printed(String name, String kana) {
        Customer c = new Customer();
        c.setName(name);
        System.out.println(c.getName());
        c.setName(kana);
        return c;
    }

    /** B01: resets before the real value: null first, false then true. */
    Customer reset(String name) {
        Customer c = new Customer();
        c.setName(null);
        c.setName(name);
        c.setActive(false);
        c.setActive(true);
        return c;
    }

    /** B02: a setter that is no plain field setter: called twice on purpose. */
    void run(Job job) {
        job.setState("SCHEDULED");
        job.setState("RUNNING");
    }

    /** B03: the same value twice: nothing is lost. */
    void twice(Customer c, String name) {
        c.setName(name);
        c.setName(name);
    }

    /** B06: setters declared by an interface are no plain field setters. */
    void configure(Settings settings) {
        settings.setMode("compact");
        settings.setMode("full");
    }
}
