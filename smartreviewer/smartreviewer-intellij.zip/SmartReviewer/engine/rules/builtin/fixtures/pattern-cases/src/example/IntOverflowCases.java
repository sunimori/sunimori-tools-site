package example;

import java.util.Date;

/** int products widened to long after they are computed (SR-JAVA-INT-OVERFLOW-001). */
public class IntOverflowCases {
    private static final int MILLIS_PER_DAY = 24 * 60 * 60 * 1000;

    /** P01: from 25 days on the product is negative. */
    long millis(int days) {
        long ms = days * 24 * 60 * 60 * 1000;
        return ms;
    }

    /** P02: added to a long: the date arithmetic of older code. */
    Date later(Date date, int days) {
        return new Date(date.getTime() + days * MILLIS_PER_DAY);
    }

    /** P03: constants that overflow: a year in milliseconds. */
    long year() {
        return 365 * 24 * 60 * 60 * 1000;
    }

    /** N01: one factor is a long: the whole product is computed in long. */
    long safe(int days) {
        return days * 24L * 60 * 60 * 1000;
    }

    /** N02: the first factor cast to long. */
    long cast(int days) {
        return (long) days * 24 * 60 * 60 * 1000;
    }

    /** N03: a constant product that fits in an int. */
    long day() {
        return 24 * 60 * 60 * 1000;
    }

    /** N04: small factors: weeks to days. */
    long weeks(int weeks) {
        return weeks * 7;
    }

    /** B01: two variables: reported only with reportVariableProducts. */
    long total(int price, int quantity) {
        return price * quantity;
    }

    /** B02: casting the product, not a factor, comes too late. */
    long lateCast(int days) {
        return (long) (days * 24 * 60 * 60 * 1000);
    }

    /** B03: the product stays an int: no widening here. */
    int intMillis(int seconds) {
        return seconds * 1000 * 1000 * 1000;
    }
}
