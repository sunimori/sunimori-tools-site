package javax.servlet;

/** Stand-in for the servlet base class. */
public abstract class GenericServlet {
    public void init() throws ServletException {
    }
}
