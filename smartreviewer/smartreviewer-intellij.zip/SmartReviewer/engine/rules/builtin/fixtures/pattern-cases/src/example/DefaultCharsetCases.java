package example;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

/** Text conversions and files that use the platform's default charset (SR-JAVA-DEFAULT-CHARSET-001). */
public class DefaultCharsetCases {

    /** P01: MS932 on Japanese Windows, UTF-8 on Linux and from Java 18. */
    byte[] encode(String name) {
        return name.getBytes();
    }

    /** P02: decoding bytes the same way. */
    String decode(byte[] data) {
        return new String(data);
    }

    /** P03: FileReader without a charset. */
    String readFirstLine(File file) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            return reader.readLine();
        }
    }

    /** P04: a reader over a stream without a charset. */
    BufferedReader lines(InputStream in) {
        return new BufferedReader(new InputStreamReader(in));
    }

    /** P05: PrintWriter(File) writes with the default charset. */
    void export(File file, String line) throws IOException {
        try (PrintWriter out = new PrintWriter(file)) {
            out.println(line);
        }
    }

    /** N01: charsets named. */
    String convert(String text, byte[] data, InputStream in, File file) throws IOException {
        byte[] utf8 = text.getBytes(StandardCharsets.UTF_8);
        String sjis = new String(data, "MS932");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
             FileWriter writer = new FileWriter(file, StandardCharsets.UTF_8)) {
            writer.write(reader.readLine());
        }
        return sjis + utf8.length;
    }

    /** N02: a PrintWriter over a Writer converts nothing itself. */
    String render(String name) {
        StringWriter sw = new StringWriter();
        PrintWriter out = new PrintWriter(sw);
        out.print(name);
        out.flush();
        return sw.toString();
    }

    /** B01: plain ASCII converts the same with every charset in use. */
    byte[] marker() {
        return "END".getBytes();
    }

    /** B02: Japanese text does not. */
    byte[] title() {
        return "請求書".getBytes();
    }

    /** B03: a charset given by name is still named. */
    byte[] legacy(String text) throws UnsupportedEncodingException {
        return text.getBytes("Windows-31J");
    }
}
