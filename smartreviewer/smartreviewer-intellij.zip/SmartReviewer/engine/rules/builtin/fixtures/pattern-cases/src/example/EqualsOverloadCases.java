package example;

import java.util.Objects;

/** equals(MyType) declared instead of overriding equals(Object) (SR-JAVA-EQUALS-OVERLOAD-001). */
public class EqualsOverloadCases {

    /** P01: HashSet, List.contains and Objects.equals call equals(Object), which still compares identity. */
    static final class Money {
        final long amount;
        final String currency;

        Money(long amount, String currency) {
            this.amount = amount;
            this.currency = currency;
        }

        public boolean equals(Money other) {
            return other != null && amount == other.amount && currency.equals(other.currency);
        }

        @Override
        public int hashCode() {
            return Objects.hash(amount, currency);
        }
    }

    /** P02: the overload is reported where it is first declared. */
    static class Shape {
        public boolean equals(Shape other) {
            return other != null && getClass() == other.getClass();
        }
    }

    /** B02: overriding the inherited overload adds nothing new to report. */
    static final class Circle extends Shape {
        final int radius;

        Circle(int radius) {
            this.radius = radius;
        }

        @Override
        public boolean equals(Shape other) {
            return other instanceof Circle && ((Circle) other).radius == radius;
        }
    }

    /** N01: overrides equals(Object). */
    static final class Code {
        final String value;

        Code(String value) {
            this.value = value;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Code && value.equals(((Code) o).value);
        }

        @Override
        public int hashCode() {
            return value.hashCode();
        }
    }

    /** N02: equals(String) of a text holder compares with something else; it does not try to override. */
    static final class Label {
        final String text;

        Label(String text) {
            this.text = text;
        }

        public boolean equals(String s) {
            return text.equals(s);
        }
    }

    /** B01: a typed helper next to equals(Object). */
    static final class Point {
        final int x;
        final int y;

        Point(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public boolean equals(Point p) {
            return p != null && x == p.x && y == p.y;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Point && equals((Point) o);
        }

        @Override
        public int hashCode() {
            return 31 * x + y;
        }
    }
}
