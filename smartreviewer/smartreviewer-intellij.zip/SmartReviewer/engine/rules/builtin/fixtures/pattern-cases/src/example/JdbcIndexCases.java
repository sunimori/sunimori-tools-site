package example;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

/** JDBC column and parameter indexes below 1 (SR-JAVA-JDBC-INDEX-001). */
public class JdbcIndexCases {
    private static final int FIRST = 0;

    /** P01: columns count from 1. */
    String name(ResultSet rs) throws SQLException {
        return rs.getString(0);
    }

    /** P02: a parameter index 0 through a constant. */
    void bind(PreparedStatement ps, String code) throws SQLException {
        ps.setString(FIRST, code);
    }

    /** P03: metadata columns count from 1 too. */
    String column(ResultSetMetaData md) throws SQLException {
        return md.getColumnName(0);
    }

    /** N01: from 1. */
    String first(ResultSet rs) throws SQLException {
        return rs.getString(1) + rs.getInt(2);
    }

    /** N02: 0 means something else for these methods (no limit, no time-out, a driver default). */
    void limits(PreparedStatement ps, ResultSet rs) throws SQLException {
        ps.setMaxRows(0);
        ps.setQueryTimeout(0);
        rs.setFetchSize(0);
    }

    /** N03: lists count from 0. */
    String list(List<String> names) {
        return names.get(0);
    }

    /** B01: a computed index is not known here. */
    void loop(PreparedStatement ps, String[] values) throws SQLException {
        for (int i = 0; i < values.length; i++) {
            ps.setString(i + 1, values[i]);
        }
    }

    /** B02: an output parameter of a stored procedure. */
    void out(CallableStatement cs) throws SQLException {
        cs.registerOutParameter(0, Types.INTEGER);
    }
}
