package example;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.sql.DataSource;

/**
 * Resource leaks, null dereferences and unlikely arguments that the flow rules missed or reported by mistake (SR-JAVA-RESOURCE-LEAK-001,
 * SR-JAVA-NULL-DEREF-001, SR-JAVA-UNLIKELY-ARG-001). The classes Unresolved and MissingSuperUser have unresolved references on purpose
 * (AuditLog, DbUtils, Kind, Audit and MissingBase do not exist): JDT leaves their methods out of its flow analysis.
 */
public class FixC3Cases {
    private static final ThreadLocal<Connection> CURRENT = new ThreadLocal<>();
    private DataSource dataSource;

    // ------------------------------------------------------------------------------------------------ files and streams

    /** fx-files-lines: JDT only says "may not be closed" about a Files.lines stream that is consumed in one expression. */
    List<String> linesOf(Path file) throws IOException {
        return Files.lines(file).collect(Collectors.toList());
    }

    /** fx-files-walk: the same for Files.walk. */
    long walked(Path root) throws IOException {
        return Files.walk(root).filter(Files::isRegularFile).count();
    }

    /** fx-files-list: and Files.list. */
    void printAll(Path dir) throws IOException {
        Files.list(dir).forEach(System.out::println);
    }

    /** fx-files-twr: closed by try-with-resources. */
    List<String> linesSafely(Path file) throws IOException {
        try (Stream<String> lines = Files.lines(file)) {
            return lines.collect(Collectors.toList());
        }
    }

    /** fx-props-inline: nobody closes the stream that Properties.load reads. */
    Properties loadInline(String path) throws IOException {
        Properties props = new Properties();
        props.load(new FileInputStream(path));
        return props;
    }

    /** fx-props-assigned: the same through a variable. */
    Properties loadAssigned(String path) throws IOException {
        Properties props = new Properties();
        FileInputStream in = new FileInputStream(path);
        props.load(in);
        return props;
    }

    /** fx-catch-null: the close at the end of the try is skipped when readLine fails; the catch returns. */
    String firstLineOrNull(String path) {
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(path));
            String line = reader.readLine();
            reader.close();
            return line;
        } catch (IOException e) {
            return null;
        }
    }

    /** fx-closer: the stream is handed to a helper that closes it. */
    int handedToCloser(String path) throws IOException {
        FileInputStream in = new FileInputStream(path);
        int first = in.read();
        closeQuietly(in);
        return first;
    }

    /** fx-reader: the stream is handed to a method of this class that reads and keeps nothing. */
    int handedToReader(String path) throws IOException {
        FileInputStream in = new FileInputStream(path);
        return firstByte(in);
    }

    /** fx-lambda: the stream is read (and closed) by the supplier that the caller runs later. */
    Supplier<Integer> deferredRead(String path) throws IOException {
        FileInputStream in = new FileInputStream(path);
        return () -> {
            try (InputStream s = in) {
                return s.read();
            } catch (IOException e) {
                return -1;
            }
        };
    }

    /** fx-task: the task that the executor runs later closes the stream. */
    void readLater(Executor executor, String path) throws IOException {
        FileInputStream in = new FileInputStream(path);
        executor.execute(() -> {
            try {
                in.read();
            } catch (IOException e) {
                // ignored
            } finally {
                closeQuietly(in);
            }
        });
    }

    /** fx-task-reads: the supplier only reads from the stream; nobody closes it. */
    Supplier<Integer> readOnLater(String path) throws IOException {
        FileInputStream in = new FileInputStream(path);
        return () -> {
            try {
                return in.read();
            } catch (IOException e) {
                return -1;
            }
        };
    }

    private static int firstByte(InputStream in) throws IOException {
        return in.read();
    }

    private static void closeQuietly(AutoCloseable closeable) {
        try {
            closeable.close();
        } catch (Exception e) {
            // ignored
        }
    }

    // ------------------------------------------------------------------------------------------------ JDBC

    /** fx-loop-twr: a statement per id; closing the connection at the end leaves them all open until then. */
    void touchAll(List<String> ids) throws SQLException {
        try (Connection con = dataSource.getConnection()) {
            for (String id : ids) {
                PreparedStatement ps = con.prepareStatement("UPDATE t SET touched = 1 WHERE id = ?");
                ps.setString(1, id);
                ps.executeUpdate();
            }
        }
    }

    /** fx-loop-finally: the same with a finally block. */
    void touchEach(List<String> ids) throws SQLException {
        Connection con = dataSource.getConnection();
        try {
            for (String id : ids) {
                PreparedStatement ps = con.prepareStatement("UPDATE t SET touched = 1 WHERE id = ?");
                ps.setString(1, id);
                ps.executeUpdate();
            }
        } finally {
            con.close();
        }
    }

    /** fx-once-twr: one statement under the connection's try-with-resources is closed with it. */
    void touchOnce(String id) throws SQLException {
        try (Connection con = dataSource.getConnection()) {
            PreparedStatement ps = con.prepareStatement("UPDATE t SET touched = 1 WHERE id = ?");
            ps.setString(1, id);
            ps.executeUpdate();
        }
    }

    /** fx-release: the early return leaves the statement open, but the finally block releases the connection through a helper. */
    int countThenRelease(boolean skip) throws SQLException {
        Connection con = dataSource.getConnection();
        try {
            PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM t");
            if (skip) {
                return 0;
            }
            ResultSet rs = ps.executeQuery();
            rs.next();
            return rs.getInt(1);
        } finally {
            release(con);
        }
    }

    /** fx-before-try: the statement is made before the try whose finally block closes the connection. */
    int countPrepared() throws SQLException {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM t");
        try {
            ResultSet rs = ps.executeQuery();
            rs.next();
            return rs.getInt(1);
        } finally {
            con.close();
        }
    }

    /** fx-unit: the connection moves into the unit of work that is returned. */
    Unit begin() throws SQLException {
        Connection con = dataSource.getConnection();
        con.setAutoCommit(false);
        return new Unit(con);
    }

    /** fx-holder: the connection is given to a holder object. */
    void attach(Holder holder) throws SQLException {
        Connection con = dataSource.getConnection();
        holder.setConnection(con);
    }

    /** fx-threadlocal: the connection is bound to the thread. */
    void bind() throws SQLException {
        Connection con = dataSource.getConnection();
        CURRENT.set(con);
    }

    /** fx-helper-closes: a method of this class closes what it is given. */
    void run() throws SQLException {
        Connection con = dataSource.getConnection();
        execute(con);
    }

    /** fx-helper-reads: the method it is given to only reads; the connection stays open. */
    int ping() throws SQLException {
        Connection con = dataSource.getConnection();
        return isolation(con);
    }

    /** fx-flag: the method closes only the connection it opened itself. */
    int isolationOf(Connection supplied) throws SQLException {
        Connection con = supplied;
        boolean own = false;
        if (con == null) {
            con = dataSource.getConnection();
            own = true;
        }
        try {
            return con.getTransactionIsolation();
        } finally {
            if (own) {
                con.close();
            }
        }
    }

    /** fx-flag-leak: no sign that the connection may be the caller's: with the flag off it stays open. */
    void logLine(String message, boolean closeAfter) throws SQLException {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = con.prepareStatement("INSERT INTO log(msg) VALUES (?)");
        ps.setString(1, message);
        ps.executeUpdate();
        if (closeAfter) {
            ps.close();
            con.close();
        }
    }

    /** fx-three-returns: one statement that stays open at three returns is one finding. */
    int updateKind(Connection con, int kind, String value) throws SQLException {
        PreparedStatement ps = con.prepareStatement("UPDATE cfg SET v = ? WHERE kind = ?");
        ps.setString(1, value);
        if (kind == 1) {
            return ps.executeUpdate();
        }
        if (kind == 2) {
            return ps.executeUpdate() + 1;
        }
        if (kind == 3) {
            return 0;
        }
        int updated = ps.executeUpdate();
        ps.close();
        return updated;
    }

    private void release(Connection con) {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            // ignored
        }
    }

    private void execute(Connection con) throws SQLException {
        try {
            con.createStatement().execute("SELECT 1");
        } finally {
            con.close();
        }
    }

    private int isolation(Connection con) throws SQLException {
        return con.getTransactionIsolation();
    }

    /** A unit of work that owns its connection. */
    static class Unit {
        private final Connection con;

        Unit(Connection con) {
            this.con = con;
        }
    }

    /** Holds a connection for its owner. */
    static class Holder {
        private Connection connection;

        void setConnection(Connection connection) {
            this.connection = connection;
        }
    }

    // ------------------------------------------------------------------------------------------------ resources made on every round

    /** fx-scanner-delimiter: a Scanner over a String holds memory only, whatever is called on it. */
    int sumCsv(String csv) {
        Scanner sc = new Scanner(csv).useDelimiter(",");
        int total = 0;
        while (sc.hasNextInt()) {
            total += sc.nextInt();
        }
        return total;
    }

    /** fx-loop-continue: the continue skips the close at the end of the round. */
    int sizes(List<File> files) throws IOException {
        int sum = 0;
        for (File f : files) {
            FileInputStream in = new FileInputStream(f);
            if (f.length() == 0) {
                continue;
            }
            sum += in.read();
            in.close();
        }
        return sum;
    }

    /** fx-loop-break: so does the break. */
    int firstNonEmpty(List<File> files) throws IOException {
        int first = -1;
        for (File f : files) {
            FileInputStream in = new FileInputStream(f);
            if (f.length() > 0) {
                first = in.read();
                break;
            }
            in.close();
        }
        return first;
    }

    /** fx-loop-closed-first: the round closes the stream before it continues. */
    int sizesClosing(List<File> files) throws IOException {
        int sum = 0;
        for (File f : files) {
            FileInputStream in = new FileInputStream(f);
            if (f.length() == 0) {
                in.close();
                continue;
            }
            sum += in.read();
            in.close();
        }
        return sum;
    }

    /** fx-loop-continue-finally: the finally block around the continue closes the stream. */
    int sizesSafely(List<File> files) throws IOException {
        int sum = 0;
        for (File f : files) {
            FileInputStream in = new FileInputStream(f);
            try {
                if (f.length() == 0) {
                    continue;
                }
                sum += in.read();
            } finally {
                in.close();
            }
        }
        return sum;
    }

    /** fx-loop-inner: the continue belongs to the inner loop, the stream is closed after it. */
    int bytesOf(List<File> files) throws IOException {
        int sum = 0;
        for (File f : files) {
            FileInputStream in = new FileInputStream(f);
            for (int i = 0; i < 4; i++) {
                if (i == 2) {
                    continue;
                }
                sum += in.read();
            }
            in.close();
        }
        return sum;
    }

    /** fx-loop-writer: a writer per round, closed once after the loop: the others stay open. */
    void splitFiles(List<String> names) throws IOException {
        FileWriter w = null;
        for (String name : names) {
            w = new FileWriter(name + ".txt");
            w.write(name);
        }
        if (w != null) {
            w.close();
        }
    }

    /** fx-loop-statement: a statement per round, closed once after the loop. */
    void insertAll(Connection con, List<String> names) throws SQLException {
        PreparedStatement ps = null;
        for (String n : names) {
            ps = con.prepareStatement("INSERT INTO t(name) VALUES (?)");
            ps.setString(1, n);
            ps.executeUpdate();
        }
        if (ps != null) {
            ps.close();
        }
    }

    /** fx-loop-connection: a connection per round, closed once after the loop. */
    void reconnect(int rounds) throws SQLException {
        Connection con = null;
        int round = 0;
        while (round++ < rounds) {
            con = dataSource.getConnection();
            con.setAutoCommit(false);
        }
        if (con != null) {
            con.close();
        }
    }

    /** fx-loop-closed-each: the round closes its writer. */
    void splitClosing(List<String> names) throws IOException {
        FileWriter w = null;
        for (String name : names) {
            w = new FileWriter(name + ".txt");
            w.write(name);
            w.close();
        }
    }

    /** fx-loop-closed-before: the writer of the previous round is closed before the next one is made. */
    void splitRotating(List<String> names) throws IOException {
        FileWriter w = null;
        for (String name : names) {
            if (w != null) {
                w.close();
            }
            w = new FileWriter(name + ".txt");
            w.write(name);
        }
        if (w != null) {
            w.close();
        }
    }

    /** fx-loop-kept: the writers are kept in a list. */
    List<FileWriter> openAll(List<String> names) throws IOException {
        List<FileWriter> all = new ArrayList<>();
        FileWriter w = null;
        for (String name : names) {
            w = new FileWriter(name + ".txt");
            all.add(w);
        }
        return all;
    }

    /** fx-loop-rerun: running the same statement again closes its previous result set. */
    int countAll(Connection con, List<String> ids) throws SQLException {
        int total = 0;
        try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM t WHERE id = ?")) {
            ResultSet rs = null;
            for (String id : ids) {
                ps.setString(1, id);
                rs = ps.executeQuery();
                rs.next();
                total += rs.getInt(1);
            }
        }
        return total;
    }

    /** fx-loop-once: the loop leaves after the first round. */
    void firstOnly(List<String> names) throws IOException {
        FileWriter w = null;
        for (String name : names) {
            w = new FileWriter(name + ".txt");
            break;
        }
        if (w != null) {
            w.close();
        }
    }

    // ------------------------------------------------------------------------------------------------ collection arguments

    static class Account {
        long id;
    }

    /** fx-default-key: the counts are keyed by Long, the id is an int (boxed to Integer): always the default. */
    int countOf(Map<Long, Integer> counts, int id) {
        return counts.getOrDefault(id, 0);
    }

    /** fx-default-ok: the key is converted to the key type. */
    int countOfLong(Map<Long, Integer> counts, int id) {
        return counts.getOrDefault((long) id, 0);
    }

    /** fx-remove-pair: Map.remove(key, value) with the wrong key type. */
    boolean dropName(Map<Long, String> names, int id) {
        return names.remove(id, "x");
    }

    /** fx-serializable: a subclass of Account can be Serializable, so the argument can match an element. */
    boolean hasSerializable(List<Account> accounts, Serializable value) {
        return accounts.contains(value);
    }

    /** fx-final-class: String is final and is not a Runnable: no element can be equal. */
    boolean hasRunnable(List<String> names, Runnable task) {
        return names.contains(task);
    }

    // ------------------------------------------------------------------------------------------------ unresolved references

    /** Methods with references that do not resolve; the rest of each method is checked all the same. */
    static class Unresolved {
        private DataSource dataSource;

        /** fx-unresolved-call: the unresolved call sits next to the leak and used to hide it. */
        int auditedUpdate() throws SQLException {
            AuditLog.write("update");
            Connection con = dataSource.getConnection();
            PreparedStatement ps = con.prepareStatement("UPDATE t SET a = 1");
            return ps.executeUpdate();
        }

        /** fx-unresolved-closer: the unresolved helper receives the connection in finally: it is taken to close it. */
        int auditedCount(boolean skip) throws SQLException {
            Connection con = dataSource.getConnection();
            try {
                PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM t");
                if (skip) {
                    return 0;
                }
                ResultSet rs = ps.executeQuery();
                rs.next();
                return rs.getInt(1);
            } finally {
                DbUtils.closeQuietly(con);
            }
        }

        /** fx-unresolved-handed: the connection goes to an unresolved method. */
        void auditedHandOver() throws SQLException {
            Connection con = dataSource.getConnection();
            Registry.register(con);
        }

        /** fx-unresolved-switch: the selector of the switch cannot be set aside, so the method stays unchecked. */
        int pick(String path) throws IOException {
            FileInputStream in = new FileInputStream(path);
            switch (Kind.of(path)) {
                case FIRST:
                    return in.read();
                default:
                    return 0;
            }
        }

        /** fx-unresolved-null: the null dereference is found next to an unresolved call. */
        int sizeOf(List<String> items) {
            Audit.record("size");
            if (items == null) {
                throw new IllegalArgumentException("no items: " + items.size());
            }
            return items.size();
        }

        /** fx-unresolved-key: so is the key of the wrong type. */
        String nameOf(Map<Long, String> names, int id) {
            Audit.record("name");
            return names.get(id);
        }

        /** fx-unresolved-default: getOrDefault, which JDT does not check, next to an unresolved call: one finding, not one per analysis. */
        int countedOf(Map<Long, Integer> counts, int id) {
            Audit.record("count");
            return counts.getOrDefault(id, 0);
        }

        /** fx-unresolved-null-switch: the switch cannot be set aside, so the null dereference below it is not looked for. */
        int sizeSwitched(List<String> items) {
            switch (Kind.of("size")) {
                case FIRST:
                    break;
                default:
                    break;
            }
            if (items == null) {
                return items.size();
            }
            return 0;
        }

        /** fx-unresolved-key-switch: the same for the key of the wrong type. */
        String nameSwitched(Map<Long, String> names, int id) {
            switch (Kind.of("name")) {
                case FIRST:
                    break;
                default:
                    break;
            }
            return names.get(id);
        }

        /** fx-unresolved-assigned: the unresolved call assigns the variable, which JDT's null analysis must not see as still null. */
        int lengthOf() {
            String text = null;
            text = Source.read();
            return text.length();
        }
    }

    /** A class whose superclass does not exist: JDT leaves out all of its methods. */
    static class MissingSuperUser extends MissingBase {
        /** fx-missing-super-key: the lookup with the wrong key type. */
        String find(Map<Long, String> names, int id) {
            return names.get(id);
        }

        /** fx-missing-super-leak: the stream that is never closed. */
        int openFirst(String path) throws IOException {
            FileInputStream in = new FileInputStream(path);
            return in.read();
        }
    }
}
