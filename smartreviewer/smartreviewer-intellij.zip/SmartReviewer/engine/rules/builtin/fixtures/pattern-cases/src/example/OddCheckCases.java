package example;

import java.util.List;
import java.util.Random;

/** x % 2 == 1 as an odd test (SR-JAVA-ODD-CHECK-001). */
public class OddCheckCases {

    /** P01: hash codes are negative half of the time. */
    int bucket(String key) {
        return 1 == key.hashCode() % 2 ? 1 : 0;
    }

    /** P02: a number typed by the user may be negative. */
    boolean oddInput(String text) {
        return Integer.parseInt(text) % 2 == 1;
    }

    /** P03: kept in a local first; -3 is taken for even. */
    boolean evenHash(Object o) {
        int h = o.hashCode();
        return h % 2 != 1;
    }

    /** P04: nextInt() without a bound is negative half of the time. */
    boolean coin(Random random) {
        return random.nextInt() % 2 == 1;
    }

    /** N01: tests that work for negative numbers. */
    boolean oddOk(int n) {
        return n % 2 != 0 || (n & 1) == 1 || n % 2 == -1;
    }

    /** N02: a loop counter from 0 is never negative. */
    int stripes(int rows) {
        int odd = 0;
        for (int i = 0; i < rows; i++) {
            if (i % 2 == 1) {
                odd++;
            }
        }
        return odd;
    }

    /** N03: a size is never negative. */
    boolean oddCount(List<String> names) {
        return names.size() % 2 == 1;
    }

    /** B01: nothing shows whether the parameter can be negative. */
    boolean odd(int n) {
        return n % 2 == 1;
    }
}
