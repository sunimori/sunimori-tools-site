package javax.servlet;

/** Stand-in for the servlet response, with only the methods the fixtures call. */
public interface ServletResponse {
    java.io.PrintWriter getWriter() throws java.io.IOException;
}
