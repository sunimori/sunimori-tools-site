package example;

/** SR-JAVA-SWITCH-FALLTHROUGH-001 cases. */
public class SwitchCases {
    /** P01: case 1 runs on into case 2. */
    String subject(int code) {
        String name = "";
        switch (code) {
            case 1:
                name = "国語";
            case 2:
                name = "数学";
                break;
            default:
                name = "?";
        }
        return name;
    }

    /** N01: every case ends with return. */
    String ok(int code) {
        switch (code) {
            case 1:
                return "a";
            case 2: {
                return "b";
            }
            default:
                return "c";
        }
    }

    /** N02: an intended fall-through explained by a comment. */
    int commented(int code) {
        int n = 0;
        switch (code) {
            case 1:
                n++;
                // fall through: case 1 also counts as case 2
            case 2:
                n++;
                break;
            default:
                break;
        }
        return n;
    }

    /** N04: the comment explaining the fall-through follows the next label. */
    int labelComment(int code) {
        int n = 0;
        switch (code) {
            case 1:
                n++;
            case 2: /* fall through from case 1 */
                n++;
                break;
            default:
                break;
        }
        return n;
    }

    /** B03: an accumulating fall-through keeps every case's work (no overwrite), so it is not reported by default. */
    int accumulate(int level) {
        int n = 0;
        switch (level) {
            case 3:
                n += 3;
            case 2:
                n += 2;
            case 1:
                n += 1;
                break;
            default:
                break;
        }
        return n;
    }

    /** N03: labels sharing one group of statements. */
    boolean weekend(int day) {
        switch (day) {
            case 6:
            case 7:
                return true;
            default:
                return false;
        }
    }

    /** B01: both branches of the if return. */
    int both(int code, boolean f) {
        switch (code) {
            case 1:
                if (f) {
                    return 1;
                } else {
                    return 2;
                }
            case 2:
                return 3;
            default:
                return 0;
        }
    }

    /** B02: the arrow form never falls through. */
    String arrow(int code) {
        switch (code) {
            case 1 -> {
                return "a";
            }
            default -> {
                return "b";
            }
        }
    }
}
