package example;

import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;

/** Null checks whose operator lets the dereference run on null (SR-JAVA-NULL-CHECK-001). */
public class NullCheckCases {
    private String name;
    private NullCheckCases instance;

    String getName() {
        return name;
    }

    /** P01: == null with &&: isEmpty() runs exactly when the value is null. */
    boolean blank(String value) {
        return value == null && value.isEmpty();
    }

    /** P02: != null with ||. */
    boolean empty(List<String> items) {
        return items != null || items.size() == 0;
    }

    /** P03: the non-short-circuit & evaluates the right side also when the map is null. */
    boolean hasKey(Map<String, Object> map, String key) {
        return map != null & map.containsKey(key);
    }

    /** P04: a getter, checked and dereferenced: it returns the same value twice. */
    boolean unnamed(NullCheckCases other) {
        return other.getName() == null && other.getName().isEmpty();
    }

    /** N01: the right guards. */
    boolean guarded(String value, List<String> items) {
        return (value != null && value.isEmpty()) || (items == null || items.isEmpty());
    }

    /** N02: assigned again before the dereference. */
    boolean loaded(String key) {
        String value = lookup(key);
        return value == null && (value = lookup(key + "/default")) != null && value.length() > 0;
    }

    /** N03: the dereference runs later, in a lambda. */
    boolean deferred(List<String> items) {
        return items == null && check(() -> items.isEmpty());
    }

    /** B01: a field may be set by the call in between. */
    boolean created() {
        return instance == null && create() && instance.getName() != null;
    }

    /** B02: a condition in between does not protect the dereference. */
    boolean same(String a, String b) {
        return a == null && b != null && a.equals(b);
    }

    private String lookup(String key) {
        return key.isEmpty() ? null : key;
    }

    private boolean check(BooleanSupplier s) {
        return s.getAsBoolean();
    }

    private boolean create() {
        instance = new NullCheckCases();
        return true;
    }
}
