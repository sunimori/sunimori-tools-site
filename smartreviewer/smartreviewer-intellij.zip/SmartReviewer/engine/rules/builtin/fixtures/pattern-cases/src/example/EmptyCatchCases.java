package example;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.sql.SQLException;

/** Catch blocks with no statement and no comment (SR-JAVA-EMPTY-CATCH-001). */
public class EmptyCatchCases {

    interface Store {
        void save(String data) throws IOException, SQLException;
    }

    /** N04: parse or keep the default, left out by default; P01: reported once ignoredExceptions is empty. */
    int quantity(String text) {
        int qty = 0;
        try {
            qty = Integer.parseInt(text);
        } catch (NumberFormatException e) {
        }
        return qty;
    }

    /** B06: a parse and a read: the multi-catch also swallows a failed read. */
    int quantityFrom(Reader reader) {
        int qty = 0;
        try {
            qty = Integer.parseInt(String.valueOf((char) reader.read()));
        } catch (NumberFormatException | IOException e) {
        }
        return qty;
    }

    /** P02: the interrupt is lost. */
    void pause() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {}
    }

    /** P03: a failed save goes unnoticed. */
    void store(Store store, String data) {
        try {
            store.save(data);
        } catch (IOException | SQLException ex) {
        }
    }

    /** N01: a comment says why. */
    int parsed(String text) {
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException e) {
            // not a number: use the default below
        }
        return -1;
    }

    /** N02: handled. */
    void logged(Store store, String data) {
        try {
            store.save(data);
        } catch (IOException | SQLException e) {
            System.err.println("save failed: " + e);
        }
    }

    /** N03: the name says so. */
    void ignored(Store store, String data) {
        try {
            store.save(data);
        } catch (IOException | SQLException ignored) {
        }
    }

    /** B01: closing quietly. */
    void closeQuietly(InputStream in) {
        try {
            in.close();
        } catch (IOException e) {
        }
    }

    /** B02: more than a close in the try block. */
    String readAndClose(Reader reader) {
        char[] buffer = new char[16];
        try {
            int n = reader.read(buffer);
            reader.close();
            return new String(buffer, 0, Math.max(n, 0));
        } catch (IOException e) {
        }
        return "";
    }
}
