package example.web;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/** One servlet instance serves every request (SR-JAVA-SINGLETON-FIELD-001). */
public class OrderServlet extends HttpServlet {
    private String customerId;
    private int count;
    private String greeting;
    private final AtomicInteger hits = new AtomicInteger();
    private static int total;

    /** N01: set once when the servlet starts. */
    @Override
    public void init() throws ServletException {
        greeting = "Hello";
    }

    /** P01: another request may change the field before this one prints it. */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        customerId = req.getParameter("customer");
        resp.getWriter().println(greeting + " " + customerId);
    }

    /** N02: locals and a thread-safe counter. */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("customer");
        hits.incrementAndGet();
        resp.getWriter().println(id);
    }

    /** P02: count++ from many threads loses updates. */
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        count++;
        resp.getWriter().println(count);
    }

    /** B01: guarded by synchronized; static fields are left to other checks. */
    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        synchronized (this) {
            count++;
        }
        total++;
        resp.getWriter().println(count);
    }
}
