package javax.servlet;

/** Stand-in for the servlet request, with only the methods the fixtures call. */
public interface ServletRequest {
    String getParameter(String name);
}
