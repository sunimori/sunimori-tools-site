package example;

import java.util.Arrays;

/** Arrays turned into strings by Object.toString() (SR-JAVA-ARRAY-TO-STRING-001). */
public class ArrayStringCases {

    /** P01: "ids=[I@1b6d3586". */
    String describe(int[] ids) {
        return "ids=" + ids;
    }

    /** P02: println(Object). */
    void print(String[] names) {
        System.out.println(names);
    }

    /** P03: toString() of the array. */
    String codes(String[] codes) {
        return codes.toString();
    }

    /** P04: append(Object). */
    String amounts(double[] amounts) {
        StringBuilder sb = new StringBuilder("amounts: ");
        sb.append(amounts);
        return sb.toString();
    }

    /** N01: the contents. */
    String describeOk(int[] ids, String[] names) {
        return "ids=" + Arrays.toString(ids) + " names=" + String.join(",", names);
    }

    /** N02: the char[] overloads print the characters. */
    void chars(char[] word) {
        System.out.println(word);
        StringBuilder sb = new StringBuilder();
        sb.append(word);
        System.out.println(String.valueOf(word));
    }

    /** N03: an element or the length. */
    String first(int[] ids) {
        return "first=" + ids[0] + " count=" + ids.length;
    }

    /** B01: in a concatenation a char[] is an Object too. */
    String word(char[] word) {
        return "word=" + word;
    }
}
