package example.web;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.IOException;

/** The JDK's HTTP server calls one handler instance from many threads (SR-JAVA-SINGLETON-FIELD-001). */
public class StatusHandler implements HttpHandler {
    private String path;

    /** P01: the path of one exchange is overwritten by the next. */
    @Override
    public void handle(HttpExchange exchange) throws IOException {
        path = exchange.getRequestURI().getPath();
        exchange.sendResponseHeaders(204, -1);
    }
}
