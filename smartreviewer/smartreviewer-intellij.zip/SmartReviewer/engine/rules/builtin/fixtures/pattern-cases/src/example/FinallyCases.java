package example;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.List;

/** return, throw, break and continue leaving a finally block (SR-JAVA-FINALLY-JUMP-001). */
public class FinallyCases {

    /** P01: the NumberFormatException never reaches the caller. */
    @SuppressWarnings("finally")
    int parse(String s) {
        try {
            return Integer.parseInt(s);
        } finally {
            return 0;
        }
    }

    /** P02: the exception from the try block is replaced. */
    @SuppressWarnings("finally")
    void process(InputStream in) throws IOException {
        try {
            in.read();
        } finally {
            throw new IllegalStateException("processed");
        }
    }

    /** B06, B07: a failed close rethrown hides the exception of the read, but only when both fail (reportCleanupFailures). */
    int read(InputStream in) throws IOException {
        try {
            return in.read();
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }
    }

    /** P04: break out of finally drops the exception. */
    @SuppressWarnings("finally")
    int first(List<String> values) {
        int n = 0;
        for (String v : values) {
            try {
                n = Integer.parseInt(v);
            } finally {
                if (n > 0) {
                    break;
                }
            }
        }
        return n;
    }

    /** N01: clean-up only. */
    int readAndClose(InputStream in) throws IOException {
        try {
            return in.read();
        } finally {
            in.close();
        }
    }

    /** N02: the throw is caught inside the finally block. */
    void closeQuietly(InputStream in) {
        try {
            in.read();
        } catch (IOException e) {
            System.err.println(e);
        } finally {
            try {
                if (in.available() < 0) {
                    throw new IOException("closed");
                }
            } catch (IOException e) {
                System.err.println(e);
            }
        }
    }

    /** N03: a return in a lambda leaves the lambda, not the finally block. */
    void later(InputStream in) throws IOException {
        try {
            in.read();
        } finally {
            Runnable r = () -> {
                return;
            };
            r.run();
        }
    }

    /** B02: an exception kept in a catch block, rethrown after the clean-up. */
    void copy(InputStream in) throws IOException {
        IOException failure = null;
        try {
            in.read();
        } catch (IOException e) {
            failure = e;
        } finally {
            in.close();
            if (failure != null) {
                throw failure;
            }
        }
    }

    /** B01: a break that stays inside the finally block. */
    void drain(InputStream in) throws IOException {
        try {
            in.read();
        } finally {
            while (true) {
                if (in.read() < 0) {
                    break;
                }
            }
        }
    }
}
