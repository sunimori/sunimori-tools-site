package example;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

/** SR-JAVA-SHARED-FORMAT-001 cases (one field per case). */
public class FormatterCases {
    /** P01 */
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy/MM/dd");
    /** P02 */
    static DecimalFormat SCORE_FORMAT = new DecimalFormat("0.0");
    /** P03 */
    private static Calendar CALENDAR = Calendar.getInstance();
    /** N01: one per instance. */
    private final SimpleDateFormat local = new SimpleDateFormat("HH:mm");
    /** N02: one per thread. */
    private static final ThreadLocal<SimpleDateFormat> PER_THREAD = ThreadLocal.withInitial(() -> new SimpleDateFormat("yyyy"));
    /** B01: DateTimeFormatter is immutable and thread-safe. */
    private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_LOCAL_DATE;

    String format(Date d) {
        return DATE_FORMAT.format(d) + local.format(d) + PER_THREAD.get().format(d) + SCORE_FORMAT.format(1) + CALENDAR.getTime()
                + ISO.toString();
    }
}
