package org.apache.struts.action;

/** Stand-in for the Struts 1 action mapping. */
public class ActionMapping {
    public ActionForward findForward(String name) {
        return new ActionForward();
    }
}
