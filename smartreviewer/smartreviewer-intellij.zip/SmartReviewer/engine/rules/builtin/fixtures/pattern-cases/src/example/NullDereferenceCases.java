package example;

import java.util.List;
import java.util.Map;

/** Variables that can only be null where they are used (SR-JAVA-NULL-DEREF-001), as JDT's flow analysis finds them. */
public class NullDereferenceCases {

    /** P01: the message is built in the branch where the list is null. */
    int size(List<String> items) {
        if (items == null) {
            throw new IllegalArgumentException("no items: " + items.size());
        }
        return items.size();
    }

    /** P02: the variable is only set in a branch that has already returned. */
    String label(Map<String, String> names, String code) {
        String name = null;
        if (code == null) {
            return name.trim();
        }
        name = names.get(code);
        return name;
    }

    /** P03: unboxing a variable that is still null. */
    int total(boolean member) {
        Integer discount = null;
        if (member) {
            return 0;
        }
        return discount;
    }

    /** N01: checked before use. */
    int length(String text) {
        if (text == null) {
            return 0;
        }
        return text.length();
    }

    /** N02: may be null (map lookup), not "can only be null". */
    String trimmed(Map<String, String> names, String code) {
        String name = names.get(code);
        return name.trim();
    }

    /** N03: assigned on every path before the use. */
    String greeting(boolean morning) {
        String text = null;
        if (morning) {
            text = "Good morning";
        } else {
            text = "Hello";
        }
        return text.toUpperCase();
    }

    /** B01: the x == null && x.m() chain is left to SR-JAVA-NULL-CHECK-001. */
    boolean blank(String value) {
        return value == null && value.isEmpty();
    }

    /** B02: asserts run together or not at all; JDT treats each as skipped. */
    String checked(List<String> codes) {
        String first = null;
        assert (first = codes.get(0)) != null;
        assert first.length() == 3;
        return codes.get(0);
    }
}
