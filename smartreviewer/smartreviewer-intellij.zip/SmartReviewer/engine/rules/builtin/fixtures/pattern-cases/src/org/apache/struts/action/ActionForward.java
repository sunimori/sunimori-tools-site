package org.apache.struts.action;

/** Stand-in for the Struts 1 forward. */
public class ActionForward {
}
