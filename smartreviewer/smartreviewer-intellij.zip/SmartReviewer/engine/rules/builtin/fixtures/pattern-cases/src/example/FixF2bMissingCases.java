package example;

import example.missing.Gone;
import example.missing.Holder;
import org.missinglib.servlet.Filter;
import org.missinglib.servlet.HttpServlet;
import org.missinglib.servlet.Widget;

import java.util.List;
import java.util.Map;

/** Cases of area F2b whose types are missing from the class path (Gone, Holder, HttpServlet, Filter and Widget do not exist). */
public class FixF2bMissingCases {
    /** FE-P9: only the element type of the list is missing; the list itself is known. */
    void feUnknownElement(List<Gone> list) {
        for (Gone g : list) {
            if (g != null) {
                list.remove(g);
            }
        }
    }

    /** FE-P10: only the value type of the map is missing. */
    void feUnknownValue(Map<String, Gone> byName) {
        for (String key : byName.keySet()) {
            byName.remove(key);
        }
    }

    /** FE-N8: the receiver itself is unknown, so nothing is known about the collection. */
    void feUnknownReceiver(Holder holder) {
        for (Object o : holder.items()) {
            holder.items().remove(o);
        }
    }

    /** SF-P1: the superclass is missing from the class path; its simple name says it is a servlet. */
    static class MissingServlet extends HttpServlet {
        private String user;

        protected void doGet(Object req, Object resp) {
            user = String.valueOf(req);
        }
    }

    /** SF-P2: the interface is missing from the class path; its simple name says it is a filter. */
    static class MissingFilter implements Filter {
        private String user;

        public void doFilter(Object req, Object resp) {
            user = String.valueOf(req);
        }
    }

    /** SF-N1: a missing superclass with another name is no component. */
    static class MissingWidget extends Widget {
        private String user;

        protected void doGet(Object req, Object resp) {
            user = String.valueOf(req);
        }
    }
}
