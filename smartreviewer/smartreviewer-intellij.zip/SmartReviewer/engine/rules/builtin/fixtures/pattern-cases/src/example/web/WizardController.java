package example.web;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.annotation.RequestScope;

/** A request-scoped controller: a new instance for every request (SR-JAVA-SINGLETON-FIELD-001). */
@RestController
@RequestScope
public class WizardController {
    private String step;

    /** B01: the field belongs to this request only. */
    @PostMapping("/wizard")
    public String next(String value) {
        step = value;
        return step;
    }
}
