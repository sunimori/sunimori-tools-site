package example;

import java.io.IOException;
import java.sql.SQLException;

/** Empty catch blocks for the separators of the ignoredExceptions parameter (SR-JAVA-EMPTY-CATCH-001). */
public class FixECases {

    interface Store {
        void save(String data) throws IOException, SQLException;
    }

    /** An interrupt that is swallowed. */
    void interrupted() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
        }
    }

    /** A save that fails unnoticed, with two exception types in one catch. */
    void stored(Store store, String data) {
        try {
            store.save(data);
        } catch (IOException | SQLException e) {
        }
    }

    /** A parse that keeps the default, which the parameter's default leaves out. */
    int parsed(String text) {
        int value = 0;
        try {
            value = Integer.parseInt(text);
        } catch (NumberFormatException e) {
        }
        return value;
    }
}
