package example;

/** SR-JAVA-INT-DIV-001 cases. */
public class DivisionCases {
    /** P01: an average truncated before it becomes a double. */
    double average(int total, int count) {
        double avg = total / count;
        return avg;
    }

    /** P02: returned as double. */
    double rate(int part, int whole) {
        return part / whole;
    }

    /** P03: Math.ceil of an integer division. */
    int pages(int items, int perPage) {
        return (int) Math.ceil(items / perPage);
    }

    /** P04: the cast comes after the division. */
    double ratio(long a, long b) {
        return (double) (a / b);
    }

    /** P05: multiplied by a double afterwards, the fraction is already gone. */
    double percent(int correct, int questions) {
        return correct / questions * 100.0;
    }

    /** N01: the cast comes before the division. */
    double ok(int total, int count) {
        return (double) total / count;
    }

    /** N02: the result stays an integer. */
    int half(int n) {
        return n / 2;
    }

    /** B01: a floating operand on the left makes the division floating. */
    double scaled(int a, int b) {
        return 1.0 * a / b;
    }
}
