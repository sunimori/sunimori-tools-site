package example;

import java.util.Iterator;
import java.util.Objects;

/** SR-JAVA-IDENTICAL-OPERANDS-001 cases. */
public class IdenticalOperandCases {
    static class Score {
        int value;
        String kbn;

        int getValue() {
            return value;
        }

        String getKbn() {
            return kbn;
        }
    }

    /** P01: compared with itself instead of the other score. */
    boolean sameScore(Score a, Score b) {
        return a.getValue() == a.getValue();
    }

    /** P02: the same condition twice in an || chain. */
    boolean anyMissing(String x, String y) {
        return x == null || y == null || x == null;
    }

    /** P03: equals with itself. */
    boolean sameKbn(Score a, Score b) {
        return a.getKbn().equals(a.getKbn());
    }

    /** P04: subtraction of itself. */
    int diff(int total, int used) {
        return total - total;
    }

    /** P05: Objects.equals with the same argument twice. */
    boolean same(Object x, Object y) {
        return Objects.equals(x, x);
    }

    /** N01: different operands. */
    boolean compare(Score a, Score b) {
        return a.getValue() == b.getValue();
    }

    /** N02: a + a and a * a are legitimate. */
    int square(int a) {
        return a + a + a * a;
    }

    /** B01: x != x is the NaN test on double. */
    boolean isNaN(double d) {
        return d != d;
    }

    /** B03: (x - x) / (x - x) produces NaN on purpose in numerical code. */
    double nan(double x) {
        return (x - x) / (x - x);
    }

    /** P06: the same integer subtracted from itself, shown with parentheses. */
    int zero(int a, int b) {
        return (a + b) - (a + b);
    }

    /** B02: operands with side effects are never treated as identical. */
    boolean pair(Iterator<String> it) {
        return it.next() == it.next();
    }
}
