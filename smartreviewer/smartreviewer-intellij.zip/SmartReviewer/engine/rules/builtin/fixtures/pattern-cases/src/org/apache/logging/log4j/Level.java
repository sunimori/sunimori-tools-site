package org.apache.logging.log4j;

/** Stand-in for the Log4j 2 levels. */
public enum Level {
    INFO, WARN, ERROR
}
