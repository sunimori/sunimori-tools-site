package example;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Supplier;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Cases added with the fixes of the rule review of 2026-10-26 (area F2b): for-each loops, switch fall-through, exceptions that
 * are not thrown, JDBC indexes, catch blocks, singleton fields, shared formats, double-checked locking and equals contracts.
 */
public class FixF2bCases {
    enum Phase { NEW, OPEN, CLOSED }

    static class Detail {
        boolean gone;
    }

    static class Header {
        private final List<Detail> details = new ArrayList<>();

        List<Detail> getDetails() {
            return details;
        }

        List<Detail> copyOfDetails() {
            return new ArrayList<>(details);
        }

        Header next() {
            return this;
        }
    }

    private final List<Detail> items = new ArrayList<>();

    List<Detail> getItems() {
        return items;
    }

    // ------------------------------------------------------------------------------------ SR-JAVA-FOREACH-MODIFY-001

    /** FE-P1: the loop and the removal both go through the getter of the header. */
    void feGetterChain(Header h) {
        for (Detail d : h.getDetails()) {
            if (d.gone) {
                h.getDetails().remove(d);
            }
        }
    }

    /** FE-P2: this.items in the loop, the plain name in the removal. */
    void feThisQualified() {
        for (Detail d : this.items) {
            if (d.gone) {
                items.remove(d);
            }
        }
    }

    /** FE-P3: the getter of this class on both sides. */
    void feOwnGetter() {
        for (Detail d : getItems()) {
            if (d.gone) {
                getItems().remove(d);
            }
        }
    }

    /** FE-P14: the loop goes through the getter, the removal through the field it returns. */
    void feGetterThenField() {
        for (Detail d : getItems()) {
            if (d.gone) {
                items.remove(d);
            }
        }
    }

    /** FE-P15: the loop goes through the field, the removal through the getter. */
    void feFieldThenGetter() {
        for (Detail d : items) {
            if (d.gone) {
                this.getItems().remove(d);
            }
        }
    }

    /** FE-P4: a getter of another file whose list is an ArrayList. */
    void feBeanTags(FixF2bBean bean) {
        for (String tag : bean.getTags()) {
            if (tag.isEmpty()) {
                bean.getTags().remove(tag);
            }
        }
    }

    /** FE-P5: poll() changes the deque that the loop iterates over. */
    void fePollInLoop(Deque<Detail> queue) {
        for (Detail d : queue) {
            if (d.gone) {
                queue.poll();
            }
        }
    }

    /** FE-P6: a type variable bounded by a List. */
    <C extends List<String>> void feGenericBound(C names) {
        for (String n : names) {
            if (n.isEmpty()) {
                names.remove(n);
            }
        }
    }

    /** FE-P7: two nested loops over the same list and one removal: one finding. */
    void feNestedOnce(List<String> names) {
        for (String a : names) {
            for (String b : names) {
                if (a.equals(b)) {
                    names.remove(b);
                }
            }
        }
    }

    /** FE-P8: the list is a field of the superclass, created as an ArrayList there. */
    static class PlainSweeper extends FixF2bBean.Registry {
        void sweep() {
            for (String n : names) {
                if (n.isEmpty()) {
                    names.remove(n);
                }
            }
        }
    }

    /** FE-N1: the getter hands out a copy, so the loop iterates over another list than the one that is changed. */
    void feCopyGetter(Header h) {
        for (Detail d : h.copyOfDetails()) {
            if (d.gone) {
                h.copyOfDetails().remove(d);
            }
        }
    }

    /** FE-N2: another header is changed. */
    void feOtherReceiver(Header a, Header b) {
        for (Detail d : a.getDetails()) {
            if (d.gone) {
                b.getDetails().remove(d);
            }
        }
    }

    /** FE-N3: the header changes in the loop, so the getter does not return the same list twice. */
    void feReceiverChanges(Header h) {
        for (Detail d : h.getDetails()) {
            h = h.next();
            h.getDetails().remove(d);
        }
    }

    /** FE-N4: the iterators of EnumSet and EnumMap never fail. */
    void feEnumCollections() {
        Set<Phase> phases = EnumSet.allOf(Phase.class);
        for (Phase p : phases) {
            if (p == Phase.CLOSED) {
                phases.remove(p);
            }
        }
        Map<Phase, Integer> counts = new EnumMap<>(Phase.class);
        for (Phase p : counts.keySet()) {
            counts.remove(p);
        }
    }

    /** FE-N5: the map of the getter is created as a ConcurrentHashMap in the other file. */
    void feBeanCache(FixF2bBean bean) {
        for (String key : bean.getCache().keySet()) {
            if (key.isEmpty()) {
                bean.getCache().remove(key);
            }
        }
    }

    /** FE-N6: the map of the getter is created in the constructor of the other file. */
    void feBeanFilled(FixF2bBean bean) {
        for (String key : bean.getFilled().keySet()) {
            bean.getFilled().remove(key);
        }
    }

    /** FE-N7: the map is created as a ConcurrentHashMap in the superclass. */
    static class ConcurrentSweeper extends FixF2bBean.Registry {
        void sweep(long limit) {
            for (String k : lastSeen.keySet()) {
                if (lastSeen.get(k) < limit) {
                    lastSeen.remove(k);
                }
            }
        }
    }

    /** FE-B1: the loop ends right after the removal through the getter. */
    void feGetterThenBreak(Header h) {
        for (Detail d : h.getDetails()) {
            if (d.gone) {
                h.getDetails().remove(d);
                break;
            }
        }
    }

    /** FE-P11: a lambda of forEach removes from the list that forEach goes through. */
    void feForEachLambda(List<String> names) {
        names.forEach(n -> {
            if (n.isEmpty()) {
                names.remove(n);
            }
        });
    }

    /** FE-P12: Map.forEach removes from the map. */
    void feMapForEach(Map<String, String> byName) {
        byName.forEach((k, v) -> {
            if (v == null) {
                byName.remove(k);
            }
        });
    }

    /** FE-P13: a stream over the list adds to the list. */
    void feStreamForEach(List<String> names) {
        names.stream().forEach(n -> names.add(n + "-copy"));
    }

    /** FE-N9: forEach changes another list; forEach over a copy; forEach that only reads. */
    void feForEachOther(List<String> names, List<String> other) {
        names.forEach(n -> other.add(n));
        new ArrayList<>(names).forEach(n -> names.remove(n));
        names.forEach(n -> System.out.println(n));
    }

    /** FE-N10: concurrent collections are iterated over a snapshot. */
    void feForEachConcurrent(java.util.concurrent.CopyOnWriteArrayList<String> names) {
        names.forEach(n -> names.remove(n));
    }

    Deque<Detail> newQueue() {
        return new ArrayDeque<>();
    }

    // ------------------------------------------------------------------------------------ SR-JAVA-SWITCH-FALLTHROUGH-001

    /** SW-P1: braced case bodies; the first case's value is overwritten. */
    int swBraced(int type) {
        int price = 0;
        switch (type) {
            case 1: {
                price = 100;
            }
            case 2: {
                price = 200;
                break;
            }
            default: {
                price = 0;
            }
        }
        return price;
    }

    /** SW-P2: comments on the case labels name the cases; they do not explain the fall-through. */
    String swLabelComments(int code) {
        String name = "";
        switch (code) {
            case 1: // 国語
                name = "国語";
            case 2: // 数学
                name = "数学";
                break;
            default: // その他
                name = "他";
        }
        return name;
    }

    /** SW-P3: a comment before the next label that does not talk about the fall-through. */
    String swUnrelatedComment(int code) {
        String name = "";
        switch (code) {
            case 1:
                name = "a";
                // TODO check the other names
            case 2:
                name = "b";
                break;
            default:
                break;
        }
        return name;
    }

    /** SW-N1: the explanation is the first line of the next case. */
    String swCommentInNextCase(int code) {
        String name = "";
        switch (code) {
            case 1:
                name = "a";
            case 2:
                // continues from case 1 on purpose
                name = "b";
                break;
            default:
                break;
        }
        return name;
    }

    /** SW-N2: the label comment says that the fall-through is intended. */
    String swLabelCommentSaysSo(int code) {
        String name = "";
        switch (code) {
            case 1:
                name = "a";
            case 2: // 意図的に case 1 から続ける
                name = "b";
                break;
            default:
                break;
        }
        return name;
    }

    /** SW-N3: braced bodies that add up. */
    int swBracedAccumulate(int level) {
        int n = 0;
        switch (level) {
            case 2: {
                n += 2;
            }
            case 1: {
                n += 1;
                break;
            }
            default:
                break;
        }
        return n;
    }

    /** SW-N4: braced body with the comment after the last statement inside the braces. */
    String swBracedComment(int code) {
        String name = "";
        switch (code) {
            case 1: {
                name = "a";
                // fall through
            }
            case 2: {
                name = "b";
                break;
            }
            default:
                break;
        }
        return name;
    }

    // ------------------------------------------------------------------------------------ SR-JAVA-UNTHROWN-EXCEPTION-001

    static class Errors {
        static IllegalArgumentException invalid(String message) {
            return new IllegalArgumentException(message);
        }

        static RuntimeException propagate(Exception e) {
            throw new IllegalStateException(e);
        }
    }

    static class Fluent extends RuntimeException {
        Fluent mark() {
            return this;
        }
    }

    /** UT-P1: the default arm of an arrow switch creates the exception and drops it. */
    void utArrowDefault(int code) {
        switch (code) {
            case 1 -> System.out.println("one");
            default -> new IllegalArgumentException("bad code " + code);
        }
    }

    /** UT-P2: an expression lambda for a Runnable creates the exception and drops it. */
    void utRunnableLambda(Executor executor) {
        executor.execute(() -> new IllegalStateException("never thrown"));
    }

    /** UT-P3: the result of a factory method that returns an exception is dropped. */
    void utDroppedFactory(int n) {
        if (n < 0) {
            Errors.invalid("negative");
        }
    }

    /** UT-N1: the exception is the value of a switch expression. */
    Exception utSwitchValue(int code) {
        return switch (code) {
            case 1 -> new IllegalStateException("one");
            default -> new IllegalArgumentException("other");
        };
    }

    /** UT-N2: lambdas that return the exception. */
    void utValueLambdas() {
        Supplier<RuntimeException> supplier = () -> new IllegalStateException("supplied");
        Callable<Exception> callable = () -> new Exception("called");
        System.out.println(supplier.get() + " " + callable);
    }

    /** UT-N3: the factory result is thrown or kept; a helper that throws itself needs no throw. */
    void utFactoryUsed(int n, Exception cause) {
        if (n < 0) {
            throw Errors.invalid("negative");
        }
        RuntimeException kept = Errors.invalid("kept");
        System.out.println(kept);
        if (n == 0) {
            Errors.propagate(cause);
        }
    }

    /** UT-N4: a method that returns the exception itself ({@code fillInStackTrace()} style) is no factory. */
    void utFluentDropped(Fluent f) {
        f.mark();
    }

    // ------------------------------------------------------------------------------------ SR-JAVA-JDBC-INDEX-001

    /** JD-P1: the loop counter starts at 0 and is the parameter index. */
    void jdLoopFromZero(PreparedStatement ps, Object[] args) throws SQLException {
        for (int i = 0; i < args.length; i++) {
            ps.setObject(i, args[i]);
        }
    }

    /** JD-P2: a counter that starts at 0 and is used before its first increment. */
    void jdCounter(PreparedStatement ps, String a, String b) throws SQLException {
        int idx = 0;
        ps.setString(idx++, a);
        ps.setString(idx++, b);
    }

    /** JD-P3: an ordinary local initialized with 0 and never changed. */
    String jdLocalZero(ResultSet rs) throws SQLException {
        int col = 0;
        return rs.getString(col);
    }

    /** JD-P4: a constant expression that is 0. */
    String jdArithmeticZero(ResultSet rs) throws SQLException {
        return rs.getString(1 - 1);
    }

    /** JD-P5: a counter used in a for-each loop. */
    void jdCounterInLoop(PreparedStatement ps, List<Object> args) throws SQLException {
        int idx = 0;
        for (Object o : args) {
            ps.setObject(idx++, o);
        }
    }

    /** JD-N1: the index is the counter plus one. */
    void jdLoopPlusOne(PreparedStatement ps, Object[] args) throws SQLException {
        for (int i = 0; i < args.length; i++) {
            ps.setObject(i + 1, args[i]);
        }
    }

    /** JD-N2: the loop starts at 1. */
    void jdLoopFromOne(PreparedStatement ps, Object[] args) throws SQLException {
        for (int i = 1; i <= args.length; i++) {
            ps.setObject(i, args[i - 1]);
        }
    }

    /** JD-N3: the counter starts at 1, or is incremented before the call. */
    void jdCounterFromOne(PreparedStatement ps, String a, String b) throws SQLException {
        int idx = 1;
        ps.setString(idx++, a);
        int next = 0;
        ps.setString(++next, b);
    }

    /** JD-N4: the counter is changed before the call. */
    String jdLocalChanged(ResultSet rs) throws SQLException {
        int col = 0;
        col++;
        return rs.getString(col);
    }

    /** JD-N5: the first round is skipped because of the counter. */
    void jdLoopGuard(PreparedStatement ps, Object[] args) throws SQLException {
        for (int i = 0; i < args.length; i++) {
            if (i == 0) {
                continue;
            }
            ps.setObject(i, args[i]);
        }
    }

    /** JD-N6: the loop body changes the counter before the call. */
    void jdLoopBodyChanges(PreparedStatement ps, Object[] args) throws SQLException {
        for (int i = 0; i < args.length; i++) {
            i++;
            ps.setObject(i, args[i]);
        }
    }

    /** JD-B1: the counter is incremented after the call in the same loop: not proven, so not reported. */
    void jdCounterAfterCall(PreparedStatement ps, List<Object> args) throws SQLException {
        int idx = 0;
        for (Object o : args) {
            if (o != null) {
                ps.setObject(idx, o);
            }
            idx++;
        }
    }

    // ------------------------------------------------------------------------------------ SR-JAVA-EMPTY-CATCH-001

    /** EC-N1: the null-guarded close of the JDBC finally idiom. */
    void ecNullGuardedClose(Connection con) {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
        }
    }

    /** EC-N2: several closes one after another. */
    void ecClosesInSequence(ResultSet rs, Statement st, Connection con) {
        try {
            rs.close();
            st.close();
            con.close();
        } catch (SQLException e) {
        }
    }

    /** EC-N3: a null-guarded close on one line, and a close through a helper. */
    void ecGuardedOneLine(InputStream in) {
        try {
            if (in != null) in.close();
        } catch (IOException e) {
        }
    }

    /** EC-P1: the null guard protects something else than a close. */
    void ecGuardedOther(InputStream in, List<String> log) {
        try {
            if (in != null) {
                log.add("closing");
            }
        } catch (RuntimeException e) {
        }
    }

    /** EC-P2: close and clear the field: more than a close. */
    void ecCloseAndNull(Connection con) {
        try {
            con.close();
            con = null;
        } catch (SQLException e) {
        }
    }

    /** EC-P3: the body holds only an empty statement. */
    void ecSemicolonOnly(Runnable r) {
        try {
            r.run();
        } catch (IllegalStateException e) {
            ;
        }
    }

    /** EC-N4: an empty statement with a comment inside the block. */
    void ecSemicolonWithComment(Runnable r) {
        try {
            r.run();
        } catch (IllegalStateException e) {
            ; // cannot happen here
        }
    }

    /** EC-P4: a comment after the closing brace is not an explanation. */
    void ecCommentAfterBrace(Runnable r) {
        try {
            r.run();
        } catch (IllegalStateException e) {} // never happens
    }

    // ------------------------------------------------------------------------------------ SR-JAVA-EQUALS-OVERLOAD-001, SR-JAVA-EQUALS-HASHCODE-001

    /** EQ-P1: the overload is declared in a local class. */
    void eqLocalClass() {
        class Key {
            public boolean equals(Key other) {
                return other == this;
            }
        }
        System.out.println(new Key());
    }

    /** EQ-P2: the overload is declared in an anonymous subclass. */
    Detail eqAnonymous() {
        return new Detail() {
            public boolean equals(Detail other) {
                return other != null && other.gone == gone;
            }
        };
    }

    /** EQ-N1: a parameter that has nothing to do with the class. */
    Detail eqAnonymousOtherType() {
        return new Detail() {
            public boolean equals(String other) {
                return other == null;
            }
        };
    }

    /** EQ-N2: the local class overrides equals(Object). */
    void eqLocalOverride() {
        class Key {
            @Override
            public boolean equals(Object other) {
                return other == this;
            }

            @Override
            public int hashCode() {
                return 1;
            }
        }
        System.out.println(new Key());
    }

    /** EH-P1: an anonymous class that overrides equals(Object) only. */
    Object ehAnonymous(String v) {
        return new Object() {
            @Override
            public boolean equals(Object o) {
                return o != null && o.toString().equals(v);
            }

            @Override
            public String toString() {
                return v;
            }
        };
    }

    /** EH-N1: the anonymous class overrides both. */
    Object ehAnonymousBoth(String v) {
        return new Object() {
            @Override
            public boolean equals(Object o) {
                return o != null && o.toString().equals(v);
            }

            @Override
            public int hashCode() {
                return v.hashCode();
            }
        };
    }

    /** EH-N2: the anonymous subclass of another class keeps the inherited hashCode (not reported by default). */
    Detail ehAnonymousSubclass() {
        return new Detail() {
            @Override
            public boolean equals(Object o) {
                return o == this;
            }
        };
    }

    // ------------------------------------------------------------------------------------ SR-JAVA-DOUBLE-CHECKED-LOCKING-001

    private static Detail detail;
    private static volatile Detail volatileDetail;
    private static String text;
    private static final ReentrantLock LOCK = new ReentrantLock();
    private Detail instanceDetail;

    /** DC-P1: a ReentrantLock instead of synchronized. */
    static Detail dcReentrantLock() {
        if (detail == null) {
            LOCK.lock();
            try {
                if (detail == null) {
                    detail = new Detail();
                }
            } finally {
                LOCK.unlock();
            }
        }
        return detail;
    }

    /** DC-P2: the second check is nested in a try. */
    static Detail dcInsideTry() {
        if (detail == null) {
            synchronized (FixF2bCases.class) {
                try {
                    if (detail == null) {
                        detail = new Detail();
                    }
                } finally {
                    System.out.println("checked");
                }
            }
        }
        return detail;
    }

    /** DC-P3: the local copy idiom works only with a volatile field. */
    static Detail dcLocalCopy() {
        Detail result = detail;
        if (result == null) {
            synchronized (FixF2bCases.class) {
                result = detail;
                if (result == null) {
                    detail = result = new Detail();
                }
            }
        }
        return result;
    }

    /** DC-P4: the field is assigned by a helper. */
    static Detail dcHelperAssigns() {
        if (detail == null) {
            synchronized (FixF2bCases.class) {
                if (detail == null) {
                    load();
                }
            }
        }
        return detail;
    }

    private static void load() {
        detail = new Detail();
    }

    /** DC-P5: this. in the second check only. */
    Detail dcThisInInnerCheck() {
        if (instanceDetail == null) {
            synchronized (this) {
                if (this.instanceDetail == null) {
                    this.instanceDetail = new Detail();
                }
            }
        }
        return instanceDetail;
    }

    /** DC-N1: the local copy idiom with a volatile field is the correct one. */
    static Detail dcLocalCopyVolatile() {
        Detail result = volatileDetail;
        if (result == null) {
            synchronized (FixF2bCases.class) {
                result = volatileDetail;
                if (result == null) {
                    volatileDetail = result = new Detail();
                }
            }
        }
        return result;
    }

    /** DC-N2: a String is immutable and safely published through its final fields. */
    static String dcImmutableString() {
        if (text == null) {
            synchronized (FixF2bCases.class) {
                if (text == null) {
                    text = String.valueOf(System.nanoTime());
                }
            }
        }
        return text;
    }

    /** DC-N3: the second check does not test the same variable. */
    static Detail dcOtherVariable(Detail other) {
        if (detail == null) {
            LOCK.lock();
            try {
                if (other == null) {
                    detail = new Detail();
                }
            } finally {
                LOCK.unlock();
            }
        }
        return detail;
    }

    private static final Object MARK = Boolean.TRUE;

    /** DC-N4: the local is read from a map and given a constant: no field is published, so there is no double-checked locking. */
    static Object dcConstantAlias(Map<String, Object> results, String key) {
        Object o = results.get(key);
        if (o == null) {
            synchronized (FixF2bCases.class) {
                o = results.get(key);
                if (o == null) {
                    o = MARK;
                    results.put(key, o);
                }
            }
        }
        return o;
    }

    // ------------------------------------------------------------------------------------ SR-JAVA-SINGLETON-FIELD-001

    /** SF-N1: lazily created collaborator, no request data. */
    static class LazyServlet extends HttpServlet {
        private Object service;
        private Detail detail;

        @Override
        protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            if (service == null) {
                service = new Object();
            }
            if (detail == null) {
                detail = new Detail();
            }
        }
    }

    /** SF-N2: counters guarded by a lock. */
    static class LockedServlet extends HttpServlet {
        private final ReentrantLock lock = new ReentrantLock();
        private int counter;
        private String last;

        @Override
        protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            lock.lock();
            try {
                counter++;
                last = req.getParameter("q");
            } finally {
                lock.unlock();
            }
        }

        @Override
        protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            lock.lock();
            counter++;
            lock.unlock();
        }
    }

    /** SF-P1: the lazily created object is built from the request. */
    static class LazyFromRequestServlet extends HttpServlet {
        private String owner;

        @Override
        protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            if (owner == null) {
                owner = req.getParameter("owner");
            }
        }
    }

    /** SF-P2: plain request data in a field of a servlet (the established case). */
    static class PlainServlet extends HttpServlet {
        private String user;

        @Override
        protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            user = req.getParameter("user");
        }
    }

    // ------------------------------------------------------------------------------------ SR-JAVA-SHARED-FORMAT-001

    /** SH-P1: an array of formatters. */
    private static final java.text.SimpleDateFormat[] FORMATS = {
        new java.text.SimpleDateFormat("yyyy/MM/dd"), new java.text.SimpleDateFormat("yyyy-MM-dd")
    };
    /** SH-P2: a map that caches formatters. */
    private static final Map<String, java.text.SimpleDateFormat> FORMAT_CACHE = new java.util.HashMap<>();
    /** SH-P3: the base type of the formatters. */
    private static final java.text.Format BASE_FORMAT = new java.text.SimpleDateFormat("yyyy");
    /** SH-P4: ChoiceFormat is a stateful NumberFormat too. */
    private static final java.text.ChoiceFormat FILES = new java.text.ChoiceFormat("0#no files|1#one file|1<many files");
    /** SH-N1: every use is synchronized on the formatter itself. */
    private static final java.text.SimpleDateFormat GUARDED = new java.text.SimpleDateFormat("yyyy/MM/dd");
    /** SH-N2: a ThreadLocal holds one formatter per thread. */
    private static final ThreadLocal<java.text.SimpleDateFormat> PER_THREAD =
            ThreadLocal.withInitial(() -> new java.text.SimpleDateFormat("yyyy"));
    /** SH-N3: only some uses are synchronized. */
    private static final java.text.SimpleDateFormat PARTLY = new java.text.SimpleDateFormat("yyyy/MM/dd");

    static String shGuarded(java.util.Date d) {
        synchronized (GUARDED) {
            return GUARDED.format(d);
        }
    }

    static String shPartly(java.util.Date d) {
        synchronized (PARTLY) {
            return PARTLY.format(d);
        }
    }

    static String shPartlyUnguarded(java.util.Date d) {
        return PARTLY.format(d);
    }

    static Object shUses(java.util.Date d) {
        return FORMATS.length + FORMAT_CACHE.size() + BASE_FORMAT.format(d) + FILES.format(1) + PER_THREAD.get().format(d);
    }

    // ------------------------------------------------------------------------------------ SR-JAVA-DUP-CONDITION-001

    /** DUP-P1: the same condition written with different spacing. */
    int dupSpacing(int score) {
        if (score >= 80) {
            return 5;
        } else if (score >= 60) {
            return 4;
        } else if (score>=80) {
            return 3;
        }
        return 1;
    }

    /** DUP-N1: conditions that differ. */
    int dupDifferent(int score) {
        if (score >= 80) {
            return 5;
        } else if (score>=70) {
            return 4;
        }
        return 1;
    }
}
