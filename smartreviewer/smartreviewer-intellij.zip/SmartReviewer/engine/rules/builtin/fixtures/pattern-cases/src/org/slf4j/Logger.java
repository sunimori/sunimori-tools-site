package org.slf4j;

/** Stand-in for the SLF4J logger interface, with only the methods the fixtures call. */
public interface Logger {
    void info(String msg);

    void info(String format, Object arg);

    void info(String format, Object arg1, Object arg2);

    void info(String format, Object... arguments);

    void info(Marker marker, String format, Object... arguments);

    void warn(String format, Object... arguments);

    void error(String msg, Throwable t);

    void error(String format, Object arg);

    void error(String format, Object arg1, Object arg2);

    void error(String format, Object... arguments);
}
