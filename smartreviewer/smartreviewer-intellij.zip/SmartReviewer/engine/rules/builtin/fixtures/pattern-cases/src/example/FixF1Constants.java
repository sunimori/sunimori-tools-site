package example;

/** Constants of another class, used by FixF1Cases: the review fixes F1 follow them across files. */
public final class FixF1Constants {
    public static final String WEEK_PATTERN = "YYYY/MM/dd";
    public static final String PIPE = "|";
    public static final String GREETING = "hello {} from {}";

    private FixF1Constants() {
    }
}
