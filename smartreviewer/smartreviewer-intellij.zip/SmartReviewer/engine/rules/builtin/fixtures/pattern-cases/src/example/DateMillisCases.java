package example;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

/** SS (milliseconds) where seconds were meant (SR-JAVA-DATE-MILLIS-SECOND-001). */
public class DateMillisCases {
    /** P01 */
    SimpleDateFormat time() {
        return new SimpleDateFormat("HH:mm:SS");
    }

    /** P02: DateTimeFormatter (S is a fraction of the second there). */
    DateTimeFormatter stamp() {
        return DateTimeFormatter.ofPattern("yyyyMMddHHmmSS");
    }

    /** N01: seconds and milliseconds. */
    SimpleDateFormat precise() {
        return new SimpleDateFormat("HH:mm:ss.SSS");
    }

    /** N02: seconds. */
    SimpleDateFormat seconds() {
        return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    }

    /** B01: SSS on its own is an explicit choice of milliseconds. */
    SimpleDateFormat millis() {
        return new SimpleDateFormat("mm:SSS");
    }

    /** B02: S in quotes is text. */
    SimpleDateFormat quoted() {
        return new SimpleDateFormat("HH:mm 'SS'");
    }
}
