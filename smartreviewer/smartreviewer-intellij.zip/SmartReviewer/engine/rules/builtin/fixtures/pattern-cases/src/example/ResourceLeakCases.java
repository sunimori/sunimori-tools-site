package example;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.Reader;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Formatter;
import java.util.Scanner;
import javax.sql.DataSource;

/** Resources that are not closed (SR-JAVA-RESOURCE-LEAK-001), as JDT's flow analysis finds them. */
public class ResourceLeakCases {
    private Reader source;
    private DataSource dataSource;

    /** P01: the reader is never closed. */
    String firstLine(File file) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(file));
        return reader.readLine();
    }

    /** P02: closed on the normal path, left open by the early return. */
    int header(File file) throws IOException {
        FileInputStream in = new FileInputStream(file);
        int first = in.read();
        if (first < 0) {
            return -1;
        }
        in.close();
        return first;
    }

    /** P03: the statement is never closed (JDBC: "may not be closed", reported by default). */
    int cancel(Connection con, String orderNo) throws SQLException {
        PreparedStatement ps = con.prepareStatement("UPDATE orders SET status = 'CANCELLED' WHERE order_no = ?");
        ps.setString(1, orderNo);
        return ps.executeUpdate();
    }

    /** P04: read through an unnamed Scanner that nobody closes. */
    String wholeFile(File file) throws IOException {
        return new Scanner(file).useDelimiter("\\Z").next();
    }

    /** N01: try-with-resources. */
    String firstLineSafely(File file) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            return reader.readLine();
        }
    }

    /** N02: closed in finally. */
    int count(Connection con) throws SQLException {
        Statement st = con.createStatement();
        try {
            ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM orders");
            rs.next();
            return rs.getInt(1);
        } finally {
            st.close();
        }
    }

    /** N03: kept in a field; whoever owns the object closes it. */
    void open(File file) throws IOException {
        source = new BufferedReader(new FileReader(file));
    }

    /** B01: a Formatter over a StringBuilder holds nothing to close. */
    String code(int number) {
        StringBuilder sb = new StringBuilder();
        Formatter formatter = new Formatter(sb);
        formatter.format("%06d", number);
        return sb.toString();
    }

    /** B02: System.in must stay open. */
    String answer() throws IOException {
        BufferedReader console = new BufferedReader(new InputStreamReader(System.in));
        return console.readLine();
    }

    /** B03: the stream becomes the channel, which the caller closes. */
    FileChannel channel(File file) throws IOException {
        return new FileInputStream(file).getChannel();
    }

    /** B04: a stream from a method JDT does not know: only "may not be closed". */
    int download(URL url) throws IOException {
        InputStream in = url.openStream();
        return in.read();
    }

    /** B08: the early return leaves the statement open, but the method closes its connection in finally. */
    int countRows(DataSource ds, boolean skip) throws SQLException {
        Connection con = ds.getConnection();
        try {
            PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM orders");
            if (skip) {
                return 0;
            }
            ResultSet rs = ps.executeQuery();
            rs.next();
            int n = rs.getInt(1);
            rs.close();
            ps.close();
            return n;
        } finally {
            con.close();
        }
    }

    /** B10: the connection is closed only when this object opened it: otherwise the early return leaves the statement open. */
    int countRowsWith(boolean own, boolean skip) throws SQLException {
        Connection con = connection();
        try {
            PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM orders");
            if (skip) {
                return 0;
            }
            ResultSet rs = ps.executeQuery();
            rs.next();
            int n = rs.getInt(1);
            rs.close();
            ps.close();
            return n;
        } finally {
            if (con != null && own) {
                con.close();
            }
        }
    }

    /** A shared or new connection (made elsewhere, not by the JDBC API in this method). */
    private Connection connection() throws SQLException {
        return dataSource.getConnection();
    }

    /** B09: piped streams hold memory only. */
    PipedInputStream pipe(Object value) throws IOException {
        PipedInputStream in = new PipedInputStream(1 << 16);
        ObjectOutputStream out = new ObjectOutputStream(new PipedOutputStream(in));
        out.writeObject(value);
        out.flush();
        return in;
    }
}
