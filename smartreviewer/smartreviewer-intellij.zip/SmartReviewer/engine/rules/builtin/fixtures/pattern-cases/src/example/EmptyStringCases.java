package example;

/** Empty strings compared by reference (SR-JAVA-EMPTY-STRING-EQ-001) next to other string comparisons (SR-JAVA-STRING-EQ-001). */
public class EmptyStringCases {
    static final String EMPTY = "";

    /** A request value compared with "" by reference: true for an empty value too. */
    boolean hasName(String name) {
        return name != null && name != "";
    }

    boolean isBlankCode(String code) {
        return "" == code;
    }

    boolean hasText(String text) {
        return text != null && !text.isEmpty();
    }

    boolean isEmptyCode(String code) {
        return "".equals(code);
    }

    /** Both sides are compile-time constants. */
    boolean constants() {
        return EMPTY == "";
    }

    /** A non-empty literal belongs to SR-JAVA-STRING-EQ-001. */
    boolean isZero(String kbn) {
        return kbn == "0";
    }
}
