package example;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.text.ChoiceFormat;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Calendar;
import java.util.Date;
import java.util.Formatter;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.BiFunction;
import java.util.function.DoubleFunction;
import java.util.function.Function;
import java.util.logging.Level;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.logging.log4j.LogManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * Regression cases of the review fixes F1: constants as date patterns, format strings, regular expressions and log messages,
 * and the BigDecimal, calendar and charset rules. Every method name is unique: the suites select them by name.
 */
@SuppressWarnings({"deprecation", "unused"})
public class FixF1Cases {
    // ------------------------------------------------------------------------------------------ constants

    static final String FX_FULL = "yyyy/MM/DD hh:mm:SS";
    static final String FX_WEEK = "YYYY-MM-dd";
    static final String FX_CORRECT = "yyyy-MM-dd";
    private static final String FX_PIPE = "|";
    private static final String FX_FORMAT = "%s and %s";
    private static final String FX_MESSAGE = "login {} from {}";
    private static final String FX_PREFIX = "YYYY";

    /** An interface constant. */
    interface FxPatterns {
        String YEAR = "YYYY";
        String DAY_OF_YEAR = "yyyy-DD-MM";
    }

    private static final Logger FX_LOG = LoggerFactory.getLogger(FixF1Cases.class);
    private static final org.apache.logging.log4j.Logger FX_LOG4J = LogManager.getLogger(FixF1Cases.class);
    private static final org.apache.logging.log4j.Logger FX_PRINTF_LOG = getFormatterLogger(FixF1Cases.class);
    private static final java.util.logging.Logger FX_JUL = java.util.logging.Logger.getLogger("fx");
    private static final ChoiceFormat FX_CHOICE = new ChoiceFormat(new double[] {0, 1, 2}, new String[] {"Jan", "Feb", "Mar"});
    private static final BigDecimal FX_HUNDRED = new BigDecimal("100");
    private final BigDecimal fxTen = BigDecimal.TEN;

    private static org.apache.logging.log4j.Logger getFormatterLogger(Class<?> type) {
        return LogManager.getLogger(type);
    }

    // ------------------------------------------------------------------------------------------ date patterns

    /** The pattern is a static final constant: DD with MM, hh without a, SS without ss (three rules). */
    SimpleDateFormat fxConstantPattern() {
        return new SimpleDateFormat(FX_FULL);
    }

    /** WEEK-YEAR: a static final constant. */
    SimpleDateFormat fxWeekConstant() {
        return new SimpleDateFormat(FX_WEEK);
    }

    /** WEEK-YEAR: applyPattern with a constant. */
    void fxWeekApply(SimpleDateFormat format) {
        format.applyPattern(FX_WEEK);
    }

    /** WEEK-YEAR: DateTimeFormatter with a constant. */
    DateTimeFormatter fxWeekOfPattern() {
        return DateTimeFormatter.ofPattern(FX_WEEK);
    }

    /** WEEK-YEAR: an interface constant joined with literals. */
    DateTimeFormatter fxWeekInterface() {
        return DateTimeFormatter.ofPattern(FxPatterns.YEAR + "-MM-dd");
    }

    /** WEEK-YEAR: two literals joined. */
    SimpleDateFormat fxWeekConcatenated() {
        return new SimpleDateFormat("YYYY" + "/MM/dd");
    }

    /** WEEK-YEAR: a constant joined with a literal. */
    SimpleDateFormat fxWeekPrefixConstant() {
        return new SimpleDateFormat(FX_PREFIX + "/MM/dd");
    }

    /** WEEK-YEAR: a final local. */
    SimpleDateFormat fxWeekFinalLocal() {
        final String pattern = "YYYY-MM-dd";
        return new SimpleDateFormat(pattern);
    }

    /** WEEK-YEAR: a local that only its initializer assigns. */
    SimpleDateFormat fxWeekEffectivelyFinalLocal() {
        String pattern = "YYYY-MM-dd";
        return new SimpleDateFormat(pattern);
    }

    /** WEEK-YEAR: a text block. */
    SimpleDateFormat fxWeekTextBlock() {
        return new SimpleDateFormat("""
                YYYY-MM-dd""");
    }

    /** WEEK-YEAR: a constant of another class. */
    SimpleDateFormat fxWeekOtherClass() {
        return new SimpleDateFormat(FixF1Constants.WEEK_PATTERN);
    }

    /** WEEK-YEAR: each constant arm of a conditional is judged where it stands (one arm is wrong). */
    SimpleDateFormat fxWeekConditional(boolean compact) {
        return new SimpleDateFormat(compact ? "yyyyMMdd" : "YYYYMMdd");
    }

    /** WEEK-YEAR: both arms are wrong. */
    DateTimeFormatter fxWeekConditionalBoth(boolean compact) {
        return DateTimeFormatter.ofPattern(compact ? "YYYYMMdd" : FX_WEEK);
    }

    /** WEEK-YEAR: the arms of a switch expression, an arrow arm and a block arm with yield (two are wrong). */
    SimpleDateFormat fxWeekSwitch(int kind) {
        return new SimpleDateFormat(switch (kind) {
            case 1 -> "yyyyMMdd";
            case 2 -> FX_WEEK;
            default -> {
                yield "YYYY/MM";
            }
        });
    }

    /** WEEK-YEAR: the conditional a local was set from. */
    SimpleDateFormat fxWeekConditionalLocal(boolean compact) {
        String pattern = compact ? "yyyyMMdd" : "YYYYMMdd";
        return new SimpleDateFormat(pattern);
    }

    /** WEEK-YEAR: the switch expression a local was set from. */
    DateTimeFormatter fxWeekSwitchLocal(int kind) {
        String pattern = switch (kind) {
            case 1 -> "yyyyMMdd";
            default -> "YYYY-MM-dd";
        };
        return DateTimeFormatter.ofPattern(pattern);
    }

    /** WEEK-YEAR (NEG): the arms of a switch expression are right. */
    DateTimeFormatter fxSwitchCorrect(int kind) {
        return DateTimeFormatter.ofPattern(switch (kind) {
            case 1 -> "yyyyMMdd";
            default -> FX_CORRECT;
        });
    }

    /** WEEK-YEAR (NEG): both arms are right. */
    SimpleDateFormat fxConditionalCorrect(boolean compact) {
        return new SimpleDateFormat(compact ? "yyyyMMdd" : FX_CORRECT);
    }

    /** WEEK-YEAR: DateTimeFormatterBuilder.appendPattern. */
    DateTimeFormatter fxWeekAppendPattern() {
        return new DateTimeFormatterBuilder().appendPattern(FX_WEEK).toFormatter();
    }

    /** WEEK-YEAR: the pattern of Jackson's @JsonFormat. */
    @JsonFormat(pattern = "YYYY-MM-dd HH:mm:ss")
    private Date fxJsonStamp;

    /** WEEK-YEAR: the pattern of Spring's @DateTimeFormat, a constant, on a parameter. */
    void fxSpringParameter(@DateTimeFormat(pattern = FX_WEEK) Date from) {
    }

    /** WEEK-YEAR (NEG): the right letters in the annotation. */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Tokyo")
    private Date fxJsonCorrect;

    /** WEEK-YEAR (NEG): no pattern in the annotation. */
    @JsonFormat(timezone = "Asia/Tokyo")
    private Date fxJsonWithoutPattern;

    /** WEEK-YEAR: super(pattern) in a subclass of SimpleDateFormat. */
    static final class FxWeekFormat extends SimpleDateFormat {
        FxWeekFormat() {
            super(FX_WEEK);
        }
    }

    /** WEEK-YEAR (NEG): the pattern is not known. */
    SimpleDateFormat fxWeekParameter(String pattern) {
        return new SimpleDateFormat(pattern);
    }

    /** WEEK-YEAR (NEG): a local that is assigned twice has no known value. */
    SimpleDateFormat fxWeekReassigned(boolean iso) {
        String pattern = "YYYY-MM-dd";
        if (iso) {
            pattern = "yyyy-MM-dd";
        }
        return new SimpleDateFormat(pattern);
    }

    /** WEEK-YEAR (NEG): a constant with the right letters. */
    SimpleDateFormat fxWeekCorrectConstant() {
        return new SimpleDateFormat(FX_CORRECT);
    }

    /** WEEK-YEAR (NEG): the week-based year together with the week. */
    DateTimeFormatter fxWeekWithWeekConstant() {
        final String pattern = "YYYY-'W'ww";
        return DateTimeFormatter.ofPattern(pattern);
    }

    /** DAY-OF-YEAR: an interface constant with DD next to MM. */
    DateTimeFormatter fxDayOfYearInterface() {
        return DateTimeFormatter.ofPattern(FxPatterns.DAY_OF_YEAR);
    }

    /** MINUTE-MONTH: mm in the date part of a timestamp pattern, the minutes after HH are right. */
    SimpleDateFormat fxMinuteMonthTimestamp() {
        return new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
    }

    /** MINUTE-MONTH: the same with a 12-hour clock. */
    SimpleDateFormat fxMinuteMonthTwelveHour() {
        return new SimpleDateFormat("yyyy-mm-dd hh:mm:ss a");
    }

    /** MINUTE-MONTH: compact digits. */
    SimpleDateFormat fxMinuteMonthCompact() {
        return new SimpleDateFormat("yyyymmddHHmmss");
    }

    /** MINUTE-MONTH: day first. */
    SimpleDateFormat fxMinuteMonthDayFirst() {
        return new SimpleDateFormat("dd/mm/yyyy HH:mm");
    }

    /** MINUTE-MONTH: through a constant. */
    SimpleDateFormat fxMinuteMonthConstant() {
        final String pattern = "yyyy-mm-dd HH:mm:ss";
        return new SimpleDateFormat(pattern);
    }

    /** MINUTE-MONTH (NEG): the time alone. */
    SimpleDateFormat fxTimeOnly() {
        return new SimpleDateFormat("HH:mm");
    }

    /** MINUTE-MONTH (NEG): minutes and seconds. */
    SimpleDateFormat fxMinutesSecondsOnly() {
        return new SimpleDateFormat("mm:ss");
    }

    /** MINUTE-MONTH (NEG): the month is MM, the minutes follow the hour. */
    SimpleDateFormat fxDateAndMinutes() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm");
    }

    /** MINUTE-MONTH (NEG): mm in quotes is text. */
    SimpleDateFormat fxQuotedMinutes() {
        return new SimpleDateFormat("yyyy-MM-dd 'mm'");
    }

    /** MINUTE-MONTH (NEG): the time comes first and the date part has its month. */
    SimpleDateFormat fxTimeThenDate() {
        return new SimpleDateFormat("HH:mm yyyy-MM-dd");
    }

    // ------------------------------------------------------------------------------------------ format strings

    /** FORMAT-ARGS: a static final format. */
    String fxFormatConstant(String a) {
        return String.format(FX_FORMAT, a);
    }

    /** FORMAT-ARGS: two literals joined. */
    String fxFormatConcatenated(String a) {
        return String.format("a %s " + "b %s", a);
    }

    /** FORMAT-ARGS: a text block with formatted(). */
    String fxFormatTextBlock(String a) {
        return """
                first %s
                second %s
                """.formatted(a);
    }

    /** FORMAT-ARGS: a text block as the format. */
    String fxFormatTextBlockArgument(String a) {
        return String.format("""
                first %s
                second %s
                """, a);
    }

    /** FORMAT-ARGS: a local that only its initializer assigns. */
    String fxFormatLocal(String a) {
        String format = "%s-%s";
        return String.format(format, a);
    }

    /** FORMAT-ARGS: a constant used with formatted(). */
    String fxFormattedConstant(String a) {
        return FX_FORMAT.formatted(a);
    }

    /** FORMAT-ARGS: the console. */
    void fxConsolePrintf(String a) {
        System.console().printf("%s %s", a);
    }

    /** FORMAT-ARGS (NEG): matching counts through a constant. */
    String fxFormatConstantMatching(String a) {
        return String.format(FX_FORMAT, a, a);
    }

    /** FORMAT-ARGS (NEG): matching counts through a text block. */
    String fxFormatTextBlockMatching(String a) {
        return """
                first %s
                second %s
                """.formatted(a, a);
    }

    // ------------------------------------------------------------------------------------------ log messages

    /** PLACEHOLDER-ARGS: the message is a constant. */
    void fxLogConstant(String user) {
        FX_LOG.info(FX_MESSAGE, user);
    }

    /** PLACEHOLDER-ARGS: two literals joined. */
    void fxLogConcatenated(String user) {
        FX_LOG.info("login {} " + "from {}", user);
    }

    /** PLACEHOLDER-ARGS: a text block. */
    void fxLogTextBlock(String a) {
        FX_LOG.info("""
                first {}
                second {}
                """, a);
    }

    /** PLACEHOLDER-ARGS: a plain Log4j 2 logger does not read printf specifiers. */
    void fxLog4jPlain(String id) {
        FX_LOG4J.info("Order %s shipped", id);
    }

    /** PLACEHOLDER-ARGS (NEG): a Log4j 2 formatter logger formats printf-style. */
    void fxLog4jFormatterLogger(String id, String address) {
        FX_PRINTF_LOG.info("Order %s shipped to %s", id, address);
    }

    /** PLACEHOLDER-ARGS (NEG): a Log4j 2 logger that comes from elsewhere and a printf message. */
    void fxLog4jUnknownOrigin(org.apache.logging.log4j.Logger logger, String id) {
        logger.info("Order %s shipped", id);
    }

    /** PLACEHOLDER-ARGS (NEG): matching counts through a constant. */
    void fxLogConstantMatching(String user, String host) {
        FX_LOG.info(FX_MESSAGE, user, host);
    }

    /** PLACEHOLDER-ARGS: java.util.logging with {0} {1} and one value. */
    void fxJulMissing(String a) {
        FX_JUL.log(Level.INFO, "Loaded {0} from {1}", a);
    }

    /** PLACEHOLDER-ARGS: java.util.logging with an array written out. */
    void fxJulArray(String a) {
        FX_JUL.log(Level.INFO, "Loaded {0} from {1}", new Object[] {a});
    }

    /** PLACEHOLDER-ARGS: java.util.logging with a parameter that no placeholder uses. */
    void fxJulExtra(String a) {
        FX_JUL.log(Level.INFO, "done", a);
    }

    /** PLACEHOLDER-ARGS (NEG): java.util.logging with matching counts. */
    void fxJulMatching(String a, String b) {
        FX_JUL.log(Level.INFO, "Loaded {0} from {1}", new Object[] {a, b});
        FX_JUL.log(Level.INFO, "Loaded {0}", a);
    }

    /** PLACEHOLDER-ARGS (NEG): java.util.logging without parameters leaves the braces as text. */
    void fxJulNoParameters() {
        FX_JUL.log(Level.INFO, "braces {0} stay text");
        FX_JUL.info("braces {0} stay text");
    }

    /** PLACEHOLDER-ARGS (NEG): java.util.logging with an array built elsewhere. */
    void fxJulUnknownArray(Object[] values) {
        FX_JUL.log(Level.INFO, "Loaded {0} from {1}", values);
    }

    // ------------------------------------------------------------------------------------------ regular expressions

    /** REGEX-LITERAL: the delimiter is a static final constant. */
    String[] fxSplitConstant(String record) {
        return record.split(FX_PIPE);
    }

    /** REGEX-LITERAL: the delimiter is a local that only its initializer assigns. */
    String[] fxSplitLocal(String record) {
        String separator = ".";
        return record.split(separator);
    }

    /** REGEX-LITERAL: the delimiter is a constant of another class. */
    String[] fxSplitOtherClass(String record) {
        return record.split(FixF1Constants.PIPE);
    }

    /** PLACEHOLDER-ARGS: the message is a constant of another class. */
    void fxLogOtherClass(String user) {
        FX_LOG.info(FixF1Constants.GREETING, user);
    }

    /** REGEX-LITERAL (NEG): the delimiter is escaped by a constant. */
    String[] fxSplitEscapedConstant(String record) {
        final String escaped = "\\|";
        return record.split(escaped);
    }

    /** REGEX-LITERAL (NEG): indenting with ^ is the insertion idiom. */
    String fxIndent(String text) {
        return text.replaceAll("^", "    ");
    }

    /** REGEX-LITERAL (NEG): terminating with $ is the insertion idiom. */
    String fxTerminate(String statement) {
        return statement.replaceAll("$", ";");
    }

    /** REGEX-LITERAL (NEG): a prefix that is not a literal. */
    String fxPrefixVariable(String text, String prefix) {
        return text.replaceAll("^", prefix);
    }

    /** REGEX-LITERAL: $ replaced by nothing is an attempt to delete the dollar sign. */
    String fxStripDollar(String price) {
        return price.replaceAll("$", "");
    }

    /** REGEX-LITERAL: ^ in split is never right. */
    String[] fxSplitCaret(String text) {
        return text.split("^");
    }

    // ------------------------------------------------------------------------------------------ BigDecimal

    /** BIGDECIMAL-DIVIDE (NEG): a static final constant with the value 100. */
    BigDecimal fxDivideByNamedConstant(BigDecimal amount, BigDecimal percent) {
        return amount.multiply(percent).divide(FX_HUNDRED);
    }

    /** BIGDECIMAL-DIVIDE (NEG): a power of ten. */
    BigDecimal fxDivideByPowerOfTen(BigDecimal value, int digits) {
        return value.divide(BigDecimal.TEN.pow(digits));
    }

    /** BIGDECIMAL-DIVIDE (NEG): valueOf(2). */
    BigDecimal fxDivideByTwo(BigDecimal value) {
        return value.divide(BigDecimal.valueOf(2));
    }

    /** BIGDECIMAL-DIVIDE (NEG): 8 is 2 to the third. */
    BigDecimal fxDivideByEight(BigDecimal value) {
        return value.divide(new BigDecimal("8"));
    }

    /** BIGDECIMAL-DIVIDE (NEG): a negative power of ten, an exponent, an unscaled value with a scale. */
    BigDecimal[] fxDivideByWrittenForms(BigDecimal value) {
        return new BigDecimal[] {value.divide(new BigDecimal("-10")), value.divide(new BigDecimal("1E+2")), value.divide(BigDecimal.valueOf(100, 2))};
    }

    /** BIGDECIMAL-DIVIDE (NEG): a final field with an initializer. */
    BigDecimal fxDivideByFinalField(BigDecimal value) {
        return value.divide(fxTen);
    }

    /** BIGDECIMAL-DIVIDE (NEG): a local set once. */
    BigDecimal fxDivideByLocal(BigDecimal value) {
        BigDecimal quarter = new BigDecimal("0.25");
        return value.divide(quarter);
    }

    /** BIGDECIMAL-DIVIDE (NEG): the exact division has its fallback. */
    BigDecimal fxDivideWithFallback(BigDecimal a, BigDecimal b) {
        try {
            return a.divide(b);
        } catch (ArithmeticException e) {
            return a.divide(b, 10, RoundingMode.HALF_UP);
        }
    }

    /** BIGDECIMAL-DIVIDE: 3 has no finite quotient. */
    BigDecimal fxDivideByThree(BigDecimal value) {
        return value.divide(new BigDecimal("3"));
    }

    /** BIGDECIMAL-DIVIDE: a divisor that is not known. */
    BigDecimal fxDivideByUnknown(BigDecimal value, BigDecimal divisor) {
        return value.divide(divisor);
    }

    /** BIGDECIMAL-DIVIDE: the catch is for another exception. */
    BigDecimal fxDivideCatchesOther(BigDecimal a, BigDecimal b) {
        try {
            return a.divide(b);
        } catch (IllegalStateException e) {
            return BigDecimal.ZERO;
        }
    }

    /** BIGDECIMAL-DIVIDE: a pow of a divisor that is not smooth stays reported. */
    BigDecimal fxDivideByPowerOfThree(BigDecimal value, int n) {
        return value.divide(BigDecimal.valueOf(3).pow(n));
    }

    /** BIGDECIMAL-DIVIDE: the call at the end of a multi-line chain is reported at its own line. */
    BigDecimal fxChainDivide(List<BigDecimal> values, int n) {
        return values.stream()
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .divide(BigDecimal.valueOf(n));
    }

    /** BIGDECIMAL-SCALE: the same for setScale. */
    BigDecimal fxChainSetScale(List<BigDecimal> values) {
        return values.stream()
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2);
    }

    /** BIGDECIMAL-EQUALS: the same for equals. */
    boolean fxChainEquals(List<BigDecimal> values, BigDecimal expected) {
        return values.stream()
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .equals(expected);
    }

    /** BIGDECIMAL-DOUBLE (NEG): 0.5 is exactly 0.5. */
    BigDecimal fxExactHalf() {
        return new BigDecimal(0.5);
    }

    /** BIGDECIMAL-DOUBLE (NEG): 1.0 and 0.0. */
    BigDecimal[] fxExactWholes() {
        return new BigDecimal[] {new BigDecimal(1.0), new BigDecimal(0.0)};
    }

    /** BIGDECIMAL-DOUBLE (NEG): rounded to 15 digits. */
    BigDecimal fxRoundedDouble(double d) {
        return new BigDecimal(d, new MathContext(15));
    }

    /** BIGDECIMAL-DOUBLE: 0.1 is not exact. */
    BigDecimal fxInexactTenth() {
        return new BigDecimal(0.1);
    }

    /** BIGDECIMAL-DOUBLE: rounded to 20 digits still shows the error. */
    BigDecimal fxRoundedTwenty(double d) {
        return new BigDecimal(d, new MathContext(20));
    }

    /** BIGDECIMAL-DOUBLE: a method reference to the double constructor. */
    DoubleFunction<BigDecimal> fxConstructorReference() {
        return BigDecimal::new;
    }

    /** BIGDECIMAL-EQUALS (NEG): both sides stripped of trailing zeros. */
    boolean fxEqualsStripped(BigDecimal a, BigDecimal b) {
        return a.stripTrailingZeros().equals(b.stripTrailingZeros());
    }

    /** BIGDECIMAL-EQUALS (NEG): both sides brought to scale 2. */
    boolean fxEqualsScaled(BigDecimal a, BigDecimal b) {
        return a.setScale(2, RoundingMode.HALF_UP).equals(b.setScale(2, RoundingMode.HALF_UP));
    }

    /** BIGDECIMAL-EQUALS: only one side is normalised. */
    boolean fxEqualsOneSideStripped(BigDecimal a, BigDecimal b) {
        return a.stripTrailingZeros().equals(b);
    }

    /** BIGDECIMAL-EQUALS: scales that differ between the sides. */
    boolean fxEqualsDifferentScales(BigDecimal a, BigDecimal b) {
        return a.setScale(2, RoundingMode.HALF_UP).equals(b.setScale(3, RoundingMode.HALF_UP));
    }

    /** BIGDECIMAL-SCALE (NEG): the receiver was just rounded to 2 places. */
    BigDecimal fxScaleOfRounded(BigDecimal value) {
        BigDecimal rounded = value.setScale(2, RoundingMode.HALF_UP);
        return rounded.setScale(4);
    }

    /** BIGDECIMAL-SCALE: the receiver has more places than the new scale. */
    BigDecimal fxScaleDown(BigDecimal value) {
        BigDecimal rounded = value.setScale(4, RoundingMode.HALF_UP);
        return rounded.setScale(2);
    }

    /** BIGDECIMAL-SCALE (NEG): integer values multiplied have scale 0. */
    BigDecimal fxScaleOfProduct(int qty, long unit) {
        return BigDecimal.valueOf(qty).multiply(BigDecimal.valueOf(unit)).setScale(2);
    }

    /** BIGDECIMAL-SCALE: a value with 3 places times one gives 3 places, and setScale(2) drops one. */
    BigDecimal fxScaleOfWideProduct() {
        return BigDecimal.valueOf(5, 3).multiply(BigDecimal.ONE).setScale(2);
    }

    /** BIGDECIMAL-SCALE: the local is assigned again, so its scale is not known. */
    BigDecimal fxScaleOfReassigned(BigDecimal value) {
        BigDecimal rounded = value.setScale(2, RoundingMode.HALF_UP);
        rounded = rounded.multiply(value);
        return rounded.setScale(4);
    }

    // ------------------------------------------------------------------------------------------ calendar and Date

    /** CALENDAR-MONTH: the month is kept in a local and concatenated later. */
    String fxMonthLocal(Calendar cal) {
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        return year + "/" + month;
    }

    /** CALENDAR-MONTH: the local is compared with 12. */
    boolean fxMonthLocalCompared(Calendar cal) {
        int month = cal.get(Calendar.MONTH);
        return month == 12;
    }

    /** CALENDAR-MONTH: the local is printed. */
    void fxMonthLocalPrinted(Calendar cal) {
        int month = cal.get(Calendar.MONTH);
        System.out.println("closing month " + month);
    }

    /** CALENDAR-MONTH: the local is passed to a formatting call. */
    String fxMonthLocalFormatted(Calendar cal) {
        final int month = cal.get(Calendar.MONTH);
        return String.format("%02d", month);
    }

    /** CALENDAR-MONTH: MessageFormat shows the month. */
    String fxMonthMessageFormat(Calendar cal) {
        return MessageFormat.format("month {0}", cal.get(Calendar.MONTH));
    }

    /** CALENDAR-MONTH: DecimalFormat shows the month, zero padded. */
    String fxMonthDecimalFormat(Calendar cal) {
        return new DecimalFormat("00").format(cal.get(Calendar.MONTH));
    }

    /** CALENDAR-MONTH (NEG): one is added before the text is made. */
    String fxMonthLocalPlusOne(Calendar cal) {
        int month = cal.get(Calendar.MONTH);
        return "m" + (month + 1);
    }

    /** CALENDAR-MONTH (NEG): the local is assigned again, so it is not followed. */
    String fxMonthLocalReassigned(Calendar cal) {
        int month = cal.get(Calendar.MONTH);
        month = month + 1;
        return "m" + month;
    }

    /** CALENDAR-MONTH (NEG): the month indexes a table of names. */
    String fxMonthLocalIndex(Calendar cal, String[] names) {
        int month = cal.get(Calendar.MONTH);
        return names[month];
    }

    /** CALENDAR-MONTH (NEG): Integer.valueOf boxes the month for a lookup. */
    String fxMonthBoxedKey(Calendar cal, Map<Integer, String> names) {
        return names.get(Integer.valueOf(cal.get(Calendar.MONTH)));
    }

    /** CALENDAR-MONTH (NEG): ChoiceFormat maps the zero-based month to a name. */
    String fxMonthChoice(Calendar cal) {
        return FX_CHOICE.format(cal.get(Calendar.MONTH));
    }

    /** CALENDAR-MONTH (NEG): an own format method that takes the zero-based month. */
    String fxMonthOwnFormatter(Calendar cal) {
        return new FxMonthNames().format(cal.get(Calendar.MONTH));
    }

    /** CALENDAR-MONTH (NEG): both sides are made from zero-based months and only compared with each other. */
    boolean fxMonthLocalsCompared(Calendar a, Calendar b) {
        int ma = a.get(Calendar.MONTH);
        int mb = b.get(Calendar.MONTH);
        String k1 = a.get(Calendar.YEAR) + "-" + ma;
        String k2 = b.get(Calendar.YEAR) + "-" + mb;
        return k1.equals(k2);
    }

    /** CALENDAR-MONTH (NEG): the text is only a key of a map. */
    void fxMonthTextKey(Map<String, Integer> counts, Calendar c) {
        String key = c.get(Calendar.YEAR) + "-" + c.get(Calendar.MONTH);
        counts.merge(key, 1, Integer::sum);
    }

    /** CALENDAR-MONTH: the text is a key of a map and is shown too. */
    String fxMonthTextKeyShown(Map<String, Integer> counts, Calendar c) {
        String key = c.get(Calendar.YEAR) + "-" + c.get(Calendar.MONTH);
        counts.merge(key, 1, Integer::sum);
        return key;
    }

    /** CALENDAR-MONTH: setMonth(12) on a Date. */
    void fxSetMonth12(Date d) {
        d.setMonth(12);
    }

    /** CALENDAR-MONTH (NEG): setMonth(11) is December. */
    void fxSetMonth11(Date d) {
        d.setMonth(11);
    }

    /** DATE-YEAR (NEG): boxing is no display. */
    Integer fxYearBoxed(Date d) {
        return Integer.valueOf(d.getYear());
    }

    /** DATE-YEAR (NEG): BigDecimal.valueOf is no display. */
    BigDecimal fxYearBigDecimal(Date d) {
        return BigDecimal.valueOf(d.getYear());
    }

    /** DATE-YEAR: String.valueOf shows it. */
    String fxYearValueOf(Date d) {
        return String.valueOf(d.getYear());
    }

    /** DATE-YEAR: the year is kept in a local and concatenated. */
    String fxYearLocal(Date d) {
        int year = d.getYear();
        return "year " + year;
    }

    /** DATE-YEAR (NEG): 1900 is added to the local. */
    String fxYearLocalAdjusted(Date d) {
        int year = d.getYear();
        return "year " + (year + 1900);
    }

    /** DATE-YEAR: setYear takes the year minus 1900. */
    void fxSetYear(Date d) {
        d.setYear(2024);
    }

    /** DATE-YEAR (NEG): the year minus 1900. */
    void fxSetYearOk(Date d) {
        d.setYear(2024 - 1900);
    }

    /** DATE-YEAR: Date.UTC takes the year minus 1900. */
    long fxUtc() {
        return Date.UTC(2024, 0, 1, 0, 0, 0);
    }

    /** DATE-YEAR (NEG): Date.UTC with the year minus 1900. */
    long fxUtcOk() {
        return Date.UTC(124, 0, 1, 0, 0, 0);
    }

    // ------------------------------------------------------------------------------------------ default charset

    /** DEFAULT-CHARSET: ByteArrayOutputStream.toString(). */
    String fxByteArrayToString(ByteArrayOutputStream out) {
        return out.toString();
    }

    /** DEFAULT-CHARSET (NEG): the charset is named. */
    String fxByteArrayToStringNamed(ByteArrayOutputStream out) throws UnsupportedEncodingException {
        return out.toString("UTF-8");
    }

    /** DEFAULT-CHARSET: Scanner over System.in. */
    Scanner fxScannerStdin() {
        return new Scanner(System.in);
    }

    /** DEFAULT-CHARSET: Scanner over a file. */
    Scanner fxScannerFile(File file) throws FileNotFoundException {
        return new Scanner(file);
    }

    /** DEFAULT-CHARSET (NEG): scanning a string converts nothing. */
    Scanner fxScannerText(String text) {
        return new Scanner(text);
    }

    /** DEFAULT-CHARSET (NEG): the charset is named. */
    Scanner fxScannerNamed(InputStream in) {
        return new Scanner(in, "UTF-8");
    }

    /** DEFAULT-CHARSET: PrintWriter over an output stream, e.g. a servlet response. */
    PrintWriter fxPrintWriterOverStream(OutputStream out) {
        return new PrintWriter(out);
    }

    /** DEFAULT-CHARSET: the autoflush overload. */
    PrintWriter fxPrintWriterAutoFlush(OutputStream out) {
        return new PrintWriter(out, true);
    }

    /** DEFAULT-CHARSET: PrintStream over an output stream. */
    PrintStream fxPrintStreamOverStream(OutputStream out) {
        return new PrintStream(out);
    }

    /** DEFAULT-CHARSET (NEG): a PrintWriter over a Writer converts nothing itself. */
    PrintWriter fxPrintWriterOverWriter(Writer writer) {
        return new PrintWriter(writer, true);
    }

    /** DEFAULT-CHARSET: Formatter writing to a file name. */
    Formatter fxFormatterFile(String name) throws FileNotFoundException {
        return new Formatter(name);
    }

    /** DEFAULT-CHARSET (NEG): a Formatter over an Appendable converts nothing. */
    Formatter fxFormatterAppendable(StringBuilder out) {
        return new Formatter(out);
    }

    /** DEFAULT-CHARSET: URLEncoder.encode(String). */
    String fxUrlEncode(String text) {
        return URLEncoder.encode(text);
    }

    /** DEFAULT-CHARSET: URLDecoder.decode(String). */
    String fxUrlDecode(String text) {
        return URLDecoder.decode(text);
    }

    /** DEFAULT-CHARSET (NEG): the charset is named. */
    String fxUrlEncodeNamed(String text) throws UnsupportedEncodingException {
        return URLEncoder.encode(text, "UTF-8");
    }

    /** DEFAULT-CHARSET (NEG): a plain ASCII literal encodes the same everywhere. */
    String fxUrlEncodeAscii() {
        return URLEncoder.encode("abc");
    }

    /** DEFAULT-CHARSET: the method reference String::getBytes. */
    Function<String, byte[]> fxGetBytesReference() {
        return String::getBytes;
    }

    /** DEFAULT-CHARSET (NEG): the method reference with a charset. */
    BiFunction<String, Charset, byte[]> fxGetBytesReferenceNamed() {
        return String::getBytes;
    }

    /** An own formatter. */
    static final class FxMonthNames {
        private static final String[] NAMES = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

        String format(int zeroBasedMonth) {
            return NAMES[zeroBasedMonth];
        }
    }
}
