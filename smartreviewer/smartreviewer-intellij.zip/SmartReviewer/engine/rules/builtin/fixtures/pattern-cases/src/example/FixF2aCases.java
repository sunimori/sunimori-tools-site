package example;

import java.io.File;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.function.DoubleSupplier;
import java.util.function.IntToDoubleFunction;
import java.util.function.LongSupplier;

/**
 * Cases added with the second review of the expression, comparison, assignment and accessor rules: integer division and int overflow
 * followed through arithmetic, comparisons, conditionals and lambdas; identity shortcuts; assignments in conditions; self-assignment
 * through two spellings of a field; enums, UUID, Path and File in equals(); getter chains as receivers of repeated keys and setters;
 * accessors that read nothing of their parameter; swapped copies; odd checks after a sign test; random numbers held in a variable.
 */
public class FixF2aCases {
    private String code;
    private Integer rank;
    private static final String UNSET = new String("<unset>");
    private boolean deleted;
    private boolean enabled;
    private boolean skip;
    private String tel;
    private int ioValue;
    private final java.util.List<String> items = new java.util.ArrayList<>();

    // ----------------------------------------------------------------------------- SR-JAVA-INT-DIV-001

    /** P: the truncated quotient is the left factor of an int product that becomes a double. */
    double divPercent(int done, int total) {
        double pct = done / total * 100;
        return pct;
    }

    /** P: the quotient is compared with a floating literal. */
    boolean divCompare(int done, int total) {
        return done / total > 0.5;
    }

    /** P: the quotient is the else arm of a conditional that becomes a double. */
    double divTernary(int sum, int count) {
        double avg = count == 0 ? 0 : sum / count;
        return avg;
    }

    /** P: the quotient is the value of an expression lambda for a DoubleSupplier. */
    DoubleSupplier divLambda(int a, int b) {
        return () -> a / b;
    }

    /** P: the quotient is returned from a block lambda for an IntToDoubleFunction. */
    IntToDoubleFunction divBlockLambda(int b) {
        return a -> {
            return a / b;
        };
    }

    /** P: the quotient is an element of a double array. */
    double[] divArray(int a, int b) {
        return new double[] {a / b, 1.5};
    }

    /** P: the quotient is a term of an int sum that becomes a double. */
    double divSum(int a, int b, int c) {
        double total = a / b + c;
        return total;
    }

    /** N: the product stays an int. */
    int divIntProduct(int done, int total) {
        int pct = done / total * 100;
        return pct + Math.max(done / total, 1);
    }

    /** N: the conditional stays an int. */
    int divIntTernary(int sum, int count) {
        int avg = count == 0 ? 0 : sum / count;
        return avg;
    }

    /** B: a string concatenation and a comparison with an int are no floating conversions. */
    String divText(int done, int total) {
        boolean half = done / total > 1;
        return "pct=" + done / total * 100 + half;
    }

    // ----------------------------------------------------------------------------- SR-JAVA-INT-OVERFLOW-001

    /** P: the product is the else arm of a conditional that becomes a long. */
    long ovTernary(boolean unlimited, int days) {
        long ms = unlimited ? 0 : days * 24 * 60 * 60 * 1000;
        return ms;
    }

    /** P: the product is compared with a long. */
    boolean ovCompare(long now, long start, int days) {
        return now - start > days * 24 * 60 * 60 * 1000;
    }

    /** P: the product is a term of an int sum that becomes a long. */
    long ovSum(int days, int extra) {
        long total = days * 86400000 + extra;
        return total;
    }

    /** P: the product is the value of a lambda for a LongSupplier. */
    LongSupplier ovLambda(int days) {
        return () -> days * 24 * 60 * 60 * 1000;
    }

    /** N: the sum stays an int. */
    int ovIntSum(int days, int extra) {
        int total = days * 86400000 + extra;
        return total;
    }

    // ----------------------------------------------------------------------------- SR-JAVA-STRING-EQ-001, SR-JAVA-BOXED-EQ-001

    /** N: an identity shortcut before equals() on the same two operands. */
    boolean refFastPath(FixF2aCases other) {
        return code == other.code || (code != null && code.equals(other.code));
    }

    /** N: the same shortcut written as an early return before compareTo(). */
    int refCompare(String a, String b) {
        if (a == b) {
            return 0;
        }
        return a.compareTo(b);
    }

    /** N: the same shortcut for boxed numbers. */
    int refRank(Integer a, Integer b) {
        if (a == b) {
            return 0;
        }
        return a.compareTo(b);
    }

    /** N: a comparison with a marker object that is created for being compared by identity. */
    boolean refSentinel(String value) {
        return value == UNSET;
    }

    /** P: no value comparison anywhere in the method; the parentheses of the operand stay in the message. */
    boolean refTernary(boolean first, String a, String b, String value) {
        return (first ? a : b) == value;
    }

    /** P: boxed numbers compared by reference, nothing else in the method. */
    boolean refRankOnly(Integer a, Integer b) {
        return a == b;
    }

    // ----------------------------------------------------------------------------- SR-JAVA-ASSIGN-CONDITION-001

    /** P: a field of another object is assigned from the same field of this object. */
    boolean acOtherObject(FixF2aCases other) {
        if (this.deleted = other.deleted) {
            return true;
        }
        return false;
    }

    /** P: two other objects. */
    boolean acTwoObjects(FixF2aCases a, FixF2aCases b) {
        if (a.deleted = b.deleted) {
            return true;
        }
        return false;
    }

    /** P: a field assigned from itself. */
    boolean acOwnField() {
        if (enabled = this.enabled) {
            return true;
        }
        return false;
    }

    /** P: a parameter with another name. */
    boolean acOtherName(boolean removed) {
        if (this.deleted = removed) {
            return true;
        }
        return false;
    }

    /** N: a field stored from the parameter of the same name. */
    boolean acStore(boolean skip) {
        if (this.skip = skip) {
            return true;
        }
        return false;
    }

    /** P: the assignment is an operand of && in the condition. */
    boolean acOperand(int n) {
        boolean flag;
        if (n > 0 && (flag = true)) {
            return flag;
        }
        return false;
    }

    // ----------------------------------------------------------------------------- SR-JAVA-SELF-ASSIGN-001

    /** P: tel is the field itself, the parameter has another name. */
    void saFieldItself(String telephone) {
        this.tel = tel;
    }

    /** P: the field assigned from this.tel. */
    void saFieldItself2() {
        tel = this.tel;
    }

    /** N: tel is the parameter. */
    void saParameter(String tel) {
        this.tel = tel;
    }

    // ----------------------------------------------------------------------------- SR-JAVA-EQUALS-TYPES-001, SR-JAVA-ARRAY-EQUALS-001

    enum Status {
        ACTIVE, CLOSED
    }

    enum Mode {
        MANUAL, AUTO
    }

    /** P: an enum constant never equals a String. */
    boolean etEnumString(Status status) {
        return status.equals("ACTIVE");
    }

    /** P: two different enums. */
    boolean etEnumEnum(Status status, Mode mode) {
        return status.equals(mode);
    }

    /** P: the enum is the argument. */
    boolean etStringEnum(Status status) {
        return "ACTIVE".equals(status);
    }

    /** P: Objects.equals. */
    boolean etObjectsEnum(Status status) {
        return Objects.equals(status, "ACTIVE");
    }

    /** N: the same enum. */
    boolean etSameEnum(Status a, Status b) {
        return a.equals(b);
    }

    /** N: the argument may be any object. */
    boolean etEnumObject(Status status, Object other) {
        return status.equals(other);
    }

    /** P: a UUID is not a String. */
    boolean etUuid(UUID id, String text) {
        return id.equals(text);
    }

    /** P: a Path is not a String. */
    boolean etPath(Path path, String text) {
        return path.equals(text);
    }

    /** P: a File is not a String. */
    boolean etFile(File file, String text) {
        return file.equals(text);
    }

    /** N: two UUIDs. */
    boolean etUuidSame(UUID a, UUID b) {
        return a.equals(b);
    }

    /** P (arrays): the array is the second argument of Objects.equals. */
    boolean aeObjects(Object any, String[] codes) {
        return Objects.equals(any, codes);
    }

    /** P: a String is never equal to an array. */
    boolean etStringArray(String text, char[] chars) {
        return text.equals(chars);
    }

    /** P (types), N (arrays): a String and an array in Objects.equals are a question of types, not of array contents. */
    boolean etObjectsStringArray(String text, char[] chars) {
        return Objects.equals(text, chars);
    }

    // ----------------------------------------------------------------------------- SR-JAVA-DUP-KEY-001, SR-JAVA-DUP-SETTER-001

    static class Holder {
        private final Map<String, Object> attributes = new HashMap<>();

        Map<String, Object> getAttributes() {
            return attributes;
        }
    }

    static class User {
        private String role;
        private String name;

        void setRole(String r) {
            role = r;
        }

        void setName(String n) {
            name = n;
        }
    }

    static class Order {
        private final User customer = new User();

        User getCustomer() {
            return customer;
        }
    }

    static class Period {
        private int days;
        private String text;

        void setDays(int d) {
            days = d;
        }

        void setDays(String t) {
            text = t;
        }
    }

    /** P (key): the receiver is a getter chain. */
    void dkChain(Holder holder, Object a, Object b) {
        holder.getAttributes().put("cart", a);
        holder.getAttributes().put("cart", b);
    }

    /** N (key): the second value reads the first one. */
    void dkReadsMap(Map<String, Integer> counts) {
        counts.put("n", 1);
        counts.put("n", counts.get("n") + 1);
    }

    /** N (key): a value in between reads the first one before it is replaced. */
    void dkReadsBetween(Map<String, Object> m) {
        m.put("current", 1);
        m.put("previous", m.get("current"));
        m.put("current", 2);
    }

    /** P (key): the receiver's name is only a word in a string literal. */
    void dkLiteralWord(Map<String, String> m) {
        m.put("a", "first");
        m.put("a", "m");
    }

    /** N (key): two different getter chains. */
    void dkOtherChains(Holder x, Holder y, Object a, Object b) {
        x.getAttributes().put("cart", a);
        y.getAttributes().put("cart", b);
    }

    enum Kind {
        A, B
    }

    /** P (key): the same int key twice. */
    void dkIntKeys(Map<Integer, String> m) {
        m.put(1, "a");
        m.put(2, "b");
        m.put(1, "c");
    }

    /** P (key): the same enum constant twice. */
    void dkEnumKeys(Map<Kind, String> m) {
        m.put(Kind.A, "a");
        m.put(Kind.B, "b");
        m.put(Kind.A, "c");
    }

    /** N (key): different int keys. */
    void dkOtherIntKeys(Map<Integer, String> m) {
        m.put(1, "a");
        m.put(2, "b");
    }

    /** P (setter): the receiver is a getter chain. */
    void dsChain(Order order, String a, String b) {
        order.getCustomer().setName(a);
        order.getCustomer().setName(b);
    }

    /** N (setter): two different getter chains. */
    void dsOtherChains(Order x, Order y, String a, String b) {
        x.getCustomer().setName(a);
        y.getCustomer().setName(b);
    }

    /** P (setter): the receiver's name is a word in the string literal of the overriding value. */
    void dsLiteralWord(User user, String role) {
        user.setRole(role);
        user.setRole("user");
    }

    /** N (setter): overloads that store into different fields, the plain setter second. */
    void dsOverloadReverse(Period period, int d, String t) {
        period.setDays(t);
        period.setDays(d);
    }

    /** N (setter): the same overloads, the plain setter first. */
    void dsOverloadForward(Period period, int d, String t) {
        period.setDays(d);
        period.setDays(t);
    }

    // ----------------------------------------------------------------------------- SR-JAVA-SETTER-PARAM-001, SR-JAVA-ACCESSOR-FIELD-001

    static class Person {
        private String memo;
        private String title;
        private String note;
        private String item1;
        private String item10;
        private String item12;
        static final Person DEFAULT = new Person();

        /** P (setter): the value is the same field of another object; the name memo is in the text, but the parameter is not read. */
        void setMemo(String memo) {
            this.memo = DEFAULT.memo;
        }

        /** P (setter): the value is a string literal that spells the parameter's name. */
        void setTitle(String title) {
            this.title = "title";
        }

        /** N (setter): the parameter is used. */
        void setNote(String note) {
            this.note = note == null ? "" : note.trim();
        }

        /** P (accessor): item1 is another property than item12. */
        String getItem12() {
            return item1;
        }

        /** P (accessor): item10 is another property than item1. */
        String getItem1() {
            return item10;
        }

        /** N (accessor): the usual getter. */
        String getItem10() {
            return item10;
        }
    }

    static class Contact {
        private String mTel;
        private String mFax;

        /** N (accessor): the usual getter of a field with the prefix m. */
        String getTel() {
            return mTel;
        }

        /** P (accessor): the getter of the fax number returns the telephone number. */
        String getFax() {
            return mTel;
        }
    }

    // ----------------------------------------------------------------------------- SR-JAVA-NULL-CHECK-001

    private java.util.Map<String, String> cache;

    /** P: cache and this.cache are the same field. */
    boolean ncSpellings() {
        return cache == null && this.cache.isEmpty();
    }

    /** N: cache is the parameter here, this.cache the field. */
    boolean ncParameter(java.util.Map<String, String> cache) {
        return cache == null && this.cache.isEmpty();
    }

    /** P: !(x != null) is x == null. */
    boolean ncNegated(String x) {
        return !(x != null) && x.isEmpty();
    }

    /** N: !(x == null) is the guard x != null. */
    boolean ncNegatedGuard(String x) {
        return !(x == null) && x.isEmpty();
    }

    // ----------------------------------------------------------------------------- SR-JAVA-COPY-MISMATCH-001

    static class FormHolder {
        private CopyMismatchCases.CustomerForm form;

        CopyMismatchCases.CustomerForm getForm() {
            return form;
        }
    }

    /** N: telephone and fax are exchanged on purpose. */
    CopyMismatchCases.CustomerDto cmSwap(CopyMismatchCases.CustomerForm form) {
        CopyMismatchCases.CustomerDto dto = new CopyMismatchCases.CustomerDto();
        dto.setName(form.getName());
        dto.setKana(form.getKana());
        dto.setTel(form.getFax());
        dto.setFax(form.getTel());
        return dto;
    }

    /** P: the odd copy passes a cast value. */
    CopyMismatchCases.CustomerDto cmCast(CopyMismatchCases.CustomerForm form) {
        CopyMismatchCases.CustomerDto dto = new CopyMismatchCases.CustomerDto();
        dto.setName(form.getName());
        dto.setKana(form.getKana());
        dto.setTel((String) form.getFax());
        return dto;
    }

    /** P: the source is a getter chain. */
    CopyMismatchCases.CustomerDto cmChain(FormHolder holder) {
        CopyMismatchCases.CustomerDto dto = new CopyMismatchCases.CustomerDto();
        dto.setName(holder.getForm().getName());
        dto.setKana(holder.getForm().getKana());
        dto.setTel(holder.getForm().getFax());
        return dto;
    }

    // ----------------------------------------------------------------------------- SR-JAVA-IDENTICAL-OPERANDS-001, SR-JAVA-IGNORED-RESULT-001

    /** P: this.ioValue and ioValue are the same field. */
    boolean ioSpellings() {
        return this.ioValue == ioValue;
    }

    /** N: ioValue is the parameter here. */
    boolean ioParameter(int ioValue) {
        return this.ioValue == ioValue;
    }

    private boolean load() {
        items.add("a");
        return false;
    }

    /** N: the call in the middle may fill the list. */
    boolean ioStateChange() {
        return items.isEmpty() || load() || items.isEmpty();
    }

    /** P: nothing in between. */
    boolean ioPlain() {
        return items.isEmpty() || rank == null || items.isEmpty();
    }

    /** P: the stripped text is dropped. */
    void irStripIndent(String text) {
        text.stripIndent();
    }

    /** P: the weekday is dropped. */
    void irDayOfWeek(java.time.DayOfWeek day) {
        day.plus(1);
    }

    // ----------------------------------------------------------------------------- SR-JAVA-ODD-CHECK-001, SR-JAVA-RANDOM-INT-001

    /** N: the hash is made non-negative by a second assignment. */
    boolean odReassigned(String key) {
        int h = key.hashCode();
        h = h & 0x7fffffff;
        return h % 2 == 1;
    }

    /** N: a negative value returns before the test. */
    boolean odGuarded(String text) {
        int n = Integer.parseInt(text);
        if (n < 0) {
            return false;
        }
        return n % 2 == 1;
    }

    /** N: the test is the right operand of a sign test. */
    boolean odSignFirst(String text) {
        int n = Integer.parseInt(text);
        return n >= 0 && n % 2 == 1;
    }

    /** P: declared first, parsed later. */
    boolean odLater(String text) {
        int n;
        try {
            n = Integer.parseInt(text);
        } catch (NumberFormatException e) {
            return false;
        }
        return n % 2 == 1;
    }

    /** P: Objects.hash. */
    boolean odObjectsHash(String a, int b) {
        return Objects.hash(a, b) % 2 == 1;
    }

    /** P: Long.hashCode. */
    boolean odLongHash(long l) {
        return Long.hashCode(l) % 2 == 1;
    }

    /** P: Arrays.hashCode. */
    boolean odArraysHash(int[] values) {
        return Arrays.hashCode(values) % 2 == 1;
    }

    /** P: a parsed number, nothing else known (control). */
    boolean odParsed(String text) {
        int n = Integer.parseInt(text);
        return n % 2 == 1;
    }

    /** P: the cast applies to the variable, which holds a number from [0, 1). */
    int riLocal(int n) {
        double r = Math.random();
        return (int) r * n;
    }

    /** N: the product is cast. */
    int riProduct(int n) {
        double r = Math.random();
        return (int) (r * n);
    }

    // ----------------------------------------------------------------------------- SR-JAVA-ARRAY-TO-STRING-001

    /** P: a long[] is one element of the format arguments and prints as [J@... */
    String atFormat(long[] counts) {
        return String.format("%s", counts);
    }

    /** N: an Object[] is the argument array. */
    String atFormatSpread(String[] names) {
        return String.format("%s", (Object[]) names);
    }
}
