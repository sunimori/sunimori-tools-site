package example;

import java.util.List;
import java.util.Map;
import java.util.Set;

/** Arguments of collection and map methods whose type cannot match (SR-JAVA-UNLIKELY-ARG-001). */
public class UnlikelyArgumentCases {

    static class Customer {
        String id;
    }

    /** P01: the keys are String codes, the argument an Integer. */
    Customer find(Map<String, Customer> byCode, Integer code) {
        return byCode.get(code);
    }

    /** P02: an int literal is boxed to Integer, the set holds Long. */
    boolean admin(Set<Long> adminIds) {
        return adminIds.contains(1);
    }

    /** P03: the object itself instead of its key. */
    void forget(Map<String, Customer> byId, Customer customer) {
        byId.remove(customer);
    }

    /** N01: matching types. */
    Customer findById(Map<String, Customer> byId, String id) {
        return byId.get(id);
    }

    /** N02: an Object argument may be anything. */
    boolean known(Set<String> codes, Object value) {
        return codes.contains(value);
    }

    /** N03: List.remove(int) removes by index, not by element. */
    String dropFirst(List<String> names) {
        return names.remove(0);
    }

    /** B01: a supertype of the elements can still match. */
    boolean listed(List<String> names, CharSequence name) {
        return names.contains(name);
    }
}
