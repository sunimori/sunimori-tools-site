package example;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/** SR-JAVA-DUP-KEY-001 cases. */
public class DuplicateKeyCases {
    interface Request {
        void setAttribute(String name, Object value);
    }

    static final String KEY_MATH = "SUGAKU";

    /** P01: report parameters, KOKUGO set twice and EIGO never. */
    Map<String, Object> params(int kokugo, int sugaku, int eigo) {
        Map<String, Object> p = new HashMap<>();
        p.put("KOKUGO", kokugo);
        p.put("SUGAKU", sugaku);
        p.put("KOKUGO", eigo);
        return p;
    }

    /** P02: a constant and a literal with the same value. */
    void attributes(Request req, Object a, Object b) {
        req.setAttribute(KEY_MATH, a);
        req.setAttribute("SUGAKU", b);
    }

    /** P03: Properties.setProperty. */
    Properties connection() {
        Properties p = new Properties();
        p.setProperty("url", "jdbc:a");
        p.setProperty("url", "jdbc:b");
        return p;
    }

    /** N01: distinct keys. */
    void distinct(Request req) {
        req.setAttribute("a", 1);
        req.setAttribute("b", 2);
    }

    /** N02: different receivers. */
    void receivers(Map<String, Object> m1, Map<String, Object> m2) {
        m1.put("k", 1);
        m2.put("k", 2);
    }

    /** B01: the first value is read in between, so overwriting it is deliberate. */
    Object reread(Map<String, Object> m) {
        m.put("k", 1);
        Object first = m.get("k");
        m.put("k", 2);
        return first;
    }
}
