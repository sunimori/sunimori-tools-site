package example;

/** SR-JAVA-LOOP-VAR-001 cases. */
public class LoopCases {
    /** P01: the inner loop advances the outer index. */
    int sum(int[][] grid) {
        int total = 0;
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; i++) {
                total += grid[i][j];
            }
        }
        return total;
    }

    /** N01: correct nesting. */
    int sumOk(int[][] grid) {
        int total = 0;
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                total += grid[i][j];
            }
        }
        return total;
    }

    /** N02: two loop variables, both updated. */
    int pairs(int n) {
        int c = 0;
        for (int i = 0, j = n; i < j; i++, j--) {
            c++;
        }
        return c;
    }

    /** N03: the bound is the loop variable; the index tested with it is the one updated. */
    int aligned(byte[] b, int off, int n) {
        int crc = 0;
        for (int end = off + n; off < end; off++) {
            crc += b[off];
        }
        return crc;
    }

    /** B01: the loop variable is advanced in the body. */
    int everyOther(int[] a) {
        int total = 0;
        int steps = 0;
        for (int i = 0; i < a.length; steps++) {
            total += a[i];
            i += 2;
        }
        return total + steps;
    }
}
