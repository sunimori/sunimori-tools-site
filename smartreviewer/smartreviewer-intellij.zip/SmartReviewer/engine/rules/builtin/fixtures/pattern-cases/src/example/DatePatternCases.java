package example;

import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;

/** Date-time pattern letters: SR-JAVA-DATE-WEEK-YEAR-001, -DAY-OF-YEAR-001, -MINUTE-MONTH-001, -12-HOUR-001. */
public class DatePatternCases {
    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("YYYY/MM/dd");

    SimpleDateFormat weekYear() {
        return new SimpleDateFormat("YYYY-MM-dd");
    }

    void applyWeekYear(SimpleDateFormat format) {
        format.applyPattern("YYYYMMdd");
    }

    /** With the week of the year, the week-based year is meant. */
    SimpleDateFormat weekYearWithWeek() {
        return new SimpleDateFormat("YYYY 'week' ww");
    }

    /** 'Y' in quotes is text. */
    SimpleDateFormat quotedLetter() {
        return new SimpleDateFormat("yyyy'Y'MM");
    }

    SimpleDateFormat calendarDate() {
        return new SimpleDateFormat("yyyy/MM/dd");
    }

    SimpleDateFormat dayOfYear() {
        return new SimpleDateFormat("yyyy/MM/DD");
    }

    /** An ordinal date without a month: the day of the year is meant. */
    SimpleDateFormat ordinalDate() {
        return new SimpleDateFormat("yyyy-DDD");
    }

    SimpleDateFormat minuteAsMonth() {
        return new SimpleDateFormat("yyyy/mm/dd");
    }

    /** Minutes and seconds without a date. */
    SimpleDateFormat minutesAndSeconds() {
        return new SimpleDateFormat("mm:ss");
    }

    SimpleDateFormat timestamp() {
        return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    }

    SimpleDateFormat twelveHour() {
        return new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
    }

    SimpleDateFormat twelveHourWithMarker() {
        return new SimpleDateFormat("hh:mm a");
    }
}
