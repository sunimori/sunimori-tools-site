package javax.servlet.http;

import javax.servlet.ServletRequest;

/** Stand-in for the HTTP servlet request. */
public interface HttpServletRequest extends ServletRequest {
    String getRemoteUser();
}
