package example;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/** Changing a collection inside a for-each loop over it (SR-JAVA-FOREACH-MODIFY-001). */
public class ForEachModifyCases {
    private final List<String> listeners = new CopyOnWriteArrayList<>();

    static class Order {
        boolean cancelled;
        String code;
    }

    /** P01: the next round of the loop throws ConcurrentModificationException. */
    void dropCancelled(List<Order> orders) {
        for (Order o : orders) {
            if (o.cancelled) {
                orders.remove(o);
            }
        }
    }

    /** P02: removing from the map while looping over its keys. */
    void dropEmpty(Map<String, String> names) {
        for (String key : names.keySet()) {
            if (names.get(key).isEmpty()) {
                names.remove(key);
            }
        }
    }

    /** P03: adding to the list being looped over. */
    void duplicate(List<String> codes) {
        for (String code : codes) {
            codes.add(code + "-copy");
        }
    }

    /** N01: the iterator's own remove. */
    void dropCancelledSafely(List<Order> orders) {
        for (Iterator<Order> it = orders.iterator(); it.hasNext();) {
            if (it.next().cancelled) {
                it.remove();
            }
        }
    }

    /** N02: removeIf, or collecting first and removing after the loop. */
    void dropLater(List<Order> orders) {
        List<Order> cancelled = new ArrayList<>();
        for (Order o : orders) {
            if (o.cancelled) {
                cancelled.add(o);
            }
        }
        orders.removeAll(cancelled);
        orders.removeIf(o -> o.cancelled);
    }

    /** N03: a copy is looped over. */
    void dropFromCopy(List<Order> orders) {
        for (Order o : new ArrayList<>(orders)) {
            if (o.cancelled) {
                orders.remove(o);
            }
        }
    }

    /** B01: the loop ends right after the change (log, then break). */
    void dropFirst(List<Order> orders, String code) {
        for (Order o : orders) {
            if (o.code.equals(code)) {
                orders.remove(o);
                System.out.println("removed " + code);
                break;
            }
        }
    }

    /** B02: a continue before the break goes round again. */
    void dropAll(List<Order> orders) {
        for (Order o : orders) {
            if (o.cancelled) {
                orders.remove(o);
                if (o.code == null) {
                    continue;
                }
                break;
            }
        }
    }

    /** B03: CopyOnWriteArrayList loops over a snapshot. */
    void fire(String event) {
        for (String l : listeners) {
            if (l.equals(event)) {
                listeners.remove(l);
            }
        }
    }

    /** B05: a nested loop fills the list up, and the loop ends right after it: the iterator never moves again. */
    void padTo(List<String> codes, int size) {
        for (String code : codes) {
            if (code.isEmpty()) {
                for (int i = codes.size(); i < size; i++) {
                    codes.add("");
                }
                break;
            }
        }
    }

    /** B06: a later round of the nested loop continues the loop, whose iterator then fails. */
    void padEach(List<String> codes, int size) {
        outer:
        for (String code : codes) {
            for (int i = 0; i < size; i++) {
                if (i > 2) {
                    continue outer;
                }
                codes.add(code + i);
            }
            break;
        }
    }
}
