package example;

import java.io.File;
import java.util.regex.Pattern;

/** A single regex metacharacter where the character itself is meant (SR-JAVA-REGEX-LITERAL-001). */
public class RegexCases {
    /** "." matches any character: the result is an empty array. */
    String[] splitDate(String date) {
        return date.split(".");
    }

    String[] splitColumns(String line) {
        return line.split("|");
    }

    String removeDots(String amount) {
        return amount.replaceAll(".", "");
    }

    String[] splitPlus(String expression) {
        return expression.split("+");
    }

    boolean endsWithDollar(String price) {
        return Pattern.matches("$", price);
    }

    String[] splitDateEscaped(String date) {
        return date.split("\\.");
    }

    String[] splitColumnsQuoted(String line) {
        return line.split(Pattern.quote("|"));
    }

    String removeDotsLiterally(String amount) {
        return amount.replace(".", "");
    }

    String[] splitCsv(String line) {
        return line.split(",");
    }

    String packageToPath(String className) {
        return className.replaceAll(".", "/") + File.separator + className.replaceAll(".", File.separator);
    }

    /** "." meant as any character: masking, the first character, exactly one character. */
    String mask(String password) {
        return password.replaceAll(".", "*");
    }

    String capitalize(String name) {
        return name.replaceFirst(".", name.substring(0, 1).toUpperCase());
    }

    boolean oneCharacter(String code) {
        return code.matches(".");
    }

    /** A space is no metacharacter; a longer regex is not judged. */
    String[] splitWords(String text) {
        return text.split(" ").length > 0 ? text.split("\\s+") : text.split(".+");
    }
}
