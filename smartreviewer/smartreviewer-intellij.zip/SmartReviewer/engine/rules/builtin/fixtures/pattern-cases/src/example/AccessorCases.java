package example;

/** SR-JAVA-ACCESSOR-FIELD-001 and SR-JAVA-SETTER-PARAM-001 cases. */
public class AccessorCases {
    private Integer value7;
    private Integer value8;
    private String name;
    private String title;
    private String memo;
    private boolean active;
    private char placeholder;
    private String placeholderString;
    private String policy;
    private java.util.Set<String> policySet;

    /** P01 (accessor): returns the neighbouring field. */
    public Integer getValue8() {
        return value7;
    }

    /** P02 (accessor): assigns the neighbouring field. */
    public void setValue7(Integer value7) {
        this.value8 = value7;
    }

    /** N01: correct getters. */
    public Integer getValue7() {
        return value7;
    }

    public String getName() {
        return this.name;
    }

    public boolean isActive() {
        return active;
    }

    /** N02: an alias property without a field of that name. */
    public String getCaption() {
        return title;
    }

    /** N04: a differently typed second representation of the property. */
    public String getPlaceholder() {
        return placeholderString;
    }

    /** N05: a field whose name extends the property name. */
    public java.util.Set<String> getPolicy() {
        return policySet;
    }

    /** B01: a setter transforming its parameter. */
    public void setName(String name) {
        this.name = name == null ? "" : name.trim();
    }

    /** P01 (setter): ignores its parameter and copies another field. */
    public void setTitle(String title) {
        this.title = name;
    }

    /** N01 (setter): the usual setter. */
    public void setMemo(String memo) {
        this.memo = memo;
    }
}
