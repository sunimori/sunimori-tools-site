package example;

import java.math.BigDecimal;

/** SR-JAVA-BIGDECIMAL-DOUBLE-001 cases. */
public class BigDecimalCases {
    /** P01: a double literal. */
    BigDecimal taxRate() {
        return new BigDecimal(0.1);
    }

    /** P02: a double variable. */
    BigDecimal fromRate(double rate) {
        return new BigDecimal(rate);
    }

    /** N01: the String constructor. */
    BigDecimal exact() {
        return new BigDecimal("0.1");
    }

    /** N02: valueOf uses the decimal representation. */
    BigDecimal viaValueOf(double rate) {
        return BigDecimal.valueOf(rate);
    }

    /** B01: an int argument selects BigDecimal(int). */
    BigDecimal count(int n) {
        return new BigDecimal(n);
    }
}
