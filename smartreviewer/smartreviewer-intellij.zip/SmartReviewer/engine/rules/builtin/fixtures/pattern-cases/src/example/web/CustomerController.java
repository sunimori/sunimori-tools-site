package example.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

/** A Spring controller is a singleton bean by default (SR-JAVA-SINGLETON-FIELD-001). */
@Controller
public class CustomerController {
    private String lastQuery;
    private String message;

    /** P01: the search words of one user are kept for everybody. */
    @GetMapping("/customers")
    public String search(String q) {
        lastQuery = q;
        return "customers";
    }

    /** N01: request data stays in locals. */
    @PostMapping("/customers")
    public String register(String name) {
        String trimmed = name.trim();
        return "redirect:/customers?name=" + trimmed;
    }

    /** N02: not a request-handling method. */
    void configure(String text) {
        message = text;
    }
}
