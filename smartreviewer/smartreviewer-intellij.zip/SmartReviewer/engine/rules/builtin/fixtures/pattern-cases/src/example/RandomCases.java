package example;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

/** Integral casts of random values in [0, 1) (SR-JAVA-RANDOM-INT-001). */
public class RandomCases {

    /** P01: always 1. */
    int dice() {
        return (int) Math.random() * 6 + 1;
    }

    /** P02: always the first item. */
    String pick(List<String> items) {
        return items.get((int) Math.random() * items.size());
    }

    /** P03: java.util.Random's nextDouble() is in [0, 1) too. */
    int percent(Random random) {
        return (int) random.nextDouble() * 100;
    }

    /** N01: the product is cast. */
    int diceOk() {
        return (int) (Math.random() * 6) + 1;
    }

    /** N02: nextInt and a cast to double. */
    double scaled(Random random) {
        return random.nextInt(6) + (double) Math.random() * 6;
    }

    /** B01: Scanner.nextDouble() reads a number, not a random value. */
    int input(Scanner in) {
        return (int) in.nextDouble() * 2;
    }
}
