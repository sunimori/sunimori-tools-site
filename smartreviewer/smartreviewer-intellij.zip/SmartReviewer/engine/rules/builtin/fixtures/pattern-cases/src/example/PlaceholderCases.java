package example;

import java.text.MessageFormat;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.Marker;

/** Placeholders and arguments of logger messages and MessageFormat (SR-JAVA-PLACEHOLDER-ARGS-001). */
public class PlaceholderCases {
    private static final Logger LOG = LoggerFactory.getLogger(PlaceholderCases.class);
    private static final org.apache.logging.log4j.Logger LOG4J = LogManager.getLogger(PlaceholderCases.class);

    /** P01: two placeholders, one argument: "{}" stays in the log. */
    void missing(String user) {
        LOG.info("login {} from {}", user);
    }

    /** P02: one placeholder, two arguments: the host is not logged. */
    void extra(String user, String host) {
        LOG.warn("login {}", user, host);
    }

    /** P03: MessageFormat: the quote of Don't makes {0} literal text. */
    String quote(String file) {
        return MessageFormat.format("Don't open {0}", file);
    }

    /** P04: Log4j 2 with a level. */
    void level(String id) {
        LOG4J.log(Level.WARN, "{} {} failed", id);
    }

    /** P05: an Object[] written out: its elements count. */
    String array(String a, String b) {
        return MessageFormat.format("{0} {1} {2}", new Object[] {a, b});
    }

    /** P06: with a marker. */
    void marked(Marker audit, String user) {
        LOG.info(audit, "{} by {}", user);
    }

    /** P07: error(String, Throwable) does not format the message: "{}" stays in the log. */
    void exceptionOnly(Exception e) {
        LOG.error("failed for {}", e);
    }

    /** N01: matching counts, and an exception as the last argument without placeholder. */
    void matching(String user, Exception e) {
        LOG.info("login {} from {}", user, "host");
        LOG.error("login failed for {}", user, e);
        LOG.error("failed", e);
        LOG4J.error("failed", e);
    }

    /** N02: MessageFormat with the quote written as '' and a number format. */
    String formatted(String name, int count) {
        return MessageFormat.format("Can''t find {0} ({1,number,integer} files)", name, count);
    }

    /** N03: a message that is no literal: not checked. */
    void dynamic(String message, String user) {
        LOG.info(message, user);
    }

    /** B01: the exception fills the last placeholder: accepted. */
    void exceptionInPlaceholder(String user, Exception e) {
        LOG.error("failed for {}: {}", user, e);
    }

    /** B02: an escaped placeholder is text. */
    void escaped(String user) {
        LOG.info("set \\{} to {}", user);
    }

    /** B03: an array built elsewhere: its length is not known here. */
    void unknownArray(Object[] args) {
        LOG.info("{} {} {}", args);
    }

    /** B04: printf formats are SR-JAVA-FORMAT-ARGS-001's. */
    String printf(String user) {
        return String.format("%s %s", user);
    }
}
