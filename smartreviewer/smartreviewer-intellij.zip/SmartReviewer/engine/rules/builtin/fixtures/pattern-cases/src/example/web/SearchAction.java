package example.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/** Struts 1 keeps one Action instance for every request (SR-JAVA-SINGLETON-FIELD-001). */
public class SearchAction extends Action {
    private String keyword;

    /** P01: the keyword of one request is seen by the others. */
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        keyword = request.getParameter("keyword");
        return mapping.findForward(keyword.isEmpty() ? "input" : "success");
    }
}
