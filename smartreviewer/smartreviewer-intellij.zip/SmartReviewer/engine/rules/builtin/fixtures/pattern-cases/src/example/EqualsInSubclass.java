package example;

/** SR-JAVA-EQUALS-HASHCODE-001 B01: a stricter equals in a subclass keeps the inherited hashCode valid. */
public class EqualsInSubclass extends EqualsAndHashCode {
    private final int version;

    public EqualsInSubclass(String code, int version) {
        super(code);
        this.version = version;
    }

    @Override
    public boolean equals(Object o) {
        return super.equals(o) && o instanceof EqualsInSubclass other && version == other.version;
    }
}
