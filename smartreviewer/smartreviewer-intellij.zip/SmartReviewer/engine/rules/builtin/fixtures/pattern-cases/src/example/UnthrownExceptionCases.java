package example;

/** Exceptions created without throw (SR-JAVA-UNTHROWN-EXCEPTION-001). */
public class UnthrownExceptionCases {
    static class BusinessException extends RuntimeException {
        BusinessException(String message) {
            super(message);
        }
    }

    static class Notice {
        Notice(String text) {
            System.out.println(text);
        }
    }

    /** P01: the throw is missing, so a negative amount goes on. */
    int doubled(int amount) {
        if (amount < 0) {
            new IllegalArgumentException("amount must not be negative: " + amount);
        }
        return amount * 2;
    }

    /** P02: an exception of the project. */
    void approve(String status) {
        if (!"OK".equals(status)) {
            new BusinessException("not approved: " + status);
        }
    }

    /** N01: thrown. */
    int checked(int amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("negative");
        }
        return amount;
    }

    /** N02: kept and returned. */
    RuntimeException kept(String message) {
        RuntimeException e = new IllegalStateException(message);
        e.addSuppressed(new IllegalArgumentException("cause"));
        return e;
    }

    /** N03: an object that is no exception, created for what its constructor does. */
    void notice() {
        new Notice("saved");
    }

    /** B01: created to print where the code is: used, not dropped. */
    void trace() {
        new Exception("trace").printStackTrace();
    }
}
