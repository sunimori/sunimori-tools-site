package example;

/** One copy out of line in a run of same-named copies, the 詰め替え of forms and DTOs (SR-JAVA-COPY-MISMATCH-001). */
public class CopyMismatchCases {
    static class CustomerForm {
        private String name;
        private String kana;
        private String tel;
        private String fax;
        private String mail;
        private Number amount;

        String getName() {
            return name;
        }

        String getKana() {
            return kana;
        }

        String getTel() {
            return tel;
        }

        String getFax() {
            return fax;
        }

        String getMail() {
            return mail;
        }

        Number getAmount() {
            return amount;
        }

        Integer getAmountInteger() {
            return amount == null ? null : amount.intValue();
        }
    }

    /** A form without getTel(). */
    static class ContactForm {
        private String name;
        private String kana;
        private String phone;

        String getName() {
            return name;
        }

        String getKana() {
            return kana;
        }

        String getPhone() {
            return phone;
        }
    }

    static class CustomerDto {
        private String name;
        private String kana;
        private String tel;
        private String fax;
        private String mail;
        private Number amount;

        void setName(String name) {
            this.name = name;
        }

        void setKana(String kana) {
            this.kana = kana;
        }

        void setTel(String tel) {
            this.tel = tel;
        }

        void setFax(String fax) {
            this.fax = fax;
        }

        void setMail(String mail) {
            this.mail = mail;
        }

        void setAmount(Number amount) {
            this.amount = amount;
        }

        /** P02: the implicit receiver: the kana gets the name. */
        void copyFrom(CustomerForm f) {
            setName(f.getName());
            setKana(f.getName());
            setTel(f.getTel());
        }
    }

    /** P01: the telephone number gets the fax number; the form has getTel(). */
    CustomerDto toDto(CustomerForm form) {
        CustomerDto dto = new CustomerDto();
        dto.setName(form.getName());
        dto.setKana(form.getKana());
        dto.setTel(form.getFax());
        dto.setFax(form.getFax());
        dto.setMail(form.getMail());
        return dto;
    }

    /** N01: every copy pairs same-named properties. */
    CustomerDto plain(CustomerForm form) {
        CustomerDto dto = new CustomerDto();
        dto.setName(form.getName());
        dto.setKana(form.getKana());
        dto.setTel(form.getTel());
        return dto;
    }

    /** N02: the source has no getTel(): a mapping between different names. */
    CustomerDto contact(ContactForm form) {
        CustomerDto dto = new CustomerDto();
        dto.setName(form.getName());
        dto.setKana(form.getKana());
        dto.setTel(form.getPhone());
        return dto;
    }

    /** B01: only one other copy: fewer than minMatchingCopies (2). */
    CustomerDto shortCopy(CustomerForm form) {
        CustomerDto dto = new CustomerDto();
        dto.setName(form.getName());
        dto.setTel(form.getFax());
        return dto;
    }

    /** B03: the getter returns another type (Integer, not the Number of getAmount()): another representation on purpose. */
    CustomerDto amountCopy(CustomerForm form) {
        CustomerDto dto = new CustomerDto();
        dto.setName(form.getName());
        dto.setKana(form.getKana());
        dto.setAmount(form.getAmountInteger());
        return dto;
    }
}
