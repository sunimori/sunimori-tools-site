package example;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** BigDecimal.setScale without a rounding mode (SR-JAVA-BIGDECIMAL-SCALE-001). */
public class BigDecimalScaleCases {
    /** P01: an amount of 1.5 yen throws ArithmeticException. */
    BigDecimal yen(BigDecimal amount) {
        return amount.setScale(0);
    }

    /** P02: a computed value. */
    BigDecimal tax(BigDecimal price, BigDecimal rate) {
        return price.multiply(rate).setScale(2);
    }

    /** N01: with a rounding mode. */
    BigDecimal rounded(BigDecimal amount) {
        return amount.setScale(2, RoundingMode.HALF_UP);
    }

    /** N02: an integer value only gets zeros. */
    BigDecimal fromYen(long yen) {
        return BigDecimal.valueOf(yen).setScale(2);
    }

    /** B01: one decimal place set to two: only adds a zero. */
    BigDecimal half() {
        return new BigDecimal("0.5").setScale(2);
    }

    /** B02: three decimal places set to two: throws. */
    BigDecimal third() {
        return new BigDecimal("1.005").setScale(2);
    }

    /** B03: the new scale computed from the value's own scale. */
    BigDecimal wider(BigDecimal amount) {
        return amount.setScale(amount.scale() + 2);
    }
}
