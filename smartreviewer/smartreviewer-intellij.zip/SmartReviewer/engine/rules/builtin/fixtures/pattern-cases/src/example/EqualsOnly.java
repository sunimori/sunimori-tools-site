package example;

/** SR-JAVA-EQUALS-HASHCODE-001 P01: equals without hashCode. */
public class EqualsOnly {
    private final String code;

    public EqualsOnly(String code) {
        this.code = code;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof EqualsOnly other && code.equals(other.code);
    }
}
