package example;

import java.util.HashMap;
import java.util.Map;

/** Double-checked locking on fields that are not volatile (SR-JAVA-DOUBLE-CHECKED-LOCKING-001). */
public class DoubleCheckedLockingCases {
    private static Settings settings;
    private static volatile Settings safeSettings;
    private Map<String, String> cache;

    static class Settings {
        final Map<String, String> values = new HashMap<>();
    }

    /** P01: another thread may see the reference before the object is built. */
    static Settings loadSettings() {
        if (settings == null) {
            synchronized (DoubleCheckedLockingCases.class) {
                if (settings == null) {
                    settings = new Settings();
                }
            }
        }
        return settings;
    }

    /** P02: an instance field, locked on this. */
    Map<String, String> loadCache() {
        if (cache == null) {
            synchronized (this) {
                if (cache == null) {
                    cache = new HashMap<>();
                }
            }
        }
        return cache;
    }

    /** B01: the first check returns early; the same race. */
    static Settings loadEarly() {
        if (settings != null) {
            return settings;
        }
        synchronized (DoubleCheckedLockingCases.class) {
            if (settings == null) {
                settings = new Settings();
            }
        }
        return settings;
    }

    /** N01: volatile makes the publication safe. */
    static Settings loadSafeSettings() {
        if (safeSettings == null) {
            synchronized (DoubleCheckedLockingCases.class) {
                if (safeSettings == null) {
                    safeSettings = new Settings();
                }
            }
        }
        return safeSettings;
    }

    /** N02: a single check inside the lock. */
    static synchronized Settings lockedSettings() {
        if (settings == null) {
            settings = new Settings();
        }
        return settings;
    }

    /** N03: the holder idiom. */
    static Settings holderSettings() {
        return Holder.INSTANCE;
    }

    private static final class Holder {
        static final Settings INSTANCE = new Settings();
    }
}
