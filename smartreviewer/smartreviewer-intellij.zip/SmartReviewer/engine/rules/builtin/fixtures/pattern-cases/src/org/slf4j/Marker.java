package org.slf4j;

/** Stand-in for the SLF4J marker interface. */
public interface Marker {
    String getName();
}
