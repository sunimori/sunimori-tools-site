package example;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Iterator;

/** Assignments used as conditions (SR-JAVA-ASSIGN-CONDITION-001). */
public class AssignmentConditionCases {
    private boolean skip;

    /** P01: = true for == true: always the first branch, and the flag is overwritten. */
    String label(boolean member) {
        if (member = true) {
            return "member";
        }
        return "guest";
    }

    /** P02: one boolean assigned to another as a while condition. */
    int retries(boolean done, boolean failed) {
        int n = 0;
        while (done = failed) {
            n++;
            failed = n < 3;
        }
        return n;
    }

    /** P03: the condition of ?: */
    int fee(boolean express) {
        return (express = false) ? 500 : 0;
    }

    /** N01: comparisons. */
    String compare(boolean member, boolean guest) {
        return member == true ? "member" : guest == false ? "guest" : "-";
    }

    /** N02: the result of a call stored and tested on purpose (reported only with values OTHER). */
    boolean consume(Iterator<String> it) {
        boolean more;
        if (more = it.hasNext()) {
            it.next();
        }
        return more;
    }

    /** N03: an assignment inside a comparison: the usual read loop. */
    int length(BufferedReader in) throws IOException {
        int n = 0;
        String line;
        while ((line = in.readLine()) != null) {
            n += line.length();
        }
        return n;
    }

    /** B01: a field stored from the parameter of the same name, then tested. */
    boolean configure(boolean skip) {
        if (this.skip = skip) {
            return false;
        }
        return true;
    }
}
