package example;

import java.io.IOException;
import java.io.Reader;
import java.util.Iterator;

/** A semicolon right after if / for / while (SR-JAVA-EMPTY-BODY-001). */
public class EmptyBodyCases {
    /** P01: the block runs for every customer. */
    int discount(int amount, boolean member) {
        int rate = 0;
        if (member);
        {
            rate = 10;
        }
        return amount - amount * rate / 100;
    }

    /** P02: the loop runs empty, then its block once. */
    int count(int n) {
        int total = 0;
        for (int i = 0; i < n; i++);
        {
            total++;
        }
        return total;
    }

    /** P03: while with a semicolon, the next line indented as its body. */
    int steps(int n) {
        int steps = 0;
        while (n-- > 0);
            steps++;
        return steps;
    }

    /** N01: a loop that does its work in the header. */
    int skipLine(Reader in) throws IOException {
        int c;
        while ((c = in.read()) != '\n' && c >= 0);
        return c;
    }

    /** N02: an empty block written as one. */
    void waitFor(boolean[] flag) {
        while (!flag[0]) {
        }
    }

    /** N03: if with else. */
    int sign(int x) {
        int s = 1;
        if (x >= 0); else s = -1;
        return s;
    }

    /** B01: the semicolon on a line of its own, with a comment: empty on purpose. */
    void drain(Iterator<String> it) {
        while (it.hasNext() && it.next() != null)
            ; // nothing to do per element
    }

    /** B02: nothing follows in the block: the condition still does nothing. */
    void check(boolean ready) {
        if (ready);
    }
}
