package example;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/** Zero-based Calendar months and Date years minus 1900 used as calendar values (SR-JAVA-CALENDAR-MONTH-001, SR-JAVA-DATE-YEAR-001). */
@SuppressWarnings("deprecation")
public class DateFieldCases {

    /** P01 (month): shown one month early. */
    String label(Calendar cal) {
        return cal.get(Calendar.YEAR) + "/" + cal.get(Calendar.MONTH) + "/" + cal.get(Calendar.DAY_OF_MONTH);
    }

    /** P02 (month): 11 is December, 12 never comes. */
    boolean december(Calendar cal) {
        return cal.get(Calendar.MONTH) == 12;
    }

    /** P03 (month): 12 is January of the next year. */
    void yearEnd(Calendar cal) {
        cal.set(Calendar.MONTH, 12);
        cal.set(Calendar.DAY_OF_MONTH, 31);
    }

    /** P04 (month): printed as is. */
    void print(Calendar cal) {
        System.out.println(cal.get(Calendar.MONTH));
    }

    /** P05 (month): the constructor takes a zero-based month too. */
    Calendar christmas(int year) {
        return new GregorianCalendar(year, 12, 25);
    }

    /** N01 (month): +1 before it is shown. */
    String labelOk(Calendar cal) {
        return cal.get(Calendar.YEAR) + "/" + (cal.get(Calendar.MONTH) + 1);
    }

    /** N02 (month): added before the string ("month + 1 + ..." adds first). */
    String monthFirst(Calendar cal) {
        return cal.get(Calendar.MONTH) + 1 + "月";
    }

    /** N03 (month): compared with the constants, used in calculations. */
    boolean january(Calendar cal) {
        int next = cal.get(Calendar.MONTH) + 1;
        return cal.get(Calendar.MONTH) == Calendar.JANUARY && next == 2;
    }

    /** P06 (year): shows 124 for 2024. */
    String fiscalYear(Date date) {
        return "年度：" + date.getYear();
    }

    /** P07 (year): getYear() is about 124, never 2000. */
    boolean modern(Date date) {
        return date.getYear() >= 2000;
    }

    /** P08 (year): the year 3924. */
    Date start() {
        return new Date(2024, 3, 1);
    }

    /** N04 (year): +1900. */
    int year(Date date) {
        return date.getYear() + 1900;
    }

    /** N05 (year): java.time has the real year. */
    String localYear(LocalDate date) {
        return "年度：" + date.getYear();
    }

    /** B04 (month): only compared with a date made the same way: both months are zero-based, the result is right. */
    boolean sameDay(Calendar a, Calendar b) {
        String d1 = String.valueOf(a.get(Calendar.YEAR)) + String.valueOf(a.get(Calendar.MONTH)) + String.valueOf(a.get(Calendar.DATE));
        String d2 = String.valueOf(b.get(Calendar.YEAR)) + String.valueOf(b.get(Calendar.MONTH)) + String.valueOf(b.get(Calendar.DATE));
        return d1.equals(d2);
    }

    /** B05 (month): StringBuilder keys compared with each other. */
    boolean sameMonth(Calendar a, Calendar b) {
        StringBuilder x = new StringBuilder().append(a.get(Calendar.YEAR)).append(a.get(Calendar.MONTH));
        StringBuilder y = new StringBuilder();
        y.append(b.get(Calendar.YEAR));
        y.append(b.get(Calendar.MONTH));
        return x.toString().equals(y.toString());
    }

    /** B06 (month): compared with text from elsewhere (yyyyM typed by the user): one month off. */
    boolean isMonth(Calendar a, String yyyym) {
        String ym = "" + a.get(Calendar.YEAR) + a.get(Calendar.MONTH);
        return ym.equals(yyyym);
    }

    /** B07 (month): only one side adds 1: the texts never match. */
    boolean sameMonthMixed(Calendar a, Calendar b) {
        String m1 = String.valueOf(a.get(Calendar.MONTH));
        String m2 = String.valueOf(b.get(Calendar.MONTH) + 1);
        return m1.equals(m2);
    }

    /** B09 (month): set later, checked for null, compared ignoring case with a date made the same way. */
    boolean sameDayChecked(Calendar a, Calendar b) {
        String d1 = null;
        String d2 = null;
        if (a != null && b != null) {
            d1 = String.valueOf(a.get(Calendar.YEAR)) + String.valueOf(a.get(Calendar.MONTH)) + String.valueOf(a.get(Calendar.DATE));
            d2 = String.valueOf(b.get(Calendar.YEAR)) + String.valueOf(b.get(Calendar.MONTH)) + String.valueOf(b.get(Calendar.DATE));
        }
        return d1 != null && d2 != null && d1.equalsIgnoreCase(d2);
    }

    /** B02 (year): two Date years compared as text: both are minus 1900. */
    boolean sameYear(Date a, Date b) {
        return String.valueOf(a.getYear()).equals(String.valueOf(b.getYear()));
    }
}
