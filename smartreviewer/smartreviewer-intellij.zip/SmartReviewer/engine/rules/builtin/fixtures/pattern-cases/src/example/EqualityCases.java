package example;

import java.math.BigDecimal;

/** SR-JAVA-BOXED-EQ-001 and SR-JAVA-STRING-EQ-001 cases. */
public class EqualityCases {
    /** P01 (boxed): Integer scores compared by reference. */
    boolean sameScore(Integer a, Integer b) {
        return a == b;
    }

    /** P02 (boxed): Long ids. */
    boolean differentId(Long x, Long y) {
        return x != y;
    }

    /** P03 (boxed): BigDecimal amounts. */
    boolean sameAmount(BigDecimal a, BigDecimal b) {
        return a == b;
    }

    /** N01 (boxed): one primitive side unboxes the other. */
    boolean withPrimitive(Integer a, int b) {
        return a == b;
    }

    /** N02 (boxed): null checks. */
    boolean isNull(Integer a) {
        return a == null;
    }

    /** N03 (boxed): equals. */
    boolean byValue(Integer a, Integer b) {
        return a.equals(b);
    }

    /** B01 (boxed): Boolean is not in the configured families. */
    boolean flags(Boolean a, Boolean b) {
        return a == b;
    }

    /** P01 (string): two strings compared by reference. */
    boolean sameKbn(String kbn, String expected) {
        return kbn == expected;
    }

    /** P02 (string): a literal operand. */
    boolean isOne(String kbn) {
        return kbn == "1";
    }

    /** N01 (string): equals with the constant first. */
    boolean isTwo(String kbn) {
        return "2".equals(kbn);
    }

    /** B01 (string): two compile-time constants are not reported. */
    boolean constants() {
        return Constants.A == Constants.B;
    }

    static final class Constants {
        static final String A = "a";
        static final String B = "b";
    }
}
