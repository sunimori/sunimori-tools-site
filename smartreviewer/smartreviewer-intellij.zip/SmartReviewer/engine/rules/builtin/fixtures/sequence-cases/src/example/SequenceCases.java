package example;

/** Boundary cases for SR-JAVA-SEQUENCE-001. */
final class SequenceCases {
    /** Months are not a numbered family. */
    Object[] months(Integer jan, Integer feb, Integer mar, Integer apr, Integer may) {
        return new Object[] {jan, feb, feb, apr, may};
    }

    /** Gaps without a repetition are legal (v1, v3, v5, ...). */
    Object[] gapsOnly(Integer v1, Integer v3, Integer v5, Integer v7, Integer v9) {
        return new Object[] {v1, v3, v5, v7, v9};
    }

    /** Below the minimum family size of 5. */
    Object[] small(Integer s1, Integer s2, Integer s3) {
        return new Object[] {s1, s2, s2, s3};
    }

    /** Repetition and gap inside an addition chain. */
    int chain(int score1, int score2, int score3, int score4, int score5, int score6) {
        return score1 + score2 + score3 + score3 + score5 + score6;
    }
}
