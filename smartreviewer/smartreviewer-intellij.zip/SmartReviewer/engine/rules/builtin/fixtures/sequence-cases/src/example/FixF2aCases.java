package example;

/** Cases added with the second review of SR-JAVA-SEQUENCE-001: one-letter prefixes, and the same number on different objects. */
final class FixF2aCases {
    static final class Counter {
        int cnt1;
        int cnt2;
        int cnt4;
        int cnt5;
    }

    /** One-letter prefix: v3 repeats, v4 is missing. */
    int oneLetter(int v1, int v2, int v3, int v5, int v6) {
        return v1 + v2 + v3 + v3 + v5 + v6;
    }

    /** cnt2 of cur and cnt2 of prev are two fields of two objects, not a repeat. */
    int otherObjects(Counter cur, Counter prev) {
        return cur.cnt1 + cur.cnt2 + prev.cnt2 + cur.cnt4 + cur.cnt5;
    }

    /** The same field of the same object twice is a repeat. */
    int sameObject(Counter cur, Counter prev) {
        return cur.cnt1 + cur.cnt2 + cur.cnt2 + cur.cnt4 + cur.cnt5 + prev.cnt1;
    }
}
