package example;

import java.util.List;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;

/** CDI bean that the pages reach through page variables set with c:set and ui:param. */
@Named("cart")
@SessionScoped
public class CartBean {
    private List<String> items;

    public int getCount() {
        return items == null ? 0 : items.size();
    }

    public List<String> getItems() {
        return items;
    }

    public boolean isReady() {
        return getCount() > 0;
    }

    public String checkout() {
        return "checkout";
    }
}
