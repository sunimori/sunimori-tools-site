package example;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Calendar;

/** Cases added with the fixes of the rule review of 2026-10-26 (SR-SQL-PARAM-001, area F2b). */
final class FixF2bCases {
    /** N01: {? = call tax(?)}: the registered OUT parameter is index 1. */
    void storedFunction(Connection c, long id) throws SQLException {
        CallableStatement cs = c.prepareCall("{? = call tax(?)}");
        cs.registerOutParameter(1, Types.NUMERIC);
        cs.setLong(2, id);
    }

    /** N02: setObject(i, v, type) and setTimestamp(i, ts, calendar) bind their first argument. */
    void typedSetters(Connection c, int a, Object v, Timestamp ts, Calendar cal) throws SQLException {
        PreparedStatement ps = c.prepareStatement("insert into t (a, b, c) values (?, ?, ?)");
        ps.setInt(1, a);
        ps.setObject(2, v, Types.VARCHAR);
        ps.setTimestamp(3, ts, cal);
    }

    /** N03: one variable prepared twice; each statement is bound on its own. */
    void reusedVariable(Connection c, long x, String y) throws SQLException {
        PreparedStatement ps = c.prepareStatement("select a from t where id = ?");
        ps.setLong(1, x);
        ps = c.prepareStatement("select a from t where id = ? and name = ?");
        ps.setLong(1, x);
        ps.setString(2, y);
    }

    /** N04: a local variable that holds the SQL text; the indices match. */
    void localMatching(Connection c, int id, int year) throws SQLException {
        String sql = "select name from pupil where id = ? and year = ?";
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setInt(1, id);
        ps.setInt(2, year);
    }

    /** N05: the text is changed after the statement was prepared; the first statement is checked on its own text. */
    void localChangedAfter(Connection c, int a) throws SQLException {
        String sql = "select name from pupil where id = ?";
        PreparedStatement first = c.prepareStatement(sql);
        first.setInt(1, a);
        sql = "select name from pupil where id = ? and year = ?";
        PreparedStatement second = c.prepareStatement(sql);
        second.setInt(1, a);
        second.setInt(2, a);
    }

    /** P01: a local variable holds the SQL text and index 3 is set for two placeholders. */
    void localSql(Connection c, int a, int b, int d) throws SQLException {
        String sql = "insert into score (pupil, subject) values (?, ?)";
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setInt(1, a);
        ps.setInt(2, b);
        ps.setInt(3, d);
    }

    /** P02: the second preparation of the variable has two placeholders and is bound three times. */
    void reusedVariableWrong(Connection c, long x, String y, String z) throws SQLException {
        PreparedStatement ps = c.prepareStatement("select a from t where id = ?");
        ps.setLong(1, x);
        ps = c.prepareStatement("select a from t where id = ? and name = ?");
        ps.setLong(1, x);
        ps.setString(2, y);
        ps.setString(3, z);
    }

    /** P03: a registered OUT parameter is bound, but the IN parameter is missing. */
    void outParameterOnly(Connection c) throws SQLException {
        CallableStatement cs = c.prepareCall("{? = call tax(?)}");
        cs.registerOutParameter(1, Types.NUMERIC);
    }

    /** B01: the text is extended before the statement is prepared: built at run time. */
    void localExtended(Connection c, String extra, int id) throws SQLException {
        String sql = "select * from t where id = ?";
        if (extra != null) {
            sql += extra;
        }
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setInt(2, id);
    }

    /** B02: a later round of the loop replaces the text before the use: built at run time. */
    void localChangedInLoop(Connection c, String[] tables, int id) throws SQLException {
        String sql = "select * from t where id = ?";
        for (String table : tables) {
            PreparedStatement ps = c.prepareStatement(sql);
            ps.setInt(2, id);
            sql = "select * from " + table + " where id = ?";
        }
    }
}
