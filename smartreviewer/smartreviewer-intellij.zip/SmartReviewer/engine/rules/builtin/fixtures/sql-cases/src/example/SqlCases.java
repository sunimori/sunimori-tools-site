package example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/** Cases for SR-SQL-PARAM-001. SQL is only analysed as text. */
final class SqlCases {
    private static final String BY_ID = "select name from pupil where id = ? and year = ?";

    /** P01: three placeholders but index 4 is set. */
    void tooMany(Connection c, int a, int b, int d) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("insert into score (pupil, subject, value) values (?, ?, ?)")) {
            ps.setInt(1, a);
            ps.setInt(2, b);
            ps.setInt(4, d);
        }
    }

    /** N01: indices match the placeholders (constant SQL via a constant field). */
    void matching(Connection c, int id, int year) throws SQLException {
        PreparedStatement ps = c.prepareStatement(BY_ID);
        ps.setInt(1, id);
        ps.setInt(2, year);
    }

    /** N02: a question mark inside a literal and a comment is not a placeholder. */
    void quoted(Connection c, String name) throws SQLException {
        PreparedStatement ps = c.prepareStatement("select '?' as q /* ? */ from pupil where name = ? -- ?\n");
        ps.setString(1, name);
    }

    /** B01: computed indices are out of scope (limitation note, no finding). */
    void loop(Connection c, int[] values) throws SQLException {
        PreparedStatement ps = c.prepareStatement("insert into t values (?, ?, ?)");
        for (int i = 0; i < values.length; i++) {
            ps.setInt(i + 1, values[i]);
        }
    }

    /** B02: dynamic SQL is not checked. */
    void dynamic(Connection c, String table, int id) throws SQLException {
        PreparedStatement ps = c.prepareStatement("select * from " + table + " where id = ?");
        ps.setInt(2, id);
    }

    /** P02: the second placeholder is never bound. */
    void unbound(Connection c, int id) throws SQLException {
        PreparedStatement ps = c.prepareStatement("update pupil set grade = ? where id = ?");
        ps.setInt(2, id);
    }
}
