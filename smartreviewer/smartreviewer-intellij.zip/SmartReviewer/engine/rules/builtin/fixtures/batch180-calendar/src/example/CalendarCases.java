package example;

import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/** Calendar.DAY_OF_WEEK used as an index (SUNDAY is 1, SR-JAVA-CALENDAR-FIELD-001) and Calendar.HOUR set without AM_PM (SR-JAVA-CALENDAR-HOUR-001). */
public class CalendarCases {
    static final String[] WEEK_DAYS = {"日", "月", "火", "水", "木", "金", "土"};
    static final String[] WEEK_DAYS_FROM_ONE = {"", "日", "月", "火", "水", "木", "金", "土"};
    static final int DAYS_IN_A_WEEK = 7;
    private String[] shortNames = {"S", "M", "T", "W", "T", "F", "S"};
    private Calendar shared = Calendar.getInstance();

    // ----- DAY_OF_WEEK as an index: Saturday is 7, which a 7-element array does not have

    String dayName(Calendar calendar) {
        return WEEK_DAYS[calendar.get(Calendar.DAY_OF_WEEK)];
    }

    String dayNameThroughALocal(Calendar calendar) {
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        return WEEK_DAYS[dayOfWeek];
    }

    String dayNameFromALocalArray(Calendar calendar) {
        String[] names = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        return names[calendar.get(Calendar.DAY_OF_WEEK)];
    }

    String dayNameFromANewArray(Calendar calendar) {
        String[] names = new String[DAYS_IN_A_WEEK];
        names[0] = "Sun";
        return names[calendar.get(Calendar.DAY_OF_WEEK)];
    }

    String dayNameFromAPrivateField(Calendar calendar) {
        return shortNames[calendar.get(Calendar.DAY_OF_WEEK)];
    }

    String dayNameOfAGregorianCalendar(GregorianCalendar calendar) {
        return WEEK_DAYS[calendar.get(Calendar.DAY_OF_WEEK)];
    }

    char dayLetter(Calendar calendar) {
        return "日月火水木金土".charAt(calendar.get(Calendar.DAY_OF_WEEK));
    }

    // ----- right ways to look up the day

    String dayNameMinusOne(Calendar calendar) {
        return WEEK_DAYS[calendar.get(Calendar.DAY_OF_WEEK) - 1];
    }

    String dayNameFromATableThatStartsAtOne(Calendar calendar) {
        return WEEK_DAYS_FROM_ONE[calendar.get(Calendar.DAY_OF_WEEK)];
    }

    String dayNameFromTheSymbols(Calendar calendar) {
        return new DateFormatSymbols().getShortWeekdays()[calendar.get(Calendar.DAY_OF_WEEK)];
    }

    String dayNameModulo(Calendar calendar) {
        return WEEK_DAYS[calendar.get(Calendar.DAY_OF_WEEK) % 7];
    }

    String dayNameAfterDecrement(Calendar calendar) {
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        dayOfWeek--;
        return WEEK_DAYS[dayOfWeek];
    }

    String monthNameIsNotTheWeek(Calendar calendar) {
        return WEEK_DAYS[calendar.get(Calendar.MONTH)];
    }

    String dayNameFromAnArrayOfUnknownLength(Calendar calendar, String[] names) {
        return names[calendar.get(Calendar.DAY_OF_WEEK)];
    }

    // ----- HOUR is the hour of the 12-hour clock: which half of the day it is in comes from AM_PM

    void setTheHour(int hour) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR, hour);
    }

    /** At midnight was meant: an afternoon date comes out at noon. */
    Date truncateToMidnight(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }

    void setTheHourOfAParameter(Calendar calendar) {
        calendar.set(Calendar.HOUR, 9);
    }

    void setTheHourOfAField() {
        this.shared.set(Calendar.HOUR, 9);
    }

    void setTheHourOfAnotherCalendar(Calendar first, Calendar second) {
        first.set(Calendar.AM_PM, Calendar.AM);
        second.set(Calendar.HOUR, 9);
    }

    // ----- the half of the day is known or kept

    void hourAndPm(Calendar calendar) {
        calendar.set(Calendar.HOUR, 9);
        calendar.set(Calendar.AM_PM, Calendar.PM);
    }

    void amFirst(Calendar calendar) {
        calendar.set(Calendar.AM_PM, Calendar.AM);
        calendar.set(Calendar.HOUR, 9);
    }

    void cleared() {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(2026, Calendar.OCTOBER, 28);
        calendar.set(Calendar.HOUR, 3);
    }

    void madeAtMidnight() {
        Calendar calendar = new GregorianCalendar(2026, Calendar.OCTOBER, 28);
        calendar.set(Calendar.HOUR, 3);
    }

    void madeAtAConstantHour() {
        Calendar calendar = new GregorianCalendar(2026, Calendar.OCTOBER, 28, 15, 0);
        calendar.set(Calendar.HOUR, 3);
    }

    void madeAtAVariableHour(int hourOfDay) {
        Calendar calendar = new GregorianCalendar(2026, Calendar.OCTOBER, 28, hourOfDay, 0);
        calendar.set(Calendar.HOUR, 3);
    }

    void oneHourLater(Calendar calendar) {
        calendar.set(Calendar.HOUR, calendar.get(Calendar.HOUR) + 1);
    }

    void hourOfDay(Calendar calendar) {
        calendar.set(Calendar.HOUR_OF_DAY, 9);
    }

    void addHours(Calendar calendar) {
        calendar.add(Calendar.HOUR, 3);
    }

    // ----- a new time starts the half of the day over: what was decided before setTime does not count after it

    void midnightThenSetTime(Date date) {
        Calendar calendar = new GregorianCalendar(2026, Calendar.OCTOBER, 28);
        calendar.setTime(date);
        calendar.set(Calendar.HOUR, 3);
    }

    void clearedThenSetTime(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR, 3);
    }

    void amPmThenSetTime(Date date, Calendar calendar) {
        calendar.set(Calendar.AM_PM, Calendar.AM);
        calendar.setTime(date);
        calendar.set(Calendar.HOUR, 3);
    }

    void setTimeThenAmPm(Date date, Calendar calendar) {
        calendar.setTime(date);
        calendar.set(Calendar.AM_PM, Calendar.AM);
        calendar.set(Calendar.HOUR, 3);
    }

    /** The AM_PM that follows the HOUR after the same setTime is the usual way to write both. */
    void setTimeThenHourThenAmPm(Date date, Calendar calendar) {
        calendar.setTime(date);
        calendar.set(Calendar.HOUR, 3);
        calendar.set(Calendar.AM_PM, Calendar.PM);
    }

    void oneHourLaterThroughALocal(Calendar calendar) {
        int hour = calendar.get(Calendar.HOUR);
        calendar.set(Calendar.HOUR, hour + 1);
    }
}
