package example;

import com.example.missing.Schedule;

import java.util.Calendar;

/** The receiver of get(Calendar.DAY_OF_WEEK) or of set(Calendar.HOUR, ...) has a type that is not on the class path. */
public class UnresolvedCalendar {
    static final String[] NAMES = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};

    String dayName(Schedule schedule) {
        return NAMES[schedule.get(Calendar.DAY_OF_WEEK)];
    }

    String fine(Schedule schedule) {
        return NAMES[schedule.get(Calendar.DAY_OF_WEEK) - 1];
    }

    void setTheHour(Schedule schedule) {
        schedule.set(Calendar.HOUR, 3);
    }

    void setTheHourAndPm(Schedule schedule) {
        schedule.set(Calendar.HOUR, 3);
        schedule.set(Calendar.AM_PM, Calendar.PM);
    }
}
