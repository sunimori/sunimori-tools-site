package example;

import com.ibm.icu.util.Calendar;

/** The Calendar class itself is not on the class path (ICU's, say): neither the receiver nor the constants Calendar.DAY_OF_WEEK and Calendar.HOUR resolve. */
public class UnresolvedIcuCalendar {
    static final String[] NAMES = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};

    String icuDayName(Calendar calendar) {
        return NAMES[calendar.get(Calendar.DAY_OF_WEEK)];
    }

    String icuDayNameMinusOne(Calendar calendar) {
        return NAMES[calendar.get(Calendar.DAY_OF_WEEK) - 1];
    }

    void icuSetTheHour(Calendar calendar) {
        calendar.set(Calendar.HOUR, 3);
    }

    void icuSetTheHourAndPm(Calendar calendar) {
        calendar.set(Calendar.HOUR, 3);
        calendar.set(Calendar.AM_PM, Calendar.PM);
    }
}
