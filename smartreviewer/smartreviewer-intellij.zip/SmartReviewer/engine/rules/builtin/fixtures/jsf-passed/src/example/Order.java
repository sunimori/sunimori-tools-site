package example;

import java.util.List;

/** A record: every value is exactly an Order, so a member it lacks is reported. */
public record Order(String number, Customer customer, List<Line> lines) {
}
