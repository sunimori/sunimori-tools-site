package example;

public record Line(String product, int quantity) {
}
