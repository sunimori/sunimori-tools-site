package example;

public record Partner(String name, String phone) {
}
