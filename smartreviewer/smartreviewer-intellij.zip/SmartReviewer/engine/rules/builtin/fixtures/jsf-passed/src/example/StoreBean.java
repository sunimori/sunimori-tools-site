package example;

import java.util.List;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

/** CDI bean whose values pages pass to templates and included pages. */
@Named("store")
@RequestScoped
public class StoreBean {
    public Order getCurrent() {
        return null;
    }

    public Order getArchived() {
        return null;
    }

    public List<Order> getOrders() {
        return List.of();
    }

    public Partner getPartner() {
        return null;
    }

    public List<Partner> getPartners() {
        return List.of();
    }

    public String getTab() {
        return "details";
    }
}
