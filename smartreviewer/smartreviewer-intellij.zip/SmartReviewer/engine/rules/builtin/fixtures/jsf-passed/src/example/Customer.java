package example;

public record Customer(String name, String city) {
}
