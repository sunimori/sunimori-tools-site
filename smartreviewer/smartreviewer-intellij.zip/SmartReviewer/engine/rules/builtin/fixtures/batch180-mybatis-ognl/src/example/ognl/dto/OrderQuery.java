package example.ognl.dto;

import java.math.BigDecimal;
import java.util.Date;

/** A parameter object: some properties have getters, some are read from the field (as MyBatis' Reflector does). */
public class OrderQuery extends BaseQuery {
    private Integer status;
    private int level;
    private String name;
    private String flag;
    private Boolean active;
    private BigDecimal price;
    private Date created;
    private Status state;
    private Character mark;
    private Range range;

    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }
    public String getFlag() { return flag; }
    public void setFlag(String flag) { this.flag = flag; }
    public Boolean isActive() { return active; }

    public static class Range {
        private Integer from;
        private String label;
    }
}
