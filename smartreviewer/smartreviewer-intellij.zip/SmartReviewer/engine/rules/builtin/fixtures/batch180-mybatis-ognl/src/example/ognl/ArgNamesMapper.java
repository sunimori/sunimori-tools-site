package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ArgNamesMapper {
    List<String> find(Integer status, String name);
}
