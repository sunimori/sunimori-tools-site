package example.ognl;

import example.ognl.dto.*;
import java.util.*;
import org.apache.ibatis.annotations.Param;

public interface WildcardImportMapper {
    List<String> find(@Param("q") OrderQuery q);
}
