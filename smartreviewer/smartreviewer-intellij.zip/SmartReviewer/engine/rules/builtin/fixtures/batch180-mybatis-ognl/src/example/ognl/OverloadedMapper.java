package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OverloadedMapper {
    List<String> find(@Param("status") Integer status);
    List<String> find(@Param("status") String status);
}
