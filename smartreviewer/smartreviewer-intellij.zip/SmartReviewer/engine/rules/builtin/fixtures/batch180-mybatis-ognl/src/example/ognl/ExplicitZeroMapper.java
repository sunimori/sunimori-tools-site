package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ExplicitZeroMapper {
    List<String> find(@Param("status") Integer status, @Param("count") Integer count);
}
