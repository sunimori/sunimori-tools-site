package example.ognl.dto;

import lombok.Data;

/** Accessors come from Lombok: the fields are all the source shows. */
@Data
public class Account {
    private Long id;
    private String code;
}
