package example.ognl;

import org.apache.ibatis.annotations.Param;

public interface BrokenInterfaceMapper {
    java.util.List<String> find(@Param("status") Integer status)
}
