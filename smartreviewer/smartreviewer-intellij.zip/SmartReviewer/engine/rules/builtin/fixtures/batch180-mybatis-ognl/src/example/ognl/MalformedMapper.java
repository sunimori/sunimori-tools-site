package example.ognl;

import org.apache.ibatis.annotations.Param;

public interface MalformedMapper {
    java.util.List<String> find(@Param("status") Integer status);
}
