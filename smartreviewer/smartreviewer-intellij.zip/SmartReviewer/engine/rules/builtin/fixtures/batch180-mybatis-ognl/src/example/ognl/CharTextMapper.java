package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CharTextMapper {
    List<String> find(@Param("mark") Character mark);
}
