package example.ognl.dto;

/** Properties that the query classes inherit. */
public class BaseQuery {
    private Integer pageNo;
    private String sortKey;

    public Integer getPageNo() { return pageNo; }
    public void setPageNo(Integer pageNo) { this.pageNo = pageNo; }
}
