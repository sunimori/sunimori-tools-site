package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ChooseMapper {
    List<String> find(@Param("price") java.math.BigDecimal price);
}
