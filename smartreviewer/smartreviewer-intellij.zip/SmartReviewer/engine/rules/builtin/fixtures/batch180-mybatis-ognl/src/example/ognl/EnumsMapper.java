package example.ognl;

import example.ognl.dto.OrderQuery;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface EnumsMapper {
    List<String> find(@Param("q") OrderQuery q, @Param("s") example.ognl.dto.Status s);
}
