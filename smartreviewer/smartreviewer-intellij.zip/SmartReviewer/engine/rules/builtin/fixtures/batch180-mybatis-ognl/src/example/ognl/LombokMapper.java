package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface LombokMapper {
    List<String> find(@Param("acc") example.ognl.dto.Account acc);
}
