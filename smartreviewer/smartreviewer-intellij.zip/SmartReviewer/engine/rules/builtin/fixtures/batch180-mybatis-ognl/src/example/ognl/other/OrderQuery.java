package example.ognl.other;

/** A second class of that name in another package. */
public class OrderQuery {
    private Integer status;
}
