package example.ognl.dto;

/** A generic wrapper: the type of value depends on the use. */
public class Page<T> {
    private T value;
    private Integer size;
}
