package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CharsMapper {
    List<String> find(@Param("mark") Character mark, @Param("grade") char grade);
}
