package example.ognl;

import example.ognl.dto.OrderQuery;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface StringsMapper {
    List<String> find(@Param("name") String name, @Param("cond") OrderQuery cond);
}
