package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OthersMapper {
    List<String> find(@Param("ids") List<Integer> ids, @Param("m") java.util.Map<String, Object> m);
}
