package example.ognl;

import example.ognl.dto.OrderQuery;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface StringCharMapper {
    List<String> find(@Param("cond") OrderQuery cond);
}
