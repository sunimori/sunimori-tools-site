package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ZeroEmptyMapper {
    List<String> find(@Param("status") Integer status, @Param("name") String name);
}
