package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PrimitivesMapper {
    List<String> find(@Param("level") int level, @Param("active") boolean active);
}
