package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface GenericMapper {
    List<String> find(@Param("p") example.ognl.dto.Page<String> p);
}
