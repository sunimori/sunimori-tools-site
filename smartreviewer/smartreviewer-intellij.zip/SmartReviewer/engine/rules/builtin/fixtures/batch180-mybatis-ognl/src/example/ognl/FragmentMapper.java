package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface FragmentMapper {
    List<String> find(@Param("status") Integer status);
    List<String> count(@Param("status") Integer status);
}
