package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NumbersMapper {
    List<String> find(@Param("status") Integer status, @Param("level") long level);
}
