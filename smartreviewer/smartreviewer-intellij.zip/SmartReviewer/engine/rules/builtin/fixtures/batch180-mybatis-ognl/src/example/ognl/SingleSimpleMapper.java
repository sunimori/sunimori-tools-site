package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface SingleSimpleMapper {
    List<String> find(Long id);
}
