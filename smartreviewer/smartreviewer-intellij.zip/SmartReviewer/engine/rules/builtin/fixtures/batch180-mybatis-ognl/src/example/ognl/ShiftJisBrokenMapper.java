package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ShiftJisBrokenMapper {
    List<String> find(@Param("status") Integer status);
}
