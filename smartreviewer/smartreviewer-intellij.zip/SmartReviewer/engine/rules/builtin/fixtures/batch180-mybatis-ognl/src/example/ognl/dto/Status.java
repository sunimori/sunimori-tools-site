package example.ognl.dto;

public enum Status { OPEN, CLOSED }
