package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ShadowedMapper {
    List<String> find(@Param("status") Integer status, @Param("ids") List<Integer> ids);
}
