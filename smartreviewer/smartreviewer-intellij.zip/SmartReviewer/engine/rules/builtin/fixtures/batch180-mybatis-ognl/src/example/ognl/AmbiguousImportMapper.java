package example.ognl;

import example.ognl.dto.*;
import example.ognl.other.*;
import java.util.*;
import org.apache.ibatis.annotations.Param;

public interface AmbiguousImportMapper {
    List<String> find(@Param("q") OrderQuery q);
}
