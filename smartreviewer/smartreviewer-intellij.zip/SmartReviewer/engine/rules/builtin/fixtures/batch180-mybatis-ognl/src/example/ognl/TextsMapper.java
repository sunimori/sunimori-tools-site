package example.ognl;

import example.ognl.dto.OrderQuery;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TextsMapper {
    List<String> find(@Param("level") Integer level, @Param("active") Boolean active, @Param("q") OrderQuery q);
}
