package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface LangMapper {
    List<String> find(@Param("status") Integer status);
    List<String> other(@Param("status") Integer status);
}
