package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CharCodeMapper {
    List<String> find(@Param("type") Integer type);
}
