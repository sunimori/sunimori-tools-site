package example.ognl;

import example.ognl.dto.OrderQuery;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DatesMapper {
    List<String> find(@Param("q") OrderQuery q, @Param("day") java.time.LocalDate day, @Param("id") java.util.UUID id);
}
