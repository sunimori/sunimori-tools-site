package example.ognl;

import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NumberTypeMapper {
    List<String> find(@Param("n") Number n);
}
