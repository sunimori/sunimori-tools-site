package javax.ws.rs.core;

/** Stub (fixture only). */
public @interface Context {
}
