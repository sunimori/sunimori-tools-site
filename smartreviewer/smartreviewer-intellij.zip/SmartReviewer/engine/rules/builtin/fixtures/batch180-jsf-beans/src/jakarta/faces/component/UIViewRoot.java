package jakarta.faces.component;

/** Stub (fixture only). */
public class UIViewRoot {
}
