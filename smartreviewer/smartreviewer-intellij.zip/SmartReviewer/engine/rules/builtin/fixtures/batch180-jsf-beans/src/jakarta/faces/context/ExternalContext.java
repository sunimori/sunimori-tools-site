package jakarta.faces.context;

/** Stub (fixture only). */
public abstract class ExternalContext {
}
