package javax.faces.context;

/** Stub (fixture only). */
public abstract class FacesContext {
}
