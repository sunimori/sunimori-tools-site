package org.springframework.beans.factory.annotation;

/** Stub (fixture only). */
public @interface Autowired {
}
