package javax.inject;

/** Stub (fixture only). */
public @interface Named {
    String value() default "";
}
