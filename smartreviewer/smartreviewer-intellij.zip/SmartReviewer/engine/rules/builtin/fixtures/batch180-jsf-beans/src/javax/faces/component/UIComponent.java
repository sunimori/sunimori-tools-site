package javax.faces.component;

/** Stub (fixture only). */
public abstract class UIComponent {
}
