package javax.faces.component;

/** Stub (fixture only). */
public class UIViewRoot {
}
