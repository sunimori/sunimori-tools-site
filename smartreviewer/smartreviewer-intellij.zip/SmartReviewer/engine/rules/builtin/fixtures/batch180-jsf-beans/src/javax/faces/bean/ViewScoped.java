package javax.faces.bean;

/** Stub (fixture only). */
public @interface ViewScoped {
}
