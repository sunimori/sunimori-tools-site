package javax.enterprise.context;

/** Stub (fixture only). */
public @interface RequestScoped {
}
