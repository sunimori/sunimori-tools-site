package javax.faces.flow;

/** Stub (fixture only). */
public @interface FlowScoped {
    String value();
}
