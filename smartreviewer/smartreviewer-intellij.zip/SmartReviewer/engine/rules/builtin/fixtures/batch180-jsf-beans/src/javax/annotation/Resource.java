package javax.annotation;

/** Stub (fixture only). */
public @interface Resource {
}
