package jakarta.inject;

/** Stub (fixture only). */
public @interface Inject {
}
