package jakarta.enterprise.context;

/** Stub (fixture only). */
public @interface ConversationScoped {
}
