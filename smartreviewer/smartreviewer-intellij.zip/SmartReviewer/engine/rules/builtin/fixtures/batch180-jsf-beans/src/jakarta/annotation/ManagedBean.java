package jakarta.annotation;

/** Stub (fixture only). */
public @interface ManagedBean {
}
