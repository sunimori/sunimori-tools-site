package jakarta.annotation;

/** Stub (fixture only). */
public @interface Resource {
}
