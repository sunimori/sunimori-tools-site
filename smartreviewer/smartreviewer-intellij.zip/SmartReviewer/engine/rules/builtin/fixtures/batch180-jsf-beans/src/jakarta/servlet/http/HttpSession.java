package jakarta.servlet.http;

/** Stub (fixture only). */
public interface HttpSession {
}
