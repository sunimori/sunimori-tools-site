package org.omnifaces.cdi;

/** Stub (fixture only). */
public @interface ViewScoped {
}
