package javax.annotation;

/** Stub (fixture only). */
public @interface ManagedBean {
}
