package javax.inject;

/** Stub (fixture only). */
public @interface Inject {
}
