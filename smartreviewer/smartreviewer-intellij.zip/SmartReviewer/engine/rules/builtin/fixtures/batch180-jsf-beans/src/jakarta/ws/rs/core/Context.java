package jakarta.ws.rs.core;

/** Stub (fixture only). */
public @interface Context {
}
