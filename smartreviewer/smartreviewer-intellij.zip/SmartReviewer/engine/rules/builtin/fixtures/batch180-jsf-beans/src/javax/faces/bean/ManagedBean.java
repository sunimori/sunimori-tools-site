package javax.faces.bean;

/** Stub (fixture only). */
public @interface ManagedBean {
    String name() default "";
    boolean eager() default false;
}
