package javax.servlet.http;

/** Stub (fixture only). */
public interface HttpSession {
}
