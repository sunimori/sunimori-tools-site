package jakarta.servlet;

/** Stub (fixture only). */
public interface ServletResponse {
}
