package jakarta.faces.bean;

/** Stub (fixture only). */
public @interface ApplicationScoped {
}
