package jakarta.faces.view;

/** Stub (fixture only). */
public @interface ViewScoped {
}
