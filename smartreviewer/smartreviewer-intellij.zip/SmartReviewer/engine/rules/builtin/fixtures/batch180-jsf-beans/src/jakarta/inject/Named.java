package jakarta.inject;

/** Stub (fixture only). */
public @interface Named {
    String value() default "";
}
