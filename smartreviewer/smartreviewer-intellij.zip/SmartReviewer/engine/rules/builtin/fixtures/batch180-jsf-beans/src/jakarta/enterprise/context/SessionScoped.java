package jakarta.enterprise.context;

/** Stub (fixture only). */
public @interface SessionScoped {
}
