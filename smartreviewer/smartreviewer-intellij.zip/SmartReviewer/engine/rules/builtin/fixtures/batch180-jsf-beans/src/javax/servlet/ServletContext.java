package javax.servlet;

/** Stub (fixture only). */
public interface ServletContext {
}
