package com.google.inject.name;

/** Stub (fixture only). */
public @interface Named {
    String value() default "";
}
