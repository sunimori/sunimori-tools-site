package javax.mail;

/** Stub (fixture only). */
public interface Part {
    void setHeader(String headerName, String headerValue) throws MessagingException;

    void addHeader(String headerName, String headerValue) throws MessagingException;

    void setDescription(String description) throws MessagingException;

    void setText(String text) throws MessagingException;
}
