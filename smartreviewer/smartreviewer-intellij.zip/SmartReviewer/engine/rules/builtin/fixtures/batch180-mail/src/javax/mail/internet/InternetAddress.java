package javax.mail.internet;

import javax.mail.Address;

/** Stub (fixture only). */
public class InternetAddress extends Address {
    public InternetAddress(String address) throws AddressException {
    }

    public InternetAddress(String address, String personal) throws java.io.UnsupportedEncodingException {
    }

    public static InternetAddress[] parse(String addresslist) throws AddressException {
        return null;
    }
}
