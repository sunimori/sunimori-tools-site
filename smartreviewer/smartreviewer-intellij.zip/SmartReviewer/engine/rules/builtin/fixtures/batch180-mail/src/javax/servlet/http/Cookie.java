package javax.servlet.http;

/** Stub (fixture only). */
public class Cookie {
    public String getValue() {
        return null;
    }
}
