package jakarta.mail;

/** Stub (fixture only). */
public class MessagingException extends Exception {
}
