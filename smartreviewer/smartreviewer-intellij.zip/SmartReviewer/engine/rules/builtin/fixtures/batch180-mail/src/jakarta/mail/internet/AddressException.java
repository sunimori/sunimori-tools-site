package jakarta.mail.internet;

import jakarta.mail.MessagingException;

/** Stub (fixture only). */
public class AddressException extends MessagingException {
}
