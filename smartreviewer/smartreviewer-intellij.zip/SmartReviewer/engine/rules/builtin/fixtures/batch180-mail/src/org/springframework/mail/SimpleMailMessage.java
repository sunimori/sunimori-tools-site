package org.springframework.mail;

/** Stub (fixture only). */
public class SimpleMailMessage implements MailMessage {
    public void setSubject(String subject) {
    }

    public void setFrom(String from) {
    }

    public void setReplyTo(String replyTo) {
    }

    public void setTo(String to) {
    }

    public void setTo(String... to) {
    }

    public void setCc(String cc) {
    }

    public void setBcc(String bcc) {
    }

    public void setText(String text) {
    }
}
