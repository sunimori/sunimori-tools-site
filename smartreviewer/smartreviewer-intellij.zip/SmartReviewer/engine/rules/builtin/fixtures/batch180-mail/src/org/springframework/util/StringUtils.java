package org.springframework.util;

/** Stub (fixture only). */
public abstract class StringUtils {
    public static String trimAllWhitespace(String str) {
        return str;
    }

    public static String deleteAny(String inString, String charsToDelete) {
        return inString;
    }

    public static String replace(String inString, String oldPattern, String newPattern) {
        return inString;
    }
}
