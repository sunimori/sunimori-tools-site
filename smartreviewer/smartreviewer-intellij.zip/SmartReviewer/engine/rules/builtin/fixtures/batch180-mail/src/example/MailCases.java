package example;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Set;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Part;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

/**
 * JavaMail cases for SR-SEC-MAIL-HEADER-INJECTION-001. The header calls (setHeader, addHeader, addHeaderLine) are reported
 * whatever the version of the library; the subject, description and address calls only when legacyLibraries is true, or auto and
 * the class path shows an older library (or nothing: the suites have no class path), because JavaMail 1.5.6 and later fold their
 * line breaks. P = reported, N = not reported, B = near the edge, L = reported with legacyLibraries only (the suite runs these
 * twice: true and false).
 */
public class MailCases {
    private static final Set<String> ORIGINS = Set.of("web", "app");
    private static final Map<String, String> LABELS = Map.of("web", "Web", "app", "App");
    private MimeMessage message;
    private MimeBodyPart part;
    private Part anyPart;
    private final InternetHeaders headers = new InternetHeaders();

    // ------------------------------------------------------------------ P: header calls

    /** P: a header value from a parameter. */
    void setHeaderValue(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Origin", request.getParameter("origin"));
    }

    /** P: addHeader. */
    void addHeaderValue(HttpServletRequest request) throws MessagingException {
        message.addHeader("X-Campaign", request.getParameter("campaign"));
    }

    /** P: the name of the header. */
    void headerName(HttpServletRequest request) throws MessagingException {
        message.setHeader(request.getParameter("name"), "1");
    }

    /** P: a raw header line. */
    void headerLine(HttpServletRequest request) throws MessagingException {
        message.addHeaderLine("X-Note: " + request.getParameter("note"));
    }

    /** P: a body part. */
    void bodyPartHeader(HttpServletRequest request) throws MessagingException {
        part.setHeader("Content-Description", request.getParameter("title"));
    }

    /** P: the header list of a message. */
    void internetHeaders(HttpServletRequest request) {
        headers.addHeader("X-Ticket", request.getParameter("ticket"));
    }

    /** P: a Part. */
    void partHeader(HttpServletRequest request) throws MessagingException {
        anyPart.setHeader("X-Source", request.getParameter("source"));
    }

    /** P: built in a local first. */
    void viaLocal(HttpServletRequest request) throws MessagingException {
        String ticket = request.getParameter("ticket");
        String value = "ticket-" + ticket;
        message.setHeader("X-Ticket", value);
    }

    /** P: String.format. */
    void viaFormat(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Ticket", String.format("%s/%s", request.getParameter("a"), request.getParameter("b")));
    }

    /** P: StringBuilder. */
    void viaBuilder(HttpServletRequest request) throws MessagingException {
        StringBuilder sb = new StringBuilder("ticket-");
        sb.append(request.getParameter("ticket"));
        message.setHeader("X-Ticket", sb.toString());
    }

    /** P: the extra path of the request is decoded by the container. */
    void decodedPath(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Path", request.getPathInfo());
    }

    /** P: a default for a missing parameter does not check the value. */
    void withDefault(HttpServletRequest request) throws MessagingException {
        String origin = request.getParameter("origin");
        if (origin == null) {
            origin = "web";
        }
        message.setHeader("X-Origin", origin);
    }

    /** P: the check holds in the other branch only. */
    void checkedInOtherBranch(HttpServletRequest request) throws MessagingException {
        String origin = request.getParameter("origin");
        if (ORIGINS.contains(origin)) {
            message.setHeader("X-Known", origin);
        } else {
            message.setHeader("X-Unknown", origin);
        }
    }

    /** P: a trimmed value still holds line breaks inside. */
    void trimmed(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Origin", request.getParameter("origin").trim());
    }

    // ------------------------------------------------------------------ N: no line break can come, or the line breaks are gone

    /** N: constants. */
    void constants() throws MessagingException {
        message.setHeader("X-Mailer", "app");
        message.addHeader("X-Priority", "1");
    }

    /** N: a header value cannot hold a raw line break. */
    void fromRequestHeader(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Agent", request.getHeader("User-Agent"));
    }

    /** N: a cookie value cannot hold a raw line break. */
    void fromCookie(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Session", request.getCookies()[0].getValue());
    }

    /** N: the request URI and the query string are percent encoded as they come. */
    void rawRequestLine(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Uri", request.getRequestURI());
        message.setHeader("X-Query", request.getQueryString());
    }

    /** N: both line breaks removed with replace. */
    void strippedWithReplace(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Origin", request.getParameter("origin").replace("\r", "").replace("\n", ""));
    }

    /** N: a character class with both. */
    void strippedWithRegex(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Origin", request.getParameter("origin").replaceAll("[\\r\\n]", ""));
    }

    /** N: runs of white space become one blank. */
    void collapsedWhiteSpace(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Origin", request.getParameter("origin").replaceAll("\\s+", " "));
    }

    /** N: only letters and digits are kept. */
    void keptLettersAndDigits(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Origin", request.getParameter("origin").replaceAll("[^A-Za-z0-9]", ""));
    }

    /** N: commons-lang removes all white space. */
    void deletedWhitespace(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Origin", StringUtils.deleteWhitespace(request.getParameter("origin")));
    }

    /** N: URL-encoded text has no raw line break. */
    void urlEncoded(HttpServletRequest request) throws MessagingException, UnsupportedEncodingException {
        message.setHeader("X-Origin", URLEncoder.encode(request.getParameter("origin"), "UTF-8"));
    }

    /** N: checked against a fixed set. */
    void allowList(HttpServletRequest request) throws MessagingException {
        String origin = request.getParameter("origin");
        if (!ORIGINS.contains(origin)) {
            return;
        }
        message.setHeader("X-Origin", origin);
    }

    /** N: a full-match pattern. */
    void pattern(HttpServletRequest request) throws MessagingException {
        String origin = request.getParameter("origin");
        if (origin.matches("[A-Za-z0-9 ._-]{1,40}")) {
            message.setHeader("X-Origin", origin);
        }
    }

    /** N: a number. */
    void number(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Count", String.valueOf(Integer.parseInt(request.getParameter("count"))));
    }

    /** N: the label comes from a fixed table. */
    void table(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Origin", LABELS.getOrDefault(request.getParameter("origin"), "Other"));
    }

    /** N: a parameter of the method is whoever calls it. */
    void parameterOfTheMethod(String origin) throws MessagingException {
        message.setHeader("X-Origin", origin);
    }

    /** N: the body of the message is not a header. */
    void bodyText(HttpServletRequest request) throws MessagingException {
        message.setText(request.getParameter("text"));
    }

    // ------------------------------------------------------------------ B: near the edge

    /** B: only the line feed is removed: a carriage return still ends a header on some servers. */
    void strippedLineFeedOnly(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Origin", request.getParameter("origin").replace("\n", ""));
    }

    /** B: the pair CR LF is replaced, a lone CR or LF is not. */
    void strippedPairOnly(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Origin", request.getParameter("origin").replace("\r\n", " "));
    }

    /** B: the second value is not cleaned. */
    void oneOfTwoCleaned(HttpServletRequest request) throws MessagingException {
        message.setHeader("X-Origin", request.getParameter("a").replaceAll("[\\r\\n]", "") + request.getParameter("b"));
    }

    /** B: cleaned on one path only. */
    void cleanedOnOnePath(HttpServletRequest request, boolean strict) throws MessagingException {
        String origin = request.getParameter("origin");
        message.setHeader("X-Origin", strict ? origin.replaceAll("[\\r\\n]", "") : origin);
    }

    /** B: the name is constant but the value is not cleaned, in addHeader. */
    void nameConstant(HttpServletRequest request) throws MessagingException {
        message.addHeader("Reply-To", request.getParameter("reply"));
    }

    // ------------------------------------------------------------------ L: only with legacyLibraries

    /** L: the subject. */
    void subject(HttpServletRequest request) throws MessagingException {
        message.setSubject(request.getParameter("subject"));
    }

    /** L: the subject with a charset. */
    void subjectWithCharset(HttpServletRequest request) throws MessagingException {
        message.setSubject("[web] " + request.getParameter("subject"), "UTF-8");
    }

    /** L: the subject of a Message. */
    void messageSubject(Message m, HttpServletRequest request) throws MessagingException {
        m.setSubject(request.getParameter("subject"));
    }

    /** L: the description of a part. */
    void description(HttpServletRequest request) throws MessagingException {
        part.setDescription(request.getParameter("title"));
    }

    /** L: recipients as text. */
    void recipients(HttpServletRequest request) throws MessagingException {
        message.setRecipients(Message.RecipientType.TO, request.getParameter("to"));
    }

    /** L: more recipients as text. */
    void addedRecipients(HttpServletRequest request) throws MessagingException {
        message.addRecipients(Message.RecipientType.CC, request.getParameter("cc"));
    }

    /** L: an address made of the parameter. */
    void address(HttpServletRequest request) throws MessagingException {
        message.setFrom(new InternetAddress(request.getParameter("from")));
    }

    /** L: an address with a display name is not parsed. */
    void addressWithName(HttpServletRequest request) throws MessagingException, UnsupportedEncodingException {
        message.setFrom(new InternetAddress(request.getParameter("from"), "Support"));
    }

    /** L: parsed addresses. */
    void parsedAddresses(HttpServletRequest request) throws MessagingException {
        message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(request.getParameter("bcc")));
    }

    /** L: the personal name of an address is folded like the rest of the header. */
    void personalNameOnly(HttpServletRequest request) throws MessagingException, UnsupportedEncodingException {
        message.setFrom(new InternetAddress("noreply@example.com", request.getParameter("name")));
    }

    /** L, N: the subject with its line breaks removed. */
    void subjectCleaned(HttpServletRequest request) throws MessagingException {
        message.setSubject(request.getParameter("subject").replaceAll("[\\r\\n]", " "));
    }

    /** L, N: an address checked by InternetAddress parsing is still a sink here, a fixed one is not. */
    void fixedAddress() throws MessagingException {
        message.setFrom(new InternetAddress("noreply@example.com"));
        message.setSubject("Order confirmation");
    }

    /** L, N: the subject from a request header has no raw line break. */
    void subjectFromHeader(HttpServletRequest request) throws MessagingException {
        message.setSubject(request.getHeader("X-Subject"));
    }

    /** Keeps the compiler quiet about an unused import. */
    AddressException unused() {
        return null;
    }
}
