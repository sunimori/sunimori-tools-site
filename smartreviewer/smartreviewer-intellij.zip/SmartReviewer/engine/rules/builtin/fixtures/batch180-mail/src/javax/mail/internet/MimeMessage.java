package javax.mail.internet;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;

/** Stub (fixture only). */
public class MimeMessage extends Message implements MimePart {
    public void setSubject(String subject) throws MessagingException {
    }

    public void setSubject(String subject, String charset) throws MessagingException {
    }

    public void setFrom(Address address) throws MessagingException {
    }

    public void setFrom(String address) throws MessagingException {
    }

    public void setRecipients(Message.RecipientType type, Address[] addresses) throws MessagingException {
    }

    public void setRecipients(Message.RecipientType type, String addresses) throws MessagingException {
    }

    public void addRecipients(Message.RecipientType type, String addresses) throws MessagingException {
    }

    public void setHeader(String name, String value) throws MessagingException {
    }

    public void addHeader(String name, String value) throws MessagingException {
    }

    public void addHeaderLine(String line) throws MessagingException {
    }

    public void setDescription(String description) throws MessagingException {
    }

    public void setText(String text) throws MessagingException {
    }
}
