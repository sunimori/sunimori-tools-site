package org.apache.commons.lang3;

/** Stub (fixture only). */
public final class StringUtils {
    private StringUtils() {
    }

    public static boolean isAlphanumeric(CharSequence cs) {
        return false;
    }

    public static String deleteWhitespace(String str) {
        return str;
    }

    public static String remove(String str, String remove) {
        return str;
    }

    public static String replace(String text, String searchString, String replacement) {
        return text;
    }

    public static String replaceChars(String str, String searchChars, String replaceChars) {
        return str;
    }

    public static String replaceChars(String str, char searchChar, char replaceChar) {
        return str;
    }
}
