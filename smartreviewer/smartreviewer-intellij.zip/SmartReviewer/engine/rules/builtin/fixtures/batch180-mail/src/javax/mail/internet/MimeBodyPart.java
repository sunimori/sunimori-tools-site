package javax.mail.internet;

import javax.mail.MessagingException;

/** Stub (fixture only). */
public class MimeBodyPart implements MimePart {
    public void setHeader(String name, String value) throws MessagingException {
    }

    public void addHeader(String name, String value) throws MessagingException {
    }

    public void addHeaderLine(String line) throws MessagingException {
    }

    public void setDescription(String description) throws MessagingException {
    }

    public void setText(String text) throws MessagingException {
    }
}
