package org.springframework.mail.javamail;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

/** Stub (fixture only). */
public class MimeMessageHelper {
    public MimeMessageHelper(MimeMessage message) {
    }

    public MimeMessage getMimeMessage() {
        return null;
    }

    public void setSubject(String subject) throws MessagingException {
    }

    public void setTo(String to) throws MessagingException {
    }

    public void setTo(String[] to) throws MessagingException {
    }

    public void setFrom(String from) throws MessagingException {
    }

    public void setCc(String cc) throws MessagingException {
    }

    public void setBcc(String bcc) throws MessagingException {
    }

    public void setReplyTo(String replyTo) throws MessagingException {
    }

    public void setText(String text) throws MessagingException {
    }
}
