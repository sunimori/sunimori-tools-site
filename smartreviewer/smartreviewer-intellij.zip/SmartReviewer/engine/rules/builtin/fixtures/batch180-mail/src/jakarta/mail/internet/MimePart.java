package jakarta.mail.internet;

import jakarta.mail.MessagingException;
import jakarta.mail.Part;

/** Stub (fixture only). */
public interface MimePart extends Part {
    void addHeaderLine(String line) throws MessagingException;
}
