package org.springframework.mail;

/** Stub (fixture only). */
public interface MailMessage {
    void setSubject(String subject);

    void setFrom(String from);

    void setReplyTo(String replyTo);

    void setTo(String to);
}
