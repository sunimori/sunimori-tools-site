package javax.mail.internet;

import javax.mail.MessagingException;

/** Stub (fixture only). */
public class AddressException extends MessagingException {
}
