package javax.mail.internet;

/** Stub (fixture only). */
public class InternetHeaders {
    public void setHeader(String name, String value) {
    }

    public void addHeader(String name, String value) {
    }

    public void addHeaderLine(String line) {
    }
}
