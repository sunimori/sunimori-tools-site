package org.apache.commons.mail;

/** Stub (fixture only). */
public class SimpleEmail extends Email {
}
