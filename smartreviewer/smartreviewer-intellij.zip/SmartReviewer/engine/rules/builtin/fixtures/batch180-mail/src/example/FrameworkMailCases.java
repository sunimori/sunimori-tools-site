package example;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

import com.opensymphony.xwork2.ActionSupport;

import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/** Spring, Commons Email, Struts 2 and JSF cases for SR-SEC-MAIL-HEADER-INJECTION-001. */
public class FrameworkMailCases {
    /** What the container injects. */
    public interface Mailer {
        String signature();
    }

    /** Spring MVC handlers and the Spring mail classes. */
    @Controller
    public static class Handlers {
        private MimeMessage message;

        /** P: a header of the message the helper wraps. */
        @PostMapping("/header")
        public void springHeader(@RequestParam("origin") String origin) throws MessagingException {
            new MimeMessageHelper(message).getMimeMessage().setHeader("X-Origin", origin);
        }

        /** P: a request body (JSON text) in a header: it decodes line breaks. */
        @PostMapping("/body")
        public void body(@RequestBody String note) throws MessagingException {
            message.addHeader("X-Note", note);
        }

        /** L: the subject through the helper. */
        @PostMapping("/helper-subject")
        public void helperSubject(@RequestParam String subject) throws MessagingException {
            new MimeMessageHelper(message).setSubject(subject);
        }

        /** L: the recipient through the helper. */
        @PostMapping("/helper-to")
        public void helperTo(@RequestParam String to) throws MessagingException {
            MimeMessageHelper helper = new MimeMessageHelper(message);
            helper.setTo(to);
            helper.setFrom("noreply@example.com");
        }

        /** L: the reply-to address. */
        @PostMapping("/helper-reply")
        public void helperReplyTo(@RequestParam String reply) throws MessagingException {
            new MimeMessageHelper(message).setReplyTo(reply);
        }

        /** L: SimpleMailMessage. */
        @PostMapping("/simple")
        public void simple(@RequestParam String subject, @RequestParam String to) {
            SimpleMailMessage mail = new SimpleMailMessage();
            mail.setSubject(subject);
            mail.setTo(to);
        }

        /** N: the text of a SimpleMailMessage is the body. */
        @PostMapping("/simple-text")
        public void simpleText(@RequestParam String text) {
            new SimpleMailMessage().setText(text);
        }

        /** N: a number. */
        @PostMapping("/number")
        public void number(@RequestParam long id) throws MessagingException {
            message.setHeader("X-Id", String.valueOf(id));
        }
    }

    /** Commons Email: 1.5 replaces the line breaks of the subject. */
    public static class CommonsEmail {
        /** L: the subject. */
        public void commonsSubject(@RequestParam String subject) throws EmailException {
            Email email = new SimpleEmail();
            email.setSubject(subject);
        }

        /** L: the bounce address. */
        public void bounce(@RequestParam String bounce) throws EmailException {
            new SimpleEmail().setBounceAddress(bounce);
        }

        /** N: addHeader of Commons Email is not covered (the documentation of its folding is not enough to tell). */
        public void commonsHeader(@RequestParam String value) throws EmailException {
            new SimpleEmail().addHeader("X-Origin", value);
        }
    }

    /** A Struts 2 action: text properties are filled from the request, the injected service is not. */
    public static class MailAction extends ActionSupport {
        private Mailer mailer;
        private MimeMessage message;
        private String origin;

        public void setMailer(Mailer mailer) {
            this.mailer = mailer;
        }

        public void setOrigin(String origin) {
            this.origin = origin;
        }

        /** P: the property is request data. */
        public String byProperty() throws MessagingException {
            message.setHeader("X-Origin", origin);
            return SUCCESS;
        }

        /** N: the service decides. */
        public String byService() throws MessagingException {
            message.setHeader("X-Signature", mailer.signature());
            return SUCCESS;
        }
    }

    /** A JSF bean. */
    @ManagedBean
    public static class MailBean {
        @ManagedProperty("#{param.origin}")
        private String origin;
        @ManagedProperty("#{mailer}")
        private Mailer mailer;
        private MimeMessage message;

        public void setOrigin(String origin) {
            this.origin = origin;
        }

        public void setMailer(Mailer mailer) {
            this.mailer = mailer;
        }

        /** P: the request parameter of @ManagedProperty. */
        public void send() throws MessagingException {
            message.setHeader("X-Origin", origin);
        }

        /** N: the injected bean. */
        public void sendSigned() throws MessagingException {
            message.setHeader("X-Signature", mailer.signature());
        }
    }
}
