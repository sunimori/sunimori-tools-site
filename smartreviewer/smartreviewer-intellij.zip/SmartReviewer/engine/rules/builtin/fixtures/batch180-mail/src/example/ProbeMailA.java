package example;

import java.util.Optional;
import java.util.stream.Stream;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Forms written while hunting for defects of SR-SEC-MAIL-HEADER-INJECTION-001 (cleaning idioms, lambdas, Spring and subject or address calls (each in the suite with and without legacyLibraries)). The expected result of each method is a case of its suite.
 */
public class ProbeMailA {
    MimeMessage message;
    jakarta.mail.internet.MimeMessage jakartaMessage;

    void m01(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("a");
        String copy = v;
        message.setHeader("X-A", "v=" + copy);
    }

    void m02(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-A", rq.getParameter("a").replaceAll("[\\r\\n]+", " "));
    }

    void m03(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-A", rq.getParameter("a").replace('\r', ' ').replace('\n', ' '));
    }

    void m04(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-A", rq.getParameter("a").replace("\r", ""));
    }

    void m06(HttpServletRequest rq) throws MessagingException {
        message.setSubject(rq.getParameter("s"));
    }

    void m07(HttpServletRequest rq) throws MessagingException {
        message.setSubject(rq.getParameter("s").replaceAll("\\R", " "));
    }

    void m09(HttpServletRequest rq) throws MessagingException {
        message.addHeader(rq.getParameter("h"), rq.getParameter("v"));
    }

    void m11(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-A", rq.getParameterMap().get("x")[0]);
    }

    void m12(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-A", Optional.ofNullable(rq.getParameter("p")).orElse("x"));
    }

    void m13(HttpServletRequest rq) throws MessagingException {
        message.setRecipients(Message.RecipientType.TO, String.join(",", rq.getParameterValues("to")));
    }

    void m14(HttpServletRequest rq) {
        Stream.of(rq.getParameterValues("h")).forEach(h -> {
            try {
                message.addHeader("X-List", h);
            } catch (MessagingException e) {
                throw new IllegalStateException(e);
            }
        });
    }

    void m15(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        message.setHeader("X-A", v != null ? v : "none");
    }

    void m16(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-A", (String) rq.getAttribute("trusted"));
    }

    void m17(HttpServletRequest rq) throws MessagingException {
        String v = switch (rq.getParameter("p")) {
            case "a" -> "Alpha";
            case "b" -> "Beta";
            default -> "Other";
        };
        message.setHeader("X-A", v);
    }

    void m18(HttpServletRequest rq) throws MessagingException {
        InternetAddress[] a = InternetAddress.parse(rq.getParameter("to"));
        message.setRecipients(Message.RecipientType.TO, a);
    }

    void m19(HttpServletRequest rq) {
        try {
            message.setHeader("X-A", rq.getParameter("a"));
        } catch (MessagingException e) {
            // ignored
        }
    }

    void m20(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-A", StringUtils.replace(rq.getParameter("a"), "\n", ""));
    }

    void m20b(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-A", StringUtils.remove(StringUtils.remove(rq.getParameter("a"), "\r"), "\n"));
    }

    void m21(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-A", rq.getParameter("a").split("\\R")[0]);
    }

    void m23(HttpServletRequest rq) throws Exception {
        jakartaMessage.setHeader("X-A", rq.getParameter("a"));
    }

    void m24(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-Id", Long.toString(Long.parseLong(rq.getParameter("id"))));
    }

    @Controller
    public static class C {
        MimeMessage message;

        @PostMapping("/a")
        void s01(@RequestParam String origin) throws MessagingException {
            new MimeMessageHelper(message).getMimeMessage().setHeader("X", origin);
        }

        @PostMapping("/b")
        void s02(@RequestParam String subject) throws MessagingException {
            new MimeMessageHelper(message).setSubject(subject.trim());
        }

        @PostMapping("/c")
        void s03(@RequestParam long id) {
            new SimpleMailMessage().setSubject("Order " + id);
        }

        @PostMapping("/d")
        void s04(@RequestParam String to) {
            SimpleMailMessage m = new SimpleMailMessage();
            m.setTo(new String[] {to});
        }
    }
}
