package javax.mail.internet;

import javax.mail.MessagingException;
import javax.mail.Part;

/** Stub (fixture only). */
public interface MimePart extends Part {
    void addHeaderLine(String line) throws MessagingException;
}
