package jakarta.mail;

/** Stub (fixture only). */
public abstract class Message implements Part {
    /** Stub (fixture only). */
    public static class RecipientType {
        public static final RecipientType TO = new RecipientType();
        public static final RecipientType CC = new RecipientType();
        public static final RecipientType BCC = new RecipientType();
    }

    public abstract void setSubject(String subject) throws MessagingException;

    public abstract void setFrom(Address address) throws MessagingException;

    public abstract void setRecipients(RecipientType type, Address[] addresses) throws MessagingException;

    public void setRecipient(RecipientType type, Address address) throws MessagingException {
    }
}
