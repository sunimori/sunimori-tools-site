package org.apache.commons.mail;

/** Stub (fixture only). */
public class EmailException extends Exception {
}
