package jakarta.mail;

/** Stub (fixture only). */
public abstract class Address {
}
