package javax.mail;

/** Stub (fixture only). */
public abstract class Address {
}
