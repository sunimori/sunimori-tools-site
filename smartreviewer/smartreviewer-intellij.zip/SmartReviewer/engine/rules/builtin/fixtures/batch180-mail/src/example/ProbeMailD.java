package example;

import java.util.regex.Pattern;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;

/**
 * The forms an independent verifier found after the first round: values that are rejected when they hold a line break, cleaners that
 * were not recognised, and the one address call that was missing.
 */
public class ProbeMailD {
    static final Pattern LINE_BREAK = Pattern.compile("[\\r\\n]");
    static final Pattern ONLY_LF = Pattern.compile("\\n");
    MimeMessage message;

    // ------------------------------------------------------------------ values that are rejected when they hold a line break

    /** N: both are rejected. */
    void rejectBothContains(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (v.contains("\r") || v.contains("\n")) {
            throw new IllegalArgumentException("line break");
        }
        message.setHeader("X-V", v);
    }

    /** N: and with indexOf, leaving the method. */
    void rejectBothIndexOf(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (v.indexOf('\r') >= 0 || v.indexOf('\n') >= 0) {
            return;
        }
        message.setHeader("X-V", v);
    }

    /** N: the value is used where neither is in it. */
    void useWhereNeitherIsIn(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (!v.contains("\r") && !v.contains("\n")) {
            message.addHeader("X-V", v);
        }
    }

    /** N: skipped in a loop. */
    void rejectAndContinue(HttpServletRequest rq) throws MessagingException {
        for (String v : rq.getParameterValues("v")) {
            if (v.contains("\r") || v.contains("\n")) {
                continue;
            }
            message.addHeader("X-V", v);
        }
    }

    /** N: a regular expression that finds a line break wherever it is (the flag lets the dot match line terminators). */
    void rejectWithDotAllPattern(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (v.matches("(?s).*[\\r\\n].*")) {
            throw new IllegalArgumentException("line break");
        }
        message.setHeader("X-V", v);
    }

    /** N: a Pattern that finds one. */
    void rejectWithFind(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (LINE_BREAK.matcher(v).find()) {
            return;
        }
        message.setHeader("X-V", v);
    }

    /** N: the same inline, with \R. */
    void rejectWithLineBreakEscape(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (Pattern.compile("\\R").matcher(v).find()) {
            return;
        }
        message.setHeader("X-V", v);
    }

    /** N: a line break is cleaned when there is one, and there is none otherwise. */
    void cleanWhenThereIsOne(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (v.contains("\r") || v.contains("\n")) {
            v = v.replaceAll("[\\r\\n]", "");
        }
        message.setHeader("X-V", v);
    }

    /** P: only the carriage return is rejected. */
    void rejectCarriageReturnOnly(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (v.contains("\r")) {
            throw new IllegalArgumentException("line break");
        }
        message.setHeader("X-V", v);
    }

    /** P: only the line feed is rejected. */
    void rejectLineFeedOnly(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (v.indexOf('\n') >= 0) {
            return;
        }
        message.setHeader("X-V", v);
    }

    /** P: a pattern for the line feed. */
    void rejectOnlyWithFind(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (ONLY_LF.matcher(v).find()) {
            return;
        }
        message.setHeader("X-V", v);
    }

    /**
     * P: the regular expression looks right, but the dot does not match a line terminator: "x\r\nBcc: a@b.c" is not matched, so it is
     * not rejected.
     */
    void rejectWithPatternThatMissesCrLf(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (v.matches(".*[\\r\\n].*")) {
            throw new IllegalArgumentException("line break");
        }
        message.setHeader("X-V", v);
    }

    /** P: the line feed is looked for, the clean-up removes both, but only when the line feed is there. */
    void cleanOnlyWhenLineFeed(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (v.indexOf('\n') >= 0) {
            v = v.replaceAll("[\\r\\n]", "");
        }
        message.setHeader("X-V", v);
    }

    /** P: a check of another variable. */
    void rejectAnotherValue(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        String w = rq.getParameter("w");
        if (w.contains("\r") || w.contains("\n")) {
            return;
        }
        message.setHeader("X-V", v);
    }

    /** P: a second parameter is appended after the check. */
    void rejectThenAppend(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (v.contains("\r") || v.contains("\n")) {
            return;
        }
        v = v + rq.getParameter("w");
        message.setHeader("X-V", v);
    }

    /** P: the guard holds in the other branch. */
    void rejectedValueIsUsed(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (v.contains("\r") || v.contains("\n")) {
            message.setHeader("X-Bad", v);
        }
    }

    /**
     * V: a pattern that backtracks without end on some texts is an allow-list like any other (the value counts as checked); the
     * analysis must not stop at it.
     */
    void patternThatBacktracks(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        if (!v.matches("^(\\w+\\s?)*$")) {
            return;
        }
        message.setHeader("X-V", v);
    }

    // ------------------------------------------------------------------ cleaners

    /** N: replaceChars deletes both. */
    void replaceCharsDeletes(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-V", StringUtils.replaceChars(rq.getParameter("v"), "\r\n", ""));
    }

    /** N: replaceChars puts spaces in their place. */
    void replaceCharsWithSpaces(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-V", StringUtils.replaceChars(rq.getParameter("v"), "\r\n", "  "));
    }

    /** P: the carriage return becomes a line feed. */
    void replaceCharsBringsALineFeedBack(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-V", StringUtils.replaceChars(rq.getParameter("v"), "\r\n", "\n"));
    }

    /** P: only the carriage return is replaced. */
    void replaceCharsOneOfThem(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-V", StringUtils.replaceChars(rq.getParameter("v"), '\r', ' '));
    }

    /** N: Spring's trimAllWhitespace removes every white space character. */
    void trimAllWhitespace(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-V", org.springframework.util.StringUtils.trimAllWhitespace(rq.getParameter("v")));
    }

    /** N: Spring's deleteAny with the two in the other order. */
    void deleteAnyBoth(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-V", org.springframework.util.StringUtils.deleteAny(rq.getParameter("v"), "\n\r"));
    }

    /** N: one deleteAny for each. */
    void deleteAnyOneEach(HttpServletRequest rq) throws MessagingException {
        String v = org.springframework.util.StringUtils.deleteAny(rq.getParameter("v"), "\r");
        message.setHeader("X-V", org.springframework.util.StringUtils.deleteAny(v, "\n"));
    }

    /** P: deleteAny of the line feed alone. */
    void deleteAnyOne(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-V", org.springframework.util.StringUtils.deleteAny(rq.getParameter("v"), "\n"));
    }

    /** N: Spring's replace of each. */
    void springReplace(HttpServletRequest rq) throws MessagingException {
        String v = org.springframework.util.StringUtils.replace(rq.getParameter("v"), "\r", "");
        message.setHeader("X-V", org.springframework.util.StringUtils.replace(v, "\n", " "));
    }

    // ------------------------------------------------------------------ what is not request data

    /** M: getServletPath() is not request data for any of the taint rules (the shared source table): documented, not reported. */
    void servletPath(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-Path", rq.getServletPath());
    }

    /** M: and getPathTranslated(). */
    void pathTranslated(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-Path", rq.getPathTranslated());
    }

    /** P: getPathInfo() is decoded request text, it is. */
    void pathInfo(HttpServletRequest rq) throws MessagingException {
        message.setHeader("X-Path", rq.getPathInfo());
    }

    // ------------------------------------------------------------------ the address call that was missing

    /** L: MimeMessage.setFrom(String) parses the text like InternetAddress.parse (JavaMail 1.5). */
    void setFromText(HttpServletRequest rq) throws MessagingException {
        message.setFrom(rq.getParameter("from"));
    }

    /** N: the Address form carries an InternetAddress, which is the call that is reported. */
    void setFromAddress(HttpServletRequest rq) throws MessagingException {
        message.setFrom(new InternetAddress("noreply@example.com"));
    }
}
