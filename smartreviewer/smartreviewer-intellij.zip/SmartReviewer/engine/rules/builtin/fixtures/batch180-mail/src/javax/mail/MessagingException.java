package javax.mail;

/** Stub (fixture only). */
public class MessagingException extends Exception {
}
