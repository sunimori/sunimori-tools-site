package org.apache.commons.mail;

/** Stub (fixture only). */
public abstract class Email {
    public Email setSubject(String subject) {
        return this;
    }

    public Email addHeader(String name, String value) {
        return this;
    }

    public Email setBounceAddress(String email) {
        return this;
    }

    public Email addTo(String email) throws EmailException {
        return this;
    }

    public Email setMsg(String msg) throws EmailException {
        return this;
    }
}
