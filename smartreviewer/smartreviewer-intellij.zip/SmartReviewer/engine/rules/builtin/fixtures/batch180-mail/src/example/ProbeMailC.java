package example;

import java.util.Optional;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

/** More forms for SR-SEC-MAIL-HEADER-INJECTION-001: arrow switch bodies, lambdas, ternaries, locks. */
public class ProbeMailC {
    MimeMessage message;

    void a03(HttpServletRequest rq) throws MessagingException {
        String v = rq.getParameter("v");
        switch (rq.getParameter("m")) {
            case "x" -> message.setHeader("X", v);
            default -> { }
        }
    }

    void c01(HttpServletRequest rq) {
        Optional.ofNullable(rq.getParameter("v")).ifPresent(v -> {
            try {
                message.setHeader("X", v);
            } catch (MessagingException e) {
                throw new IllegalStateException(e);
            }
        });
    }

    void e03(HttpServletRequest rq, boolean flag) throws MessagingException {
        message.setHeader("X", flag ? rq.getParameter("a") : "none");
    }

    void g01(HttpServletRequest rq) throws MessagingException {
        synchronized (this) {
            message.addHeader("X-P", rq.getParameter("p"));
        }
    }
}
