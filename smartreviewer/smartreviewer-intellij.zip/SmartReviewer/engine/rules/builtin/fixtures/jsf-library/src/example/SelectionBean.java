package example;

import java.util.LinkedHashSet;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

/** Its superclass is a library class read from class files (the JDK here: rule packages contain no jars). */
@Named("selection")
@SessionScoped
public class SelectionBean extends LinkedHashSet<String> {
    private static final long serialVersionUID = 1L;

    public String getLabel() {
        return size() + " selected";
    }
}
