package example;

import com.vendor.web.LegacyPage;
import javax.inject.Named;

/** Its library superclass extends a class that is not on the class path: members stay unknown. */
@Named("legacyPage")
public class LegacyPageBean extends LegacyPage {
}
