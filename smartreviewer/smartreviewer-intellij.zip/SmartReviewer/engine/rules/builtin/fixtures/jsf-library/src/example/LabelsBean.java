package example;

import java.util.HashMap;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

/** A map: EL resolves #{labels.anyKey} as a map lookup, so its members are not checked. */
@Named("labels")
@ApplicationScoped
public class LabelsBean extends HashMap<String, String> {
    private static final long serialVersionUID = 1L;
}
