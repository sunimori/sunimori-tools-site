package example;

import com.vendor.web.*;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/** Its superclass comes from a library jar (web/WEB-INF/lib/vendor-web.jar) through an on-demand import. */
@Named("account")
@RequestScoped
public class AccountBean extends BasePage {
    private static final long serialVersionUID = 1L;

    public String getOwner() {
        return "owner";
    }
}
