package example;

import java.util.List;

/** Generic base of backing beans: subclasses fix T (ShopBean extends CrudBean&lt;Order&gt;). */
public abstract class CrudBean<T> {
    private T selected;
    private List<T> recentItems;

    public T getSelected() {
        return selected;
    }

    public void setSelected(T selected) {
        this.selected = selected;
    }

    public List<T> getRecentItems() {
        return recentItems;
    }
}
