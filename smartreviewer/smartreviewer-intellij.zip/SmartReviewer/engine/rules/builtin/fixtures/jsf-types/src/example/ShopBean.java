package example;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

/** The pages reach every type below through this bean's getters. */
@Named("shop")
@RequestScoped
public class ShopBean extends CrudBean<Order> {
    public Customer getCustomer() {
        return null;
    }

    public List<Customer> getCustomers() {
        return List.of();
    }

    public Map<String, Customer> getCustomersByCode() {
        return Map.of();
    }

    public Optional<Customer> getOptionalCustomer() {
        return Optional.empty();
    }

    public Order[] getOrders() {
        return new Order[0];
    }

    public int[] getCounts() {
        return new int[0];
    }

    public List<Line> getLines() {
        return List.of();
    }

    public Line getFeaturedLine() {
        return null;
    }

    public Status getStatus() {
        return Status.OPEN;
    }

    public Priority getPriority() {
        return Priority.LOW;
    }

    public Payment getPayment() {
        return null;
    }

    public Document getDocument() {
        return null;
    }

    public BigDecimal getTotal() {
        return BigDecimal.ZERO;
    }

    public String getTitle() {
        return "shop";
    }

    public String save() {
        return "saved";
    }
}
