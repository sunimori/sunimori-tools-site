package example;

/** An enum without constant bodies: its members are checked (name() is a method, not a property). */
public enum Status {
    OPEN, CLOSED;

    public String getLabel() {
        return name().toLowerCase();
    }
}
