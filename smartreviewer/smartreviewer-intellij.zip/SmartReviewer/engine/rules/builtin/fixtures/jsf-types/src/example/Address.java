package example;

/** A record: its components are properties (EL 6) and accessor methods. */
public record Address(String street, String city) {
    public String getLabel() {
        return street + ", " + city;
    }
}
