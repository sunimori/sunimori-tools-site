package example;

import java.util.List;

/** A final class: every Order value is exactly an Order, so its members are checked. */
public final class Order {
    public String getNumber() {
        return "1";
    }

    public Customer getCustomer() {
        return null;
    }

    public List<Line> getLines() {
        return List.of();
    }

    public String cancel() {
        return "cancelled";
    }
}
