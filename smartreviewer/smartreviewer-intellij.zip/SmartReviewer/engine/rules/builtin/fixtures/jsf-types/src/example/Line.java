package example;

/** Extended by DiscountLine: members Line lacks may exist at run time, so they are only noted. */
public class Line {
    public String getProduct() {
        return "product";
    }

    public int getQuantity() {
        return 1;
    }
}
