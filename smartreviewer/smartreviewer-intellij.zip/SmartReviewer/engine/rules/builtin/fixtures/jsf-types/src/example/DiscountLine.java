package example;

import java.math.BigDecimal;

/** A subclass: makes Line a type whose values may have more members. */
public class DiscountLine extends Line {
    public BigDecimal getDiscount() {
        return BigDecimal.ONE;
    }
}
