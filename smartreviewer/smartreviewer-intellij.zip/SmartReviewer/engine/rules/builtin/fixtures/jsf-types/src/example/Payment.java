package example;

/** An interface: the run-time class may have more members, so missing ones are only noted. */
public interface Payment {
    String getMethod();
}
