package example;

/** An abstract class: missing members are only noted. */
public abstract class Document {
    public abstract String getTitle();
}
