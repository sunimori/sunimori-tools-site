package example;

/** Not final, but nothing in the project extends it: its members are checked. */
public class Customer {
    public String getName() {
        return "name";
    }

    public boolean isActive() {
        return true;
    }

    public Address getAddress() {
        return null;
    }

    public java.time.LocalDate getSince() {
        return null;
    }
}
