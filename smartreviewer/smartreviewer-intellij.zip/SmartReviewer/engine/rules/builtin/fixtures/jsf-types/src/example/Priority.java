package example;

/** Constants with class bodies are subclasses of the enum: members the enum lacks are only noted. */
public enum Priority {
    LOW,
    HIGH {
        @Override
        public boolean isUrgent() {
            return true;
        }
    };

    public boolean isUrgent() {
        return false;
    }
}
