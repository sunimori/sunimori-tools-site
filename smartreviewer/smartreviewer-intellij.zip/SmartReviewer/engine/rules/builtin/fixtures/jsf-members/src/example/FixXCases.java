package example;

import java.util.List;

/** A cart whose members are used the right and the wrong way in the pages fx-el-*.xhtml (fixture). */
@javax.inject.Named("fxCart")
public final class FixXCases {
    public boolean isFull() {
        return false;
    }

    public String getOwner() {
        return "";
    }

    public String checkout() {
        return "done";
    }

    public static String label(String text) {
        return text;
    }

    public List<String> getLines() {
        return null;
    }

    public String getName() {
        return "";
    }
}
