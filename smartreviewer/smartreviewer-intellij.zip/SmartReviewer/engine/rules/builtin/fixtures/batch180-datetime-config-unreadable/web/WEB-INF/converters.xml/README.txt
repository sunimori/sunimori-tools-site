A folder named like a configuration file: it is no regular file, so the rule cannot tell what it declares.
