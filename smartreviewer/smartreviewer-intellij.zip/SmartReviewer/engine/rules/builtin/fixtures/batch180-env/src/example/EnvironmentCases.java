package example;

import java.io.File;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.regex.Pattern;

/** Strings that write the environment into the program (SR-JAVA-HARDCODED-ENV-001). */
public class EnvironmentCases {
    static final String REPORT_DIRECTORY = "D:/work/reports";
    static final String LOG_DIRECTORY = "/var/log/" + "app";

    // ----- hard-coded locations and addresses

    File windowsDrive() {
        return new File("C:\\data\\import.csv");
    }

    File windowsDriveWithASpace() {
        return new File("C:\\Program Files\\Vendor\\tool.exe");
    }

    String uncShare() {
        return "\\\\fileserver\\share\\incoming";
    }

    String windowsPathAndAName(String name) {
        return "C:\\logs\\" + name + ".log";
    }

    String optDirectory() {
        return "/opt/app/conf";
    }

    String etcFile() {
        return "/etc/app/app.conf";
    }

    String homeDirectory() {
        return "/home/batch/work";
    }

    String dataDirectory() {
        return "/data/app/files";
    }

    String fileUrl() {
        return "file:///srv/www/app/index.xml";
    }

    String privateAddress() {
        return "192.168.1.10";
    }

    String databaseHost() {
        return "jdbc:oracle:thin:@10.1.2.3:1521:orcl";
    }

    InetAddress publicAddressAsAHost() throws UnknownHostException {
        return InetAddress.getByName("203.0.114.7");
    }

    String serverAddress() {
        String proxyHost = "198.18.0.5";
        return proxyHost;
    }

    File etcDirectoryAndAName(String name) {
        return new File("/etc/" + name);
    }

    /** The value is shown on one line, without the line end of the text block. */
    String textBlockPath() {
        return """
                /opt/app/conf
                """;
    }

    /** One value, one finding, however many paths it holds. */
    String classPathList() {
        return "C:\\lib\\a.jar;C:\\lib\\b.jar";
    }

    // ----- not an environment

    String webInfPath() {
        return "/WEB-INF/views/list.xhtml";
    }

    String pageInTheApplication() {
        return "/home/index.xhtml";
    }

    String actionPath() {
        return "/data/list.do";
    }

    String urlOfTheApplication() {
        String listUrl = "/data/list";
        return listUrl;
    }

    InputStream classPathResource() {
        return EnvironmentCases.class.getResourceAsStream("/data/sample.csv");
    }

    String temporaryDirectory() {
        return "/tmp/work";
    }

    String loopbackAddress() {
        return "127.0.0.1";
    }

    String localhostUrl() {
        return "http://localhost:8080/app";
    }

    String unspecifiedAddress() {
        return "0.0.0.0";
    }

    String netmask() {
        return "255.255.255.0";
    }

    String networkWithAPrefix() {
        return "10.0.0.0/8";
    }

    String addressForDocumentation() {
        return "http://203.0.113.5/example";
    }

    String objectIdentifier() {
        return "2.5.4.3";
    }

    String versionNumber() {
        String driverVersion = "10.2.0.4";
        return driverVersion;
    }

    Pattern drivePattern() {
        return Pattern.compile("C:\\\\.*");
    }

    String formatOfAPath(String name) {
        return String.format("/opt/%s/app.conf", name);
    }

    boolean comparedWithAPath(String path) {
        return path.startsWith("/etc/passwd");
    }

    String continuationOfAnAddress(String base) {
        return base + "/data/list";
    }

    String sentenceThatMentionsAPath() {
        return "the files are under /opt/app on the server";
    }

    // ----- text that is compared, a key, a path inside the application

    boolean yodaComparison(String path) {
        return "/opt/app".equals(path) || "192.168.1.10".equals(path) || !"C:\\data\\x".equalsIgnoreCase(path);
    }

    int switchOnAPath(String path) {
        return switch (path) {
            case "/var/log/a" -> 1;
            case "/etc/app/b" -> 2;
            default -> 0;
        };
    }

    Object keyOfAMap(Map<String, Object> cache) {
        return cache.get("/data/export/x");
    }

    void routeOfAMap(Map<String, String> routes) {
        routes.put("/data/list", "ListAction");
    }

    Object resourceOfTheClassPath() {
        return new ClassPathResource("/data/ctx.xml");
    }

    /** Spring's class for a path inside the class path (a stand-in with the same name). */
    static class ClassPathResource {
        ClassPathResource(String path) {
        }
    }

    String versionWithAPrefix() {
        String text = "v10.1.2.3";
        return text;
    }

    String versionWithASuffix() {
        String text = "10.1.2.3-SNAPSHOT";
        return text;
    }

    String hostNameThatStartsWithNumbers() {
        String text = "10.1.2.3.example.com";
        return text;
    }

    String homeAndAUser(String user) {
        return "/home/" + user + "/.ssh";
    }

    String bareDirectory() {
        return "/var";
    }

    File driveRoot() {
        return new File("E:\\");
    }
}
