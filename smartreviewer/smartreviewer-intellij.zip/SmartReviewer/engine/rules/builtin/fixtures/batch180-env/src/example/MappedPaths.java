package example;

/** Annotations: only a Windows path in one is an environment; a mapping is a URL. */
public class MappedPaths {
    @interface Mapping {
        String value();
    }

    @interface Setting {
        String value();
    }

    @Mapping("/data/list")
    String list() {
        return "list";
    }

    @Setting("C:\\conf\\app.properties")
    String configFile = "";
}
