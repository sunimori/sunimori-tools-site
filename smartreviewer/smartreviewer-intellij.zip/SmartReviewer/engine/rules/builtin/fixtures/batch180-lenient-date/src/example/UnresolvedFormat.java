package example;

import com.example.missing.DateChecker;

import java.text.ParseException;

/** The type of the format is not on the class path. */
public class UnresolvedFormat {
    boolean isDate(DateChecker checker, String text) {
        try {
            checker.parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    Object convert(DateChecker checker, String text) {
        try {
            return checker.parse(text);
        } catch (ParseException e) {
            return null;
        }
    }
}
