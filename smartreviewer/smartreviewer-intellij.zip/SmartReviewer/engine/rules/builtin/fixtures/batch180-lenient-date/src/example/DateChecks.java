package example;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/** Date strings checked with a lenient or a strict format (SR-JAVA-LENIENT-DATE-001). */
public class DateChecks {
    private static final SimpleDateFormat SHARED_FORMAT = new SimpleDateFormat("yyyy/MM/dd");
    private static final SimpleDateFormat STRICT_FORMAT = new SimpleDateFormat("yyyy/MM/dd");
    private static final ThreadLocal<SimpleDateFormat> THREAD_FORMAT = ThreadLocal.withInitial(() -> new SimpleDateFormat("yyyyMMdd"));
    private final SimpleDateFormat configured = new SimpleDateFormat("yyyyMMdd");

    static {
        STRICT_FORMAT.setLenient(false);
    }

    DateChecks() {
        configured.getCalendar().setLenient(false);
    }

    // ----- a lenient format whose parse is the only check

    boolean isDate(String text) {
        try {
            new SimpleDateFormat("yyyyMMdd").parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    boolean isDateWithALocalFormat(String text) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        try {
            format.parse(text);
        } catch (ParseException e) {
            return false;
        }
        return true;
    }

    boolean isDateWithTheSharedFormat(String text) {
        try {
            SHARED_FORMAT.parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    void requireDate(String text) {
        try {
            new SimpleDateFormat("yyyy-MM-dd").parse(text);
        } catch (ParseException e) {
            throw new IllegalArgumentException("not a date: " + text);
        }
    }

    boolean isTime(String text) {
        boolean valid = true;
        try {
            new SimpleDateFormat("HH:mm").parse(text);
        } catch (ParseException e) {
            valid = false;
        }
        return valid;
    }

    void collectError(String text, List<String> errors) {
        try {
            new SimpleDateFormat("yyyy/MM/dd").parse(text);
        } catch (ParseException e) {
            errors.add("invalid date: " + text);
        }
    }

    String messageFor(String text) {
        try {
            new SimpleDateFormat("yyyy/MM/dd").parse(text);
            return null;
        } catch (ParseException e) {
            return "invalid date";
        }
    }

    boolean parsedIsNotNull(String text) {
        try {
            return new SimpleDateFormat("yyyyMMdd").parse(text) != null;
        } catch (ParseException e) {
            return false;
        }
    }

    boolean systemFormat(String text) {
        try {
            DateFormat.getDateInstance().parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    // ----- strict, converting, or not known to be lenient

    boolean strictLocalFormat(String text) {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        format.setLenient(false);
        try {
            format.parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    boolean strictThroughTheCalendar(String text) {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        format.getCalendar().setLenient(false);
        try {
            format.parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    boolean strictSharedFormat(String text) {
        try {
            STRICT_FORMAT.parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    boolean formatConfiguredInTheConstructor(String text) {
        try {
            configured.parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    /** Written back and compared: the lenient parse is caught by the comparison. */
    boolean roundTrip(String text) {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        try {
            return format.format(format.parse(text)).equals(text);
        } catch (ParseException e) {
            return false;
        }
    }

    /** A conversion: the date is used. */
    Date toDate(String text) {
        try {
            return new SimpleDateFormat("yyyyMMdd").parse(text);
        } catch (ParseException e) {
            return null;
        }
    }

    boolean usesTheDate(String text) {
        try {
            Date date = new SimpleDateFormat("yyyyMMdd").parse(text);
            return date.before(new Date());
        } catch (ParseException e) {
            return false;
        }
    }

    boolean handlerOnlyLogs(String text) {
        try {
            new SimpleDateFormat("yyyyMMdd").parse(text);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return true;
    }

    boolean formatFromTheCaller(DateFormat format, String text) {
        try {
            format.parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    boolean formatFromAThreadLocal(String text) {
        try {
            THREAD_FORMAT.get().parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    /** Only a year: a lenient format lets year 0 through and nothing else. */
    boolean onlyAYear(String text) {
        try {
            new SimpleDateFormat("yyyy").parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    boolean explicitlyLenient(String text) {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        format.setLenient(true);
        try {
            format.parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    boolean numbersAreNoDates(String text) {
        try {
            NumberFormat.getInstance().parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    /** The name of a month cannot be out of range: there is nothing that leniency could let through. */
    boolean monthNameOnly(String text) {
        try {
            new SimpleDateFormat("MMM", java.util.Locale.ENGLISH).parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    boolean dayNameOnly(String text) {
        try {
            new SimpleDateFormat("EEE", java.util.Locale.ENGLISH).parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    /** A name and a number: the number can be out of range. */
    boolean monthNameAndDay(String text) {
        try {
            new SimpleDateFormat("MMM dd, yyyy", java.util.Locale.ENGLISH).parse(text);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
}
