package example.session;

public interface Unmapped {
    int save(Object o);
}
