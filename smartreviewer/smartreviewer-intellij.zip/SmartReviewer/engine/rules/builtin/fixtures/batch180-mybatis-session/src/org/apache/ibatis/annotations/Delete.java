package org.apache.ibatis.annotations; public @interface Delete { String[] value(); }
