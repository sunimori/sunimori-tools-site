package example.session;

import java.sql.Connection;
import java.util.List;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.TransactionIsolationLevel;

public class MapperCalls {
    private final SqlSessionFactory factory;

    public MapperCalls(SqlSessionFactory factory) {
        this.factory = factory;
    }

    /** The method has @Insert. */
    public void annotatedWrite(Object order) {
        try (SqlSession session = factory.openSession()) {
            OrderMapper mapper = session.getMapper(OrderMapper.class);
            mapper.annotatedInsert(order);
        }
    }

    /** The statement is an insert in the project's mapper XML. */
    public void xmlWrite(Object order) {
        try (SqlSession session = factory.openSession()) {
            OrderMapper mapper = session.getMapper(OrderMapper.class);
            mapper.addOrder(order);
        }
    }

    public void xmlUpdate(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.getMapper(OrderMapper.class).changeOrder(order);
        }
    }

    public void xmlDeleteBeforeRead(Long id) {
        try (SqlSession session = factory.openSession()) {
            OrderMapper mapper = session.getMapper(OrderMapper.class);
            mapper.findOrder(id);
            mapper.removeOrder(id);
        }
    }

    /** Reads only: the XML statements are selects, the annotation is @Select. */
    public void reads(Long id) {
        try (SqlSession session = factory.openSession()) {
            OrderMapper mapper = session.getMapper(OrderMapper.class);
            mapper.findOrder(id);
            mapper.listOrders();
            mapper.annotatedSelect(id);
        }
    }

    public void committedMapperWrite(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.getMapper(OrderMapper.class).addOrder(order);
            session.commit();
        }
    }

    /** The first write is committed; the insert of the XML statement after the commit is not. */
    public void commitThenXmlWrite(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.insert("example.session.OrderMapper.addOrder", order);
            session.commit();
            session.getMapper(OrderMapper.class).addOrder(order);
        }
    }

    /** Every write through the mapper is named, the finding is at the last one. */
    public void twoXmlWrites(Object order, Long id) {
        try (SqlSession session = factory.openSession()) {
            OrderMapper mapper = session.getMapper(OrderMapper.class);
            mapper.addOrder(order);
            mapper.findOrder(id);
            mapper.removeOrder(id);
        }
    }

    /** Sessions of one name are judged each on its own. */
    public void sameNameThreeTimes(Object order, Long id) {
        try (SqlSession session = factory.openSession()) {
            session.getMapper(OrderMapper.class).addOrder(order);
        }
        try (SqlSession session = factory.openSession()) {
            session.getMapper(OrderMapper.class).findOrder(id);
        }
        try (SqlSession session = factory.openSession()) {
            session.getMapper(OrderMapper.class).changeOrder(order);
        }
    }

    /** No statement of that name shows in the project's files: the kind is not known. */
    public void unknownStatement() {
        try (SqlSession session = factory.openSession()) {
            session.getMapper(OrderMapper.class).mystery();
        }
    }

    /** The mapper belongs to no mapper XML of the project. */
    public void mapperWithoutXml(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.getMapper(Unmapped.class).save(order);
        }
    }

    /** The mapper is handed on; writes through it are not seen here. */
    public void mapperHandedOn() {
        try (SqlSession session = factory.openSession()) {
            OrderMapper mapper = session.getMapper(OrderMapper.class);
            consume(mapper);
        }
    }

    private void consume(OrderMapper mapper) {
    }
}
