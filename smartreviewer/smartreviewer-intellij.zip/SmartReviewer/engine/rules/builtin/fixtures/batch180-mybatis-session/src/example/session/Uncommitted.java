package example.session;

import java.sql.Connection;
import java.util.List;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.TransactionIsolationLevel;

public class Uncommitted {
    private final SqlSessionFactory factory;

    public Uncommitted(SqlSessionFactory factory) {
        this.factory = factory;
    }

    /** The changes are rolled back by close(). */
    public void insertWithoutCommit(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.insert("example.session.OrderMapper.addOrder", order);
        }
    }

    /** The classic shape: declared before the try, opened inside it, closed in the finally block. */
    public void updateInFinally(Object order) {
        SqlSession session = null;
        try {
            session = factory.openSession();
            session.update("example.session.OrderMapper.changeOrder", order);
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }

    /** The commit comes before the second write. */
    public void deleteAfterCommit(Object order, Long id) {
        try (SqlSession session = factory.openSession()) {
            session.insert("example.session.OrderMapper.addOrder", order);
            session.commit();
            session.delete("example.session.OrderMapper.removeOrder", id);
        }
    }

    /** A rollback in the error handler does not commit the successful path. */
    public void rollbackOnlyOnFailure(Object order) {
        SqlSession session = factory.openSession();
        try {
            session.insert("example.session.OrderMapper.addOrder", order);
        } catch (RuntimeException e) {
            session.rollback();
            throw e;
        } finally {
            session.close();
        }
    }

    /** The batch is sent by flushStatements() and still rolled back: the write is the insert, not the flush. */
    public void batchWithoutCommit(Object order) {
        try (SqlSession session = factory.openSession(ExecutorType.BATCH)) {
            OrderMapper mapper = session.getMapper(OrderMapper.class);
            mapper.annotatedInsert(order);
            session.flushStatements();
        }
    }

    /** The count of changed rows is used, the commit is missing. */
    public int updateCount(Object order) {
        try (SqlSession session = factory.openSession(false)) {
            int rows = session.update("example.session.OrderMapper.changeOrder", order);
            return rows;
        }
    }

    public void otherOpenOverloads(Object order) {
        try (SqlSession a = factory.openSession(ExecutorType.REUSE)) {
            a.insert("example.session.OrderMapper.addOrder", order);
        }
        try (SqlSession b = factory.openSession(TransactionIsolationLevel.READ_COMMITTED)) {
            b.insert("example.session.OrderMapper.addOrder", order);
        }
        try (SqlSession c = factory.openSession(ExecutorType.SIMPLE, TransactionIsolationLevel.SERIALIZABLE)) {
            c.delete("example.session.OrderMapper.removeOrder");
        }
        try (SqlSession d = factory.openSession(ExecutorType.BATCH, false)) {
            d.update("example.session.OrderMapper.changeOrder", order);
        }
    }

    /** The session is not even closed. */
    public void neverClosed(Object order) {
        SqlSession session = factory.openSession();
        session.insert("example.session.OrderMapper.addOrder", order);
    }

    /** The factory comes from a call. */
    public void factoryFromACall(Object order) {
        try (SqlSession session = current().openSession()) {
            session.insert("example.session.OrderMapper.addOrder", order);
        }
    }

    private SqlSessionFactory current() {
        return factory;
    }

    /** The commit is before the write in the loop: the last write has no commit. */
    public void commitBeforeWriteInLoop(List<Object> orders) {
        try (SqlSession session = factory.openSession()) {
            for (Object order : orders) {
                session.commit();
                session.insert("example.session.OrderMapper.addOrder", order);
            }
        }
    }

    /** One session commits, the other does not. */
    public void twoSessions(Object order) {
        try (SqlSession first = factory.openSession(); SqlSession second = factory.openSession()) {
            first.insert("example.session.OrderMapper.addOrder", order);
            first.commit();
            second.insert("example.session.OrderMapper.addOrder", order);
        }
    }

    /** An arrow case of a switch statement is a yield statement for the compiler's tree. */
    public void arrowCaseWrite(int kind, Object order) {
        try (SqlSession session = factory.openSession()) {
            switch (kind) {
                case 1 -> session.insert("example.session.OrderMapper.addOrder", order);
                default -> session.selectOne("example.session.OrderMapper.findOrder", order);
            }
        }
    }

    /** Written in a lambda that runs inside the method, not a hand-over: the lambda has its own session. */
    public Runnable sessionInsideLambda(Object order) {
        return () -> {
            try (SqlSession session = factory.openSession()) {
                session.insert("example.session.OrderMapper.addOrder", order);
            }
        };
    }
}
