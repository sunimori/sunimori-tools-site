package org.apache.ibatis.annotations; public @interface Flush { }
