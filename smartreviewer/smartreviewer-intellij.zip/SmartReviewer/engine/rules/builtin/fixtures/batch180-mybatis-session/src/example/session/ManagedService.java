package example.session;

import java.sql.Connection;
import java.util.List;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.TransactionIsolationLevel;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class ManagedService {
    private final SqlSessionFactory factory;

    public ManagedService(SqlSessionFactory factory) {
        this.factory = factory;
    }

    public void insertInATransactionalClass(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.insert("example.session.OrderMapper.addOrder", order);
        }
    }
}
