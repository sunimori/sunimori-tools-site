package example.session;

import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Flush;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.executor.BatchResult;

public interface OrderMapper {
    /** A write by its annotation. */
    @Insert("INSERT INTO orders (code) VALUES (#{code})")
    int annotatedInsert(Object order);

    @Update("UPDATE orders SET done = 1")
    int annotatedUpdate();

    @Delete("DELETE FROM orders")
    int annotatedDelete();

    @Flush
    List<BatchResult> flushBatch();

    /** A read by its annotation. */
    @Select("SELECT * FROM orders WHERE id = #{id}")
    Object annotatedSelect(Long id);

    /** Statements of the XML. */
    int addOrder(Object order);

    int changeOrder(Object order);

    int removeOrder(Long id);

    Object findOrder(Long id);

    List<Object> listOrders();

    /** No statement anywhere that the project's files show. */
    int mystery();
}
