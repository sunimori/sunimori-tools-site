package example.session;

import java.sql.Connection;
import java.util.List;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.TransactionIsolationLevel;
import org.apache.ibatis.annotations.Select;
import org.springframework.transaction.annotation.Transactional;

public class Committed {
    private final SqlSessionFactory factory;
    private SqlSession kept;

    @org.springframework.beans.factory.annotation.Autowired
    private SqlSession injected;

    public Committed(SqlSessionFactory factory) {
        this.factory = factory;
    }

    public void committed(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.insert("example.session.OrderMapper.addOrder", order);
            session.commit();
        }
    }

    public void commitInFinally(Object order) {
        SqlSession session = factory.openSession();
        try {
            session.insert("example.session.OrderMapper.addOrder", order);
        } finally {
            session.commit();
            session.close();
        }
    }

    /** One commit after the loop covers every write. */
    public void commitAfterLoop(List<Object> orders) {
        try (SqlSession session = factory.openSession()) {
            for (Object order : orders) {
                session.insert("example.session.OrderMapper.addOrder", order);
            }
            session.commit();
        }
    }

    /** Committing on some paths is the author's decision. */
    public void conditionalCommit(Object order, boolean ok) {
        try (SqlSession session = factory.openSession()) {
            session.insert("example.session.OrderMapper.addOrder", order);
            if (ok) {
                session.commit();
            }
        }
    }

    public void forcedCommit(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.update("example.session.OrderMapper.changeOrder", order);
            session.commit(true);
        }
    }

    public void commitAfterABatch(Object order) {
        try (SqlSession session = factory.openSession(ExecutorType.BATCH)) {
            session.getMapper(OrderMapper.class).annotatedInsert(order);
            session.flushStatements();
            session.commit();
        }
    }

    /** A rollback on the normal path is a decision too (a dry run). */
    public void dryRun(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.insert("example.session.OrderMapper.addOrder", order);
            session.rollback();
        }
    }

    public void commitAndRollbackHandler(Object order) {
        SqlSession session = factory.openSession();
        try {
            session.insert("example.session.OrderMapper.addOrder", order);
            session.commit();
        } catch (RuntimeException e) {
            session.rollback();
            throw e;
        } finally {
            session.close();
        }
    }

    /** Auto-commit: every statement is committed as it runs. */
    public void autoCommit(Object order) {
        try (SqlSession session = factory.openSession(true)) {
            session.insert("example.session.OrderMapper.addOrder", order);
        }
        try (SqlSession batch = factory.openSession(ExecutorType.BATCH, true)) {
            batch.insert("example.session.OrderMapper.addOrder", order);
        }
    }

    /** The mode of the connection decides, which this code does not show. */
    public void withConnection(Connection connection, Object order) {
        try (SqlSession session = factory.openSession(connection)) {
            session.insert("example.session.OrderMapper.addOrder", order);
        }
        try (SqlSession session = factory.openSession(ExecutorType.SIMPLE, connection)) {
            session.insert("example.session.OrderMapper.addOrder", order);
        }
    }

    /** flushStatements() alone does not make the session dirty: a recording JDBC connection saw no rollback. */
    public void flushOnly() {
        try (SqlSession session = factory.openSession(ExecutorType.BATCH)) {
            session.flushStatements();
        }
    }

    public void readThenFlush(Long id) {
        try (SqlSession session = factory.openSession(ExecutorType.BATCH)) {
            session.selectList("example.session.OrderMapper.findOrder", id);
            session.flushStatements();
        }
    }

    /** A @Flush method only calls flushStatements(). */
    public void flushThroughTheMapper() {
        try (SqlSession session = factory.openSession(ExecutorType.BATCH)) {
            session.getMapper(OrderMapper.class).flushBatch();
        }
    }

    /** Nothing to commit. */
    public Object readOnly(Long id) {
        try (SqlSession session = factory.openSession()) {
            session.clearCache();
            List<Object> all = session.selectList("example.session.OrderMapper.listOrders");
            return all.isEmpty() ? session.selectOne("example.session.OrderMapper.findOrder", id) : all.get(0);
        }
    }

    public int committedByAHelper(Object order) {
        SqlSession session = factory.openSession();
        try {
            int rows = session.insert("example.session.OrderMapper.addOrder", order);
            finish(session);
            return rows;
        } finally {
            session.close();
        }
    }

    private void finish(SqlSession session) {
        session.commit();
    }

    public SqlSession returned(Object order) {
        SqlSession session = factory.openSession();
        session.insert("example.session.OrderMapper.addOrder", order);
        return session;
    }

    public void stored(Object order) {
        SqlSession session = factory.openSession();
        session.insert("example.session.OrderMapper.addOrder", order);
        this.kept = session;
    }

    public void committedInALambda(List<Object> orders) {
        try (SqlSession session = factory.openSession()) {
            orders.forEach(order -> session.insert("example.session.OrderMapper.addOrder", order));
            Runnable done = () -> session.commit();
            done.run();
        }
    }

    public void connectionHandled(Object order) throws Exception {
        try (SqlSession session = factory.openSession()) {
            session.insert("example.session.OrderMapper.addOrder", order);
            session.getConnection().commit();
        }
    }

    /** The session does not come from a plain open call. */
    public void sessionFromAHelper(Object order) {
        SqlSession session = obtain();
        session.insert("example.session.OrderMapper.addOrder", order);
    }

    public void mixedSources(Object order, boolean fresh) {
        SqlSession session = fresh ? factory.openSession() : obtain();
        session.insert("example.session.OrderMapper.addOrder", order);
    }

    public void parameter(SqlSession session, Object order) {
        session.insert("example.session.OrderMapper.addOrder", order);
    }

    public void template(org.mybatis.spring.SqlSessionTemplate template, Object order) {
        template.insert("example.session.OrderMapper.addOrder", order);
    }

    /** Spring's SqlSessionUtils hands out the session of the current transaction. */
    public void utils(Object order) {
        SqlSession session = org.mybatis.spring.SqlSessionUtils.getSqlSession(factory);
        session.insert("example.session.OrderMapper.addOrder", order);
    }

    /** An injected session is a proxy that Spring commits with the transaction. */
    public void injectedSession(Object order) {
        injected.insert("example.session.OrderMapper.addOrder", order);
    }

    private SqlSession obtain() {
        return factory.openSession();
    }

    /** A transaction that Spring commits. */
    @Transactional
    public void springManaged(Object order) {
        try (SqlSession session = factory.openSession()) {
            session.insert("example.session.OrderMapper.addOrder", order);
        }
    }
}
