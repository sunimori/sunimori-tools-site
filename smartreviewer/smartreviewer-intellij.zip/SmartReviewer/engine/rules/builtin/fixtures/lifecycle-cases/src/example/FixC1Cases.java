package example;

import jakarta.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/** Review of 2026-10-26 (C1): lock release, interrupt restoration, thread local cleanup and proxy self-invocation. */
public class FixC1Cases {
    private static final Logger LOG = Logger.getLogger("fix");
    private static final ThreadLocal<String> USER = new ThreadLocal<>();
    private static final ThreadLocal<String> LOCALE = new ThreadLocal<>();
    private static final ThreadLocal<String> TRACE = new ThreadLocal<>();
    private final Lock lock = new ReentrantLock();
    private final Lock other = new ReentrantLock();
    private final Lock[] stripes = new Lock[4];
    private final Map<String, Lock> perKey = new ConcurrentHashMap<>();
    private final BlockingQueue<String> queue = new LinkedBlockingQueue<>();
    private volatile boolean enabled = true;
    private boolean retrying;
    private boolean pendingFlag;
    private int attempts = 3;

    private void work() { }
    private void audit() { }
    private String describe() { return "x"; }
    private Lock lockFor(String key) { return perKey.computeIfAbsent(key, k -> new ReentrantLock()); }
    private Lock freshFor(String key) { return new ReentrantLock(); }

    // ---- LOCK-RELEASE: an acquisition that fails inside its own try/catch

    boolean lkTimedTryLockCatch() {
        boolean got;
        try {
            got = lock.tryLock(1, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        if (!got) return false;
        try {
            work();
            return true;
        } finally {
            lock.unlock();
        }
    }

    boolean lkTimedTryLockCatchNoFinally() {
        boolean got;
        try {
            got = lock.tryLock(1, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        if (!got) return false;
        work();
        lock.unlock();
        return true;
    }

    boolean lkTimedTryLockMoreInTry() {
        boolean got;
        try {
            got = lock.tryLock(1, TimeUnit.SECONDS);
            work();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
        if (!got) return false;
        try {
            work();
            return true;
        } finally {
            lock.unlock();
        }
    }

    void lkLockInterruptiblyCatch() {
        try {
            lock.lockInterruptibly();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
        }
        try {
            work();
        } finally {
            lock.unlock();
        }
    }

    void lkLockInterruptiblyCatchNoFinally() {
        try {
            lock.lockInterruptibly();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return;
        }
        work();
        lock.unlock();
    }

    // ---- LOCK-RELEASE: tryLock inside a longer test, and retried in a loop

    boolean lkTryLockAnd() {
        if (enabled && lock.tryLock()) {
            try {
                work();
                return true;
            } finally {
                lock.unlock();
            }
        }
        return false;
    }

    boolean lkTryLockAndFirst() {
        if (lock.tryLock() && enabled) {
            try {
                work();
                return true;
            } finally {
                lock.unlock();
            }
        }
        return false;
    }

    void lkTryLockOrNot() {
        if (!enabled || !lock.tryLock()) return;
        try {
            work();
        } finally {
            lock.unlock();
        }
    }

    void lkTryLockLoop() {
        while (!lock.tryLock()) {
            Thread.yield();
        }
        try {
            work();
        } finally {
            lock.unlock();
        }
    }

    void lkTryLockDoLoop() {
        do {
            Thread.yield();
        } while (!lock.tryLock());
        try {
            work();
        } finally {
            lock.unlock();
        }
    }

    void lkTryLockLoopBreak() {
        while (!lock.tryLock()) {
            if (enabled) break;
        }
        try {
            work();
        } finally {
            lock.unlock();
        }
    }

    void lkTryLockLoopNoFinally() {
        while (!lock.tryLock()) {
            Thread.yield();
        }
        work();
        lock.unlock();
    }

    void lkTryLockIgnored() {
        lock.tryLock();
        try {
            work();
        } finally {
            lock.unlock();
        }
    }

    // ---- LOCK-RELEASE: several acquisitions in a row

    void lkTwoLocks() {
        lock.lock();
        other.lock();
        try {
            work();
        } finally {
            other.unlock();
            lock.unlock();
        }
    }

    void lkTwoLocksUnlockedInOrder() {
        lock.lock();
        other.lock();
        try {
            work();
        } finally {
            lock.unlock();
            other.unlock();
        }
    }

    void lkTwoLocksOneMissing() {
        lock.lock();
        other.lock();
        try {
            work();
        } finally {
            other.unlock();
        }
    }

    void lkTwoLocksSecondInterruptible() throws InterruptedException {
        lock.lock();
        other.lockInterruptibly();
        try {
            work();
        } finally {
            other.unlock();
            lock.unlock();
        }
    }

    void lkTwoLocksWorkBetween() {
        lock.lock();
        work();
        other.lock();
        try {
            work();
        } finally {
            other.unlock();
            lock.unlock();
        }
    }

    List<String> lkDeclarationBeforeTry() {
        lock.lock();
        final List<String> result;
        try {
            result = new java.util.ArrayList<>();
        } finally {
            lock.unlock();
        }
        return result;
    }

    String lkInitializedDeclarationBeforeTry() {
        lock.lock();
        String text = describe();
        try {
            return text;
        } finally {
            lock.unlock();
        }
    }

    /** Lock downgrading: only the read lock taken in the finally is left to its caller. */
    void lkDowngrade() {
        other.lock();
        try {
            work();
        } finally {
            lock.lock();
            other.unlock();
        }
    }

    void lkLocksLoop(List<Lock> locks) {
        for (Lock each : locks) {
            each.lock();
        }
        try {
            work();
        } finally {
            for (Lock each : locks) {
                each.unlock();
            }
        }
    }

    void lkLocksLoopOtherCollection(List<Lock> taken, List<Lock> released) {
        for (Lock each : taken) {
            each.lock();
        }
        try {
            work();
        } finally {
            for (Lock each : released) {
                each.unlock();
            }
        }
    }

    void lkNestedOr() {
        if (enabled && (retrying || lock.tryLock())) {
            try {
                work();
            } finally {
                lock.unlock();
            }
        }
    }

    void lkDoubleNegation() {
        if (!(retrying || !lock.tryLock())) {
            try {
                work();
            } finally {
                lock.unlock();
            }
        }
    }

    void lkRetryCounter() throws InterruptedException {
        while (!lock.tryLock(1, TimeUnit.SECONDS) && attempts-- > 0) {
            work();
        }
        try {
            work();
        } finally {
            lock.unlock();
        }
    }

    void lkReentrantRun() {
        lock.lock();
        lock.lock();
        try {
            work();
        } finally {
            lock.unlock();
            lock.unlock();
        }
    }

    void lkSecondOnly() {
        lock.lock();
        lock.lock();
        try {
            work();
        } finally {
            lock.unlock();
        }
    }

    // ---- LOCK-RELEASE: lock expressions that are not simple names

    void lkStripe(int hash) {
        stripes[hash & 3].lock();
        try {
            work();
        } finally {
            stripes[hash & 3].unlock();
        }
    }

    void lkStripeIndexChanged(int index) {
        stripes[index].lock();
        try {
            index++;
        } finally {
            stripes[index].unlock();
        }
    }

    void lkStripeOtherIndex(int first, int second) {
        stripes[first].lock();
        try {
            work();
        } finally {
            stripes[second].unlock();
        }
    }

    void lkPerKey(String key) {
        perKey.get(key).lock();
        try {
            work();
        } finally {
            perKey.get(key).unlock();
        }
    }

    void lkPerKeyOtherKey(String first, String second) {
        perKey.get(first).lock();
        try {
            work();
        } finally {
            perKey.get(second).unlock();
        }
    }

    void lkLockFor(String key) {
        lockFor(key).lock();
        try {
            work();
        } finally {
            lockFor(key).unlock();
        }
    }

    void lkFreshFor(String key) {
        freshFor(key).lock();
        try {
            work();
        } finally {
            freshFor(key).unlock();
        }
    }

    // ---- LOCK-RELEASE: statements before the unlock in the finally

    void lkLogBeforeUnlock() {
        lock.lock();
        try {
            work();
        } finally {
            LOG.fine("releasing");
            lock.unlock();
        }
    }

    void lkLogWithArgumentsBeforeUnlock(String name) {
        lock.lock();
        try {
            work();
        } finally {
            LOG.log(Level.FINE, "released " + name + " by " + Thread.currentThread().getName());
            lock.unlock();
        }
    }

    void lkPrintBeforeUnlock() {
        lock.lock();
        try {
            work();
        } finally {
            System.out.println("bye");
            lock.unlock();
        }
    }

    void lkCallBeforeUnlock() {
        lock.lock();
        try {
            work();
        } finally {
            audit();
            lock.unlock();
        }
    }

    void lkLogOfCallBeforeUnlock() {
        lock.lock();
        try {
            work();
        } finally {
            LOG.fine(describe());
            lock.unlock();
        }
    }

    // ---- INTERRUPT: the flag is restored after the try, through an alias, by the thread itself

    void itFlagAfterTry() {
        boolean interrupted = false;
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            interrupted = true;
        }
        if (interrupted) {
            Thread.currentThread().interrupt();
        }
    }

    void itFlagInFinally() {
        boolean interrupted = false;
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            interrupted = true;
        } finally {
            if (interrupted) {
                Thread.currentThread().interrupt();
            }
        }
    }

    String itFlagInOuterFinally() {
        boolean interrupted = false;
        try {
            while (true) {
                try {
                    return queue.take();
                } catch (InterruptedException e) {
                    interrupted = true;
                }
            }
        } finally {
            if (interrupted) {
                Thread.currentThread().interrupt();
            }
        }
    }

    void itFlagNeverRestored() {
        boolean interrupted = false;
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            interrupted = true;
        }
        if (interrupted) {
            work();
        }
    }

    void itFlagRestoredWhenAlsoEnabled() {
        boolean interrupted = false;
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            interrupted = true;
        }
        if (interrupted && enabled) {
            Thread.currentThread().interrupt();
        }
    }

    void itFlagLostByEarlyReturn() {
        boolean interrupted = false;
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            interrupted = true;
        }
        if (enabled) {
            return;
        }
        if (interrupted) {
            Thread.currentThread().interrupt();
        }
    }

    void itFlagResetBeforeRestore() {
        boolean interrupted = false;
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            interrupted = true;
        }
        interrupted = enabled;
        if (interrupted) {
            Thread.currentThread().interrupt();
        }
    }

    void itFlagAfterEarlyExit() {
        boolean interrupted = false;
        for (int i = 0; i < 3; i++) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                if (enabled) {
                    break;
                }
                interrupted = true;
            }
        }
        if (interrupted) {
            Thread.currentThread().interrupt();
        }
    }

    void itFlagInSwitch(int kind) {
        boolean interrupted = false;
        switch (kind) {
            case 1:
                try {
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                    interrupted = true;
                }
                break;
            default:
                break;
        }
        if (interrupted) {
            Thread.currentThread().interrupt();
        }
    }

    void itFlagInLoop(boolean done) {
        boolean interrupted = false;
        while (!done) {
            try {
                queue.take();
            } catch (InterruptedException e) {
                interrupted = true;
            }
        }
        if (interrupted) {
            Thread.currentThread().interrupt();
        }
    }

    void itFlagTwoHandlers() {
        boolean interrupted = false;
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            interrupted = true;
        }
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            interrupted = true;
        }
        if (interrupted) {
            Thread.currentThread().interrupt();
        }
    }

    void itFlagRestoredInElseOnly(boolean skip) {
        boolean interrupted = false;
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            interrupted = true;
        }
        if (skip) {
            return;
        } else if (interrupted) {
            Thread.currentThread().interrupt();
        }
    }

    void itFlagInField() {
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            pendingFlag = true;
        }
        if (pendingFlag) {
            Thread.currentThread().interrupt();
        }
    }

    void itAliasOfEitherThread(Thread worker, boolean own) {
        Thread self = own ? Thread.currentThread() : worker;
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            self.interrupt();
        }
    }

    void itRestoreThroughAlias() {
        final Thread self = Thread.currentThread();
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            self.interrupt();
        }
    }

    void itRestoreThroughReassignedAlias(Thread worker) {
        Thread self = Thread.currentThread();
        self = worker;
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            self.interrupt();
        }
    }

    void itRestoreThroughCapturedAlias(ExecutorService pool) {
        final Thread self = Thread.currentThread();
        pool.submit(() -> {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                self.interrupt();
            }
        });
    }

    void itInterruptOtherThread(Thread worker) {
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            worker.interrupt();
        }
    }

    static class BeatThread extends Thread {
        @Override public void run() {
            try {
                sleep(1);
            } catch (InterruptedException e) {
                interrupt();
            }
        }
    }

    static class BeatThisThread extends Thread {
        @Override public void run() {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                this.interrupt();
            }
        }
    }

    static class JoiningThread extends Thread {
        void shutdown(Thread worker) {
            try {
                worker.join();
            } catch (InterruptedException e) {
                interrupt();
            }
        }
    }

    String itMultiCatchRestores(Future<String> future) {
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            throw new IllegalStateException(e);
        }
    }

    String itPatternMultiCatchRestores(Future<String> future) {
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            if (e instanceof InterruptedException interrupt) {
                Thread.currentThread().interrupt();
            }
            throw new IllegalStateException(e);
        }
    }

    String itPatternMultiCatchNeverRestores(Future<String> future) {
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            if (e instanceof InterruptedException interrupt) {
                LOG.warning(interrupt.toString());
            }
            throw new IllegalStateException(e);
        }
    }

    String itMultiCatchNeverRestores(Future<String> future) {
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            if (e instanceof InterruptedException) {
                LOG.warning("interrupted");
            }
            throw new IllegalStateException(e);
        }
    }

    void itNewInterruptedException() throws InterruptedException {
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            LOG.warning("cancelled");
            throw new InterruptedException("cancelled");
        }
    }

    void itWrapInRuntimeException() {
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
    }

    // ---- INTERRUPT: a catch of Exception or Throwable also takes an InterruptedException

    void itCatchException() {
        try {
            Thread.sleep(1);
        } catch (Exception e) {
            LOG.warning(e.toString());
        }
    }

    String itCatchThrowable() {
        try {
            return queue.take();
        } catch (Throwable t) {
            return null;
        }
    }

    void itCatchExceptionRestores() {
        try {
            Thread.sleep(1);
        } catch (Exception e) {
            Thread.currentThread().interrupt();
        }
    }

    void itCatchExceptionTestsType() {
        try {
            Thread.sleep(1);
        } catch (Exception e) {
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            LOG.warning(e.toString());
        }
    }

    void itCatchExceptionRethrows() throws Exception {
        try {
            Thread.sleep(1);
        } catch (Exception e) {
            LOG.warning(e.toString());
            throw e;
        }
    }

    void itCatchExceptionWithoutInterrupt() {
        try {
            work();
        } catch (Exception e) {
            LOG.warning(e.toString());
        }
    }

    void itCatchExceptionAfterNarrowCatch() {
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            LOG.warning(e.toString());
        }
    }

    void itCatchExceptionAroundHandledSleep() {
        try {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        } catch (Exception e) {
            LOG.warning(e.toString());
        }
    }

    // ---- THREADLOCAL-CLEANUP: every thread local is removed, in any order

    void tlTwoRemoved(HttpServletRequest request) {
        try {
            USER.set(request.getParameter("user"));
            LOCALE.set(request.getParameter("lang"));
            work();
        } finally {
            USER.remove();
            LOCALE.remove();
        }
    }

    void tlSetsBeforeTry(HttpServletRequest request) {
        USER.set(request.getParameter("user"));
        LOCALE.set(request.getParameter("lang"));
        TRACE.set(request.getParameter("trace"));
        try {
            work();
        } finally {
            TRACE.remove();
            LOCALE.remove();
            USER.remove();
        }
    }

    void tlOneOfTwoRemoved(HttpServletRequest request) {
        try {
            USER.set(request.getParameter("user"));
            LOCALE.set(request.getParameter("lang"));
            work();
        } finally {
            LOCALE.remove();
        }
    }

    void tlSetsBeforeTryOneMissing(HttpServletRequest request) {
        USER.set(request.getParameter("user"));
        LOCALE.set(request.getParameter("lang"));
        try {
            work();
        } finally {
            USER.remove();
        }
    }

    void tlLogBeforeRemove(HttpServletRequest request) {
        try {
            USER.set(request.getParameter("user"));
            work();
        } finally {
            System.out.println("done");
            USER.remove();
        }
    }

    void tlCallBeforeRemove(HttpServletRequest request) {
        try {
            USER.set(request.getParameter("user"));
            work();
        } finally {
            audit();
            USER.remove();
        }
    }

    void tlSetNullInCatch(HttpServletRequest request) {
        try {
            USER.set(request.getParameter("user"));
            work();
        } catch (RuntimeException e) {
            USER.set(null);
            throw e;
        } finally {
            USER.remove();
        }
    }

    void tlSetInCatch(HttpServletRequest request) {
        try {
            work();
        } catch (RuntimeException e) {
            USER.set("failed");
            throw e;
        } finally {
            USER.remove();
        }
    }

    void tlSetInCatchWithoutFinally(HttpServletRequest request) {
        try {
            work();
        } catch (RuntimeException e) {
            USER.set("failed");
            throw e;
        }
    }

    void tlSetNullInFinally(HttpServletRequest request) {
        try {
            USER.set(request.getParameter("user"));
            work();
        } finally {
            USER.set(null);
        }
    }

    void tlSetNullOnly(HttpServletRequest request) {
        USER.set(null);
        work();
    }

    Runnable tlClearingLambda() {
        return () -> USER.set(null);
    }

    void tlCallBetweenRemoves(HttpServletRequest request) {
        try {
            USER.set(request.getParameter("user"));
            LOCALE.set(request.getParameter("lang"));
            work();
        } finally {
            USER.remove();
            audit();
            LOCALE.remove();
        }
    }

    void tlGuardedByOtherValue(HttpServletRequest request) {
        try {
            USER.set(request.getParameter("user"));
            work();
        } finally {
            if (LOCALE.get() != null) {
                USER.remove();
            }
        }
    }

    void tlGuardedRemove(HttpServletRequest request) {
        try {
            USER.set(request.getParameter("user"));
            work();
        } finally {
            if (USER.get() != null) {
                USER.remove();
            }
        }
    }

    // ---- THREADLOCAL-CLEANUP: tasks written as lambdas

    void tlRunnableLambda(ExecutorService pool, String user) {
        pool.submit(() -> {
            USER.set(user);
            work();
        });
    }

    Callable<String> tlCallableLambda(String user) {
        return () -> {
            USER.set(user);
            return USER.get();
        };
    }

    void tlRunnableLambdaCleaned(ExecutorService pool, String user) {
        pool.submit(() -> {
            try {
                USER.set(user);
                work();
            } finally {
                USER.remove();
            }
        });
    }

    Supplier<String> tlSupplierLambda(String user) {
        return () -> {
            USER.set(user);
            return USER.get();
        };
    }

    // ---- TRANSACTION-SELF

    static class GenericBean<T> {
        void txGeneric() { saveGeneric(); }
        void txGenericWithArgument(T value) { saveGenericValue(value); }
        @Transactional void saveGeneric() { }
        @Transactional void saveGenericValue(T value) { }
    }

    interface DefaultApi {
        @Transactional default void saveDefault() { }
    }

    static class DefaultImpl implements DefaultApi {
        void txDefaultMethod() { saveDefault(); }
    }

    static class NestedForms {
        void txAnonymousInLambda() {
            Runnable job = () -> new Thread(new Runnable() {
                @Override public void run() { saveNested(); }
            }).start();
            job.run();
        }
        void txLocalClass() {
            class Local {
                void go() { saveNested(); }
            }
            new Local().go();
        }
        class Worker {
            void txQualifiedThis() { NestedForms.this.saveNested(); }
        }
        void txStream(List<String> rows) { rows.stream().map(row -> { saveNested(); return row; }).count(); }
        @Transactional void saveNested() { }
    }

    static class SuperCaller extends NestedForms {
        @Override @Transactional void saveNested() { super.saveNested(); }
    }

    static class BaseBean {
        @Transactional void saveBase() { }
    }

    static class ChildBean extends BaseBean {
        void txInherited() { saveBase(); }
        void txInheritedThis() { this.saveBase(); }
    }

    static class GenericBaseBean<T> {
        @Transactional void saveGenericBase(T value) { }
    }

    static class StringChildBean extends GenericBaseBean<String> {
        void txInheritedGeneric() { saveGenericBase("x"); }
    }

    static class LambdaBean {
        void txLambda(List<String> rows) { rows.forEach(row -> saveOne(row)); }
        void txMethodReference(List<String> rows) { rows.forEach(this::saveOne); }
        void txQualifiedThisInLambda(List<String> rows) { rows.forEach(row -> LambdaBean.this.saveOne(row)); }
        void txOtherInstance(List<String> rows, LambdaBean proxy) { rows.forEach(row -> proxy.saveOne(row)); }
        @Transactional void txLambdaInTransaction(List<String> rows) { rows.forEach(row -> saveOne(row)); }
        @Transactional void saveOne(String row) { }
    }

    interface Job { void execute(); }

    static class AnonymousBean {
        void txAnonymous() {
            Job job = new Job() {
                @Override public void execute() { saveAnonymous(); }
            };
            job.execute();
        }
        @Transactional void saveAnonymous() { }
    }

    static class InnerBean {
        class Worker {
            void txInner() { saveInner(); }
        }
        @Transactional void saveInner() { }
    }

    @Transactional
    static class AnnotatedInnerBean {
        class Worker {
            void txInnerUnderClassLevel() { saveUnderClassLevel(); }
        }
        @Transactional void saveUnderClassLevel() { }
    }

    static class ComposedBean {
        @Transactional(propagation = Propagation.REQUIRES_NEW) @interface Isolated { }
        @Transactional @interface Plain { }
        void txComposedTarget() { saveIsolated(); }
        @Plain void txComposedCaller() { savePlain(); }
        @Isolated void saveIsolated() { }
        @Transactional void savePlain() { }
    }

    @Transactional
    static abstract class AnnotatedBase { }

    static class ClassLevelChild extends AnnotatedBase {
        void txClassLevelInherited() { saveClassLevel(); }
        @Transactional void saveClassLevel() { }
    }

    @Transactional
    interface AnnotatedApi {
        void txViaInterface();
    }

    static class InterfaceChild implements AnnotatedApi {
        @Override public void txViaInterface() { saveViaInterface(); }
        @Transactional void saveViaInterface() { }
    }

    static class NewBoundaryChild extends AnnotatedBase {
        void txClassLevelNewBoundary() { saveNewBoundary(); }
        @Transactional(propagation = Propagation.REQUIRES_NEW) void saveNewBoundary() { }
    }
}
