package example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.stream.Stream;

/**
 * Review fixes of 2026-10-26 (area C2): streams chosen by a conditional or on different paths, streams of the outer scope consumed in
 * loops, and lists of fixed size reached through Collections.addAll, views, iterators, switch expressions and final fields. The method
 * names are unique in this file, so that every suite case can select one of them.
 */
public class FixC2Cases {
    private static final List<String> FIXED_NAMES = Arrays.asList("a", "b");
    private final List<String> fixedOwn = Arrays.asList("x");
    private static final List<String> COPIED_NAMES = new ArrayList<>(Arrays.asList("a"));
    private static List<String> reboundNames = Arrays.asList("a");

    // ---------------------------------------------------------------- STREAM_REUSE
    public long streamTernary(List<String> a, List<String> b, boolean first) {
        Stream<String> s = first ? a.stream() : b.stream();
        long n = s.count();
        return n + s.count();
    }

    public long streamNullSafeSource(List<String> names) {
        Stream<String> s = names == null ? Stream.empty() : names.stream();
        long n = s.count();
        return n + s.filter(x -> !x.isEmpty()).count();
    }

    public long streamAssignedOnBothPaths(List<String> a, List<String> b, boolean first) {
        Stream<String> s;
        if (first) {
            s = a.stream();
        } else {
            s = b.stream();
        }
        long n = s.count();
        return n + s.count();
    }

    public long streamConsumedOnBothPaths(List<String> a, List<String> b, boolean first) {
        Stream<String> s;
        if (first) {
            s = a.stream();
            s.count();
        } else {
            s = b.stream();
            s.count();
        }
        return s.count();
    }

    public long streamConsumedOnOnePath(List<String> a, List<String> b, boolean first) {
        Stream<String> s;
        if (first) {
            s = a.stream();
            s.count();
        } else {
            s = b.stream();
        }
        return s.count();
    }

    public long streamTernaryOnce(List<String> a, List<String> b, boolean first) {
        Stream<String> s = first ? a.stream() : b.stream();
        return s.count();
    }

    public long streamTernaryWithNull(List<String> a, boolean first) {
        Stream<String> s = first ? a.stream() : null;
        return s.count();
    }

    public int streamOuterInForEach(List<String> allowed, List<String> codes) {
        Stream<String> allowedStream = allowed.stream();
        int n = 0;
        for (String code : codes) {
            if (allowedStream.anyMatch(a -> a.equals(code))) {
                n++;
            }
        }
        return n;
    }

    public void streamOuterInWhile(List<String> a, Iterator<String> it) {
        Stream<String> s = a.stream();
        while (it.hasNext()) {
            it.next();
            s.forEach(x -> { });
        }
    }

    public int streamOuterInLoopThatExits(List<String> a, List<String> codes) {
        Stream<String> s = a.stream();
        int n = 0;
        for (String code : codes) {
            n += s.count();
            break;
        }
        return n;
    }

    public int streamCreatedInLoop(List<String> a, List<String> codes) {
        int n = 0;
        for (String code : codes) {
            n += a.stream().count();
        }
        return n;
    }

    public int streamAssignedInLoop(List<String> a, List<String> codes) {
        Stream<String> s = a.stream();
        int n = 0;
        for (String code : codes) {
            s = a.stream();
            n += s.count();
        }
        return n;
    }

    public void streamForEachVariable(List<Stream<String>> streams) {
        for (Stream<String> s : streams) {
            long n = s.count();
            s.forEach(x -> System.out.println(n + x));
        }
    }

    public void streamForEachVariableOnce(List<Stream<String>> streams) {
        for (Stream<String> s : streams) {
            long n = s.count();
        }
    }

    // ---------------------------------------------------------------- FIXED_LIST
    public void fixedCollectionsAddAll() {
        List<String> l = Arrays.asList("a");
        Collections.addAll(l, "b", "c");
    }

    public void fixedCollectionsAddAllToCopy() {
        List<String> l = new ArrayList<>(Arrays.asList("a"));
        Collections.addAll(l, "b", "c");
    }

    public void fixedSubListAdd() {
        List<String> l = Arrays.asList("a", "b");
        l.subList(0, 1).add("c");
    }

    public void fixedSubListKept() {
        List<String> l = Arrays.asList("a", "b");
        List<String> part = l.subList(0, 1);
        part.clear();
    }

    public void fixedSubListCopied() {
        List<String> l = Arrays.asList("a", "b");
        new ArrayList<>(l.subList(0, 1)).add("c");
    }

    public void fixedIteratorRemove() {
        List<String> l = Arrays.asList("a", "b");
        Iterator<String> it = l.iterator();
        while (it.hasNext()) {
            if (it.next().isEmpty()) it.remove();
        }
    }

    public void fixedListIteratorAdd() {
        List<String> l = Arrays.asList("a", "b");
        ListIterator<String> it = l.listIterator();
        it.add("c");
    }

    public void fixedIteratorOfCopy() {
        List<String> l = new ArrayList<>(Arrays.asList("a", "b"));
        Iterator<String> it = l.iterator();
        it.next();
        it.remove();
    }

    public void fixedIteratorNext() {
        List<String> l = Arrays.asList("a", "b");
        Iterator<String> it = l.iterator();
        it.next();
    }

    public void fixedSwitchExpressionArms(int k) {
        List<String> l = switch (k) {
            case 1 -> Arrays.asList("a");
            default -> Arrays.asList("b");
        };
        l.add("c");
    }

    public void fixedSwitchExpressionMixed(int k) {
        List<String> l = switch (k) {
            case 1 -> Arrays.asList("a");
            default -> new ArrayList<>();
        };
        l.add("c");
    }

    public void fixedConditionalArms(boolean c) {
        List<String> l = c ? Arrays.asList("a") : Arrays.asList("b");
        l.add("c");
    }

    public void fixedAssignedOnBothPaths(boolean c) {
        List<String> l;
        if (c) l = Arrays.asList("a"); else l = Arrays.asList("b");
        l.add("z");
    }

    public void fixedAssignedOnOnePath(boolean c) {
        List<String> l;
        if (c) l = Arrays.asList("a"); else l = new ArrayList<>();
        l.add("z");
    }

    public void fixedStaticField() {
        FIXED_NAMES.add("c");
    }

    public void fixedInstanceField() {
        this.fixedOwn.remove("x");
    }

    public void fixedFieldAlias() {
        List<String> l = FIXED_NAMES;
        l.clear();
    }

    public void fixedFieldSet() {
        FIXED_NAMES.set(0, "z");
    }

    public void fixedFieldOfCopy() {
        COPIED_NAMES.add("c");
    }

    public void fixedFieldNotFinal() {
        reboundNames.add("c");
    }
}
