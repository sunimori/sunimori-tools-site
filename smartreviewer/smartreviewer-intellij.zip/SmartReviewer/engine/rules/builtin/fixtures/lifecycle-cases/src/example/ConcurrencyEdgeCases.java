package example;

import java.util.function.BooleanSupplier;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class ConcurrencyEdgeCases {
    public enum Pick { FIRST, SECOND }
    static void interrupted() throws InterruptedException { throw new InterruptedException(); }
    public static int nullSwitchReturn(String text) {
        try { interrupted(); } catch (InterruptedException original) {
            try { return switch (text) { default -> { Thread.currentThread().interrupt(); yield 1; } }; }
            catch (NullPointerException swallowed) { }
        }
        return 0;
    }
    public static void nullSwitchCondition(String text) {
        try { interrupted(); } catch (InterruptedException original) {
            try { if (switch (text) { default -> { Thread.currentThread().interrupt(); yield true; } }) { } }
            catch (NullPointerException swallowed) { }
        }
    }
    public static void conditionalUnboxing(Integer number, boolean choose) {
        try { interrupted(); } catch (InterruptedException original) {
            try {
                ((IntSupplier) () -> choose ? number : number).getAsInt();
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException swallowed) { }
        }
    }
    public static void conditionalBooleanUnboxing(Boolean value, boolean choose) {
        try { interrupted(); } catch (InterruptedException original) {
            try {
                ((BooleanSupplier) () -> choose ? value : value).getAsBoolean();
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException swallowed) { }
        }
    }
    public static void conditionalUnboxingAfterRestore(Integer number, boolean choose) {
        try { interrupted(); } catch (InterruptedException original) {
            try {
                Thread.currentThread().interrupt();
                ((IntSupplier) () -> choose ? number : number).getAsInt();
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { } catch (NullPointerException preserved) { }
        }
    }
    public static void primitiveConditionalDoesNotThrow(boolean choose) {
        try { interrupted(); } catch (InterruptedException original) {
            try {
                ((IntSupplier) () -> choose ? 1 : 2).getAsInt();
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException unreachable) { }
        }
    }
    public static int expressionSelectorRestoresBeforeNull() {
        try { interrupted(); } catch (InterruptedException original) {
            try { return switch (((Supplier<String>) () -> { Thread.currentThread().interrupt(); return null; }).get()) { default -> 1; }; }
            catch (NullPointerException preserved) { }
        }
        return 0;
    }
    public static void statementSelectorRestoresBeforeNull() {
        try { interrupted(); } catch (InterruptedException original) {
            try { switch (((Supplier<String>) () -> { Thread.currentThread().interrupt(); return null; }).get()) { default: break; } }
            catch (NullPointerException preserved) { }
        }
    }
    public static void monitorRestoresBeforeNull() {
        try { interrupted(); } catch (InterruptedException original) {
            try { synchronized (((Supplier<Object>) () -> { Thread.currentThread().interrupt(); return null; }).get()) { } }
            catch (NullPointerException preserved) { }
        }
    }
    public static void nullMonitorBeforeRestore(Object monitor) {
        try { interrupted(); } catch (InterruptedException original) {
            try { synchronized (monitor) { Thread.currentThread().interrupt(); } }
            catch (NullPointerException swallowed) { }
        }
    }
    public static int literalSelectorDoesNotThrow() {
        try { interrupted(); } catch (InterruptedException original) {
            try { return switch ("fixed") { default -> { Thread.currentThread().interrupt(); yield 1; } }; }
            catch (NullPointerException unreachable) { }
        }
        return 0;
    }
    public static void exhaustiveEnumRestores() {
        try { interrupted(); } catch (InterruptedException original) {
            boolean value = switch (Pick.FIRST) {
                case FIRST -> { Thread.currentThread().interrupt(); yield false; }
                case SECOND -> { Thread.currentThread().interrupt(); yield true; }
            };
        }
    }
    public static void exhaustiveEnumConditionRestores() {
        try { interrupted(); } catch (InterruptedException original) {
            if (switch (Pick.FIRST) {
                case FIRST -> { Thread.currentThread().interrupt(); yield false; }
                case SECOND -> { Thread.currentThread().interrupt(); yield true; }
            }) { }
        }
    }
    public static boolean nullableEnumReturn(Pick selected) {
        try { interrupted(); } catch (InterruptedException original) {
            try { return switch (selected) {
                case FIRST -> { Thread.currentThread().interrupt(); yield false; }
                case SECOND -> { Thread.currentThread().interrupt(); yield true; }
            }; } catch (NullPointerException swallowed) { }
        }
        return false;
    }
    public static void falseWhileCondition() {
        try {
            while (switch (1) { default -> {
                try { interrupted(); } catch (InterruptedException restored) { Thread.currentThread().interrupt(); }
                yield false;
            } }) { Thread.interrupted(); }
        } finally { }
    }
    public static void falseForCondition() {
        try {
            for (; switch (1) { default -> {
                try { interrupted(); } catch (InterruptedException restored) { Thread.currentThread().interrupt(); }
                yield false;
            } };) { Thread.interrupted(); }
        } finally { }
    }
    public static void falseDoCondition() {
        try {
            do { Thread.interrupted(); } while (switch (1) { default -> {
                try { interrupted(); } catch (InterruptedException restored) { Thread.currentThread().interrupt(); }
                yield false;
            } });
        } finally { }
    }
    public static void trueWhileCannotReachFinally() {
        try {
            while (switch (1) { default -> { try { interrupted(); } catch (InterruptedException swallowed) { } yield true; } }) Thread.onSpinWait();
        } finally { Thread.currentThread().interrupt(); }
    }
    public static void trueForCannotReachFinally() {
        try {
            for (; switch (1) { default -> { try { interrupted(); } catch (InterruptedException swallowed) { } yield true; } };) Thread.onSpinWait();
        } finally { Thread.currentThread().interrupt(); }
    }
    public static void trueDoCannotReachFinally() {
        try {
            do { Thread.onSpinWait(); } while (switch (1) { default -> { try { interrupted(); } catch (InterruptedException swallowed) { } yield true; } });
        } finally { Thread.currentThread().interrupt(); }
    }
    public static void trueLoopBreakReachesFinally() {
        try {
            while (switch (1) { default -> { try { interrupted(); } catch (InterruptedException swallowed) { } yield true; } }) break;
        } finally { Thread.currentThread().interrupt(); }
    }
    public static void unknownLoopCanExit(boolean take) {
        try {
            while (switch (1) { default -> { try { interrupted(); } catch (InterruptedException swallowed) { } yield take; } }) Thread.onSpinWait();
        } finally { Thread.currentThread().interrupt(); }
    }
    public static void switchResultUnboxing(Integer number) {
        try { interrupted(); } catch (InterruptedException original) {
            try {
                ((IntSupplier) () -> switch (1) { default -> number; }).getAsInt();
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException swallowed) { }
        }
    }
    public static void switchResultUnboxingAfterRestore(Integer number) {
        try { interrupted(); } catch (InterruptedException original) {
            try {
                Thread.currentThread().interrupt();
                ((IntSupplier) () -> switch (1) { default -> number; }).getAsInt();
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { } catch (NullPointerException preserved) { }
        }
    }
    public static void nullSwitchFinallyRestores(String text) {
        try { interrupted(); } catch (InterruptedException original) {
            try { if (switch (text) { default -> true; }) { } }
            catch (NullPointerException expected) { }
            finally { Thread.currentThread().interrupt(); }
        }
    }
    public static void conditionalUnboxingFinallyRestores(Integer number) {
        try { interrupted(); } catch (InterruptedException original) {
            try { ((IntSupplier) () -> true ? number : number).getAsInt(); }
            catch (NullPointerException expected) { }
            finally { Thread.currentThread().interrupt(); }
        }
    }
    public static void booleanLoopLock(java.util.concurrent.locks.Lock lock) {
        lock.lock();
        try { while (switch (1) { default -> true; }) { } }
        finally { lock.unlock(); }
    }
    public static void falseLoopLock(java.util.concurrent.locks.Lock lock) {
        lock.lock();
        try { while (switch (1) { default -> false; }) { } }
        finally { lock.unlock(); }
    }
    public static void booleanLoopThreadLocal(ThreadLocal<String> local, jakarta.servlet.http.HttpServletRequest request) {
        local.set("value");
        try { while (switch (1) { default -> true; }) { } }
        finally { local.remove(); }
    }
    public static void falseLoopThreadLocal(ThreadLocal<String> local, jakarta.servlet.http.HttpServletRequest request) {
        local.set("value");
        try { while (switch (1) { default -> false; }) { } }
        finally { local.remove(); }
    }
}
