package jakarta.servlet.http; public interface HttpServletRequest extends jakarta.servlet.ServletRequest { }
