package example;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/** Review regressions (2026-10-24): constant-true loops left by break, return or a declared exception, and lock getters. */
public class ConcurrencyLoopExitCases {
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition notEmpty = lock.newCondition();
    private final Deque<String> items = new ArrayDeque<>();
    private final BlockingQueue<Runnable> queue = new LinkedBlockingQueue<>();
    private final LockHolder holder = new LockHolder();
    private volatile boolean running;

    private Lock getLock() {
        return this.lock;
    }

    private Lock newLock() {
        return new ReentrantLock();
    }

    public String take() throws InterruptedException {
        lock.lockInterruptibly();
        try {
            while (true) {
                if (!items.isEmpty()) return items.poll();
                notEmpty.await();
            }
        } finally {
            lock.unlock();
        }
    }

    public void drain(List<String> out) {
        lock.lock();
        try {
            for (;;) {
                String item = items.poll();
                if (item == null) break;
                out.add(item);
            }
        } finally {
            lock.unlock();
        }
    }

    public void doBreak() {
        lock.lock();
        try {
            do {
                if (queue.isEmpty()) break;
                queue.poll().run();
            } while (true);
        } finally {
            lock.unlock();
        }
    }

    public Runnable forReturn() {
        lock.lock();
        try {
            for (;;) {
                Runnable next = queue.poll();
                if (next != null) return next;
                Thread.onSpinWait();
            }
        } finally {
            lock.unlock();
        }
    }

    public void nestedTry() {
        lock.lock();
        try {
            while (true) {
                try {
                    if (queue.isEmpty()) break;
                    queue.poll().run();
                } finally {
                    running = false;
                }
            }
        } finally {
            lock.unlock();
        }
    }

    public void labelledBreak() {
        lock.lock();
        try {
            outer:
            while (true) {
                while (true) {
                    if (queue.isEmpty()) break outer;
                    queue.poll().run();
                }
            }
        } finally {
            lock.unlock();
        }
    }

    public void worker() {
        lock.lock();
        try {
            while (true) {
                queue.take().run();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            lock.unlock();
        }
    }

    public void spin() {
        lock.lock();
        try {
            while (true) {
                Thread.onSpinWait();
            }
        } finally {
            lock.unlock();
        }
    }

    public void drainThenRestore(List<String> out) {
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            while (true) {
                String item = items.poll();
                if (item == null) break;
                out.add(item);
            }
            Thread.currentThread().interrupt();
        }
    }

    public void getterLock() {
        getLock().lock();
        try {
            running = true;
        } finally {
            getLock().unlock();
        }
    }

    public void holderLock() {
        holder.lock().lock();
        try {
            running = true;
        } finally {
            holder.lock().unlock();
        }
    }

    public void factoryLock() {
        newLock().lock();
        try {
            running = true;
        } finally {
            newLock().unlock();
        }
    }

    public void freshHolderLock() {
        holder.fresh().lock();
        try {
            running = true;
        } finally {
            holder.fresh().unlock();
        }
    }

    public void flagBeforeUnlock() {
        lock.lock();
        try {
            while (running) {
                try {
                    queue.take().run();
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        } catch (ThreadDeath death) {
            throw death;
        } finally {
            running = false;
            lock.unlock();
        }
    }

    public void earlyReturnLeak() {
        if (!running) {
            lock.lock();
            if (running) {
                return;
            }
            try {
                running = true;
            } finally {
                lock.unlock();
            }
        }
    }

    /** A task drains its queue with a request-scoped ThreadLocal set. */
    public static class Worker implements Runnable {
        private static final ThreadLocal<String> CONTEXT = new ThreadLocal<>();
        private final BlockingQueue<String> jobs = new LinkedBlockingQueue<>();

        @Override public void run() {
            CONTEXT.set("worker");
            try {
                while (true) {
                    String job = jobs.poll();
                    if (job == null) break;
                    System.out.println(job);
                }
            } finally {
                CONTEXT.remove();
            }
        }
    }

    /** A task that never leaves its loop never reaches its cleanup. */
    public static class Spinner implements Callable<String> {
        private static final ThreadLocal<String> CONTEXT = new ThreadLocal<>();

        @Override public String call() {
            CONTEXT.set("spinner");
            try {
                while (true) {
                    Thread.onSpinWait();
                }
            } finally {
                CONTEXT.remove();
            }
        }
    }
}
