package org.springframework.transaction.annotation; public enum Propagation { REQUIRED, REQUIRES_NEW, NESTED, NOT_SUPPORTED, NEVER }
