package example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

/** The arms of a switch are branches: each is followed on its own and none is read as the continuation of another. */
public class SwitchCases {
    long streamTwiceInArm(Stream<String> a, int k) { switch (k) { case 1: a.count(); a.findFirst(); break; default: break; } return 0; }
    long streamOncePerArm(Stream<String> a, int k) { return switch (k) { case 1 -> a.count(); default -> a.count(); }; }
    long streamOncePerStatementArm(Stream<String> a, int k) { long r; switch (k) { case 1: r = a.count(); break; default: r = a.count(); } return r; }
    long streamBeforeAndAfter(Stream<String> a, int k) { a.count(); switch (k) { case 1: break; default: break; } return a.count(); }
    long streamInOnePathOnly(Stream<String> a, int k) { switch (k) { case 1: a.count(); break; default: break; } return a.count(); }

    void fixedListInArm(int k) { List<String> l = Arrays.asList("a"); switch (k) { case 1: l.add("b"); break; default: break; } }
    void fixedListAfterSwitch(int k) { List<String> l = Arrays.asList("a"); switch (k) { case 1: System.out.println(); break; default: break; } l.add("b"); }
    void fixedListReplacedInArm(int k) { List<String> l = Arrays.asList("a"); switch (k) { case 1: l = new ArrayList<>(); break; default: break; } l.add("b"); }
    void copiedListInArm(int k) { switch (k) { case 1: { List<String> a = new ArrayList<>(Arrays.asList("a")); a.add("b"); break; } default: break; } }
}
