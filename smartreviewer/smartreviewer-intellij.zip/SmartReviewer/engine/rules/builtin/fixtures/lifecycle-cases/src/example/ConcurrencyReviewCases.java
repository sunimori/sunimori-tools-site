package example;

import java.util.concurrent.locks.*;
import java.util.function.BooleanSupplier;
import jakarta.servlet.http.HttpServletRequest;

public class ConcurrencyReviewCases {
    ReentrantLock lock = new ReentrantLock();
    final ThreadLocal<String> local = new ThreadLocal<>();

    void sequentialLockScopes() {
        try {
            lock.lock();
            try { System.out.println("first"); } finally { lock.unlock(); }
            lock.lock();
            System.out.println("second");
        } finally { if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    void sequentialTryLockScopes() {
        try {
            if (lock.tryLock()) { try { System.out.println("first"); } finally { lock.unlock(); } }
            lock.lock();
        } finally { if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    void missingSecondScopeRelease() {
        try {
            lock.lock();
            try { } finally { lock.unlock(); }
            lock.lock();
        } finally { System.out.println("no cleanup"); }
    }
    void immediatelyInvokedLambdaWrite() {
        lock.lock();
        try { ((Runnable) () -> lock = new ReentrantLock()).run(); }
        finally { lock.unlock(); }
    }
    void immediatelyInvokedBlockLambdaWrite() {
        lock.lock();
        try { ((Runnable) () -> { lock = new ReentrantLock(); }).run(); }
        finally { lock.unlock(); }
    }
    void immediatelyInvokedLambdaNoWrite() {
        lock.lock();
        try { ((Runnable) () -> System.out.println(lock)).run(); }
        finally { lock.unlock(); }
    }
    void lambdaObjectMethodDoesNotExecuteBody() {
        lock.lock();
        try { ((Runnable) () -> lock = new ReentrantLock()).toString(); }
        finally { lock.unlock(); }
    }
    void immediateLambdaContainsDeferredWrite() {
        lock.lock();
        try { ((Runnable) () -> { Runnable later = () -> lock = new ReentrantLock(); }).run(); }
        finally { lock.unlock(); }
    }
    void fixedLoopOneRelease() {
        try { for (int i = 0; i < 2; i++) lock.lock(); }
        finally { lock.unlock(); }
    }
    void fixedLoopTwoReleases() {
        try { for (int i = 0; i < 2; i++) lock.lock(); }
        finally { lock.unlock(); lock.unlock(); }
    }
    void nestedLoopsOneRelease() {
        try { for (int i = 0; i < 2; i++) for (int j = 0; j < 2; j++) lock.lock(); }
        finally { lock.unlock(); }
    }
    void descendingLoopOneRelease() {
        try { for (int i = 2; i > 0; --i) lock.lock(); }
        finally { lock.unlock(); }
    }
    void unknownLoopOneRelease(boolean again) {
        try { while (again) lock.lock(); }
        finally { if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    void enhancedLoopOneRelease(String[] values) {
        try { for (String value : values) lock.lock(); }
        finally { if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    void loopContinuesAfterAcquisition() {
        try { for (int i = 0; i < 2; i++) { lock.lock(); continue; } }
        finally { lock.unlock(); }
    }
    void balancedInsideLoop(boolean again) {
        while (again) { lock.lock(); try { } finally { lock.unlock(); } }
    }
    void oneIterationLoop() {
        try { for (int i = 0; i < 1; i++) lock.lock(); }
        finally { lock.unlock(); }
    }
    void loopAlwaysBreaks() {
        try { while (true) { lock.lock(); break; } }
        finally { lock.unlock(); }
    }
    void doLoopOnce() {
        try { do { lock.lock(); } while (false); }
        finally { lock.unlock(); }
    }
    void loopInitializerAcquiresOnce() {
        try { for (boolean acquired = lock.tryLock(); acquired; ) { break; } }
        finally { if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    void loopUpdatesItsIndexAgain() {
        try { for (int i = 0; i < 1; i++) { lock.lock(); i--; } }
        finally { lock.unlock(); }
    }
    void byteLoopMayOverflow() {
        try { for (byte i = 0; i <= 127; i++) lock.lock(); }
        finally { lock.unlock(); }
    }
    void repeatedThreadLocalSets(HttpServletRequest request, boolean again) {
        try { while (again) local.set("request"); }
        finally { local.remove(); }
    }
    void interruptedInfiniteWhile() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { while (true) { System.out.println("retry"); } }
    }
    void interruptedInfiniteFor() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { for (;;) { continue; } }
    }
    void interruptedInfiniteDo() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { do { System.out.println("retry"); } while (true); }
    }
    void restoredInfiniteLoop() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { Thread.currentThread().interrupt(); while (true) { System.out.println("retry"); } }
    }
    void restoringInsideInfiniteLoop() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { for (;;) { Thread.currentThread().interrupt(); } }
    }
    void restoringBeforeLoopBreak() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { while (true) { Thread.currentThread().interrupt(); break; } }
    }
    void restoringAfterLoopBreak() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { while (true) { break; } Thread.currentThread().interrupt(); }
    }
    void infiniteLoopSkipsRestoringFinally() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { while (true) { System.out.println("retry"); } }
        finally { Thread.currentThread().interrupt(); }
    }
    void nestedInfiniteLoopSkipsRestoration() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) {
            try { while (true) { System.out.println("retry"); } }
            finally { Thread.currentThread().interrupt(); }
        }
    }
    void assertClearsInterrupt() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { Thread.currentThread().interrupt(); assert Thread.interrupted(); }
    }
    void assertMessageClearsInterrupt() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { Thread.currentThread().interrupt(); assert false : Thread.interrupted(); }
    }
    void assertUnexecutedMessagePreservesInterrupt() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { Thread.currentThread().interrupt(); assert true : Thread.interrupted(); }
    }
    void skippedAssertClearPreservesInterrupt() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { Thread.currentThread().interrupt(); assert true || Thread.interrupted(); }
    }
    void restoreAfterAssert() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { Thread.currentThread().interrupt(); assert Thread.interrupted(); Thread.currentThread().interrupt(); }
    }
    void restoringOnlyInAssertIsOptional() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { assert ((BooleanSupplier) () -> { Thread.currentThread().interrupt(); return true; }).getAsBoolean(); }
    }
    void restoreInOwningFinally() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { System.out.println(ex); }
        finally { Thread.currentThread().interrupt(); }
    }
    void restoreReturnInOwningFinally() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { return; }
        finally { Thread.currentThread().interrupt(); }
    }
    void conditionalRestoreInOwningFinally(boolean restore) {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { System.out.println(ex); }
        finally { if (restore) Thread.currentThread().interrupt(); }
    }
    void owningFinallyClearsRestoration() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
        finally { Thread.interrupted(); }
    }
    void rethrowWithClearingFinally() throws InterruptedException {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { throw ex; }
        finally { Thread.interrupted(); }
    }
    void rethrowSuppressedByFinallyReturn() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { throw ex; }
        finally { return; }
    }
    void rethrowSuppressedByFinallyThrow() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { throw ex; }
        finally { throw new IllegalStateException(); }
    }
    void directLambdaRestoresInterrupt() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { ((Runnable) () -> Thread.currentThread().interrupt()).run(); }
    }
    void directLambdaClearsInterrupt() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { Thread.currentThread().interrupt(); ((Runnable) () -> Thread.interrupted()).run(); }
    }
    void directLambdaReturnResumesCatch() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { ((Runnable) () -> { return; }).run(); Thread.currentThread().interrupt(); }
    }
    void directLambdaThrowSkipsRestoration() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) { ((Runnable) () -> { throw new IllegalStateException(); }).run(); Thread.currentThread().interrupt(); }
    }

    void repeatedAcquisitionWithNestedReleases() {
        try { for (int i = 0; i < 2; i++) lock.lock(); }
        finally { lock.unlock(); try { } finally { lock.unlock(); } }
    }
    void repeatedAcquisitionWithNestedFirstRelease() {
        try { for (int i = 0; i < 2; i++) lock.lock(); }
        finally { try { } finally { lock.unlock(); } lock.unlock(); }
    }
    void nestedTryMayPreventLaterRelease() {
        try { for (int i = 0; i < 2; i++) lock.lock(); }
        finally { try { System.out.println("can throw"); } finally { lock.unlock(); } lock.unlock(); }
    }
    void fractionalDoubleLoopUnderReleased() {
        try { for (int i = 0; i < 2.5; i++) lock.lock(); }
        finally { lock.unlock(); lock.unlock(); }
    }
    void fractionalDoubleLoopBalanced() {
        try { for (int i = 0; i < 2.5; i++) lock.lock(); }
        finally { lock.unlock(); lock.unlock(); lock.unlock(); }
    }
    void halfIterationStillAcquires() {
        try { for (int i = 0; i < 0.5; i++) lock.lock(); lock.lock(); }
        finally { lock.unlock(); }
    }
    void fractionalFloatLoopUnderReleased() {
        try { for (int i = 0; i <= 2.5f; i++) lock.lock(); }
        finally { lock.unlock(); lock.unlock(); }
    }
    void descendingFractionalLoopUnderReleased() {
        try { for (int i = 2; i > -0.5; i--) lock.lock(); }
        finally { lock.unlock(); lock.unlock(); }
    }
    void nanBoundDoesNotAcquire() {
        try { for (int i = 0; i < Double.NaN; i++) lock.lock(); }
        finally { if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    void infiniteBoundAcquiresRepeatedly() {
        try { for (int i = 0; i < Double.POSITIVE_INFINITY; i++) lock.lock(); }
        finally { lock.unlock(); }
    }
    void floatRoundingCanRepeatAnInclusiveBound() {
        try { for (int i = 16777216; i <= 16777216f; i++) lock.lock(); }
        finally { lock.unlock(); }
    }
    void infiniteLambdaInConditionalExpression() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) {
            if (((BooleanSupplier) () -> { while (true) { } }).getAsBoolean() ? Thread.interrupted() : Thread.interrupted()) { }
            Thread.currentThread().interrupt();
        }
    }
    void infiniteLambdaInShortCircuitExpression() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) {
            if (((BooleanSupplier) () -> { while (true) { } }).getAsBoolean() && Thread.interrupted()) { }
            Thread.currentThread().interrupt();
        }
    }
    void throwingLambdaInConditionalExpression() {
        try { Thread.sleep(1); }
        catch (InterruptedException ex) {
            if (((BooleanSupplier) () -> { throw new IllegalStateException(); }).getAsBoolean() ? Thread.interrupted() : Thread.interrupted()) { }
            Thread.currentThread().interrupt();
        }
    }
    void nanInequalityAcquiresRepeatedly() {
        try { for (int i = 0; i != Double.NaN; i++) lock.lock(); }
        finally { lock.unlock(); }
    }
}
