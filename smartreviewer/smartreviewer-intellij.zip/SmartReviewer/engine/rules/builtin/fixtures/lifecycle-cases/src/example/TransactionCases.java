package example;
import org.springframework.transaction.annotation.Transactional;
public class TransactionCases {
    void selfCall() { save(); }
    void externalCall(TransactionCases proxy) { proxy.save(); }
    @Transactional void newTransactionCaller() { isolated(); }
    @Transactional(propagation=org.springframework.transaction.annotation.Propagation.REQUIRES_NEW) void isolated() { }
    @Transactional void save() { }
    @Transactional void existingTransaction() { save(); }
}
