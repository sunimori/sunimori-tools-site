package example;

import java.net.URI;
import java.net.URL;
import java.text.MessageFormat;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Cases for SR-SEC-SSRF-001: where the host of the target is fixed by constant text, a configured base URL or a table, and where
 * request text can still reach it (fixes of the 2026-10-26 review, area S1; case ids start with fx).
 */
public class FixS1Cases {
    private static final Map<String, String> ENDPOINTS = Map.of("eu", "https://eu.example.com/api", "us", "https://us.example.com/api");
    private static final Set<String> HOSTS = Set.of("api.example.com", "files.example.com");

    private String apiBase;
    private final String configuredBase;

    FixS1Cases(String configuredBase) {
        this.configuredBase = configuredBase;
    }

    /** fx-format-fixed: the text before the placeholder is a scheme, a host and a path. */
    void formatFixedHost(HttpServletRequest request) throws Exception {
        String url = String.format("https://api.example.com/v1/users/%s", request.getParameter("userId"));
        new URL(url).openConnection();
    }

    /** fx-format-host: the placeholder is the host. */
    void formatDynamicHost(HttpServletRequest request) throws Exception {
        String url = String.format("https://%s/v1/", request.getParameter("host"));
        new URL(url).openConnection();
    }

    /** fx-format-host-tail: the placeholder follows the host without a slash, so it can extend the host name. */
    void formatHostTail(HttpServletRequest request) throws Exception {
        String url = String.format("https://api.example.com%s", request.getParameter("suffix"));
        new URL(url).openConnection();
    }

    /** fx-builder-fixed. */
    void builderFixedHost(HttpServletRequest request) throws Exception {
        StringBuilder sb = new StringBuilder("https://api.example.com/v1/users/");
        sb.append(request.getParameter("userId"));
        new URL(sb.toString()).openConnection();
    }

    /** fx-builder-host. */
    void builderDynamicHost(HttpServletRequest request) throws Exception {
        StringBuilder sb = new StringBuilder("https://");
        sb.append(request.getParameter("host")).append("/v1/");
        new URL(sb.toString()).openConnection();
    }

    /** fx-message-format-fixed. */
    void messageFormatFixedHost(HttpServletRequest request) throws Exception {
        String url = MessageFormat.format("https://api.example.com/v1/users/{0}", request.getParameter("userId"));
        new URL(url).openConnection();
    }

    /** fx-base-field: a configured base URL, a slash, then the request text. */
    void configuredField(HttpServletRequest request) throws Exception {
        new URL(apiBase + "/orders/" + request.getParameter("id")).openConnection();
    }

    /** fx-base-final-field. */
    void configuredFinalField(HttpServletRequest request) throws Exception {
        new URL(configuredBase + "/users/" + request.getParameter("userId")).openConnection();
    }

    /** fx-base-local: a local that holds a literal but is not final. */
    void configuredLocal(HttpServletRequest request) throws Exception {
        String baseUrl = "https://crm.example.com/api";
        String no = request.getParameter("customerNo");
        new URL(baseUrl + "/customers/" + no).openConnection();
    }

    /** fx-base-port: a host from a system property, then constant text with a path. */
    void configuredHostAndPort(HttpServletRequest request) throws Exception {
        String host = System.getProperty("backend.host", "backend.internal");
        new URL("http://" + host + ":8080/items/" + request.getParameter("itemId")).openConnection();
    }

    /** fx-base-no-slash: the request text follows the base URL directly and can extend its host name. */
    void configuredNoSlash(HttpServletRequest request) throws Exception {
        new URL(apiBase + request.getParameter("path")).openConnection();
    }

    /** fx-base-scheme: a configured scheme, then the request text is the host. */
    void configuredSchemeRequestHost(HttpServletRequest request) throws Exception {
        new URL(apiBase + "://" + request.getParameter("host") + "/status").openConnection();
    }

    /** fx-table: the target is chosen from a fixed table by the request text. */
    void endpointTable(HttpServletRequest request) throws Exception {
        String endpoint = ENDPOINTS.get(request.getParameter("region"));
        if (endpoint == null) {
            throw new IllegalArgumentException("unknown region");
        }
        new URL(endpoint).openConnection();
    }

    /** fx-host-checked: the host of the parsed URL is in a fixed set. */
    void hostChecked(HttpServletRequest request) throws Exception {
        String target = request.getParameter("url");
        if (!HOSTS.contains(new URI(target).getHost())) {
            throw new IllegalArgumentException("host");
        }
        new URL(target).openConnection();
    }

    /** fx-host-unchecked: only the scheme is checked, the host is not. */
    void schemeChecked(HttpServletRequest request) throws Exception {
        String target = request.getParameter("url");
        if (!"https".equals(new URI(target).getScheme())) {
            throw new IllegalArgumentException("scheme");
        }
        new URL(target).openConnection();
    }

    /** fx-anonymous: a request value captured by an anonymous class. */
    Runnable anonymousCapture(HttpServletRequest request) {
        final String target = request.getParameter("url");
        return new Runnable() {
            @Override
            public void run() {
                try {
                    new URL(target).openConnection();
                } catch (java.io.IOException e) {
                    throw new IllegalStateException(e);
                }
            }
        };
    }

    /** fx-optional. */
    void optionalIfPresent(HttpServletRequest request) {
        Optional.ofNullable(request.getParameter("u")).ifPresent(u -> {
            try {
                new URL(u).openConnection();
            } catch (java.io.IOException e) {
                throw new IllegalStateException(e);
            }
        });
    }
}
