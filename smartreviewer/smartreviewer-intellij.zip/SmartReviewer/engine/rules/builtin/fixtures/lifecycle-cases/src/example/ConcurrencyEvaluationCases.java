package example;

import java.io.IOException;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.IntSupplier;

public class ConcurrencyEvaluationCases {
    static void interrupted() throws InterruptedException { throw new InterruptedException(); }
    static void io(int value) throws IOException { throw new IOException(); }
    static class Failing {
        Failing(int value) throws IOException { throw new IOException(); }
    }
    public static void callAfterLockArgument(ReentrantLock lock) {
        try { io(switch (1) { default -> { for (int i = 0; i < 2; i++) lock.lock(); yield 1; } }); }
        catch (IOException failure) { while (true) Thread.onSpinWait(); }
        finally { if (lock.isHeldByCurrentThread()) lock.unlock(); if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    public static void callAfterSingleLockArgument(ReentrantLock lock) {
        try { io(switch (1) { default -> { lock.lock(); yield 1; } }); }
        catch (IOException failure) { while (true) Thread.onSpinWait(); }
        finally { if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    public static void constructorAfterLockArgument(ReentrantLock lock) {
        try { new Failing(switch (1) { default -> { for (int i = 0; i < 2; i++) lock.lock(); yield 1; } }); }
        catch (IOException failure) { while (true) Thread.onSpinWait(); }
        finally { if (lock.isHeldByCurrentThread()) lock.unlock(); if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    public static void constructorAfterSingleLockArgument(ReentrantLock lock) {
        try { new Failing(switch (1) { default -> { lock.lock(); yield 1; } }); }
        catch (IOException failure) { while (true) Thread.onSpinWait(); }
        finally { if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    public static void throwAfterLockExpression(ReentrantLock lock) {
        try { throw switch (1) { default -> { for (int i = 0; i < 2; i++) lock.lock(); yield new IOException(); } }; }
        catch (IOException failure) { while (true) Thread.onSpinWait(); }
        finally { if (lock.isHeldByCurrentThread()) lock.unlock(); if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    public static void yieldingThroughWhile(boolean enter) {
        try {
            int value = switch (1) { default -> {
                while (enter) { try { interrupted(); } catch (InterruptedException swallowed) { } yield 1; }
                Thread.currentThread().interrupt(); yield 0;
            } };
        } finally { }
    }
    public static void yieldingThroughFor(boolean enter) {
        try {
            int value = switch (1) { default -> {
                for (; enter;) { try { interrupted(); } catch (InterruptedException swallowed) { } yield 1; }
                Thread.currentThread().interrupt(); yield 0;
            } };
        } finally { }
    }
    public static void yieldingThroughSwitch(int mode) {
        try {
            int value = switch (1) { default -> {
                switch (mode) { case 1: try { interrupted(); } catch (InterruptedException swallowed) { } yield 1; default: break; }
                Thread.currentThread().interrupt(); yield 0;
            } };
        } finally { }
    }
    public static void yieldFinallyRestores(boolean enter) {
        try {
            int value = switch (1) { default -> {
                while (enter) {
                    try { try { interrupted(); } catch (InterruptedException swallowed) { } yield 1; }
                    finally { Thread.currentThread().interrupt(); }
                }
                yield 0;
            } };
        } finally { }
    }
    public static void falseYieldSkipsAndClear() {
        try {
            boolean value = switch (1) { default -> {
                try { interrupted(); } catch (InterruptedException restored) { Thread.currentThread().interrupt(); }
                yield false;
            } } && Thread.interrupted();
        } finally { }
    }
    public static void trueYieldSkipsOrClear() {
        try {
            boolean value = switch (1) { default -> {
                try { interrupted(); } catch (InterruptedException restored) { Thread.currentThread().interrupt(); }
                yield true;
            } } || Thread.interrupted();
        } finally { }
    }
    public static void trueYieldEvaluatesAndClear() {
        try {
            boolean value = switch (1) { default -> {
                try { interrupted(); } catch (InterruptedException restored) { Thread.currentThread().interrupt(); }
                yield true;
            } } && Thread.interrupted();
        } finally { }
    }
    public static void falseYieldEvaluatesOrClear() {
        try {
            boolean value = switch (1) { default -> {
                try { interrupted(); } catch (InterruptedException restored) { Thread.currentThread().interrupt(); }
                yield false;
            } } || Thread.interrupted();
        } finally { }
    }
    public static void unknownYieldMayClear(boolean take) {
        try {
            boolean value = switch (1) { default -> {
                try { interrupted(); } catch (InterruptedException restored) { Thread.currentThread().interrupt(); }
                yield take;
            } } && Thread.interrupted();
        } finally { }
    }
    public static void falseYieldSelectsElse() {
        try {
            boolean value = switch (1) { default -> {
                try { interrupted(); } catch (InterruptedException restored) { Thread.currentThread().interrupt(); }
                yield false;
            } } ? Thread.interrupted() : false;
        } finally { }
    }
    public static void falseYieldSkipsIfClear() {
        try {
            if (switch (1) { default -> {
                try { interrupted(); } catch (InterruptedException restored) { Thread.currentThread().interrupt(); }
                yield false;
            } }) Thread.interrupted();
        } finally { }
    }
    public static void nestedBooleanYieldSkipsClear() {
        try {
            boolean value = !(switch (1) { default -> { yield switch (2) { default -> {
                try { interrupted(); } catch (InterruptedException restored) { Thread.currentThread().interrupt(); }
                yield false;
            } }; } }) || Thread.interrupted();
        } finally { }
    }
    public static void unboxingAfterRestore(Integer number) {
        try { interrupted(); } catch (InterruptedException caught) {
            try {
                Thread.currentThread().interrupt();
                ((IntSupplier) () -> number).getAsInt();
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { } catch (NullPointerException expected) { }
        }
    }
    public static void unboxingAfterClear(Integer number) {
        try { interrupted(); } catch (InterruptedException caught) {
            try {
                Thread.currentThread().interrupt();
                Thread.interrupted();
                ((IntSupplier) () -> number).getAsInt();
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException swallowed) { }
        }
    }
    public static void branchRestoresBeforeUnboxing(Integer number, boolean take) {
        try { interrupted(); } catch (InterruptedException caught) {
            try {
                if (take) Thread.currentThread().interrupt(); else Thread.currentThread().interrupt();
                ((IntSupplier) () -> number).getAsInt();
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { } catch (NullPointerException expected) { }
        }
    }
    public static void branchMayClearBeforeUnboxing(Integer number, boolean clear) {
        try { interrupted(); } catch (InterruptedException caught) {
            try {
                Thread.currentThread().interrupt();
                if (clear) Thread.interrupted();
                ((IntSupplier) () -> number).getAsInt();
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException swallowed) { }
        }
    }
    static void helper(Integer number) throws IOException { if (number == null) throw new IOException(); }
    public static void nestedAllCatchRestores(Integer number) {
        try { interrupted(); } catch (InterruptedException caught) {
            try {
                try { ((IntSupplier) () -> number).getAsInt(); } catch (Throwable expected) { Thread.currentThread().interrupt(); }
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException unreachable) { }
        }
    }
    public static void nestedNpeCatchRestores(Integer number) {
        try { interrupted(); } catch (InterruptedException caught) {
            try {
                try { ((IntSupplier) () -> number).getAsInt(); } catch (NullPointerException expected) { Thread.currentThread().interrupt(); }
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException unreachable) { }
        }
    }
    public static void nestedFinallyRestores(Integer number) {
        try { interrupted(); } catch (InterruptedException caught) {
            try {
                try { ((IntSupplier) () -> number).getAsInt(); } finally { Thread.currentThread().interrupt(); }
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException preserved) { }
        }
    }
    public static void nestedEscapingNpeClears(Integer number) {
        try { interrupted(); } catch (InterruptedException caught) {
            try {
                try { Thread.currentThread().interrupt(); ((IntSupplier) () -> number).getAsInt(); } catch (IllegalArgumentException expected) { }
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException cleared) { Thread.interrupted(); }
        }
    }
    public static void handlerFailureCrossesFinally(Integer number) {
        try { interrupted(); } catch (InterruptedException caught) {
            try {
                try { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
                catch (IllegalArgumentException expected) { ((IntSupplier) () -> number).getAsInt(); }
                finally { Thread.currentThread().interrupt(); }
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException preserved) { }
        }
    }
    public static void nestedUnknownCaughtRestores(Integer number) {
        try { interrupted(); } catch (InterruptedException caught) {
            try {
                try { helper(number); } catch (Throwable expected) { Thread.currentThread().interrupt(); }
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (NullPointerException unreachable) { }
        }
    }
    public static void nestedUnknownMayEscape(Integer number) {
        try { interrupted(); } catch (InterruptedException caught) {
            try {
                try { helper(number); } catch (NullPointerException expected) { Thread.currentThread().interrupt(); }
                ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
            } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); } catch (IOException swallowed) { }
        }
    }
}
