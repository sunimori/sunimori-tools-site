package example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Stream;

/** Initializer blocks and lambda bodies hold statements like methods do: locks, interrupts, streams and lists are followed in them too. */
public class InitializerCases {
    static final Lock SHARED = new ReentrantLock();

    static class LockInStaticBlock {
        static { SHARED.lock(); work(); SHARED.unlock(); }
        static void work() { }
    }
    static class LockReleasedInStaticBlock {
        static { SHARED.lock(); try { work(); } finally { SHARED.unlock(); } }
        static void work() { }
    }
    static class LockInInstanceBlock {
        final Lock lock = new ReentrantLock();
        { lock.lock(); work(); lock.unlock(); }
        void work() { }
    }
    static class LockReleasedInInstanceBlock {
        final Lock lock = new ReentrantLock();
        { lock.lock(); try { work(); } finally { lock.unlock(); } }
        void work() { }
    }
    // The lock is a field of the enclosing class, reached from the block of an inner class.
    final Lock outer = new ReentrantLock();
    class InnerBlockReleasingOuterLock {
        { outer.lock(); try { work(); } finally { outer.unlock(); } }
        void work() { }
    }

    static class InterruptSwallowedInStaticBlock {
        static { try { Thread.sleep(1); } catch (InterruptedException e) { System.out.println(e); } }
    }
    static class InterruptRestoredInStaticBlock {
        static { try { Thread.sleep(1); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }
    }

    static class StreamReusedInStaticBlock {
        static { Stream<String> a = Stream.of("a"); Stream<String> b = a; a.count(); b.findFirst(); }
    }
    static class StreamUsedOnceInStaticBlock {
        static { Stream<String> a = Stream.of("a"); a.count(); }
    }

    static class FixedListResizedInInstanceBlock {
        { List<String> a = Arrays.asList("a"); List<String> b = a; b.add("b"); }
    }
    static class CopiedListResizedInInstanceBlock {
        { List<String> a = new ArrayList<>(Arrays.asList("a")); a.add("b"); }
    }

    // Lambda bodies are scopes of their own, as methods are.
    static class LockInLambda {
        void run(ExecutorService pool) { pool.submit(() -> { SHARED.lock(); work(); SHARED.unlock(); }); }
        static void work() { }
    }
    static class LockReleasedInLambda {
        void run(ExecutorService pool) { pool.submit(() -> { SHARED.lock(); try { work(); } finally { SHARED.unlock(); } }); }
        static void work() { }
    }
    static class InterruptSwallowedInLambda {
        void run(ExecutorService pool) {
            pool.submit(() -> { try { Thread.sleep(1); } catch (InterruptedException e) { System.out.println(e); } });
        }
    }
    static class InterruptRestoredInLambda {
        void run(ExecutorService pool) {
            pool.submit(() -> { try { Thread.sleep(1); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } });
        }
    }
    static class StreamReusedInLambda {
        void run(List<String> names) {
            names.forEach(name -> { Stream<String> a = Stream.of(name); Stream<String> b = a; a.count(); b.findFirst(); });
        }
    }
    static class StreamUsedOnceInLambda {
        void run(List<String> names) { names.forEach(name -> { Stream<String> a = Stream.of(name); a.count(); }); }
    }
    static class StreamOfTheMethodInLambda {
        // The stream belongs to the method: what a lambda does with it later is not inferred.
        void run(Stream<String> stream) { Runnable r = () -> stream.count(); r.run(); stream.findFirst(); }
    }
    static class FixedListResizedInLambda {
        void run(ExecutorService pool) {
            pool.submit(() -> { List<String> a = Arrays.asList("a"); List<String> b = a; b.add("b"); });
        }
    }
    static class CopiedListResizedInLambda {
        void run(ExecutorService pool) {
            pool.submit(() -> { List<String> a = new ArrayList<>(Arrays.asList("a")); a.add("b"); });
        }
    }
}
