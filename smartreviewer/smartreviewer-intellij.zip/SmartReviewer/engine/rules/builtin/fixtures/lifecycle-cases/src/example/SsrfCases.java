package example;
import java.net.*;
import java.net.http.*;
import jakarta.servlet.http.HttpServletRequest;
public class SsrfCases {
    void requested(HttpServletRequest request) throws Exception { String target = request.getParameter("url"); URL u = new URL(target); u.openConnection(); }
    void fixed(HttpServletRequest request) throws Exception { new URL("https://example.org/data").openConnection(); }
    void fixedHost(HttpServletRequest request) throws Exception { new URL("https://example.org/search?q=" + request.getParameter("q")).openStream(); }
    void dynamicHost(HttpServletRequest request) throws Exception { new URL("https://" + request.getParameter("host") + "/").openStream(); }
    void weakGuard(HttpServletRequest request) throws Exception { String url=request.getParameter("url"); if(url.startsWith("http")) new URL(url).openConnection(); }
    void encoded(HttpServletRequest request) throws Exception { new URL(URLEncoder.encode(request.getParameter("url"), "UTF-8")).openConnection(); }
    void client(HttpServletRequest request) throws Exception { HttpRequest.newBuilder(URI.create(request.getParameter("url"))).GET().build(); }
    void strippedPrefix(HttpServletRequest request) throws Exception {
        String wrapped = "https://example.org/" + request.getParameter("url");
        new URL(wrapped.substring("https://example.org/".length())).openConnection();
    }
    void replacedPrefix(HttpServletRequest request) throws Exception {
        String wrapped = "https://example.org/" + request.getParameter("url");
        new URL(wrapped.replace("https://example.org/", "")).openStream();
    }
    void fixedHostAlias(HttpServletRequest request) throws Exception {
        String target = "https://example.org/" + request.getParameter("path");
        new URL(target + "?format=json").openConnection();
    }
    void fixedHostClient(HttpServletRequest request) throws Exception {
        HttpRequest.newBuilder(URI.create("https://example.org/search?q=" + request.getParameter("q"))).GET().build();
    }
}
