package example;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/** Exposes its lock through a trivial getter declared in another compilation unit than its callers. */
public final class LockHolder {
    private final Lock lock = new ReentrantLock();

    public Lock lock() {
        return lock;
    }

    public Lock fresh() {
        return new ReentrantLock();
    }
}
