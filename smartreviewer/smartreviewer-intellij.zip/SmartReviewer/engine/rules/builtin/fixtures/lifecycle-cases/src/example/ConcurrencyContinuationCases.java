package example;

import java.util.concurrent.locks.*;
import java.util.function.IntSupplier;
import java.io.*;
public class ConcurrencyContinuationCases {
  static void interrupted() throws InterruptedException { throw new InterruptedException(); }
  static void io(boolean fail) throws IOException { if(fail) throw new IOException(); }
  public static void lambdaUnboxing(Integer number) {
    try { interrupted(); } catch (InterruptedException e) {
      try {
        ((IntSupplier) () -> { return number; }).getAsInt();
        ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
      } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
      catch (NullPointerException swallowed) { }
    }
  }
  public static void yieldBeforeInfinite() {
    try {
      int value = switch(1) {
        default -> { try { interrupted(); } catch(InterruptedException e) { } yield 1; }
      };
      while(true) { Thread.onSpinWait(); }
    } finally { Thread.currentThread().interrupt(); }
  }
  public static void yieldThenClear(int mode) {
    try {
      int value = switch(mode) {
        case 1 -> { try { interrupted(); } catch(InterruptedException e) { Thread.currentThread().interrupt(); } yield 1; }
        default -> 0;
      };
      Thread.interrupted();
    } finally { }
  }
  public static void yieldThenRestore(int mode) {
    try {
      int value = switch(mode) {
        case 1 -> { try { interrupted(); } catch(InterruptedException e) { } yield 1; }
        default -> 0;
      };
      Thread.currentThread().interrupt();
    } finally { }
  }
  public static void arrowArgumentAfterCatch() {
    try {
      consume(switch(1) { default -> { try { interrupted(); } catch(InterruptedException e) { Thread.currentThread().interrupt(); } yield 1; } }, Thread.interrupted());
    } finally { }
  }
  static void consume(int i, boolean b) { }
  public static void safeIoBeforeLocks(ReentrantLock lock, boolean fail) {
    try {
      io(fail);
      for(int i=0;i<2;i++) lock.lock();
    } catch(IOException e) { while(true) { Thread.onSpinWait(); } }
    finally { if(lock.isHeldByCurrentThread()) lock.unlock(); if(lock.isHeldByCurrentThread()) lock.unlock(); }
  }
  public static void nestedTryAfterFinalUnlock(ReentrantLock lock) {
    try { for(int i=0;i<2;i++) lock.lock(); }
    finally {
      lock.unlock();
      try { while(true) { Thread.onSpinWait(); } }
      finally { lock.unlock(); }
    }
  }
  public static void localInfiniteFinally(ReentrantLock lock) {
    lock.lock();
    try { while(true) { Thread.onSpinWait(); } } finally { lock.unlock(); }
  }

  public static void expressionLambdaUnboxing(Integer number) {
    try { interrupted(); } catch (InterruptedException e) {
      try {
        ((IntSupplier) () -> number).getAsInt();
        ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
      } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
      catch (NullPointerException swallowed) { }
    }
  }
  public static void primitiveLambdaReturn(int number) {
    try { interrupted(); } catch (InterruptedException e) {
      try {
        ((IntSupplier) () -> { return number; }).getAsInt();
        ((Runnable) () -> { throw new IllegalArgumentException(); }).run();
      } catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
      catch (NullPointerException unreachable) { }
    }
  }
  public static void yieldInEarlierArgumentRestores() {
    try {
      consume(switch(1) { default -> { try { interrupted(); } catch(InterruptedException e) { } yield 1; } }, false);
      Thread.currentThread().interrupt();
    } finally { }
  }
  public static void yieldInConditionalArmSkipsOtherArm() {
    try {
      boolean value = true ? switch(1) { default -> { try { interrupted(); } catch(InterruptedException e) { Thread.currentThread().interrupt(); } yield true; } } : Thread.interrupted();
    } finally { }
  }
  public static void traditionalYieldThenClear() {
    try {
      int value = switch(1) { default: try { interrupted(); } catch(InterruptedException e) { Thread.currentThread().interrupt(); } yield 1; };
      Thread.interrupted();
    } finally { }
  }
  public static void nestedYieldThenRestore() {
    try {
      int value = switch(1) { default -> { yield switch(2) { default -> { try { interrupted(); } catch(InterruptedException e) { } yield 1; } }; } };
      Thread.currentThread().interrupt();
    } finally { }
  }
  public static void ioAfterLocks(ReentrantLock lock, boolean fail) {
    try { for(int i=0;i<2;i++) lock.lock(); io(fail); }
    catch(IOException e) { while(true) { Thread.onSpinWait(); } }
    finally { if(lock.isHeldByCurrentThread()) lock.unlock(); if(lock.isHeldByCurrentThread()) lock.unlock(); }
  }
  public static void nestedReturningTryReleases(ReentrantLock lock) {
    try { for(int i=0;i<2;i++) lock.lock(); }
    finally { lock.unlock(); try { return; } finally { lock.unlock(); } }
  }
  public static void nestedThrowingTryReleases(ReentrantLock lock) {
    try { for(int i=0;i<2;i++) lock.lock(); }
    finally { lock.unlock(); try { throw new IllegalStateException(); } finally { lock.unlock(); } }
  }
  public static void nestedDivergingCatch(ReentrantLock lock) {
    try { for(int i=0;i<2;i++) lock.lock(); }
    finally {
      lock.unlock();
      try { throw new IllegalStateException(); }
      catch(IllegalStateException e) { while(true) { Thread.onSpinWait(); } }
      finally { lock.unlock(); }
    }
  }

  public static void ioInLoopBeforeLocks(ReentrantLock lock, boolean fail) {
    try { for(int i=0;i<2;i++) { io(fail); lock.lock(); } }
    catch(IOException e) { while(true) { Thread.onSpinWait(); } }
    finally { if(lock.isHeldByCurrentThread()) lock.unlock(); if(lock.isHeldByCurrentThread()) lock.unlock(); }
  }
  public static void resourceCloseAfterLocks(ReentrantLock lock, Closeable resource) {
    try (resource) { for(int i=0;i<2;i++) lock.lock(); }
    catch(IOException e) { while(true) { Thread.onSpinWait(); } }
    finally { if(lock.isHeldByCurrentThread()) lock.unlock(); if(lock.isHeldByCurrentThread()) lock.unlock(); }
  }
  public static void switchInSelectorClears() {
    try {
      switch(switch(1) { default -> { try { interrupted(); } catch(InterruptedException e) { Thread.currentThread().interrupt(); } yield 1; } }) {
        default: Thread.interrupted();
      }
    } finally { }
  }
  public static void switchInLoopConditionCannotReachFinally() {
    try {
      while(switch(1) { default -> { try { interrupted(); } catch(InterruptedException e) { } yield true; } }) {
        while(true) { Thread.onSpinWait(); }
      }
    } finally { Thread.currentThread().interrupt(); }
  }
  public static int returnSwitchSkipsFollowingClear(boolean take) {
    try {
      if(take) return switch(1) { default -> { try { interrupted(); } catch(InterruptedException e) { Thread.currentThread().interrupt(); } yield 1; } };
      Thread.interrupted();
      return 0;
    } finally { }
  }
  public static void throwSwitchReachesHandler() {
    try {
      try {
        throw switch(1) { default -> { try { interrupted(); } catch(InterruptedException e) { } yield new IllegalArgumentException(); } };
      } catch(IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
    } finally { }
  }
  public static void unreachableLocalRemove(jakarta.servlet.http.HttpServletRequest request) {
    ThreadLocal<String> local = new ThreadLocal<>();
    local.set("value");
    try { while(true) { Thread.onSpinWait(); } } finally { local.remove(); }
  }
  public static void returningLocalRemove(jakarta.servlet.http.HttpServletRequest request) {
    ThreadLocal<String> local = new ThreadLocal<>();
    local.set("value");
    try { return; } finally { local.remove(); }
  }
  public static void resourceCloseAfterSingleLock(ReentrantLock lock, Closeable resource) {
    try (resource) { lock.lock(); }
    catch(IOException e) { while(true) { Thread.onSpinWait(); } }
    finally { if(lock.isHeldByCurrentThread()) lock.unlock(); }
  }
}
