package example;

import java.util.concurrent.locks.*;
import java.util.function.BooleanSupplier;
import jakarta.servlet.http.HttpServletRequest;

public class ConcurrencyBoundaryCases {
    Lock lock = new ReentrantLock();
    final ReadWriteLock rw = new ReentrantReadWriteLock();
    final ThreadLocal<String> local = new ThreadLocal<>();

    class Inner {
        void qualifiedThisLock() {
            ConcurrencyBoundaryCases.this.lock.lock();
            try { } finally { ConcurrencyBoundaryCases.this.lock.unlock(); }
        }
        void qualifiedAndImplicitThisLock() {
            ConcurrencyBoundaryCases.this.lock.lock();
            try { } finally { lock.unlock(); }
        }
        void qualifiedThisReadWriteLock() {
            ConcurrencyBoundaryCases.this.rw.writeLock().lock();
            try { } finally { ConcurrencyBoundaryCases.this.rw.writeLock().unlock(); }
        }
        void qualifiedThisThreadLocal(HttpServletRequest request) {
            try { ConcurrencyBoundaryCases.this.local.set("request"); }
            finally { ConcurrencyBoundaryCases.this.local.remove(); }
        }
    }
    void deferredLambdaWrite() {
        lock.lock();
        try { Runnable later = () -> { lock = new ReentrantLock(); }; }
        finally { lock.unlock(); }
    }
    void deferredLocalClassWrite() {
        lock.lock();
        try { class Later { void run() { lock = new ReentrantLock(); } } }
        finally { lock.unlock(); }
    }
    void deferredAnonymousMethodWrite() {
        lock.lock();
        try { Runnable later = new Runnable() { public void run() { lock = new ReentrantLock(); } }; }
        finally { lock.unlock(); }
    }
    void executedAnonymousInitializerWrite() {
        lock.lock();
        try { Object now = new Object() { { lock = new ReentrantLock(); } }; }
        finally { lock.unlock(); }
    }
    void twoAcquisitionsOneRelease() {
        try { lock.lock(); lock.lock(); }
        finally { lock.unlock(); }
    }
    void twoAcquisitionsTwoReleases() {
        try { lock.lock(); lock.lock(); }
        finally { lock.unlock(); lock.unlock(); }
    }
    void nestedBalancedAcquisitions() {
        lock.lock();
        try { lock.lock(); try { } finally { lock.unlock(); } }
        finally { lock.unlock(); }
    }
    void exclusiveAcquisitions(boolean flag) {
        try { if (flag) lock.lock(); else lock.lock(); }
        finally { lock.unlock(); }
    }
    void exclusiveAndUnconditionalAcquisitions(boolean flag) {
        try { if (flag) lock.lock(); else lock.lock(); lock.lock(); }
        finally { lock.unlock(); }
    }
    void exclusiveSwitchAcquisitions(int choice) {
        try { switch (choice) { case 1: lock.lock(); break; default: lock.lock(); break; } }
        finally { lock.unlock(); }
    }
    void exclusiveSwitchRuleAcquisitions(int choice) {
        try { switch (choice) { case 1 -> lock.lock(); default -> lock.lock(); } }
        finally { lock.unlock(); }
    }
    void fallThroughAcquisitions(int choice) {
        try { switch (choice) { case 1: lock.lock(); default: lock.lock(); } }
        finally { lock.unlock(); }
    }
    void multipleThreadLocalSets(HttpServletRequest request) {
        try { local.set("first"); local.set("second"); }
        finally { local.remove(); }
    }
    void clearingInterruptInitializer() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); boolean cleared = Thread.interrupted(); }
    }
    void clearingInterruptCondition() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); if (Thread.interrupted()) { } }
    }
    void clearingInterruptArgument() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); Boolean.valueOf(Thread.interrupted()); }
    }
    boolean clearingInterruptReturn() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); return Thread.interrupted(); }
        return false;
    }
    void clearingInterruptShortCircuit(boolean flag) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); boolean cleared = flag && Thread.interrupted(); }
    }
    void restoringAfterInterruptInitializer() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { boolean cleared = Thread.interrupted(); Thread.currentThread().interrupt(); }
    }
    void restoringAfterInterruptCondition() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); if (Thread.interrupted()) { Thread.currentThread().interrupt(); } else { Thread.currentThread().interrupt(); } }
    }
    void skippedInterruptClear() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); boolean skipped = false && Thread.interrupted(); }
    }
    void skippedInterruptClearOr() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); boolean skipped = true || Thread.interrupted(); }
    }
    void restoringOnlyAfterTrueInterruptTest() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); if (Thread.interrupted()) Thread.currentThread().interrupt(); }
    }
    void restoringOnlyAfterNegatedInterruptTest() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); if (!Thread.interrupted()) { } else Thread.currentThread().interrupt(); }
    }
    void clearingInterruptWhileCondition() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); while (Thread.interrupted()) { break; } }
    }
    void clearingInterruptForCondition() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); for (; Thread.interrupted();) { break; } }
    }
    void clearingInterruptForInitializer() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); for (boolean cleared = Thread.interrupted(); cleared;) { break; } }
    }
    void clearingInterruptForUpdater() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); for (int i = 0; i < 1; Thread.interrupted(), i++) { } }
    }
    void clearingInterruptSwitchSelector() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); switch (Thread.interrupted() ? 1 : 0) { default: break; } }
    }
    void clearingInterruptMonitor() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); synchronized (Boolean.valueOf(Thread.interrupted())) { } }
    }
    void optionalLoopRestoration(boolean run) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { while (run) { Thread.currentThread().interrupt(); break; } }
    }
    void restoringInEnteredWhileBody() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); while (Thread.interrupted()) { Thread.currentThread().interrupt(); break; } }
    }
    void restoringInDoBody() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { do { Thread.currentThread().interrupt(); } while (false); }
    }
    void clearingInDoCondition() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); do { } while (Thread.interrupted()); }
    }
    void breakSkipsForUpdater() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); for (;; Thread.interrupted()) { break; } }
    }
    void continueRunsForUpdater(boolean run) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); for (; run; Thread.interrupted()) { continue; } }
    }
    void returningFromLoopPreservesRestoration(boolean run) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); while (run) { return; } }
    }
    void labelledBreakSkipsRestoration(boolean run) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { outer: while (true) { while (run) { break outer; } Thread.currentThread().interrupt(); } }
    }
    void labelledBreakThenRestore() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { outer: while (true) { while (true) { break outer; } } Thread.currentThread().interrupt(); }
    }
    void labelledContinueSkipsRestoration(boolean run) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { outer: do { while (run) { continue outer; } Thread.currentThread().interrupt(); } while (false); }
    }
    void labelledContinueThroughFinallyRestores(boolean run) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { outer: do { try { while (run) { continue outer; } } finally { Thread.currentThread().interrupt(); } } while (false); }
    }
    void clearingInterruptAnonymousInitializer() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); Object now = new Object() { { Thread.interrupted(); } }; }
    }
    void clearingInterruptAnonymousFieldInitializer() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); Object now = new Object() { final boolean cleared = Thread.interrupted(); }; }
    }
    void deferredInterruptAnonymousMethod() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); BooleanSupplier later = new BooleanSupplier() { public boolean getAsBoolean() { return Thread.interrupted(); } }; }
    }
    void skippedInterruptConstantClear() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); final boolean CLEAR = false; boolean skipped = CLEAR && Thread.interrupted(); }
    }
    void restoringAfterEqualityInterruptTest() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); if (Thread.interrupted() == true) Thread.currentThread().interrupt(); }
    }
    void restoringAfterReversedEqualityInterruptTest() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); if (false != Thread.interrupted()) Thread.currentThread().interrupt(); }
    }
    void deferredInterruptClear() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); BooleanSupplier later = () -> Thread.interrupted(); }
    }
    void deferredInterruptRestore() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { Runnable later = () -> Thread.currentThread().interrupt(); }
    }
}
