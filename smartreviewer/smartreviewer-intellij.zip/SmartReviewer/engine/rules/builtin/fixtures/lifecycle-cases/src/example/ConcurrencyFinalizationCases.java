package example;

import java.util.concurrent.Callable;
import java.util.concurrent.locks.ReentrantLock;

public class ConcurrencyFinalizationCases extends ConcurrencyFinalizationBase {
    final ReentrantLock lock = new ReentrantLock();
    void outerFinallyClears() {
        try {
            try { Thread.sleep(1); } catch (InterruptedException e) { }
            finally { Thread.currentThread().interrupt(); }
        } finally { Thread.interrupted(); }
    }
    void outerFinallyRestores() {
        try { try { Thread.sleep(1); } catch (InterruptedException e) { } }
        finally { Thread.currentThread().interrupt(); }
    }
    void outerFinallyRestoresReturningCatch() {
        try { try { Thread.sleep(1); } catch (InterruptedException e) { return; } }
        finally { Thread.currentThread().interrupt(); }
    }
    void outerFinallyRestoresThrowingCatch() {
        try { try { Thread.sleep(1); } catch (InterruptedException e) { throw new IllegalStateException(e); } }
        finally { Thread.currentThread().interrupt(); }
    }
    void threeFinalliesEndRestored() {
        try {
            try {
                try { Thread.sleep(1); } catch (InterruptedException e) { }
                finally { Thread.currentThread().interrupt(); }
            } finally { Thread.interrupted(); }
        } finally { Thread.currentThread().interrupt(); }
    }
    void outerFinallyCannotRepairInfiniteCatch() {
        try { try { Thread.sleep(1); } catch (InterruptedException e) { while (true) { } } }
        finally { Thread.currentThread().interrupt(); }
    }
    void infiniteTailSkipsOuterFinally() {
        try {
            try { Thread.sleep(1); } catch (InterruptedException e) { }
            while (true) { }
        } finally { Thread.currentThread().interrupt(); }
    }
    void infiniteEnclosingLoopSkipsOuterFinally() {
        try { while (true) { try { Thread.sleep(1); } catch (InterruptedException e) { } } }
        finally { Thread.currentThread().interrupt(); }
    }
    void breakReachesOuterFinally() {
        try {
            while (true) { try { Thread.sleep(1); } catch (InterruptedException e) { break; } }
        } finally { Thread.currentThread().interrupt(); }
    }
    void continueSkipsOuterFinally() {
        try {
            while (true) { try { Thread.sleep(1); } catch (InterruptedException e) { continue; } }
        } finally { Thread.currentThread().interrupt(); }
    }
    void arrowSwitchDoesNotRunTheFollowingInfiniteArm(int choice) {
        try {
            switch (choice) {
                case 0 -> { try { Thread.sleep(1); } catch (InterruptedException e) { } }
                default -> { while (true) { } }
            }
        } finally { Thread.currentThread().interrupt(); }
    }
    void arrowSwitchDoesNotBorrowTheFollowingRestoration(int choice) {
        try {
            switch (choice) {
                case 0 -> { try { Thread.sleep(1); } catch (InterruptedException e) { } }
                default -> Thread.currentThread().interrupt();
            }
        } finally { }
    }
    void traditionalSwitchContinuesIntoTheNextArm(int choice) {
        try {
            switch (choice) {
                case 0: try { Thread.sleep(1); } catch (InterruptedException e) { }
                default: Thread.currentThread().interrupt();
            }
        } finally { }
    }
    void conditionalOuterFinally(boolean restore) {
        try { try { Thread.sleep(1); } catch (InterruptedException e) { } }
        finally { if (restore) Thread.currentThread().interrupt(); }
    }
    void rethrowSuppressedByOuterFinally() throws InterruptedException {
        try { try { Thread.sleep(1); } catch (InterruptedException e) { throw e; } }
        finally { return; }
    }
    void outerFinallyClearsOnlyAfterInnerReturn() {
        try {
            try { Thread.sleep(1); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
        } finally { Thread.interrupted(); }
    }
    void directLambdaThrowsCaught() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException ex) { }
            Thread.currentThread().interrupt();
        }
    }
    void directLambdaThrowsCaughtBySupertype() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (RuntimeException ex) { }
            Thread.currentThread().interrupt();
        }
    }
    void directLambdaThrowsCaughtByUnion() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException | UnsupportedOperationException ex) { }
            Thread.currentThread().interrupt();
        }
    }
    void directLambdaThrowsUnmatchedCatch() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (UnsupportedOperationException ex) { }
            Thread.currentThread().interrupt();
        }
    }
    void directLambdaCaughtThrowExitsAgain() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException ex) { throw new UnsupportedOperationException(); }
            Thread.currentThread().interrupt();
        }
    }
    void directLambdaCaughtThrowPreservesFlag() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            try { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException ex) { }
        }
    }
    void directLambdaCaughtThrowClearsFlag() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            try { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException ex) { Thread.interrupted(); }
        }
    }
    void directLambdaFirstMatchingCatchWins() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException ex) { Thread.currentThread().interrupt(); }
            catch (RuntimeException ex) { }
        }
    }
    void directLambdaUnknownThrownTypeRemainsPossible(RuntimeException failure) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Runnable) () -> { throw failure; }).run(); }
            catch (IllegalArgumentException ex) { Thread.currentThread().interrupt(); }
        }
    }
    void helperBeforeKnownThrowCanEnterAnotherCatch() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { arbitrary(); throw new IllegalArgumentException(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (IllegalStateException other) { }
        }
    }
    void helperBeforeLambdaThrowCanEnterAnotherCatch() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { arbitrary(); ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (IllegalStateException other) { }
        }
    }
    void superHelperBeforeKnownThrowCanEnterAnotherCatch() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { super.helper(); throw new IllegalArgumentException(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (IllegalStateException other) { }
        }
    }
    void arithmeticBeforeKnownThrowCanEnterAnotherCatch(int divisor) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { int result = 1 / divisor; throw new IllegalArgumentException(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (ArithmeticException other) { }
        }
    }
    void arrayAccessBeforeKnownThrowCanEnterAnotherCatch(int[] input) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { int result = input[0]; throw new IllegalArgumentException(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (IndexOutOfBoundsException other) { }
        }
    }
    void objectCastBeforeKnownThrowCanEnterAnotherCatch(Object value) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { String cast = (String) value; throw new IllegalArgumentException(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (ClassCastException lost) { }
        }
    }
    void unboxingBeforeKnownThrowCanEnterAnotherCatch(Boolean condition) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { if (condition) { } throw new IllegalArgumentException(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (NullPointerException lost) { }
        }
    }
    void arrayCreationBeforeKnownThrowCanEnterAnotherCatch(int length) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { int[] allocated = new int[length]; throw new IllegalArgumentException(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (NegativeArraySizeException lost) { }
        }
    }
    void qualifiedKnownLambdaThrowSelectsOnlyItsCatch() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Runnable) () -> { throw new java.lang.IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (ClassCastException unreachable) { }
        }
    }
    void resourceInitializerThrowsBeforeKnownLambda() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try (java.io.Closeable resource = openResource()) { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (java.io.IOException lost) { }
        }
    }
    void laterResourceInitializerThrowsBeforeKnownLambda(java.io.Closeable existing) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try (existing; java.io.Closeable resource = openResource()) { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (java.io.IOException lost) { }
        }
    }
    void resourceInitializerFailureRestoresInterrupt() {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try (java.io.Closeable resource = openResource()) { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (java.io.IOException restored) { Thread.currentThread().interrupt(); }
        }
    }
    void closeFailureAfterNormalBodyCanClearInterrupt(java.io.Closeable existing) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try (existing) { Thread.currentThread().interrupt(); }
            catch (java.io.IOException cleared) { Thread.interrupted(); }
        }
    }
    void closeFailureAfterReturnCanClearInterrupt(java.io.Closeable existing) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try (existing) { Thread.currentThread().interrupt(); return; }
            catch (java.io.IOException cleared) { Thread.interrupted(); }
        }
    }
    void closeFailureAfterReturnRestoresInterrupt(java.io.Closeable existing) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try (existing) { Thread.currentThread().interrupt(); return; }
            catch (java.io.IOException restored) { Thread.currentThread().interrupt(); }
        }
    }
    void closeFailureIsSuppressedByKnownThrownException(java.io.Closeable existing) {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try (existing) { ((Runnable) () -> { throw new IllegalArgumentException(); }).run(); }
            catch (IllegalArgumentException expected) { Thread.currentThread().interrupt(); }
            catch (java.io.IOException unreachable) { }
        }
    }
    void closeFailureDoesNotReplaceRethrownInterrupt(java.io.Closeable existing) throws Exception {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try (existing) { ((Callable<Void>) () -> { throw e; }).call(); }
            catch (java.io.IOException unreachable) { }
        }
    }
    java.io.Closeable openResource() throws java.io.IOException { return null; }
    void directLambdaRethrows() throws Exception {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { ((Callable<Void>) () -> { throw e; }).call(); }
    }
    void directLambdaExpressionRethrows() throws Exception {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { ((Callable<Void>) () -> ((Callable<Void>) () -> { throw e; }).call()).call(); }
    }
    void directLambdaRethrowHasLocalReturn(boolean done) throws Exception {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { ((Callable<Void>) () -> { if (done) return null; throw e; }).call(); }
    }
    void directLambdaRethrowCaughtAndSwallowed() throws Exception {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Callable<Void>) () -> { throw e; }).call(); }
            catch (Exception ignored) { }
        }
    }
    void directLambdaRethrowCaughtAndRestored() throws Exception {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Callable<Void>) () -> { throw e; }).call(); }
            catch (Exception ignored) { Thread.currentThread().interrupt(); }
        }
    }
    void directLambdaRethrowCaughtAndRethrown() throws Exception {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Callable<Void>) () -> { throw e; }).call(); }
            catch (Exception same) { throw same; }
        }
    }
    void directLambdaRethrowCatchReassignsException() throws Exception {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Callable<Void>) () -> { throw e; }).call(); }
            catch (Exception replaced) { replaced = new IllegalStateException(); throw replaced; }
        }
    }
    void directLambdaRethrowCatchConditionallyReassignsException(boolean replace) throws Exception {
        try { Thread.sleep(1); }
        catch (InterruptedException e) {
            try { ((Callable<Void>) () -> { throw e; }).call(); }
            catch (Exception replaced) { if (replace) replaced = new IllegalStateException(); throw replaced; }
        }
    }
    void directLambdaWrapsInterrupt() throws Exception {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { ((Callable<Void>) () -> { throw new IllegalStateException(e); }).call(); }
    }
    void directLambdaRethrowSuppressedByFinally() throws Exception {
        try { Thread.sleep(1); }
        catch (InterruptedException e) { ((Callable<Void>) () -> { try { throw e; } finally { return null; } }).call(); }
    }
    void splitFinallyReleases() {
        try { try { for (int i = 0; i < 2; i++) lock.lock(); } finally { lock.unlock(); } }
        finally { lock.unlock(); }
    }
    void splitGuardedFinallyReleases(ReentrantLock candidate) {
        try { try { for (int i = 0; i < 2; i++) candidate.lock(); }
            finally { if (candidate.isHeldByCurrentThread()) candidate.unlock(); }
        } finally { if (candidate.isHeldByCurrentThread()) candidate.unlock(); }
    }
    void scopeSplitReleases() {
        try { for (int i = 0; i < 2; i++) lock.lock(); try { } finally { lock.unlock(); } }
        finally { lock.unlock(); }
    }
    void scopeSplitGuardedReleases() {
        try { for (int i = 0; i < 2; i++) lock.lock(); try { } finally { if (lock.isHeldByCurrentThread()) lock.unlock(); } }
        finally { if (lock.isHeldByCurrentThread()) lock.unlock(); }
    }
    void threeSplitFinallyReleases() {
        try { try { try { for (int i = 0; i < 3; i++) lock.lock(); } finally { lock.unlock(); } }
            finally { lock.unlock(); }
        } finally { lock.unlock(); }
    }
    void splitFinallyUnderReleased() {
        try { try { for (int i = 0; i < 3; i++) lock.lock(); } finally { lock.unlock(); } }
        finally { lock.unlock(); }
    }
    void conditionalSplitFinally(boolean release) {
        try { try { for (int i = 0; i < 2; i++) lock.lock(); } finally { if (release) lock.unlock(); } }
        finally { lock.unlock(); }
    }
    void divergentInnerFinallyPreventsOuterUnlock() {
        try { try { for (int i = 0; i < 2; i++) lock.lock(); } finally { lock.unlock(); while (true) { } } }
        finally { lock.unlock(); }
    }
    void throwingBeforeInnerUnlockLeavesOneHold() {
        try { try { for (int i = 0; i < 2; i++) lock.lock(); } finally { arbitrary(); lock.unlock(); } }
        finally { lock.unlock(); }
    }
    void returningAfterInnerUnlockStillRunsOuter() {
        try { try { for (int i = 0; i < 2; i++) lock.lock(); } finally { lock.unlock(); return; } }
        finally { lock.unlock(); }
    }
    void arbitraryWorkAfterLoopSkipsLocalUnlock() {
        try { for (int i = 0; i < 2; i++) lock.lock(); arbitrary(); try { } finally { lock.unlock(); } }
        finally { lock.unlock(); }
    }
    void arbitraryWorkInsideLoopSkipsLocalUnlock() {
        try { for (int i = 0; i < 2; i++) { lock.lock(); arbitrary(); } try { } finally { lock.unlock(); } }
        finally { lock.unlock(); }
    }
    void splitFinallyCannotShareOuterRelease() {
        try { try { for (int i = 0; i < 2; i++) lock.lock(); } finally { lock.unlock(); } lock.lock(); }
        finally { lock.unlock(); }
    }
    void failedSingleAcquisitionHasNoHoldToRelease(ReentrantLock candidate) {
        try { candidate.lock(); }
        catch (RuntimeException failure) { while (true) { } }
        finally { if (candidate.isHeldByCurrentThread()) candidate.unlock(); }
    }
    void failureAfterSingleAcquisitionCanPreventRelease(ReentrantLock candidate) {
        try { candidate.lock(); arbitrary(); }
        catch (RuntimeException failure) { while (true) { } }
        finally { if (candidate.isHeldByCurrentThread()) candidate.unlock(); }
    }
    void acquiringFailureDivergesBeforeBothFinallies(ReentrantLock candidate) {
        try {
            try { for (int i = 0; i < 2; i++) candidate.lock(); }
            catch (RuntimeException failure) { while (true) { } }
            finally { if (candidate.isHeldByCurrentThread()) candidate.unlock(); }
        } finally { if (candidate.isHeldByCurrentThread()) candidate.unlock(); }
    }
    void acquiringFailureReturnsThroughBothFinallies(ReentrantLock candidate) {
        try {
            try { for (int i = 0; i < 2; i++) candidate.lock(); }
            catch (RuntimeException failure) { return; }
            finally { if (candidate.isHeldByCurrentThread()) candidate.unlock(); }
        } finally { if (candidate.isHeldByCurrentThread()) candidate.unlock(); }
    }
    void acquiringFailureThrowsThroughBothFinallies(ReentrantLock candidate) {
        try {
            try { for (int i = 0; i < 2; i++) candidate.lock(); }
            catch (RuntimeException failure) { throw failure; }
            finally { if (candidate.isHeldByCurrentThread()) candidate.unlock(); }
        } finally { if (candidate.isHeldByCurrentThread()) candidate.unlock(); }
    }
    void arbitrary() { }
}

class ConcurrencyFinalizationBase {
    void helper() { }
}
