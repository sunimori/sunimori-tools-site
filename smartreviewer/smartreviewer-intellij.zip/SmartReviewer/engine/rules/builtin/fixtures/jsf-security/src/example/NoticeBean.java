package example;

/** A notice shown on the top page; its text is entered by an administrator (fixture). */
@javax.inject.Named("notice")
public class NoticeBean {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
