package example;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * Cases of SR-JAVA-JDBC-BATCH-001. The method names are unique in this file, so that every suite case can select one of them.
 */
public class JdbcBatchCases {
    private static final String SQL = "insert into t(id, name) values (?, ?)";
    private static final int BATCH_SIZE = 500;
    private PreparedStatement pending;
    private PreparedStatement shared;

    /** A row to insert. */
    record Row(int id, String name) { }

    private static void closeQuietly(Statement statement) {
        try {
            if (statement != null) {
                statement.close();
            }
        } catch (SQLException ignored) {
            // nothing to do
        }
    }

    private static void bind(PreparedStatement ps, Row row) throws SQLException {
        ps.setInt(1, row.id());
        ps.setString(2, row.name());
    }

    private static void flush(PreparedStatement ps) throws SQLException {
        ps.executeBatch();
    }

    private static void fill(PreparedStatement ps, Row row) throws SQLException {
        bind(ps, row);
        ps.addBatch();
    }

    // ------------------------------------------------------------------ the batch is never executed

    void neverExecuted(Connection con, List<Row> rows) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.setString(2, row.name());
                ps.addBatch();
            }
        }
    }

    void neverExecutedStatement(Connection con) throws SQLException {
        Statement st = con.createStatement();
        st.addBatch("insert into t(id) values (1)");
        st.addBatch("insert into t(id) values (2)");
        st.close();
    }

    void neverExecutedFinallyClose(Connection con, List<Row> rows) throws SQLException {
        PreparedStatement ps = null;
        try {
            ps = con.prepareStatement(SQL);
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
            }
        } finally {
            if (ps != null) {
                ps.close();
            }
        }
    }

    void neverExecutedCallable(Connection con, List<Row> rows) throws SQLException {
        try (CallableStatement call = con.prepareCall("{call add_row(?)}")) {
            for (Row row : rows) {
                call.setInt(1, row.id());
                call.addBatch();
            }
        }
    }

    void neverExecutedBinder(Connection con, List<Row> rows) throws SQLException {
        PreparedStatement ps = con.prepareStatement(SQL);
        try {
            for (Row row : rows) {
                bind(ps, row);
                ps.addBatch();
            }
        } finally {
            closeQuietly(ps);
        }
    }

    void neverExecutedVar(Connection con, List<Row> rows) throws SQLException {
        var ps = con.prepareStatement(SQL);
        for (Row row : rows) {
            ps.setInt(1, row.id());
            ps.addBatch();
        }
        ps.close();
    }

    void twoStatementsOneMissing(Connection con, List<Row> rows) throws SQLException {
        try (PreparedStatement inserts = con.prepareStatement(SQL); PreparedStatement audits = con.prepareStatement("insert into audit(id) values (?)")) {
            for (Row row : rows) {
                inserts.setInt(1, row.id());
                inserts.addBatch();
                audits.setInt(1, row.id());
                audits.addBatch();
            }
            inserts.executeBatch();
        }
    }

    void neverExecutedInLambda(Connection con, Consumer<Consumer<Connection>> work, List<Row> rows) {
        work.accept(c -> {
            try (PreparedStatement ps = c.prepareStatement(SQL)) {
                for (Row row : rows) {
                    ps.setInt(1, row.id());
                    ps.addBatch();
                }
            } catch (SQLException e) {
                throw new IllegalStateException(e);
            }
        });
    }

    void neverExecutedCast(Connection con) throws SQLException {
        Statement st = con.prepareStatement(SQL);
        ((PreparedStatement) st).addBatch();
        st.close();
    }

    // ------------------------------------------------------------------ only a periodic flush inside the loop

    void tailLost(Connection con, List<Row> rows) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++n % 1000 == 0) {
                    ps.executeBatch();
                }
            }
        }
    }

    void tailLostIndex(Connection con, Row[] rows) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (int i = 0; i < rows.length; i++) {
                ps.setInt(1, rows[i].id());
                ps.addBatch();
                if ((i + 1) % 500 == 0) {
                    ps.executeBatch();
                }
            }
        }
    }

    void tailLostThreshold(Connection con, List<Row> rows) throws SQLException {
        int count = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++count >= BATCH_SIZE) {
                    ps.executeBatch();
                    count = 0;
                }
            }
        }
    }

    void tailLostLimitVariable(Connection con, ResultSet rs, int batchSize) throws SQLException {
        int count = 0;
        PreparedStatement ps = con.prepareStatement(SQL);
        while (rs.next()) {
            ps.setInt(1, rs.getInt(1));
            ps.addBatch();
            count++;
            if (count == batchSize) {
                ps.executeBatch();
                count = 0;
            }
        }
        ps.close();
    }

    void tailLostWhile(Connection con, ResultSet rs) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            while (rs.next()) {
                ps.setInt(1, rs.getInt(1));
                ps.addBatch();
                n++;
                if (n % 100 == 0) ps.executeBatch();
            }
        }
    }

    void tailLostGuarded(Connection con, List<Row> rows) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                n++;
                if (n > 0 && n % 1000 == 0) {
                    ps.executeBatch();
                }
            }
        }
    }

    void tailLostOuterFlush(Connection con, List<List<Row>> groups) throws SQLException {
        int group = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (List<Row> rows : groups) {
                for (Row row : rows) {
                    ps.setInt(1, row.id());
                    ps.addBatch();
                }
                if (++group % 10 == 0) {
                    ps.executeBatch();
                }
            }
        }
    }

    void tailLostLambda(Connection con, List<Row> rows) throws SQLException {
        AtomicInteger n = new AtomicInteger();
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            rows.forEach(row -> {
                try {
                    ps.setInt(1, row.id());
                    ps.addBatch();
                    if (n.incrementAndGet() % 100 == 0) {
                        ps.executeBatch();
                    }
                } catch (SQLException e) {
                    throw new IllegalStateException(e);
                }
            });
        }
    }

    void tailLostClearedAfterFlush(Connection con, List<Row> rows) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++n % 1000 == 0) {
                    int[] counts = ps.executeBatch();
                    ps.clearBatch();
                }
            }
        }
    }

    // ------------------------------------------------------------------ the batch is executed

    void executedAfterLoop(Connection con, List<Row> rows) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    void executedInFinally(Connection con, List<Row> rows) throws SQLException {
        PreparedStatement ps = con.prepareStatement(SQL);
        try {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
            }
        } finally {
            ps.executeBatch();
            ps.close();
        }
    }

    void executedEveryIteration(Connection con, List<Row> rows) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                ps.executeBatch();
            }
        }
    }

    void periodicWithFinalFlush(Connection con, List<Row> rows) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++n % 1000 == 0) {
                    ps.executeBatch();
                }
            }
            if (n % 1000 != 0) {
                ps.executeBatch();
            }
        }
    }

    void periodicOrLastRow(Connection con, Iterator<Row> rows) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            while (rows.hasNext()) {
                Row row = rows.next();
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++n % 1000 == 0 || !rows.hasNext()) {
                    ps.executeBatch();
                }
            }
        }
    }

    void lastIndexFlush(Connection con, List<Row> rows) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (int i = 0; i < rows.size(); i++) {
                ps.setInt(1, rows.get(i).id());
                ps.addBatch();
                if (i == rows.size() - 1) {
                    ps.executeBatch();
                }
            }
        }
    }

    void lastConstantIndexFlush(Connection con) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (int i = 0; i < 10; i++) {
                ps.setInt(1, i);
                ps.addBatch();
                if (i == 9) {
                    ps.executeBatch();
                }
            }
        }
    }

    void lastRowFlush(Connection con, ResultSet rs) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            while (rs.next()) {
                ps.setInt(1, rs.getInt(1));
                ps.addBatch();
                if (rs.isLast()) {
                    ps.executeBatch();
                }
            }
        }
    }

    void executeLargeBatchAfterLoop(Connection con, List<Row> rows) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
            }
            ps.executeLargeBatch();
        }
    }

    void executedInLambda(Connection con, List<Row> rows) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            rows.forEach(row -> {
                try {
                    ps.setInt(1, row.id());
                    ps.addBatch();
                } catch (SQLException e) {
                    throw new IllegalStateException(e);
                }
            });
            ps.executeBatch();
        }
    }

    void nestedLoopsExecuted(Connection con, List<List<Row>> groups) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (List<Row> rows : groups) {
                for (Row row : rows) {
                    ps.setInt(1, row.id());
                    ps.addBatch();
                }
                ps.executeBatch();
            }
        }
    }

    void statementExecuted(Connection con) throws SQLException {
        try (Statement st = con.createStatement()) {
            st.addBatch("insert into t(id) values (1)");
            st.executeBatch();
        }
    }

    void twoStatementsBothExecuted(Connection con, List<Row> rows) throws SQLException {
        try (PreparedStatement a = con.prepareStatement(SQL); PreparedStatement b = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                a.setInt(1, row.id());
                a.addBatch();
                b.setInt(1, row.id());
                b.addBatch();
            }
            a.executeBatch();
            b.executeBatch();
        }
    }

    // ------------------------------------------------------------------ the statement leaves the method, or the batch is dropped on purpose

    void clearedOnPurpose(Connection con, boolean valid) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            ps.setInt(1, 1);
            ps.addBatch();
            if (valid) {
                ps.executeBatch();
            } else {
                ps.clearBatch();
            }
        }
    }

    void onlyClearedBatch(Connection con) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            ps.addBatch();
            ps.clearBatch();
        }
    }

    void executedByHelper(Connection con, List<Row> rows) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                fill(ps, row);
            }
            flush(ps);
        }
    }

    void passedToAnotherMethod(Connection con, List<Row> rows) throws SQLException {
        PreparedStatement ps = con.prepareStatement(SQL);
        for (Row row : rows) {
            ps.setInt(1, row.id());
            ps.addBatch();
        }
        flush(ps);
    }

    PreparedStatement returned(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement(SQL);
        ps.addBatch();
        return ps;
    }

    void storedInField(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement(SQL);
        ps.addBatch();
        this.pending = ps;
    }

    void aliased(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement(SQL);
        PreparedStatement same = ps;
        ps.addBatch();
        same.executeBatch();
    }

    void parameterStatement(PreparedStatement ps, List<Row> rows) throws SQLException {
        for (Row row : rows) {
            ps.setInt(1, row.id());
            ps.addBatch();
        }
    }

    void fieldStatement(List<Row> rows) throws SQLException {
        for (Row row : rows) {
            shared.setInt(1, row.id());
            shared.addBatch();
        }
    }

    void capturedByAnonymousClass(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement(SQL);
        ps.addBatch();
        Runnable later = new Runnable() {
            @Override public void run() {
                try {
                    ps.executeBatch();
                } catch (SQLException e) {
                    throw new IllegalStateException(e);
                }
            }
        };
        later.run();
    }

    void cachedStatement(java.util.Map<String, PreparedStatement> cache, String key, Row row) throws SQLException {
        PreparedStatement ps = cache.get(key);
        ps.setInt(1, row.id());
        ps.addBatch();
    }

    void helperStatement(Row row) throws SQLException {
        PreparedStatement ps = sharedStatement();
        ps.setInt(1, row.id());
        ps.addBatch();
    }

    void ownHelperStatement(Connection con, Row row) throws SQLException {
        PreparedStatement ps = open(con);
        ps.setInt(1, row.id());
        ps.addBatch();
    }

    private PreparedStatement open(Connection con) throws SQLException {
        return con.prepareStatement(SQL);
    }

    private PreparedStatement sharedStatement() {
        return shared;
    }

    void reassignedFromCache(Connection con, java.util.Map<String, PreparedStatement> cache, boolean reuse) throws SQLException {
        PreparedStatement ps = con.prepareStatement(SQL);
        if (reuse) {
            ps = cache.get("x");
        }
        ps.addBatch();
    }

    void noBatch(Connection con) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            ps.setInt(1, 1);
            ps.executeUpdate();
        }
    }

    // ------------------------------------------------------------------ the periodic flush written as a guard that skips it

    void tailLostContinueGuard(Connection con, List<Row> rows) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++n % 1000 != 0) {
                    continue;
                }
                ps.executeBatch();
            }
        }
    }

    void tailLostContinueThreshold(Connection con, List<Row> rows) throws SQLException {
        int count = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++count < BATCH_SIZE) {
                    continue;
                }
                ps.executeBatch();
                count = 0;
            }
        }
    }

    void tailLostElseBranch(Connection con, List<Row> rows) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++n % 1000 != 0) {
                    log(row);
                } else {
                    ps.executeBatch();
                }
            }
        }
    }

    /** A counter compared with a constant and never reset flushes once, at that row, and loses everything after it. */
    void tailLostFlushOnce(Connection con, List<Row> rows) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++n == 1000) {
                    ps.executeBatch();
                }
            }
        }
    }

    void continueGuardWithFinalFlush(Connection con, List<Row> rows) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++n % 1000 != 0) {
                    continue;
                }
                ps.executeBatch();
            }
            if (n % 1000 != 0) {
                ps.executeBatch();
            }
        }
    }

    /** The guard skips the flush at the boundary only: the flush runs in nearly every iteration, the last row included. */
    void flushAlmostEveryIteration(Connection con, List<Row> rows) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++n % 1000 == 0) {
                    continue;
                }
                ps.executeBatch();
            }
        }
    }

    void flushOnTheRowsThatAreNotTheBoundary(Connection con, List<Row> rows) throws SQLException {
        int n = 0;
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (++n % 1000 != 0) {
                    ps.executeBatch();
                }
            }
        }
    }

    void flushBehindAGuardThatIsNoPeriod(Connection con, List<Row> rows, boolean dryRun) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(SQL)) {
            for (Row row : rows) {
                ps.setInt(1, row.id());
                ps.addBatch();
                if (dryRun) {
                    continue;
                }
                ps.executeBatch();
            }
        }
    }

    /** One variable for two statements is one batch to the rule: the executeBatch of the first hides the missing one of the second. */
    void reusedVariableHidesTheSecondStatement(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement(SQL);
        ps.addBatch();
        ps.executeBatch();
        ps = con.prepareStatement(SQL);
        ps.addBatch();
        ps.close();
    }

    private void log(Row row) { }
}
