package example;

import com.other.Workbook;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/** The POI jar is not on the class path of this fixture project: the workbook type is recognised by its imported name, with a lower quality. */
public class PoiUnresolvedCases {
    void styleInLoopWithoutPoiJar(HSSFWorkbook wb, List<String> rows) {
        for (String row : rows) {
            wb.createCellStyle();
        }
    }

    void cachedWithoutPoiJar(HSSFWorkbook wb, List<String> rows, java.util.Map<String, Object> styles) {
        for (String row : rows) {
            if (!styles.containsKey(row)) {
                styles.put(row, wb.createCellStyle());
            }
        }
    }

    void otherLibraryWithTheSameName(Workbook wb, List<String> rows) {
        for (String row : rows) {
            wb.createCellStyle();
        }
    }

    void unknownTypeWithTheSameCalls(Missing missing, List<String> rows) {
        for (String row : rows) {
            missing.createCellStyle();
        }
    }
}
