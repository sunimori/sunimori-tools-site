package example;

import com.missing.Handle;

/** The receiver's type is not on the class path: the calls cannot be judged, and the review has to say so. */
public class UnresolvedFileCases {
    void unresolvedReceiver(Handle handle) {
        handle.delete();
        handle.mkdirs();
    }

    void resolvedNextToUnresolved(Handle handle, java.io.File file) {
        handle.delete();
        file.delete();
    }
}
