package example;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.function.Consumer;

/**
 * Cases of SR-JAVA-FILE-RESULT-001. The method names are unique in this file, so that every suite case can select one of them.
 */
public class FileResultCases {
    private static final File TEMP = new File("work.tmp");
    private final Runnable cleanup = () -> TEMP.delete();

    static {
        new File("lock.tmp").delete();
    }

    /** A project class whose delete() is not java.io.File's. */
    static class Record {
        boolean delete() { return true; }
    }

    /** A project class with a void delete(). */
    static class Entity {
        void delete() { }
    }

    /** A File subclass: the call without receiver is File's own delete(). */
    static class TempFile extends File {
        TempFile(String name) { super(name); }
        void cleanSelf() {
            delete();
        }
    }

    /** A File subclass that decides what delete() does itself. */
    static class QuietFile extends File {
        QuietFile(String name) { super(name); }
        @Override public boolean delete() { return true; }
    }

    // ------------------------------------------------------------------ discarded results

    void deleteStatement(File f) {
        f.delete();
    }

    void renameStatement(File from, File to) {
        from.renameTo(to);
    }

    void mkdirStatement(File dir) {
        dir.mkdir();
    }

    void mkdirsStatement(File dir) {
        dir.mkdirs();
    }

    void createNewFileStatement(File lock) throws IOException {
        lock.createNewFile();
    }

    void setLastModifiedStatement(File f, long time) {
        f.setLastModified(time);
    }

    void setReadOnlyStatement(File f) {
        f.setReadOnly();
    }

    void setWritableStatement(File f) {
        f.setWritable(true);
    }

    void setReadableStatement(File f) {
        f.setReadable(false, true);
    }

    void setExecutableStatement(File f) {
        f.setExecutable(true);
    }

    void parentDirectory(File target) {
        target.getParentFile().mkdirs();
    }

    void freshFile(String dir, String name) {
        new File(dir, name).delete();
    }

    void viaPath(Path path) {
        path.toFile().delete();
    }

    void selfCall(TempFile file) {
        file.cleanSelf();
        file.delete();
    }

    void finallyCleanup(File tmp) throws IOException {
        try {
            Files.writeString(tmp.toPath(), "x");
        } finally {
            tmp.delete();
        }
    }

    void catchCleanup(File tmp) throws IOException {
        try {
            Files.writeString(tmp.toPath(), "x");
        } catch (IOException e) {
            tmp.delete();
            throw e;
        }
    }

    void lambdaExpression(List<File> files) {
        files.forEach(f -> f.delete());
    }

    void lambdaBlock(List<File> files) {
        files.forEach(f -> {
            f.delete();
        });
    }

    void methodReference(List<File> files) {
        files.forEach(File::delete);
    }

    void boundMethodReference(File lock) {
        Runnable r = lock::delete;
        r.run();
    }

    void walkAndDelete(Path root) throws IOException {
        try (var paths = Files.walk(root)) {
            paths.map(Path::toFile).forEach(File::delete);
        }
    }

    void arrowStatement(int mode, File f) {
        switch (mode) {
            case 1 -> f.delete();
            default -> { }
        }
    }

    void switchColonStatement(int mode, File f) {
        boolean r = switch (mode) {
            case 1:
                f.delete();
                yield true;
            default:
                yield false;
        };
        report(r);
    }

    void twoFiles(File a, File b) {
        a.delete();
        b.delete();
    }

    void sameFileTwice(File a) {
        a.delete();
        a.delete();
    }

    void anonymousClass(File f) {
        Runnable r = new Runnable() {
            @Override public void run() {
                f.delete();
            }
        };
        r.run();
    }

    // ------------------------------------------------------------------ the result is used

    boolean returned(File f) {
        return f.delete();
    }

    void assigned(File f) {
        boolean ok = f.delete();
        if (!ok) {
            throw new IllegalStateException(f.getPath());
        }
    }

    void reassigned(File f) {
        boolean ok;
        ok = f.mkdirs();
        System.out.println(ok);
    }

    void inCondition(File f) throws IOException {
        if (!f.delete()) {
            throw new IOException("cannot delete " + f);
        }
    }

    void inLoopCondition(File f) {
        while (!f.delete()) {
            Thread.yield();
        }
    }

    void passedOn(File f) {
        report(f.delete());
    }

    void asserted(File f) {
        assert f.delete();
    }

    void combined(File a, File b) {
        boolean both = a.delete() && b.delete();
        System.out.println(both);
    }

    boolean conditional(File f, boolean strict) {
        return strict ? f.delete() : f.mkdir();
    }

    private void report(boolean ok) { }

    void switchValue(int mode, File f) {
        boolean r = switch (mode) {
            case 1 -> f.delete();
            default -> false;
        };
        report(r);
    }

    void switchBlockYield(int mode, File f) {
        boolean r = switch (mode) {
            case 1 -> {
                yield f.delete();
            }
            default -> false;
        };
        report(r);
    }

    // ------------------------------------------------------------------ other methods and types

    void deleteOnExitOnly(File f) {
        f.deleteOnExit();
    }

    void nioDelete(Path p) throws IOException {
        Files.delete(p);
        Files.deleteIfExists(p);
        Files.createDirectories(p);
        Files.move(p, p.resolveSibling("x"));
    }

    void projectDelete(Record r) {
        r.delete();
    }

    void voidDelete(Entity e) {
        e.delete();
    }

    void overridingSubclass(QuietFile q) {
        q.delete();
    }

    void lambdaWithResult(List<File> files) {
        files.removeIf(f -> f.delete());
        files.stream().filter(File::delete).count();
    }

    void callableLambda(ExecutorService pool, File f) {
        pool.submit(() -> f.delete());
    }

    void lambdaReturnsBoolean(File f) {
        java.util.function.Supplier<Boolean> s = () -> f.delete();
        s.get();
    }

    void consumerOfSomethingElse(Consumer<File> sink, File f) {
        sink.accept(f);
    }

    // ------------------------------------------------------------------ the outcome is checked

    void outcomeCheckedMkdirs(File dir) throws IOException {
        dir.mkdirs();
        if (!dir.isDirectory()) {
            throw new IOException("cannot create " + dir);
        }
    }

    void outcomeCheckedDelete(File f) {
        f.delete();
        if (f.exists()) {
            System.err.println("still there: " + f);
        }
    }

    void outcomeCheckedAfterBranch(File dir) throws IOException {
        if (!dir.exists()) {
            dir.mkdirs();
        }
        if (!dir.isDirectory()) {
            throw new IOException("cannot create " + dir);
        }
    }

    void outcomeCheckedRename(File from, File to) throws IOException {
        from.renameTo(to);
        if (!to.exists()) {
            throw new IOException("rename failed");
        }
    }

    void outcomeCheckedAssert(File dir) {
        dir.mkdirs();
        assert dir.isDirectory();
    }

    void outcomeOfAnotherFile(File a, File b) {
        a.delete();
        if (b.exists()) {
            System.err.println("b is there");
        }
    }

    void outcomeNotChecked(File dir) {
        dir.mkdirs();
        System.out.println("created");
        if (!dir.isDirectory()) {
            System.err.println("too late to matter?");
        }
    }

    // ------------------------------------------------------------------ the outcome is looked at where it is recorded

    private boolean deleted;

    void outcomeAssignedToVariable(File f) {
        f.delete();
        boolean gone = !f.exists();
        System.out.println(gone);
    }

    void outcomeAssignedToField(File f) {
        f.delete();
        this.deleted = !f.exists();
    }

    void outcomeInConditionalInitializer(File f) {
        f.delete();
        String state = f.exists() ? "kept" : "gone";
        System.out.println(state);
    }

    void outcomeOfAnotherFileAssigned(File a, File b) {
        a.delete();
        boolean other = b.exists();
        System.out.println(other);
    }

    /** Ten levels of branches around the call: the next statement is still found. */
    void outcomeCheckedDeeplyNested(File f, boolean b) {
        if (b) { if (b) { if (b) { if (b) { if (b) { if (b) { if (b) { if (b) { if (b) { if (b) {
            f.delete();
        } } } } } } } } } }
        if (f.exists()) {
            System.err.println("still there");
        }
    }

    // ------------------------------------------------------------------ the call is written over several lines

    void multiLineCall(File file) {
        file
                .delete();
    }

    void multiLineArguments(File from, File to) {
        from.renameTo(
                to);
    }
}
