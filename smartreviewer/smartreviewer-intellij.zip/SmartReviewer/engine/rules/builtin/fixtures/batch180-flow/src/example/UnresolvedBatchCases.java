package example;

import com.missing.BatchWriter;

/** The statement's type is not on the class path: the calls cannot be judged, and the review has to say so. */
public class UnresolvedBatchCases {
    void unresolvedWriter(BatchWriter writer) {
        writer.addBatch();
    }
}
