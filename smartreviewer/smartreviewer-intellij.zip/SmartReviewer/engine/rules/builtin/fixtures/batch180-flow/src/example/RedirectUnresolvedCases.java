package example;

import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletResponse;

/** The servlet API is not on the class path of this fixture project: the types are recognised by their simple names. */
public class RedirectUnresolvedCases {
    void redirectThenChainWithoutServletJar(HttpServletResponse response, ServletRequest request, FilterChain chain) throws IOException {
        response.sendRedirect("/login");
        chain.doFilter(request, response);
    }

    void guardedWithoutServletJar(HttpServletResponse response, ServletRequest request, FilterChain chain, boolean ok) throws IOException {
        if (!ok) {
            response.sendRedirect("/login");
            return;
        }
        chain.doFilter(request, response);
    }

    void unknownReceiver(Missing context) throws IOException {
        context.getResponse().sendRedirect("/login");
        context.go();
    }
}
