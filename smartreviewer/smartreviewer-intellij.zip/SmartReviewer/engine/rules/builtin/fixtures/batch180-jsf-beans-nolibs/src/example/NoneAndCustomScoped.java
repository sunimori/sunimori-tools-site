package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.NoneScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@NoneScoped
public class NoneAndCustomScoped implements java.io.Serializable {
    private FacesContext context;
}
