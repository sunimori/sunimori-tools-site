package example;

import javax.faces.bean.ManagedBean;
import javax.enterprise.context.RequestScoped;

@ManagedBean
@RequestScoped
public class ManagedRequestCdi implements java.io.Serializable {
}
