package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class OtherContextTypes implements java.io.Serializable {
    private java.util.List<javax.faces.context.FacesContext> history;
    private java.util.Map<String, javax.servlet.http.HttpServletRequest> byId;
    private Object context;
}
