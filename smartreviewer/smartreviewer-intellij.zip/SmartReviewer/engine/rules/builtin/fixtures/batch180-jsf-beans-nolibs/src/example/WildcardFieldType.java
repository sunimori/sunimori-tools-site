package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.*;

@ManagedBean
@SessionScoped
public class WildcardFieldType implements java.io.Serializable {
    private FacesContext context;
    private ExternalContext external;
}
