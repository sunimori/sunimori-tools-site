package example;

import javax.faces.bean.ManagedBean;
import javax.enterprise.context.SessionScoped;

public class AnnotationInMethodBody {
    public Object make() {
        @ManagedBean @SessionScoped class Local {
        }
        return new Local();
    }
}
