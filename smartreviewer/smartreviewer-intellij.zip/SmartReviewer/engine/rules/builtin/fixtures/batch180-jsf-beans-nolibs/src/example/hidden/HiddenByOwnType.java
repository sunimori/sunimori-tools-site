package example.hidden;

import javax.faces.bean.ManagedBean;

@ManagedBean
@SessionScoped
public class HiddenByOwnType {
}

@interface SessionScoped {
}
