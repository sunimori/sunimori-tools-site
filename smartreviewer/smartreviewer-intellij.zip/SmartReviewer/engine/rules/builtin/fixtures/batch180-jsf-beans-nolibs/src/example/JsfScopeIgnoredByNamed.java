package example;

import javax.inject.Named;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@Named
@SessionScoped
public class JsfScopeIgnoredByNamed implements java.io.Serializable {
    private FacesContext context;
}
