package example;

import javax.faces.bean.*;
import javax.enterprise.context.*;

@ManagedBean
@SessionScoped
public class BothWildcards implements java.io.Serializable {
}
