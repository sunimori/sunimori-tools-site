package example;

import javax.faces.bean.ManagedBean;
import javax.enterprise.context.SessionScoped;
import javax.faces.view.ViewScoped;

@ManagedBean
@SessionScoped
@ViewScoped
public class TwoIgnored implements java.io.Serializable {
}
