package example;

import javax.faces.bean.ManagedBean;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@SessionScoped
public class CdiScopeIgnoredByManagedBean implements java.io.Serializable {
    private FacesContext context;
}
