package example;

import javax.annotation.ManagedBean;
import javax.enterprise.context.SessionScoped;

@ManagedBean
@SessionScoped
public class PlatformManagedBean implements java.io.Serializable {
}
