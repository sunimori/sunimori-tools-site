package example;

import javax.faces.bean.ManagedBean;
import javax.enterprise.context.SessionScoped;

/** The bean of the order page. */
@ManagedBean(name = "orders")
@SessionScoped
public class ConstantsAreIrrelevant implements java.io.Serializable {
    public static final String NAME = "orders";

    public String getName() {
        return NAME;
    }
}
