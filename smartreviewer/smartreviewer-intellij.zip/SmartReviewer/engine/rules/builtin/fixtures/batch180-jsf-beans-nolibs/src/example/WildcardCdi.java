package example;

import javax.faces.bean.*;
import javax.enterprise.context.SessionScoped;

@ManagedBean
@SessionScoped
public class WildcardCdi implements java.io.Serializable {
}
