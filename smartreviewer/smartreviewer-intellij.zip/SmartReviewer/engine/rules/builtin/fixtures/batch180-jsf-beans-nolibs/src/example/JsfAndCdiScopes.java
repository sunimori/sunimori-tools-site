package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
@javax.enterprise.context.SessionScoped
public class JsfAndCdiScopes implements java.io.Serializable {
}
