package example;

import javax.faces.bean.ManagedBean;

@ManagedBean
@OwnScopeAnnotation.SessionScoped
public class OwnScopeAnnotation {
    @interface SessionScoped {
    }
}
