package example;

import javax.inject.Named;
import javax.inject.Inject;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;

@Named
@SessionScoped
public class InjectedByConstructor implements java.io.Serializable {
    private final FacesContext context;

    @Inject
    public InjectedByConstructor(FacesContext context) {
        this.context = context;
    }
}
