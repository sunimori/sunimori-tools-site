package example;

import javax.annotation.*;
import javax.enterprise.context.SessionScoped;

@ManagedBean
@SessionScoped
public class PlatformManagedBeanWildcard implements java.io.Serializable {
}
