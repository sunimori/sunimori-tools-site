package example;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import org.springframework.beans.factory.annotation.Autowired;
import javax.servlet.http.HttpServletRequest;
import javax.faces.context.FacesContext;

@Named
@SessionScoped
public class AutowiredByConstructor implements java.io.Serializable {
    private final HttpServletRequest request;
    private final FacesContext context;

    @Autowired
    public AutowiredByConstructor(HttpServletRequest request, FacesContext context) {
        this.request = request;
        this.context = context;
    }
}
