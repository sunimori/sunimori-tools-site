package example;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;

@Named
@SessionScoped
public class NamedSession implements java.io.Serializable {
}
