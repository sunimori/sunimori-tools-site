package example;

import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

@ManagedBean
public class NoScopeManaged implements java.io.Serializable {
    private FacesContext context;
}
