package example;

import javax.faces.bean.ManagedBean;
import javax.enterprise.context.ApplicationScoped;

@ManagedBean(eager = true)
@ApplicationScoped
public class ManagedApplicationCdi implements java.io.Serializable {
}
