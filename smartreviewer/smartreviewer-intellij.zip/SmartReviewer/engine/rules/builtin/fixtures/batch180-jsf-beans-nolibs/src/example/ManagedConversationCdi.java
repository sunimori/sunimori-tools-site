package example;

import javax.faces.bean.ManagedBean;
import javax.enterprise.context.ConversationScoped;

@ManagedBean
@ConversationScoped
public class ManagedConversationCdi implements java.io.Serializable {
}
