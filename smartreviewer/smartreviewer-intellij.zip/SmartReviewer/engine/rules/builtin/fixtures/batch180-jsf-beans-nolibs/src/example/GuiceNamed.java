package example;

import com.google.inject.name.Named;
import javax.faces.bean.SessionScoped;

@Named("x")
@SessionScoped
public class GuiceNamed implements java.io.Serializable {
}
