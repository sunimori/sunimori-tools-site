package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@SessionScoped
public class SessionFacesContext implements java.io.Serializable {
    private FacesContext context;

    public void init() {
        context = FacesContext.getCurrentInstance();
    }
}
