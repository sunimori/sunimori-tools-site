package example;

import javax.faces.bean.ManagedBean;
import org.omnifaces.cdi.ViewScoped;

@ManagedBean
@ViewScoped
public class OmniFacesViewOnManagedBean implements java.io.Serializable {
}
