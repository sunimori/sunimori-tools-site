package example;

import javax.inject.Named;
import javax.enterprise.context.ConversationScoped;
import javax.faces.context.FacesContext;

@Named
@ConversationScoped
public class ConversationScoped implements java.io.Serializable {
    private FacesContext context;
}
