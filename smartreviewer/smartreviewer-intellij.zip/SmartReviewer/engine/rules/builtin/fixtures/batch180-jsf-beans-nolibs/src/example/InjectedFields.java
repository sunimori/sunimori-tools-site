package example;

import javax.inject.Named;
import javax.inject.Inject;
import javax.annotation.Resource;
import javax.ws.rs.core.Context;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.faces.context.ExternalContext;

@Named
@SessionScoped
public class InjectedFields implements java.io.Serializable {
    @Inject
    private FacesContext context;
    @Inject
    private HttpServletRequest request;
    @Resource
    private ExternalContext external;
    @Context
    private HttpServletResponse response;
}
