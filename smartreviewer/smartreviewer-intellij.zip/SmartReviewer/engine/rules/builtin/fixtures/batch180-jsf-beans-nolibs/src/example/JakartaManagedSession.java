package example;

import jakarta.faces.bean.ManagedBean;
import jakarta.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class JakartaManagedSession implements java.io.Serializable {
}
