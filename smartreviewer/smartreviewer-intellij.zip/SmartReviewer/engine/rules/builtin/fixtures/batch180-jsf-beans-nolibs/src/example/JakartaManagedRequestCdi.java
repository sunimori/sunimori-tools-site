package example;

import jakarta.faces.bean.ManagedBean;
import jakarta.enterprise.context.RequestScoped;

@ManagedBean
@RequestScoped
public class JakartaManagedRequestCdi implements java.io.Serializable {
}
