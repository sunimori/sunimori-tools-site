package example;

import javax.enterprise.context.SessionScoped;

@SessionScoped
public class ScopedBase implements java.io.Serializable {
}
