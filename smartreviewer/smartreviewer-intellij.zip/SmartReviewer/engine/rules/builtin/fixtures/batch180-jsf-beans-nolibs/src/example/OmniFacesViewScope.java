package example;

import javax.inject.Named;
import org.omnifaces.cdi.ViewScoped;

@Named
@ViewScoped
public class OmniFacesViewScope implements java.io.Serializable {
}
