package example;

import javax.inject.Named;
import javax.faces.bean.*;
import javax.enterprise.context.*;
import javax.faces.context.FacesContext;

@Named
@SessionScoped
public class AmbiguousScope implements java.io.Serializable {
    private FacesContext context;
}
