package example;

import javax.inject.Named;
import javax.faces.view.ViewScoped;
import javax.faces.context.ExternalContext;

@Named
@ViewScoped
public class CdiViewExternal implements java.io.Serializable {
    protected ExternalContext external;
}
