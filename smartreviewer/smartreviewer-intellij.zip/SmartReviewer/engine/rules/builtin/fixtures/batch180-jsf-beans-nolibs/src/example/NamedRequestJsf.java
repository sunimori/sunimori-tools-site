package example;

import javax.inject.Named;
import javax.faces.bean.RequestScoped;

@Named
@RequestScoped
public class NamedRequestJsf implements java.io.Serializable {
}
