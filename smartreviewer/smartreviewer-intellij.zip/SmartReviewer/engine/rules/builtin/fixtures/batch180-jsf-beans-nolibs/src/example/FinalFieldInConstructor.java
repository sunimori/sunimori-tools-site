package example;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;

@Named
@SessionScoped
public class FinalFieldInConstructor implements java.io.Serializable {
    private final FacesContext context;

    public FinalFieldInConstructor() {
        this.context = FacesContext.getCurrentInstance();
    }
}
