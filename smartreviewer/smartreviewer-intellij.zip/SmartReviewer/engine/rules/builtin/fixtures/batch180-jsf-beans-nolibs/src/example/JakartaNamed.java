package example;

import jakarta.inject.Named;
import jakarta.faces.bean.RequestScoped;

@Named
@RequestScoped
public class JakartaNamed implements java.io.Serializable {
}
