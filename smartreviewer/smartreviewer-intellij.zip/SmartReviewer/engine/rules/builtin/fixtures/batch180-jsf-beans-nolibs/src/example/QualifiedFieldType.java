package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class QualifiedFieldType implements java.io.Serializable {
    private javax.faces.context.FacesContext context;
}
