package example;

import javax.inject.Named;
import javax.faces.bean.CustomScoped;

@Named
@CustomScoped("#{map}")
public class NamedCustomJsf implements java.io.Serializable {
}
