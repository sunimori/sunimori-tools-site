package example;

import javax.inject.Named;

@Named
@javax.enterprise.context.Dependent
@javax.faces.bean.NoneScoped
public class NamedDependentAndNone implements java.io.Serializable {
}
