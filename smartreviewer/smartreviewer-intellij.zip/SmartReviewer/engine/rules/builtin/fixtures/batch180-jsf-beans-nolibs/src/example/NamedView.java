package example;

import javax.inject.Named;
import javax.faces.view.ViewScoped;

@Named
@ViewScoped
public class NamedView implements java.io.Serializable {
}
