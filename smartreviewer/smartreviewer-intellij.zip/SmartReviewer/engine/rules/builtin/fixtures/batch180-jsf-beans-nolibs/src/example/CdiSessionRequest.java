package example;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.servlet.http.HttpServletRequest;

@Named
@SessionScoped
public class CdiSessionRequest implements java.io.Serializable {
    private HttpServletRequest request;
}
