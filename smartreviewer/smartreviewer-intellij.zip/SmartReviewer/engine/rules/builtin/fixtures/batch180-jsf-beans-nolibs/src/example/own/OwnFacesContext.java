package example.own;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class OwnFacesContext implements java.io.Serializable {
    private FacesContext context;
    private HttpServletRequest request;
}

class FacesContext {
}

interface HttpServletRequest {
}
