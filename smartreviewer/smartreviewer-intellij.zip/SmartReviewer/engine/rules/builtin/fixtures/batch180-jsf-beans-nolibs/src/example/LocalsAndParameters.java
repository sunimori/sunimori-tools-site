package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

@ManagedBean
@SessionScoped
public class LocalsAndParameters implements java.io.Serializable {
    public String action(HttpServletRequest request) {
        FacesContext context = FacesContext.getCurrentInstance();
        return context == null || request == null ? "a" : "b";
    }

    public FacesContext current() {
        return FacesContext.getCurrentInstance();
    }
}
