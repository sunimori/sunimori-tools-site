package example;

import jakarta.faces.bean.ManagedBean;
import jakarta.faces.view.ViewScoped;

@ManagedBean
@ViewScoped
public class JakartaManagedView implements java.io.Serializable {
}
