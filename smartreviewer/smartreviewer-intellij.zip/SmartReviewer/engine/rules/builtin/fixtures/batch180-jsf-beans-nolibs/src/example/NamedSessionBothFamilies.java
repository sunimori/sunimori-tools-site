package example;

import javax.inject.Named;

@Named
@javax.enterprise.context.SessionScoped
@javax.faces.bean.SessionScoped
public class NamedSessionBothFamilies implements java.io.Serializable {
}
