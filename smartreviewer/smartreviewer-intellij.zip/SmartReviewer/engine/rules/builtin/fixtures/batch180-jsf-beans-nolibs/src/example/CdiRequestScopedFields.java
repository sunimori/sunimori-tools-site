package example;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;

@Named
@RequestScoped
public class CdiRequestScopedFields implements java.io.Serializable {
    private FacesContext context;
}
