package example;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import org.apache.deltaspike.core.api.scope.WindowScoped;

@Named
@SessionScoped
@WindowScoped
public class ForeignScopeAnnotation implements java.io.Serializable {
    private FacesContext context;
}
