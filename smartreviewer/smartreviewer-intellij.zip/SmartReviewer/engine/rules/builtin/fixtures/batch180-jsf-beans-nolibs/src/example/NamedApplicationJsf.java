package example;

import javax.inject.Named;
import javax.faces.bean.ApplicationScoped;

@Named
@ApplicationScoped
public class NamedApplicationJsf implements java.io.Serializable {
}
