package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ManagedProperty;
import javax.servlet.http.HttpServletRequest;

@ManagedBean
@SessionScoped
public class ManagedPropertyRequest implements java.io.Serializable {
    @ManagedProperty("#{request}")
    private HttpServletRequest request;
}
