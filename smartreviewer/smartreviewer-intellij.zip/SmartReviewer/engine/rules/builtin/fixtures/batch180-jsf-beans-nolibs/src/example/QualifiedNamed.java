package example;


@javax.inject.Named("x")
@javax.faces.bean.SessionScoped
public class QualifiedNamed implements java.io.Serializable {
}
