package example;

import javax.inject.Named;
import javax.faces.bean.NoneScoped;

@Named
@NoneScoped
public class NamedNoneJsf implements java.io.Serializable {
}
