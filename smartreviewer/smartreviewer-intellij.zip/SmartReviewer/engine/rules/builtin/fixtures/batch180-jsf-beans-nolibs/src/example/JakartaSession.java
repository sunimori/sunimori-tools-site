package example;

import jakarta.inject.Named;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.context.FacesContext;
import jakarta.servlet.http.HttpServletRequest;

@Named
@SessionScoped
public class JakartaSession implements java.io.Serializable {
    private FacesContext context;
    private HttpServletRequest request;
}
