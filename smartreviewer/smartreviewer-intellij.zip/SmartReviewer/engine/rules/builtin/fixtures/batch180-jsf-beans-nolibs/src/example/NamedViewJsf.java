package example;

import javax.inject.Named;
import javax.faces.bean.ViewScoped;

@Named("editor")
@ViewScoped
public class NamedViewJsf implements java.io.Serializable {
}
