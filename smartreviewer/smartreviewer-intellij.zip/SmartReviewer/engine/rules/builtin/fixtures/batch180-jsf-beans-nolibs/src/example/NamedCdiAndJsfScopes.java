package example;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;

@Named
@SessionScoped
@javax.faces.bean.ViewScoped
public class NamedCdiAndJsfScopes implements java.io.Serializable {
}
