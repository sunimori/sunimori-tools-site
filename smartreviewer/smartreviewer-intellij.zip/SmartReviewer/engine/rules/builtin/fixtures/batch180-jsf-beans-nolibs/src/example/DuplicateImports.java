package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.enterprise.context.SessionScoped;

@ManagedBean
@SessionScoped
public class DuplicateImports implements java.io.Serializable {
}
