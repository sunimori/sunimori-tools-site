package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

@ManagedBean
@RequestScoped
public class RequestScopedFields implements java.io.Serializable {
    private FacesContext context;
    private HttpServletRequest request;
}
