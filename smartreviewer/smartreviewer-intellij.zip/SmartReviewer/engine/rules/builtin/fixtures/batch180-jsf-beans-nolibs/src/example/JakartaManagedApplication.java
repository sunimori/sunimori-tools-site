package example;

import jakarta.faces.bean.ManagedBean;
import jakarta.faces.bean.ApplicationScoped;
import jakarta.servlet.ServletResponse;

@ManagedBean
@ApplicationScoped
public class JakartaManagedApplication implements java.io.Serializable {
    private ServletResponse response;
}
