package example;

import javax.faces.bean.ManagedBean;
import javax.faces.flow.FlowScoped;

@ManagedBean
@FlowScoped("checkout")
public class ManagedFlowCdi implements java.io.Serializable {
}
