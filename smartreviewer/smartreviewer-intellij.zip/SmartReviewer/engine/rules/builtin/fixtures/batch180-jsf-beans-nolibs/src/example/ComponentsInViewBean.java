package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;

@ManagedBean
@ViewScoped
public class ComponentsInViewBean implements java.io.Serializable {
    private UIComponent input;
    private UIViewRoot root;
}
