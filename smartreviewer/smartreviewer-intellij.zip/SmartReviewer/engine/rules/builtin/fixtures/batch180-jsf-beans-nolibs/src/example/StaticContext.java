package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ApplicationScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@ApplicationScoped
public class StaticContext implements java.io.Serializable {
    private static FacesContext shared;
}
