package example;

import javax.inject.Named;
import javax.faces.flow.FlowScoped;

@Named
@FlowScoped("a")
public class NamedFlow implements java.io.Serializable {
}
