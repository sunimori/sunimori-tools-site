package example;


@jakarta.faces.bean.ManagedBean
@jakarta.enterprise.context.SessionScoped
public class JakartaManaged implements java.io.Serializable {
}
