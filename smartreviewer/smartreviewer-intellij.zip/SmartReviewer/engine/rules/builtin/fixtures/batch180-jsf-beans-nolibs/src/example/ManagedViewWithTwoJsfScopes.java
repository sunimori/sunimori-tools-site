package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
@javax.faces.bean.ViewScoped
@javax.enterprise.context.RequestScoped
public class ManagedViewWithTwoJsfScopes implements java.io.Serializable {
}
