package example;


@javax.faces.bean.ManagedBean
@javax.enterprise.context.SessionScoped
public class QualifiedNames implements java.io.Serializable {
}
