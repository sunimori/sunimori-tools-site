package example;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.servlet.http.HttpServletRequest;

@Named
@SessionScoped
public class TypeVariableWithoutRequestBound<A, B extends java.io.Serializable, C extends java.io.Serializable & HttpServletRequest> implements java.io.Serializable {
    private A first;
    private B second;
    private C third;
}
