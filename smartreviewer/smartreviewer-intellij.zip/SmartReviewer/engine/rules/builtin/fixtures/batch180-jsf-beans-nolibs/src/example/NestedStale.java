package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

public class NestedStale {
    @ManagedBean
    @SessionScoped
    public static class Inner implements java.io.Serializable {
        private FacesContext context;
    }
}
