package example;

import javax.enterprise.context.SessionScoped;
import javax.servlet.http.HttpServletRequest;

@SessionScoped
public class ScopeWithoutBeanAnnotation implements java.io.Serializable {
    private HttpServletRequest request;
}
