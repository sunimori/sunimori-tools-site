package example;

import javax.enterprise.context.SessionScoped;

@SessionScoped
public class ScopeOnly implements java.io.Serializable {
}
