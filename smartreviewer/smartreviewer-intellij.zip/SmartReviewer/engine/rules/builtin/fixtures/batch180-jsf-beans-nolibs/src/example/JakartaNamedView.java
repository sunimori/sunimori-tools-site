package example;

import jakarta.inject.Named;
import jakarta.faces.view.ViewScoped;

@Named
@ViewScoped
public class JakartaNamedView implements java.io.Serializable {
}
