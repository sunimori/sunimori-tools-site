package example;

import javax.faces.bean.SessionScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

@ManagedBean
@SessionScoped
public abstract class AbstractBase implements java.io.Serializable {
    protected FacesContext context;
}
