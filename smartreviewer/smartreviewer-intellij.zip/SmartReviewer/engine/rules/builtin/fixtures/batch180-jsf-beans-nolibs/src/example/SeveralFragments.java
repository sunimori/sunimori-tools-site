package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@SessionScoped
public class SeveralFragments implements java.io.Serializable {
    private FacesContext first, second;
    private FacesContext[] many;
}
