package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
@javax.enterprise.context.RequestScoped
public class ManagedSessionWithCdiRequest implements java.io.Serializable {
}
