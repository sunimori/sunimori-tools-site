package example;

import javax.inject.Named;
import javax.enterprise.context.ApplicationScoped;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

@Named
@ApplicationScoped
public class ApplicationResponses implements java.io.Serializable {
    ServletRequest generic;
    public ServletResponse genericResponse;
    private final HttpServletResponse response = null;
}
