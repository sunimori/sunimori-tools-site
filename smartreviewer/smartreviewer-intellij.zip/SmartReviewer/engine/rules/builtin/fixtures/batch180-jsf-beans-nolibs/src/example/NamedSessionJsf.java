package example;

import javax.inject.Named;
import javax.faces.bean.SessionScoped;

@Named
@SessionScoped
public class NamedSessionJsf implements java.io.Serializable {
}
