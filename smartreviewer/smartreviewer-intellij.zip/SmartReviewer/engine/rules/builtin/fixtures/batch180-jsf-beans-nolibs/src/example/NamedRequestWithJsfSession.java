package example;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

@Named
@RequestScoped
@javax.faces.bean.SessionScoped
public class NamedRequestWithJsfSession implements java.io.Serializable {
}
