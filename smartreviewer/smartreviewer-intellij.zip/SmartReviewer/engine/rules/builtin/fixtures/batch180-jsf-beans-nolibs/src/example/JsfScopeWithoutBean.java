package example;

import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@SessionScoped
public class JsfScopeWithoutBean implements java.io.Serializable {
    private FacesContext context;
}
