package example;

import javax.inject.Named;

@Named
public class NamedNoScope implements java.io.Serializable {
}
