package example;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.servlet.http.HttpServletRequest;

@Named
@SessionScoped
public class TypeVariableRequest<T extends HttpServletRequest> implements java.io.Serializable {
    private T request;
}
