package example;

import javax.faces.bean.SessionScoped;

@SessionScoped
public class JsfScopeOnly implements java.io.Serializable {
}
