package example;

import javax.inject.Named;
import javax.faces.context.FacesContext;

@Named
public class NoScopeNamed implements java.io.Serializable {
    private FacesContext context;
}
