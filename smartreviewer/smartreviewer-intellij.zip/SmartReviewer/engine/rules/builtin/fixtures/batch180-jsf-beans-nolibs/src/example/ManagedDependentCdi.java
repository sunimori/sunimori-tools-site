package example;

import javax.faces.bean.ManagedBean;
import javax.enterprise.context.Dependent;

@ManagedBean
@Dependent
public class ManagedDependentCdi implements java.io.Serializable {
}
