package example;

import javax.faces.bean.ManagedBean;

@ManagedBean
@javax.faces.bean.SessionScoped
@javax.enterprise.context.SessionScoped
public class ManagedSessionBothFamilies implements java.io.Serializable {
}
