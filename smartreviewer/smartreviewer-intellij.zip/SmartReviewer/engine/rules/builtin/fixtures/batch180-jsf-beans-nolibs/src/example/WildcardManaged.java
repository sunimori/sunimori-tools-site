package example;

import javax.faces.bean.*;

@ManagedBean
@javax.enterprise.context.SessionScoped
public class WildcardManaged implements java.io.Serializable {
}
