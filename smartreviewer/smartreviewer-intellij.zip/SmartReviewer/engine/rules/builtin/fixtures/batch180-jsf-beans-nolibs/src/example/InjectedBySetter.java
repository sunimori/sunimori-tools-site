package example;

import javax.inject.Named;
import javax.inject.Inject;
import javax.enterprise.context.SessionScoped;
import javax.servlet.http.HttpServletRequest;

@Named
@SessionScoped
public class InjectedBySetter implements java.io.Serializable {
    private HttpServletRequest request;

    @Inject
    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }
}
