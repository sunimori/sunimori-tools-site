package example;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.servlet.ServletRequest;

public class TypeVariableOfTheOuterClass<T extends ServletRequest> {
    @Named
    @SessionScoped
    public class Inner implements java.io.Serializable {
        protected T request;
    }
}
