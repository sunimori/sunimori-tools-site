package example;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;

@Named
@SessionScoped
public interface InterfaceConstants {
    FacesContext CONTEXT = null;
}
