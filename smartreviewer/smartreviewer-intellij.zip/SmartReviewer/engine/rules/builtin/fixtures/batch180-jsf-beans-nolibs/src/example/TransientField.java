package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.servlet.http.HttpServletRequest;

@ManagedBean
@ViewScoped
public class TransientField implements java.io.Serializable {
    private transient HttpServletRequest request;
}
