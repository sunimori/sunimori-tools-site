package example;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import org.springframework.beans.factory.annotation.Autowired;
import javax.faces.context.FacesContext;
import javax.faces.context.ExternalContext;

@Named
@SessionScoped
public class AutowiredFacesContext implements java.io.Serializable {
    @Autowired
    private FacesContext context;
    @Autowired
    private ExternalContext external;
}
