package example;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class ManagedNoScope implements java.io.Serializable {
}
