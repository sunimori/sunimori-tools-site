package example;

import javax.inject.Named;
import javax.faces.context.FacesContext;

@Named
public class ScopeFromSuperclass extends ScopedBase {
    private FacesContext context;
}
