package example;

import javax.inject.*;
import javax.faces.bean.*;

@Named
@ViewScoped
public class WildcardNamed implements java.io.Serializable {
}
