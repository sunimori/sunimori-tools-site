package example;

import javax.faces.bean.ManagedBean;
import javax.faces.view.ViewScoped;

@ManagedBean(name = "editor")
@ViewScoped
public class ManagedViewCdi implements java.io.Serializable {
}
