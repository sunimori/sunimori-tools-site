package example;

import javax.inject.Named;
import javax.faces.flow.FlowScoped;
import javax.faces.context.FacesContext;

@Named
@FlowScoped("a")
public class FlowScopedFields implements java.io.Serializable {
    private FacesContext context;
}
