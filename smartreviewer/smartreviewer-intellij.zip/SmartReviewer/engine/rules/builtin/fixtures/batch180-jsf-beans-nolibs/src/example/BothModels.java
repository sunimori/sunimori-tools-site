package example;

import javax.faces.bean.ManagedBean;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;

@ManagedBean
@Named
@SessionScoped
public class BothModels implements java.io.Serializable {
}
