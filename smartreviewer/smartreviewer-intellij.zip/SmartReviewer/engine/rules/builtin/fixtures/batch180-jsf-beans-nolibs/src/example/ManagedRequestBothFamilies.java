package example;

import javax.faces.bean.ManagedBean;

@ManagedBean
@javax.faces.bean.RequestScoped
@javax.enterprise.context.RequestScoped
public class ManagedRequestBothFamilies implements java.io.Serializable {
}
