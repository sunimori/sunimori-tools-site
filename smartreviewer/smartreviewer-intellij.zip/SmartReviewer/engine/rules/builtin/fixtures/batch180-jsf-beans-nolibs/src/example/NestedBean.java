package example;

import javax.faces.bean.ManagedBean;
import javax.enterprise.context.SessionScoped;

public class NestedBean {
    @ManagedBean
    @SessionScoped
    public static class Inner implements java.io.Serializable {
    }
}
