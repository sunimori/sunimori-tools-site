package example;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletContext;

@ManagedBean
@SessionScoped
public class SessionAndServletContext implements java.io.Serializable {
    private HttpSession session;
    private ServletContext application;
}
