package example;

import javax.faces.bean.ManagedBean;
import javax.enterprise.context.SessionScoped;

@ManagedBean
@SessionScoped
@SomethingElse
@Foo.Bar
public class UnknownAnnotations implements java.io.Serializable {
}
