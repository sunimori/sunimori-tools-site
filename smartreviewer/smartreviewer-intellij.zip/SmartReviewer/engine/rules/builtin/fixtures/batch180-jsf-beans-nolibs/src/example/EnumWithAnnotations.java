package example;

import javax.inject.Named;
import javax.faces.bean.SessionScoped;

@Named
@SessionScoped
public enum EnumWithAnnotations {
    A
}
