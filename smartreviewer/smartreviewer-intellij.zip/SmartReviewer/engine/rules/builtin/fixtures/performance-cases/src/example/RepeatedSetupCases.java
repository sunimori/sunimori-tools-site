package example;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/** Cases for SR-PERF-REGEX-IN-LOOP-001 and SR-PERF-FORMAT-IN-LOOP-001: the same set-up repeated in every iteration. */
final class RepeatedSetupCases {
    private static final Pattern DIGITS = Pattern.compile("[0-9]+");
    private static final String DATE = "yyyy/MM/dd";

    /** P01: Pattern.compile of a constant regex in the loop. */
    int numbers(List<String> values) {
        int n = 0;
        for (String v : values) {
            if (Pattern.compile("[0-9]+").matcher(v).matches()) {
                n++;
            }
        }
        return n;
    }

    /** P02: String.matches and replaceAll compile their regex on each call. */
    List<String> codes(List<String> values) {
        List<String> out = new ArrayList<>();
        for (String v : values) {
            if (v.matches("[A-Z]{3}-\\d{4}")) {
                out.add(v.replaceAll("\\s+", ""));
            }
        }
        return out;
    }

    /** P03: split with a real regex. */
    int words(List<String> lines) {
        int n = 0;
        for (String line : lines) {
            n += line.split("\\s*,\\s*").length;
        }
        return n;
    }

    /** P04: the regex is a parameter that the loop does not change. */
    int count(List<String> values, String regex) {
        int n = 0;
        for (String v : values) {
            n += v.matches(regex) ? 1 : 0;
        }
        return n;
    }

    /** N01: split on one plain character, or an escaped one that is no letter or digit, takes String's fast path. */
    int fields(List<String> lines) {
        int n = 0;
        for (String line : lines) {
            n += line.split(",").length + line.split("\t").length + line.split("\\|").length;
        }
        return n;
    }

    /** N02: the compiled pattern is a constant. */
    int precompiled(List<String> values) {
        int n = 0;
        for (String v : values) {
            n += DIGITS.matcher(v).matches() ? 1 : 0;
        }
        return n;
    }

    /** B01: an escaped letter (\t as a regex) is not on split's fast path, so a pattern is compiled each time. */
    int tabs(List<String> lines) {
        int n = 0;
        for (String line : lines) {
            n += line.split("\\t").length;
        }
        return n;
    }

    /** B02: four fixed iterations (quarters). */
    List<String> quarters(long[] totals) {
        List<String> out = new ArrayList<>();
        for (int q = 0; q < 4; q++) {
            out.add(new DecimalFormat("#,##0").format(totals[q]));
        }
        return out;
    }

    /** N03: a different regex in each iteration. */
    int each(List<String> values, List<String> regexes) {
        int n = 0;
        for (int i = 0; i < values.size(); i++) {
            n += values.get(i).matches(regexes.get(i)) ? 1 : 0;
        }
        return n;
    }

    /** P05: a SimpleDateFormat created for every row. */
    List<String> dates(List<Date> values) {
        List<String> out = new ArrayList<>();
        for (Date d : values) {
            out.add(new SimpleDateFormat(DATE, Locale.JAPAN).format(d));
        }
        return out;
    }

    /** P06: DecimalFormat and DateTimeFormatter.ofPattern in a loop. */
    List<String> amounts(List<Long> values, List<LocalDate> days) {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < values.size(); i++) {
            DecimalFormat money = new DecimalFormat("#,##0");
            out.add(money.format(values.get(i)) + " " + days.get(i).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        }
        return out;
    }

    /** N04: the formatter is created once. */
    List<String> once(List<Date> values) {
        SimpleDateFormat f = new SimpleDateFormat(DATE);
        List<String> out = new ArrayList<>();
        for (Date d : values) {
            out.add(f.format(d));
        }
        return out;
    }

    /** B03: the formatter is made only for the row that ends the loop. */
    String firstAfter(List<Date> values, Date after) {
        for (Date d : values) {
            if (d.after(after)) {
                SimpleDateFormat f = new SimpleDateFormat(DATE);
                return f.format(d);
            }
        }
        return null;
    }

    /** N05: each row has its own pattern. */
    List<String> patterns(List<Date> values, List<String> formats) {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < values.size(); i++) {
            out.add(new SimpleDateFormat(formats.get(i)).format(values.get(i)));
        }
        return out;
    }
}
