package org.apache.logging.log4j;

/** Stub of the Log4j 2 level (fixture only). */
public final class Level {
    public static final Level TRACE = new Level();
    public static final Level DEBUG = new Level();
    public static final Level INFO = new Level();
    public static final Level WARN = new Level();

    private Level() {
    }
}
