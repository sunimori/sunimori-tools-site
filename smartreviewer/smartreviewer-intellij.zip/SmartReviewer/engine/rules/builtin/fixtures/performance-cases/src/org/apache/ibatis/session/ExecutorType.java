package org.apache.ibatis.session;

/** Stub of the MyBatis executor types (fixture only). */
public enum ExecutorType {
    SIMPLE, REUSE, BATCH
}
