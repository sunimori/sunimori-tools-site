package org.apache.logging.log4j;

/** Stub of the Log4j 2 logger (fixture only). */
public interface Logger {
    boolean isDebugEnabled();

    boolean isInfoEnabled();

    boolean isTraceEnabled();

    boolean isEnabled(Level level);

    void debug(String message);

    void debug(String message, Object... params);

    void info(String message);
}
