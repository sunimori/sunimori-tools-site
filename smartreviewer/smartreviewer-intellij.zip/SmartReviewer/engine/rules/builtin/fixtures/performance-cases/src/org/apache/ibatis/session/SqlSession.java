package org.apache.ibatis.session;

import java.io.Closeable;
import java.util.List;

/** Stub of the MyBatis session (fixture only). */
public interface SqlSession extends Closeable {
    int insert(String statement, Object parameter);

    int update(String statement, Object parameter);

    <T> T selectOne(String statement, Object parameter);

    List<Object> flushStatements();

    void commit();

    @Override
    void close();
}
