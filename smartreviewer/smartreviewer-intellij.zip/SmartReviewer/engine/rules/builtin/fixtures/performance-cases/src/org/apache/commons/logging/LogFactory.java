package org.apache.commons.logging;

/** Stub (fixture only). */
public final class LogFactory {
    private LogFactory() {
    }

    public static Log getLog(Class<?> type) {
        return null;
    }
}
