package example;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.logging.log4j.LogManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Cases added with the fixes of the 2026-10 rule review for the loop-work rules (SR-PERF-*): guards of debug messages, loop exits,
 * the DAO calls the query rule recognises, single-byte file I/O, and what makes a loop's work fixed. The suites select the
 * methods by name, so every name here is unique.
 */
final class FixLCases {
    private static final Logger SLF = LoggerFactory.getLogger(FixLCases.class);
    private static final org.apache.logging.log4j.Logger L4J = LogManager.getLogger(FixLCases.class);
    private static final java.util.logging.Logger JUL = java.util.logging.Logger.getLogger("example");
    private static final String[] QUARTERS = {"Q1", "Q2", "Q3", "Q4"};

    private OrderDao orderDao;
    private OrderDaoImpl orderDaoImpl;
    private AuditDaoImpl auditDao;
    private InvoiceDao invoiceDao;
    private OrderDtoMapper orderDtoMapper;
    private ArtifactRepo artifactRepo;
    private SqlSessionFactory factory;

    /** A DAO whose methods use the project's own verbs. */
    interface InvoiceDao {
        Order create(String customerCode);

        List<Order> list(String customerCode);

        void markPaid(long id);

        void setSource(String source);
    }

    /** An implementation class named after its interface. */
    static class OrderDaoImpl implements OrderDao {
        @Override
        public Order findById(long id) {
            return null;
        }

        @Override
        public List<Order> selectByCustomer(String customerCode) {
            return null;
        }

        @Override
        public int updateStatus(long id, String status) {
            return 0;
        }

        @Override
        public javax.sql.DataSource getDataSource() {
            return null;
        }
    }

    /** An implementation class that has no interface of its own. */
    static class AuditDaoImpl {
        void record(long id, String text) {
        }
    }

    /** A MapStruct-style conversion between objects: no SQL. */
    interface OrderDtoMapper {
        void updateEntityFromDto(OrderDto dto, Order target);
    }

    static class OrderDto {
    }

    /** A repository of files, not a database. */
    static class ArtifactRepo {
        byte[] fetch(String name) {
            return new byte[0];
        }

        void update(String name) {
        }
    }

    enum Weekday { MON, TUE, WED, THU, FRI, SAT, SUN }

    // ------------------------------------------------------------------------------------------------ SR-PERF-LOG-CONCAT-001

    /** A String named like a login is no level check. */
    void fxLogIdVariable(String loginId, int attempts) {
        if (loginId != null) {
            SLF.debug("login attempt " + attempts + " for " + loginId);
        }
    }

    /** A null test of the logger is no level check. */
    void fxLogNullLogger(Logger log, String user) {
        if (log != null) {
            log.debug("user " + user);
        }
    }

    /** A collection named catalog is no level check. */
    void fxLogCatalogLoop(List<String> catalog) {
        if (!catalog.isEmpty()) {
            for (String c : catalog) {
                SLF.debug("entry " + c);
            }
        }
    }

    /** A String named traceId is no debug switch. */
    void fxLogTraceId(String traceId) {
        if (traceId != null) {
            SLF.debug("trace " + traceId);
        }
    }

    /** isInfoEnabled() is true in production: the debug message is still built there. */
    void fxLogWrongLevel(org.apache.logging.log4j.Logger log, String user) {
        if (log.isInfoEnabled()) {
            log.debug("user " + user);
        }
    }

    /** The same with isEnabled(Level.INFO). */
    void fxLogWrongLevelEnabled(String user) {
        if (L4J.isEnabled(org.apache.logging.log4j.Level.INFO)) {
            L4J.debug("user " + user);
        }
    }

    /** The same with java.util.logging. */
    void fxLogJulWrongLevel(String user) {
        if (JUL.isLoggable(Level.INFO)) {
            JUL.fine("user " + user);
        }
    }

    /** The else branch runs when debug is off. */
    void fxLogElseBranch(String user) {
        if (SLF.isDebugEnabled()) {
            SLF.debug("user {}", user);
        } else {
            SLF.debug("user " + user);
        }
    }

    /** Leaving when debug is ON: the message is built exactly when it is off. */
    void fxLogReturnWhenEnabled(String user) {
        if (SLF.isDebugEnabled()) {
            return;
        }
        SLF.debug("user " + user);
    }

    /** java.util.logging log(Level, message) names its level in the first argument. */
    void fxLogJulLevelArgument(String user) {
        JUL.log(Level.FINEST, "user " + user);
    }

    /** The lambda of forEach runs inside the level check. */
    void fxLogLambdaGuard(List<String> items) {
        if (SLF.isDebugEnabled()) {
            items.forEach(i -> SLF.debug("item " + i));
        }
    }

    /** The same after an early return. */
    void fxLogLambdaEarlyReturn(List<String> items) {
        if (!SLF.isDebugEnabled()) {
            return;
        }
        items.forEach(i -> SLF.debug("item " + i));
    }

    /** The else branch of a negated level check runs when the level is on. */
    void fxLogNegatedElse(String user) {
        if (!SLF.isDebugEnabled()) {
            SLF.info("quiet");
        } else {
            SLF.debug("user " + user);
        }
    }

    /** A null test combined with the level check. */
    void fxLogNullAndLevel(String user) {
        if (SLF != null && SLF.isDebugEnabled()) {
            SLF.debug("user " + user);
        }
    }

    /** isLoggable(Level.FINE) for a fine message. */
    void fxLogJulFine(String user) {
        if (JUL.isLoggable(Level.FINE)) {
            JUL.fine("user " + user);
        }
    }

    /** The debug check also covers the trace message in the same block. */
    void fxLogDebugBlockWithTrace(String a, String b) {
        if (SLF.isDebugEnabled()) {
            SLF.debug("a " + a);
            SLF.trace("b " + b);
        }
    }

    /** isEnabled(Level.DEBUG). */
    void fxLogEnabledDebugLevel(String user) {
        if (L4J.isEnabled(org.apache.logging.log4j.Level.DEBUG)) {
            L4J.debug("user " + user);
        }
    }

    /** A boolean switch named debug. */
    void fxLogBooleanFlag(boolean debugEnabled, String user) {
        if (debugEnabled) {
            SLF.debug("user " + user);
        }
    }

    /** A level number named debugLevel, compared in the condition. */
    void fxLogLevelNumber(int debugLevel, String user) {
        if (debugLevel > 1) {
            SLF.debug("user " + user);
        }
    }

    // ------------------------------------------------------------------------------------------------ SR-PERF-QUERY-IN-LOOP-001

    /** A method reference given to map runs once per element. */
    List<Order> fxQueryMethodRef(List<Long> ids) {
        return ids.stream().map(orderDao::findById).collect(Collectors.toList());
    }

    /** The value function of Collectors.toMap runs once per element. */
    Map<Long, Order> fxQueryToMap(List<Long> ids) {
        return ids.stream().collect(Collectors.toMap(id -> id, id -> orderDao.findById(id)));
    }

    /** The receiver is typed with the implementation class of the DAO. */
    List<Order> fxQueryImplReceiver(List<Long> ids) {
        List<Order> out = new ArrayList<>();
        for (Long id : ids) {
            out.add(orderDaoImpl.findById(id));
        }
        return out;
    }

    /** An implementation class named ...DaoImpl without any interface. */
    void fxQueryImplWithoutInterface(List<Long> ids) {
        for (Long id : ids) {
            auditDao.record(id, "seen");
        }
    }

    /** create, list and markPaid are data access verbs of the project's own DAO. */
    void fxQueryProjectVerbs(List<String> codes) {
        for (String c : codes) {
            invoiceDao.create(c);
            invoiceDao.list(c);
            invoiceDao.markPaid(c.length());
        }
    }

    /** Setters, Object methods and getters of a DAO are no queries. */
    void fxQueryNoSqlMethods(List<String> codes) {
        for (String c : codes) {
            invoiceDao.setSource(c);
            String text = orderDaoImpl.toString();
            boolean same = orderDaoImpl.equals(c);
            orderDaoImpl.getDataSource();
        }
    }

    /** A MyBatis session in batch mode queues the statements. */
    void fxQueryMyBatisBatch(List<Order> orders) {
        try (SqlSession session = factory.openSession(ExecutorType.BATCH)) {
            for (Order o : orders) {
                session.insert("example.OrderMapper.insert", o);
            }
            session.flushStatements();
            session.commit();
        }
    }

    /** A MyBatis session in the default mode runs each insert. */
    void fxQueryMyBatisSimple(List<Order> orders) {
        try (SqlSession session = factory.openSession()) {
            for (Order o : orders) {
                session.insert("example.OrderMapper.insert", o);
            }
            session.commit();
        }
    }

    /** A mapper that copies between objects touches no database. */
    void fxQueryMapStruct(List<OrderDto> dtos, List<Order> targets) {
        for (int i = 0; i < dtos.size(); i++) {
            orderDtoMapper.updateEntityFromDto(dtos.get(i), targets.get(i));
        }
    }

    /** A Repo class is not one of the documented data access types. */
    long fxQueryRepoSuffix(List<String> names) {
        long total = 0;
        for (String n : names) {
            total += artifactRepo.fetch(n).length;
            artifactRepo.update(n);
        }
        return total;
    }

    /** The statement of a retry is prepared again only after a failure; the attempt returns. */
    int fxQueryWhileRetry(Connection c, long id, int maxAttempts) throws SQLException {
        int attempt = 0;
        while (true) {
            try (PreparedStatement ps = c.prepareStatement("update orders set status = 'DONE' where id = ?")) {
                ps.setLong(1, id);
                return ps.executeUpdate();
            } catch (SQLException e) {
                if (++attempt >= maxAttempts) {
                    throw e;
                }
            }
        }
    }

    /** Preparing and executing a statement for each element in a try-with-resources is two calls per element. */
    void fxQueryPrepareInTry(Connection c, List<Long> ids) throws SQLException {
        for (Long id : ids) {
            try (PreparedStatement ps = c.prepareStatement("delete from orders where id = ?")) {
                ps.setLong(1, id);
                ps.executeUpdate();
            }
        }
    }

    /** Each arm of an arrow switch is a branch: the throw of the default arm does not end the loop for the others. */
    void fxQueryArrowSwitch(List<Order> orders) {
        for (Order o : orders) {
            switch (o.getCustomerCode()) {
                case "NEW" -> orderDao.updateStatus(o.getId(), "SYNCED");
                case "OLD" -> orderDao.findById(o.getId());
                default -> throw new IllegalStateException("unknown " + o.getCustomerCode());
            }
        }
    }

    /** The colon form of the same switch. */
    void fxQueryColonSwitch(List<Order> orders) {
        for (Order o : orders) {
            switch (o.getCustomerCode()) {
                case "NEW":
                    orderDao.updateStatus(o.getId(), "SYNCED");
                    break;
                case "OLD":
                    orderDao.findById(o.getId());
                    break;
                default:
                    throw new IllegalStateException("unknown " + o.getCustomerCode());
            }
        }
    }

    /** The call of the first arm is followed by a return; the call of the second arm is not. */
    Order fxQueryArrowReturn(List<String> kinds, long id) {
        for (String k : kinds) {
            switch (k) {
                case "A" -> {
                    orderDao.updateStatus(id, "A");
                    return null;
                }
                case "B" -> orderDao.findById(id);
                default -> id++;
            }
        }
        return null;
    }

    /** Four fixed iterations inside a loop over all customers are four queries per customer. */
    long fxQueryQuarters(List<String> codes) {
        long total = 0;
        for (String code : codes) {
            for (int q = 1; q <= 4; q++) {
                total += orderDao.selectByCustomer(code + q).size();
            }
        }
        return total;
    }

    /** Every enclosing loop has a fixed count: nine queries, however often the method runs. */
    void fxQueryFixedNested() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                orderDao.findById(i * 3 + j);
            }
        }
    }

    /** A for-each over a constant list is a fixed loop. */
    void fxQueryFixedForEach() {
        for (long id : new long[] {1L, 2L, 3L}) {
            orderDao.findById(id);
        }
    }

    // ------------------------------------------------------------------------------------------------ SR-PERF-UNBUFFERED-IO-001

    /** The stream is assigned in the try (the style before try-with-resources). */
    int fxIoNullAssign(File f) throws IOException {
        InputStream in = null;
        int n = 0;
        try {
            in = new FileInputStream(f);
            while (in.read() != -1) {
                n++;
            }
        } finally {
            if (in != null) {
                in.close();
            }
        }
        return n;
    }

    /** One byte of each file: the stream is new in every iteration, nothing is read byte by byte. */
    int fxIoOneBytePerFile(List<File> files) throws IOException {
        int n = 0;
        for (File f : files) {
            try (FileInputStream in = new FileInputStream(f)) {
                if (in.read() == '%') {
                    n++;
                }
            }
        }
        return n;
    }

    /** The same with a variable declared before the loop and assigned in it. */
    int fxIoOneBytePerFileLegacy(List<File> files) throws IOException {
        int n = 0;
        FileInputStream in = null;
        for (File f : files) {
            try {
                in = new FileInputStream(f);
                if (in.read() == '%') {
                    n++;
                }
            } finally {
                if (in != null) {
                    in.close();
                }
            }
        }
        return n;
    }

    /** Every byte of each file is read one by one. */
    int fxIoBytesOfEachFile(List<File> files) throws IOException {
        int n = 0;
        for (File f : files) {
            try (FileInputStream in = new FileInputStream(f)) {
                while (in.read() != -1) {
                    n++;
                }
            }
        }
        return n;
    }

    /** One byte written to each new file. */
    void fxIoOneWritePerFile(List<File> files) throws IOException {
        for (File f : files) {
            try (FileOutputStream out = new FileOutputStream(f)) {
                out.write(0);
            }
        }
    }

    /** The variable is wrapped in a buffer before the loop. */
    int fxIoWrappedAfterOpen(File f) throws IOException {
        InputStream in = null;
        int n = 0;
        try {
            in = new FileInputStream(f);
            in = new BufferedInputStream(in);
            while (in.read() != -1) {
                n++;
            }
        } finally {
            if (in != null) {
                in.close();
            }
        }
        return n;
    }

    // ------------------------------------------------------------------------------------------------ SR-PERF-STRING-CONCAT-001

    /** Each arm of an arrow switch is a branch; the string keeps growing through the first two. */
    String fxConcatArrowSwitch(List<String> kinds) {
        String out = "";
        for (String k : kinds) {
            switch (k) {
                case "a" -> out += "<A:" + k + ">";
                case "b" -> out += "<B:" + k + ">";
                default -> throw new IllegalArgumentException(k);
            }
        }
        return out;
    }

    /** Three cells per row inside a loop over all rows. */
    String fxConcatRowCells(List<String[]> rows) {
        String out = "";
        for (String[] row : rows) {
            for (int i = 0; i < 3; i++) {
                out += row[i] + ";";
            }
            out += "\n";
        }
        return out;
    }

    /** The buffer is emptied after its use in the same iteration: nothing accumulates. */
    int fxConcatResetAfterUse(List<String> rows) {
        String chunk = "";
        int sent = 0;
        for (String r : rows) {
            chunk += r;
            sent += chunk.length();
            chunk = "";
        }
        return sent;
    }

    /** The buffer is emptied only when it is large: it accumulates between the resets. */
    int fxConcatConditionalReset(List<String> rows) {
        String chunk = "";
        int sent = 0;
        for (String r : rows) {
            chunk += r;
            if (chunk.length() > 1000) {
                sent += chunk.length();
                chunk = "";
            }
        }
        return sent;
    }

    /** A continue between the concatenation and the reset skips the reset. */
    int fxConcatResetSkipped(List<String> rows) {
        String chunk = "";
        int sent = 0;
        for (String r : rows) {
            chunk += r;
            if (r.isEmpty()) {
                continue;
            }
            sent += chunk.length();
            chunk = "";
        }
        return sent;
    }

    /** A for-each over an array literal has a fixed count. */
    String fxConcatArrayLiteral() {
        String s = "";
        for (String q : new String[] {"Q1", "Q2", "Q3"}) {
            s += q + ";";
        }
        return s;
    }

    /** A for-each over the constants of an enum has a fixed count. */
    String fxConcatEnumValues() {
        String h = "";
        for (Weekday d : Weekday.values()) {
            h += d + ",";
        }
        return h;
    }

    /** A for-each over a constant array field has a fixed count. */
    String fxConcatConstantField(int year) {
        String h = "";
        for (String q : QUARTERS) {
            h += year + q + ";";
        }
        return h;
    }

    /** A for-each over List.of(...) has a fixed count. */
    String fxConcatListOf() {
        String s = "";
        for (String q : List.of("a", "b", "c")) {
            s += q + ";";
        }
        return s;
    }

    /** An array that arrives as a parameter has any length. */
    String fxConcatParameterArray(String[] parts) {
        String s = "";
        for (String p : parts) {
            s += p + ";";
        }
        return s;
    }

    /** concat copies the whole string just like +. */
    String fxConcatMethod(List<String> parts) {
        String result = "";
        for (String p : parts) {
            result = result.concat(p);
        }
        return result;
    }

    // ------------------------------------------------------------------------------------------------ SR-PERF-REGEX-IN-LOOP-001

    /** The pattern is compiled on first use only. */
    int fxRegexLazy(List<String> values) {
        Pattern p = null;
        int n = 0;
        for (String v : values) {
            if (p == null) {
                p = Pattern.compile("[0-9]+");
            }
            if (p.matcher(v).matches()) {
                n++;
            }
        }
        return n;
    }

    /** The pattern is compiled again in every iteration. */
    int fxRegexReassigned(List<String> values) {
        Pattern p = null;
        int n = 0;
        for (String v : values) {
            p = Pattern.compile("[0-9]+");
            if (p.matcher(v).matches()) {
                n++;
            }
        }
        return n;
    }

    /** Three iterations over a constant list. */
    String fxRegexConstantSource(String text) {
        String t = text;
        for (String ignored : List.of("a", "b", "c")) {
            t = t.replaceAll("\\s+", " ");
        }
        return t;
    }

    // ------------------------------------------------------------------------------------------------ SR-PERF-FORMAT-IN-LOOP-001

    /** The formatter is created on first use only. */
    List<String> fxFormatLazy(List<Date> dates) {
        List<String> out = new ArrayList<>();
        SimpleDateFormat f = null;
        for (Date d : dates) {
            if (f == null) {
                f = new SimpleDateFormat("yyyyMMdd");
            }
            out.add(f.format(d));
        }
        return out;
    }

    /** new Locale(...) with constant arguments does not change. */
    List<String> fxFormatNewLocale(List<Date> dates) {
        List<String> out = new ArrayList<>();
        for (Date d : dates) {
            out.add(new SimpleDateFormat("GGGGy", new Locale("ja", "JP", "JP")).format(d));
        }
        return out;
    }

    /** Locale.getDefault() does not change in the loop. */
    List<String> fxFormatDefaultLocale(List<Date> dates) {
        List<String> out = new ArrayList<>();
        for (Date d : dates) {
            out.add(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(d));
        }
        return out;
    }

    /** The symbols of a constant locale. */
    List<String> fxFormatSymbols(List<Double> values) {
        List<String> out = new ArrayList<>();
        for (Double v : values) {
            out.add(new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.JAPAN)).format(v));
        }
        return out;
    }

    /** The locale is made from an element of another list: it differs between the iterations. */
    List<String> fxFormatLocaleOfElement(List<Date> dates, List<String> languages) {
        List<String> out = new ArrayList<>();
        for (int i = 0; i < dates.size(); i++) {
            out.add(new SimpleDateFormat("yyyy", new Locale(languages.get(i))).format(dates.get(i)));
        }
        return out;
    }

    /** Four fixed iterations inside a loop over many years. */
    List<String> fxFormatQuarters(List<double[]> yearly) {
        List<String> out = new ArrayList<>();
        for (double[] year : yearly) {
            for (int q = 0; q < 4; q++) {
                out.add(new DecimalFormat("#,##0").format(year[q]));
            }
        }
        return out;
    }

    /** A for-each over an array literal has a fixed count. */
    List<String> fxFormatArrayLiteral(int n) {
        List<String> out = new ArrayList<>();
        for (String suffix : new String[] {"A", "B", "C"}) {
            out.add(new DecimalFormat("000").format(n) + suffix);
        }
        return out;
    }

    // ------------------------------------------------------------------------------------------------ SR-PERF-KEYSET-GET-001

    /** The key is declared before the loop and set from the iterator in it. */
    int fxKeyDeclaredBefore(Map<String, Integer> counts) {
        int total = 0;
        Iterator<String> it = counts.keySet().iterator();
        String key = null;
        while (it.hasNext()) {
            key = it.next();
            total += counts.get(key);
        }
        return total;
    }

    /** The key is also set to something else in the loop. */
    int fxKeyReassigned(Map<String, Integer> counts) {
        int total = 0;
        Iterator<String> it = counts.keySet().iterator();
        String key = null;
        while (it.hasNext()) {
            key = it.next();
            if (key.isEmpty()) {
                key = "none";
            }
            total += counts.get(key);
        }
        return total;
    }

    /** keySet().forEach with a lookup of each key. */
    List<String> fxKeyForEachLambda(Map<String, Integer> counts) {
        List<String> out = new ArrayList<>();
        counts.keySet().forEach(k -> out.add(k + "=" + counts.get(k)));
        return out;
    }

    /** The lookup in the predicate of a stream of the keys. */
    long fxKeyStreamFilter(Map<String, Integer> counts) {
        return counts.keySet().stream().filter(k -> counts.get(k) > 0).count();
    }

    /** The keys of one map looked up in another. */
    int fxKeyOtherMapLambda(Map<String, Integer> left, Map<String, Integer> right) {
        int[] total = new int[1];
        left.keySet().forEach(k -> total[0] += right.get(k));
        return total[0];
    }

    // ------------------------------------------------------------------------------------------------ SR-PERF-LINKEDLIST-GET-001

    /** The index is derived from the loop counter. */
    long fxLinkedMinusOne(LinkedList<Long> readings, int n) {
        long sum = 0;
        for (int i = 1; i < n; i++) {
            sum += readings.get(i - 1);
        }
        return sum;
    }

    /** The index is a counter that the call increments itself. */
    int fxLinkedPostIncrement(List<String> codes, LinkedList<String> names) {
        int idx = 0;
        int n = 0;
        for (String c : codes) {
            n += c.length() + names.get(idx++).length();
        }
        return n;
    }

    /** The index of the outer loop used inside the inner loop. */
    int fxLinkedOuterIndex(LinkedList<String> accounts, List<String> codes) {
        int matches = 0;
        for (int i = 0; i < accounts.size(); i++) {
            for (String code : codes) {
                if (accounts.get(i).startsWith(code)) {
                    matches++;
                }
            }
        }
        return matches;
    }

    /** Counting from the end. */
    long fxLinkedReverse(LinkedList<Long> values) {
        long total = 0;
        for (int i = 0; i < values.size(); i++) {
            total += values.get(values.size() - 1 - i);
        }
        return total;
    }

    /** An index that does not follow the loop counter (times is not changed). */
    long fxLinkedFixedOffset(LinkedList<Long> values, int times) {
        long total = 0;
        for (int i = 0; i < times; i++) {
            total += values.get(times - 1);
        }
        return total;
    }

    // ------------------------------------------------------------------------------------------------ SR-PERF-LIST-SEARCH-001

    /** De-duplicating three constants is no quadratic work. */
    List<String> fxListSearchConstants() {
        List<String> out = new ArrayList<>();
        for (String s : new String[] {"a", "b", "a"}) {
            if (!out.contains(s)) {
                out.add(s);
            }
        }
        return out;
    }

    /** Three cells per row inside a loop over all rows: the list grows with the rows. */
    List<String> fxListSearchCells(List<String[]> rows) {
        List<String> out = new ArrayList<>();
        for (String[] row : rows) {
            for (int i = 0; i < 3; i++) {
                if (!out.contains(row[i])) {
                    out.add(row[i]);
                }
            }
        }
        return out;
    }
}
