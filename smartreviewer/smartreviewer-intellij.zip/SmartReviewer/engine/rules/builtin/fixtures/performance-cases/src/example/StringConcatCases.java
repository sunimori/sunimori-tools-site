package example;

import java.util.List;
import java.util.Map;

/** Cases for SR-PERF-STRING-CONCAT-001: a String grown with + in a loop. */
final class StringConcatCases {
    private String log = "";

    /** P01: CSV built with += over every row. */
    String csv(List<String> rows) {
        String out = "";
        for (String row : rows) {
            out += row;
            out += "\r\n";
        }
        return out;
    }

    /** P02: s = s + ... in a while loop over a map's entries. */
    String query(Map<String, String> conditions) {
        String where = " WHERE 1 = 1";
        java.util.Iterator<Map.Entry<String, String>> it = conditions.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, String> e = it.next();
            where = where + " AND " + e.getKey() + " = '" + e.getValue() + "'";
        }
        return where;
    }

    /** P03: a field accumulates in a counting loop. */
    void history(String[] events) {
        for (int i = 0; i < events.length; i++) {
            this.log = this.log + events[i];
        }
    }

    /** N01: StringBuilder. */
    String builder(List<String> rows) {
        StringBuilder sb = new StringBuilder();
        for (String row : rows) {
            sb.append(row).append("\r\n");
        }
        return sb.toString();
    }

    /** N02: the string is declared inside the loop, so nothing accumulates across iterations. */
    int lines(List<String> rows) {
        int total = 0;
        for (String row : rows) {
            String line = "";
            line += row;
            line += ";";
            total += line.length();
        }
        return total;
    }

    /** B01: zero padding: the loop is bounded by the string's own length and only constants are added. */
    String pad(String code) {
        String s = code;
        while (s.length() < 8) {
            s = "0" + s;
        }
        return s;
    }

    /** B02: the loop is left right after the concatenation. */
    String first(List<String> rows, String prefix) {
        String found = "";
        for (String row : rows) {
            if (row.startsWith(prefix)) {
                found += row;
                break;
            }
        }
        return found;
    }

    /** B03: three fixed iterations. */
    String three(String[] parts) {
        String s = "";
        for (int i = 0; i < 3; i++) {
            s += parts[i];
        }
        return s;
    }

    /** P04: a break that only leaves the switch: the loop goes on and the string keeps growing. */
    String marked(List<String> rows) {
        String out = "";
        for (String row : rows) {
            switch (row.isEmpty() ? ' ' : row.charAt(0)) {
                case '*':
                    out += row;
                    break;
                default:
                    break;
            }
        }
        return out;
    }

    /** B04: each matching row sets the stamp anew before the time is added, in the block that encloses the append. */
    String lastStamp(List<String[]> rows) {
        String stamp = null;
        for (String[] r : rows) {
            if (r.length > 1) {
                stamp = r[0];
                if (!r[1].isEmpty()) {
                    stamp += " " + r[1];
                }
            }
        }
        return stamp;
    }
}
