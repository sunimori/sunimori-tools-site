package example;

/** An entity (fixture). */
class Order {
    long id;
    String customerCode;
    String status;

    long getId() {
        return id;
    }

    String getCustomerCode() {
        return customerCode;
    }
}
