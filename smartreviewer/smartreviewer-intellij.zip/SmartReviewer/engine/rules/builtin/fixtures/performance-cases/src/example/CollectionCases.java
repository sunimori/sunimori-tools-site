package example;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Cases for SR-PERF-LINKEDLIST-GET-001, SR-PERF-KEYSET-GET-001 and SR-PERF-LIST-SEARCH-001: collection access that turns a loop
 * quadratic or doubles its lookups.
 */
final class CollectionCases {
    /** P01: LinkedList.get(i) walks the list from the start in every iteration. */
    long sumLinked(LinkedList<Long> values) {
        long total = 0;
        for (int i = 0; i < values.size(); i++) {
            total += values.get(i);
        }
        return total;
    }

    /** N01: ArrayList.get(i) is constant time. */
    long sumArray(ArrayList<Long> values) {
        long total = 0;
        for (int i = 0; i < values.size(); i++) {
            total += values.get(i);
        }
        return total;
    }

    /** B01: a fixed index is no walk per iteration (one lookup of the first element). */
    long firstTimes(LinkedList<Long> values, int times) {
        long total = 0;
        for (int i = 0; i < times; i++) {
            total += values.get(0);
        }
        return total;
    }

    /** P02: the key set is iterated and each value looked up again. */
    int total(Map<String, Integer> counts) {
        int total = 0;
        for (String key : counts.keySet()) {
            total += counts.get(key);
        }
        return total;
    }

    /** P03: the same with an iterator (pre-Java 5 style). */
    int totalIterator(Map<String, Integer> counts) {
        int total = 0;
        Iterator<String> it = counts.keySet().iterator();
        while (it.hasNext()) {
            String key = it.next();
            total += counts.get(key);
        }
        return total;
    }

    /** B02: a lookup for some of the keys only is still a second lookup of each of them. */
    int someKeys(Map<String, Integer> counts, String prefix) {
        int total = 0;
        for (String key : counts.keySet()) {
            if (key.startsWith(prefix)) {
                total += counts.get(key);
            }
        }
        return total;
    }

    /** N02: entrySet. */
    int totalEntries(Map<String, Integer> counts) {
        int total = 0;
        for (Map.Entry<String, Integer> e : counts.entrySet()) {
            total += e.getValue();
        }
        return total;
    }

    /** N03: keys of one map looked up in another map. */
    int join(Map<String, Integer> left, Map<String, Integer> right) {
        int total = 0;
        for (String key : left.keySet()) {
            Integer r = right.get(key);
            total += r == null ? 0 : r;
        }
        return total;
    }

    /** P04: de-duplication with contains on the list being filled. */
    List<String> distinct(List<String> codes) {
        List<String> out = new ArrayList<>();
        for (String code : codes) {
            if (!out.contains(code)) {
                out.add(code);
            }
        }
        return out;
    }

    /** N04: a set does the same in constant time. */
    Set<String> distinctSet(List<String> codes) {
        Set<String> out = new LinkedHashSet<>();
        for (String code : codes) {
            if (!out.contains(code)) {
                out.add(code);
            }
        }
        return out;
    }

    /** N05: contains on a list that the loop does not change (its size is not known to grow). */
    int known(List<String> codes, List<String> allowed) {
        int n = 0;
        for (String code : codes) {
            if (allowed.contains(code)) {
                n++;
            }
        }
        return n;
    }

    /** B02: remove(int) removes by position; it is not a search. */
    void trim(List<String> codes, int keep) {
        List<String> out = new ArrayList<>(codes);
        while (out.size() > keep) {
            out.remove(out.size() - 1);
            out.add(0, "");
            out.remove(0);
        }
    }

    /** P05: indexOf on the growing list. */
    List<Integer> positions(List<String> words) {
        List<String> seen = new ArrayList<>();
        List<Integer> out = new ArrayList<>();
        for (String w : words) {
            int at = seen.indexOf(w);
            if (at < 0) {
                seen.add(w);
                at = seen.size() - 1;
            }
            out.add(at);
        }
        return out;
    }

    /** N06: a set built first (no search in a list). */
    int unique(List<String> words) {
        Set<String> s = new HashSet<>(words);
        return s.size();
    }

    /** B03: two lookups of the same key in one loop: one finding for the loop. */
    int spread(Map<String, Integer> counts) {
        int max = 0;
        int min = Integer.MAX_VALUE;
        for (String key : counts.keySet()) {
            max = Math.max(max, counts.get(key));
            min = Math.min(min, counts.get(key));
        }
        return max - min;
    }

    /** B04: the lookup returns, so it runs once. */
    Integer firstLong(Map<String, Integer> counts) {
        for (String key : counts.keySet()) {
            if (key.length() > 10) {
                return counts.get(key);
            }
        }
        return null;
    }

    static final class Group {
        final Map<String, String> entries = new java.util.HashMap<>();
    }

    /** N07: the keys of one group's map looked up in another group's map (the same field of another object). */
    List<String> copies(Group src, Group dst) {
        List<String> out = new ArrayList<>();
        for (String id : src.entries.keySet()) {
            out.add(id + "=" + dst.entries.get(id));
        }
        return out;
    }

    /** B05: two searches in the same growing list: one finding for the loop. */
    List<String> merge(List<String> words) {
        List<String> out = new ArrayList<>();
        for (String w : words) {
            if (out.contains(w) || out.indexOf(w.trim()) >= 0) {
                continue;
            }
            out.add(w);
        }
        return out;
    }

    /** B06: two lookups of the same index: one finding for the loop. */
    long positives(LinkedList<Long> values) {
        long total = 0;
        for (int i = 0; i < values.size(); i++) {
            if (values.get(i) > 0) {
                total += values.get(i);
            }
        }
        return total;
    }
}
