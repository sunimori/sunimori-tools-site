package example;

import java.util.List;

/** A DAO of the application (fixture). */
interface OrderDao {
    Order findById(long id);

    List<Order> selectByCustomer(String customerCode);

    int updateStatus(long id, String status);

    javax.sql.DataSource getDataSource();
}
