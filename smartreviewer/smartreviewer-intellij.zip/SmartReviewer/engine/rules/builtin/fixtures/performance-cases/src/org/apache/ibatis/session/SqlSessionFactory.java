package org.apache.ibatis.session;

/** Stub (fixture only). */
public interface SqlSessionFactory {
    SqlSession openSession();

    SqlSession openSession(ExecutorType type);
}
