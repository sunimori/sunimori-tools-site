package example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

/** Cases for SR-PERF-QUERY-IN-LOOP-001: database calls repeated for each element (N+1). */
final class QueryLoopCases {
    private OrderDao orderDao;
    private EntityManager em;

    /** P01: one query per id with a statement prepared once. */
    List<String> names(Connection c, List<Long> ids) throws SQLException {
        List<String> out = new ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement("select name from customer where id = ?")) {
            for (Long id : ids) {
                ps.setLong(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        out.add(rs.getString(1));
                    }
                }
            }
        }
        return out;
    }

    /** P02: for each order row, another query for its lines (the statement is also prepared each time). */
    int lines(Connection c) throws SQLException {
        int total = 0;
        try (Statement st = c.createStatement(); ResultSet orders = st.executeQuery("select id from orders")) {
            while (orders.next()) {
                PreparedStatement ps = c.prepareStatement("select count(*) from order_line where order_id = ?");
                ps.setLong(1, orders.getLong(1));
                ResultSet rs = ps.executeQuery();
                rs.next();
                total += rs.getInt(1);
            }
        }
        return total;
    }

    /** P03: a DAO lookup per element, in a stream. */
    List<Order> orders(List<Long> ids) {
        List<Order> out = new ArrayList<>();
        ids.forEach(id -> out.add(orderDao.findById(id)));
        return out;
    }

    /** P04: JPA find per id. */
    List<Order> entities(List<Long> ids) {
        List<Order> out = new ArrayList<>();
        for (Long id : ids) {
            out.add(em.find(Order.class, id));
        }
        return out;
    }

    /** N01: batch insert: addBatch in the loop, one executeBatch after it. */
    void insert(Connection c, List<Order> orders) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("insert into orders (id, status) values (?, ?)")) {
            for (Order o : orders) {
                ps.setLong(1, o.id);
                ps.setString(2, o.status);
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    /** N02: one query, and getters of the loaded objects in the loop. */
    List<String> codes(String customer) {
        List<String> out = new ArrayList<>();
        for (Order o : orderDao.selectByCustomer(customer)) {
            out.add(o.getCustomerCode());
        }
        return out;
    }

    /** N03: Optional.map is no loop. */
    Optional<Order> one(Optional<Long> id) {
        return id.map(orderDao::findById).or(() -> id.map(x -> orderDao.findById(x)));
    }

    /** B01: a retry loop with three attempts. */
    int retry(Connection c, long id) throws SQLException {
        SQLException last = null;
        for (int attempt = 0; attempt < 3; attempt++) {
            try (PreparedStatement ps = c.prepareStatement("update orders set status = 'DONE' where id = ?")) {
                ps.setLong(1, id);
                return ps.executeUpdate();
            } catch (SQLException e) {
                last = e;
            }
        }
        throw last;
    }

    /** B02: a getter of the DAO itself is no query. */
    int sources(List<Long> ids) {
        int n = 0;
        for (Long id : ids) {
            n += orderDao.getDataSource() == null ? 0 : 1;
        }
        return n;
    }
}
