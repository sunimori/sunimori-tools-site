package org.slf4j;

/** Stub (fixture only). */
public final class LoggerFactory {
    private LoggerFactory() {
    }

    public static Logger getLogger(Class<?> type) {
        return null;
    }
}
