package org.apache.logging.log4j;

/** Stub (fixture only). */
public final class LogManager {
    private LogManager() {
    }

    public static Logger getLogger(Class<?> type) {
        return null;
    }
}
