package javax.persistence;

/** Stub of the JPA entity manager (fixture only). */
public interface EntityManager {
    <T> T find(Class<T> type, Object id);

    Query createQuery(String jpql);
}
