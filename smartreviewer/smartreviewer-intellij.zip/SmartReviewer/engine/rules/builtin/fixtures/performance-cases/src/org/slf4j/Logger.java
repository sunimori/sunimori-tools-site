package org.slf4j;

/** Stub of the SLF4J logger (fixture only). */
public interface Logger {
    boolean isDebugEnabled();

    boolean isTraceEnabled();

    void debug(String msg);

    void debug(String format, Object arg);

    void trace(String msg);

    void info(String msg);

    void info(String format, Object arg);
}
