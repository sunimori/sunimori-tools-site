package org.apache.commons.logging;

/** Stub of the commons-logging log (fixture only). */
public interface Log {
    boolean isDebugEnabled();

    void debug(Object message);

    void info(Object message);
}
