package example;

import java.util.List;
import java.util.logging.Level;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Cases for SR-PERF-LOG-CONCAT-001: debug messages built even when debug logging is off. */
final class LogCases {
    private static final Log LOG = LogFactory.getLog(LogCases.class);
    private static final Logger SLF = LoggerFactory.getLogger(LogCases.class);
    private static final java.util.logging.Logger JUL = java.util.logging.Logger.getLogger("example");
    private static final boolean DEBUG = false;

    /** P01: commons-logging debug with concatenation. */
    void save(Order order) {
        LOG.debug("save order: id=" + order.getId() + ", customer=" + order.getCustomerCode());
    }

    /** P02: in a loop, with java.util.logging fine. */
    void each(List<Order> orders) {
        for (Order o : orders) {
            JUL.fine("order " + o.getId());
            JUL.log(Level.FINER, "customer " + o.getCustomerCode());
        }
    }

    /** P03: SLF4J debug with concatenation instead of a placeholder. */
    void slf(Order order) {
        SLF.debug("order " + order.getId());
    }

    /** N01: guarded by the level check. */
    void guarded(Order order) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("save order: id=" + order.getId());
        }
    }

    /** N02: SLF4J placeholder. */
    void placeholder(Order order) {
        SLF.debug("order {}", order.getId());
    }

    /** N03: info level is normally on; the message is needed. */
    void info(Order order) {
        LOG.info("saved order " + order.getId());
    }

    /** N04: constants only (folded by the compiler). */
    void constant() {
        LOG.debug("start " + "of " + "batch");
    }

    /** B01: an early return when debug is off guards the rest of the method. */
    void early(Order order) {
        if (!SLF.isDebugEnabled()) {
            return;
        }
        SLF.debug("order " + order.getId() + " " + order.getCustomerCode());
    }

    /** B02: a constant flag named DEBUG is taken as a guard. */
    void flag(Order order) {
        if (DEBUG) {
            LOG.debug("order " + order.getId());
        }
    }
}
