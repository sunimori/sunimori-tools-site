package javax.persistence;

import java.util.List;

/** Stub (fixture only). */
public interface Query {
    Query setParameter(String name, Object value);

    List<?> getResultList();

    Object getSingleResult();
}
