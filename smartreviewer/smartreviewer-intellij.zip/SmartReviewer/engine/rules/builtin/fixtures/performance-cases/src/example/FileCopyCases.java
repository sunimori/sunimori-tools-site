package example;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;

/** Cases for SR-PERF-UNBUFFERED-IO-001: one system call per byte. */
final class FileCopyCases {
    /** P01: byte-by-byte copy between unbuffered file streams. */
    void copy(File from, File to) throws IOException {
        try (FileInputStream in = new FileInputStream(from); FileOutputStream out = new FileOutputStream(to)) {
            int b;
            while ((b = in.read()) != -1) {
                out.write(b);
            }
        }
    }

    /** P02: an InputStream variable that holds a FileInputStream. */
    long checksum(File f) throws IOException {
        long sum = 0;
        InputStream in = new FileInputStream(f);
        try {
            for (int b = in.read(); b >= 0; b = in.read()) {
                sum += b;
            }
        } finally {
            in.close();
        }
        return sum;
    }

    /** P03: RandomAccessFile read() in a loop. */
    int countLines(File f) throws IOException {
        int n = 0;
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            int c;
            while ((c = raf.read()) != -1) {
                if (c == '\n') {
                    n++;
                }
            }
        }
        return n;
    }

    /** N01: buffered streams. */
    void buffered(File from, File to) throws IOException {
        try (InputStream in = new BufferedInputStream(new FileInputStream(from));
             OutputStream out = new BufferedOutputStream(new FileOutputStream(to))) {
            int b;
            while ((b = in.read()) != -1) {
                out.write(b);
            }
        }
    }

    /** N02: block reads. */
    void blocks(File from, File to) throws IOException {
        byte[] buf = new byte[8192];
        try (FileInputStream in = new FileInputStream(from); FileOutputStream out = new FileOutputStream(to)) {
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
        }
    }

    /** B01: a single read outside any loop (a magic byte). */
    int magic(File f) throws IOException {
        try (FileInputStream in = new FileInputStream(f)) {
            return in.read();
        }
    }
}
