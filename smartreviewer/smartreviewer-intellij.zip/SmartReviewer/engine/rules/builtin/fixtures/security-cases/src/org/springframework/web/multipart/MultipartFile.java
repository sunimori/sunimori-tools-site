package org.springframework.web.multipart;

/** Stub (fixture only). */
public interface MultipartFile {
    String getOriginalFilename();

    void transferTo(java.io.File dest) throws java.io.IOException;
}
