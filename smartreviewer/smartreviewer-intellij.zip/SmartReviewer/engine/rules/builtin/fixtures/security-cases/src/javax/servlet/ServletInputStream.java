package javax.servlet;

/** Stub (fixture only). */
public abstract class ServletInputStream extends java.io.InputStream {
}
