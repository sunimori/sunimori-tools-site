package org.springframework.data.repository;

/** Stub (fixture only). */
public interface CrudRepository<T, ID> extends Repository<T, ID> {
    java.util.Optional<T> findById(ID id);

    void deleteById(ID id);
}
