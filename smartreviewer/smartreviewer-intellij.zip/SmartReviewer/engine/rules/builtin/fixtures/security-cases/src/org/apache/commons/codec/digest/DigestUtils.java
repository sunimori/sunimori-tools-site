package org.apache.commons.codec.digest;

/** Stub (fixture only). */
public final class DigestUtils {
    private DigestUtils() {
    }

    public static String md5Hex(String data) {
        return data;
    }

    public static String sha256Hex(String data) {
        return data;
    }
}
