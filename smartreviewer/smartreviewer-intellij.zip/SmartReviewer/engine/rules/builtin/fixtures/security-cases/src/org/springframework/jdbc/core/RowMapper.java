package org.springframework.jdbc.core;

/** Stub (fixture only). */
public interface RowMapper<T> {
    T mapRow(java.sql.ResultSet rs, int row) throws java.sql.SQLException;
}
