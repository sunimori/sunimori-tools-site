package org.apache.commons.fileupload.servlet;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;

/** Stub (fixture only). */
public class ServletFileUpload {
    public List<FileItem> parseRequest(HttpServletRequest request) throws Exception {
        return null;
    }
}
