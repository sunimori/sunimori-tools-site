package org.apache.commons.lang3;

/** Stub (fixture only). */
public final class StringEscapeUtils {
    private StringEscapeUtils() {
    }

    public static String escapeHtml4(String s) {
        return s;
    }

    public static String escapeEcmaScript(String s) {
        return s;
    }

    public static String unescapeHtml4(String s) {
        return s;
    }
}
