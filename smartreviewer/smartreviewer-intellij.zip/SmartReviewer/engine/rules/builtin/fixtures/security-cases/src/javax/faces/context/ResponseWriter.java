package javax.faces.context;

/** Stub (fixture only). */
public abstract class ResponseWriter extends java.io.Writer {
    public abstract void writeText(Object text, String property);
}
