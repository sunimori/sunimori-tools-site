package org.slf4j;

/** Stub (fixture only). */
public interface Logger {
    void debug(String msg);

    void info(String msg);

    void info(String format, Object arg);

    void warn(String msg);
}
