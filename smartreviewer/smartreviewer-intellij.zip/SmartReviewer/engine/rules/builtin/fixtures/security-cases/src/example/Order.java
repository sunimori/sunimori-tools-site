package example;

/** An entity (fixture). */
public class Order {
    private long id;
    private String owner;
    private String password;

    public long getId() {
        return id;
    }

    public String getOwner() {
        return owner;
    }

    public String getPassword() {
        return password;
    }
}
