package example;

import java.io.InputStream;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.dom4j.io.SAXReader;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;

/**
 * Regression cases of the security API rules for libraries that are not on the class path (commons-lang3, HttpClient 4, dom4j and
 * Spring Security are not among the stubs of this project): their calls do not resolve, but the imports name the types.
 */
public class FixS2NoLibCases {
    /** P: the legacy MD5 password encoder of Spring Security. */
    private final Md5PasswordEncoder passwordEncoder = new Md5PasswordEncoder();

    /** P: commons-lang3 random text for an API key. */
    String fxApiKeyFromLang3() {
        String apiKey = RandomStringUtils.randomAlphanumeric(40);
        return apiKey;
    }

    /** P: HttpClient 4 trusts self-signed certificates. */
    Object fxSelfSignedFromHttpClient4() {
        return new TrustSelfSignedStrategy();
    }

    /** P: dom4j reads an upload without settings. */
    Object fxDom4jReader(InputStream in) throws Exception {
        SAXReader reader = new SAXReader();
        return reader.read(in);
    }

    /** N: an own class of the same simple name is not dom4j's. */
    static class Local {
        static class SAXReader {
            Object read(InputStream in) {
                return null;
            }
        }

        Object fxOwnReader(InputStream in) {
            return new SAXReader().read(in);
        }
    }
}
