package org.apache.http.conn.ssl;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

/** Stub (fixture only). */
public class SSLConnectionSocketFactory {
    public static final HostnameVerifier ALLOW_ALL_HOSTNAME_VERIFIER = null;

    public SSLConnectionSocketFactory(SSLContext context, HostnameVerifier verifier) {
    }
}
