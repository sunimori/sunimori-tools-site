package example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringEscapeUtils;

/** Cases for SR-SEC-SQL-INJECTION-001 and SR-SEC-SQL-DYNAMIC-001. */
public class SqlCases extends HttpServlet {
    private Connection connection;
    private EntityManager em;
    private String tableName = "customer";

    /** P01 (injection): a request parameter pasted into the SQL of a Statement. */
    List<String> search(HttpServletRequest request) throws SQLException {
        String name = request.getParameter("name");
        List<String> out = new ArrayList<>();
        try (Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("SELECT id FROM customer WHERE name = '" + name + "'")) {
            while (rs.next()) {
                out.add(rs.getString(1));
            }
        }
        return out;
    }

    /** P02 (injection): dynamic conditions built with a StringBuilder, then prepared (the pasted text is not a parameter). */
    PreparedStatement filter(HttpServletRequest request) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT * FROM orders WHERE 1 = 1");
        String status = request.getParameter("status");
        if (status != null && !status.isEmpty()) {
            sql.append(" AND status = '").append(status.trim()).append("'");
        }
        String sort = request.getParameter("sort");
        if (sort != null) {
            sql.append(" ORDER BY ").append(sort);
        }
        return connection.prepareStatement(sql.toString());
    }

    /** P03 (injection): JPQL with a request value. */
    List<?> jpql(HttpServletRequest request) {
        return em.createQuery("select o from Order o where o.customer.name like '%" + request.getParameter("q") + "%'").getResultList();
    }

    /** N01: bind variables. */
    List<String> safe(HttpServletRequest request) throws SQLException {
        List<String> out = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement("SELECT id FROM customer WHERE name = ?")) {
            ps.setString(1, request.getParameter("name"));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(rs.getString(1));
                }
            }
        }
        return out;
    }

    /** N02: the request value is a number by the time it reaches the SQL. */
    int count(HttpServletRequest request) throws SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery("SELECT count(*) FROM orders WHERE customer_id = " + id)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    /** N03: escaped for SQL. */
    int escaped(HttpServletRequest request) throws SQLException {
        String name = StringEscapeUtils.escapeSql(request.getParameter("name"));
        try (Statement st = connection.createStatement()) {
            return st.executeUpdate("UPDATE customer SET flag = 1 WHERE name = '" + name + "'");
        }
    }

    /** B01: an allow-list check on the column name before it is pasted (validated). */
    PreparedStatement sorted(HttpServletRequest request) throws SQLException {
        String column = request.getParameter("column");
        if (!column.matches("[A-Za-z_]{1,30}")) {
            throw new IllegalArgumentException("column");
        }
        return connection.prepareStatement("SELECT * FROM orders ORDER BY " + column);
    }

    /** P04 (dynamic): a DAO method pastes its parameter; who calls it decides whether that is safe. */
    int deleteByCode(String code) throws SQLException {
        try (Statement st = connection.createStatement()) {
            return st.executeUpdate("DELETE FROM item WHERE code = '" + code + "'");
        }
    }

    /** P05 (dynamic): a table name from a field. */
    int countRows() throws SQLException {
        try (Statement st = connection.createStatement(); ResultSet rs = st.executeQuery("SELECT count(*) FROM " + tableName)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    /** N04 (dynamic): only constants and a number. */
    int older(int days) throws SQLException {
        try (Statement st = connection.createStatement()) {
            return st.executeUpdate("DELETE FROM log WHERE created < CURRENT_DATE - " + days);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws Exception {
        search(request);
    }
}
