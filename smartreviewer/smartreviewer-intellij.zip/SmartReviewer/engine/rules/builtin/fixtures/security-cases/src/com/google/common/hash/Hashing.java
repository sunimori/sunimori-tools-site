package com.google.common.hash;

/** Stub (fixture only). */
public final class Hashing {
    private Hashing() {
    }

    public static HashFunction md5() {
        return null;
    }

    public static HashFunction sha256() {
        return null;
    }
}
