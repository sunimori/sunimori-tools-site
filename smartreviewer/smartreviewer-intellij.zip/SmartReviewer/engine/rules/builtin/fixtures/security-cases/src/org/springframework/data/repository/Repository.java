package org.springframework.data.repository;

/** Stub (fixture only). */
public interface Repository<T, ID> {
}
