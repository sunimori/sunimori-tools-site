package javax.servlet.http;

import java.io.InputStream;

/** Stub (fixture only). */
public interface Part {
    InputStream getInputStream();

    String getSubmittedFileName();
}
