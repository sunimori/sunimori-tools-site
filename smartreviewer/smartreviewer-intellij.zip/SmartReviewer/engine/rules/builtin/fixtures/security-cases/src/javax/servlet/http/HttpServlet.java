package javax.servlet.http;

import javax.servlet.ServletContext;

/** Stub (fixture only). */
public abstract class HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws Exception {
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws Exception {
    }

    public ServletContext getServletContext() {
        return null;
    }
}
