package org.apache.struts.util;

/** Stub of Struts 1 (fixture only). */
public final class ResponseUtils {
    private ResponseUtils() {
    }

    public static String filter(String value) {
        return value;
    }
}
