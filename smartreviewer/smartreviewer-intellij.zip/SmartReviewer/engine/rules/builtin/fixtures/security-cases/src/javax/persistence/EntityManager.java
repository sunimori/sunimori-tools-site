package javax.persistence;

/** Stub (fixture only). */
public interface EntityManager {
    <T> T find(Class<T> type, Object id);

    Query createQuery(String jpql);

    Query createNativeQuery(String sql);
}
