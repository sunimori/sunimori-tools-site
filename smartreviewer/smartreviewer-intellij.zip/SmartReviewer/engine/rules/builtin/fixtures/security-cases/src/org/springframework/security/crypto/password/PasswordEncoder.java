package org.springframework.security.crypto.password;

/** Stub (fixture only). */
public interface PasswordEncoder {
    String encode(CharSequence rawPassword);

    boolean matches(CharSequence rawPassword, String encodedPassword);
}
