package org.apache.struts.action;

/** Stub (fixture only). */
public class ActionMapping {
    public ActionForward findForward(String name) {
        return null;
    }
}
