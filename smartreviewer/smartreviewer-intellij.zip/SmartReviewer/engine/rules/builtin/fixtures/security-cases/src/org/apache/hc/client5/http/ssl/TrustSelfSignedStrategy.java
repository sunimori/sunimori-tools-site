package org.apache.hc.client5.http.ssl;

/** Stub (fixture only). */
public class TrustSelfSignedStrategy {
}
