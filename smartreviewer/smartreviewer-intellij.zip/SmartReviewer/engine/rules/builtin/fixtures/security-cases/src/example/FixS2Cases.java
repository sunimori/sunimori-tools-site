package example;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509ExtendedTrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;

import org.apache.ibatis.annotations.Select;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.shiro.crypto.hash.SimpleHash;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseCookie;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import static org.apache.http.conn.ssl.SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;

/**
 * Regression cases of the security API rules (credentials, log secrets, XXE, cookies, TLS, hashes, random numbers, MyBatis ${}):
 * the names and shapes that the first versions of the rules did not handle.
 */
public class FixS2Cases {
    private static final Logger LOG = LoggerFactory.getLogger(FixS2Cases.class);
    private static final java.util.logging.Logger JUL = java.util.logging.Logger.getLogger("fx");
    private static final Random FX_RANDOM = new Random();
    private static final boolean FX_SECURE_OFF = false;
    private static final boolean FX_FORBID_DOCTYPE = true;
    private static final boolean FX_SKIP_CHECK = true;

    // ------------------------------------------------------------------ credentials: names

    /** P: a key of a service (apiKey, API_KEY). */
    private static final String API_KEY = "sk_live_51Hx7Qz";
    /** P: SECRET_KEY. */
    private static final String SECRET_KEY = "k3Zp0wQx9L";
    /** P: accessKey. */
    private String accessKey = "AKIAIOSFODNN7EXAMPLE";
    /** P: privateKey. */
    private String privateKey = "q8Zr2Lm5Tn";
    /** P: the password word written in one piece. */
    private String dbpassword = "Xy7#kQ29";
    /** P: digits after the word. */
    private String password1 = "Xy7#kQ29";
    /** P: digits after the abbreviation. */
    private String pwd2 = "Xy7#kQ29";
    /** P: pw, the short form. */
    private static final String DB_PW = "Xy7#kQ29";
    /** P: a word for the value itself after the term. */
    private String secretCode = "483920";
    /** P: passwordText. */
    private String passwordText = "Xy7#kQ29";
    /** N: the message of a check, not a password. */
    private static final String ERR_PASSWORD_EMPTY = "E1001";
    /** N: the message of a check. */
    private static final String MSG_PASSWORD_EXPIRED = "MSG0042";
    /** N: describes the password, does not hold it. */
    private String passwordPolicy = "strong";

    // ------------------------------------------------------------------ credentials: shapes of the value

    /** P: an AWS secret key contains slashes. */
    static boolean fxAwsSecret() {
        String awsSecretKey = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";
        return awsSecretKey.isEmpty();
    }

    /** P: a PEM block has blanks, and its header says private key. */
    static boolean fxPemKey() {
        String privateKeyPem = "-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEAxyz\n-----END RSA PRIVATE KEY-----";
        return privateKeyPem.isEmpty();
    }

    /** P: two literals. */
    static int fxConcatenated() {
        String password = "Xy7" + "#kQ29";
        return password.length();
    }

    /** P: the bytes of a literal. */
    static int fxBytes() {
        byte[] secretKey = "0123456789abcdef".getBytes(StandardCharsets.UTF_8);
        return secretKey.length;
    }

    /** P: a text block. */
    static int fxTextBlock() {
        String secret = """
                Xy7#kQ29
                """;
        return secret.length();
    }

    /** B: a path is not a secret. */
    static int fxKeyFile() {
        String secretKey = "config/db.properties";
        return secretKey.length();
    }

    /** B: a location with a scheme is not a secret. */
    static int fxKeyLocation() {
        String privateKey = "classpath:keys/private.pem";
        return privateKey.length();
    }

    /** B: a format. */
    static int fxPasswordFormat() {
        String password = "%s%s";
        return password.length();
    }

    /** P: the key of a property names the secret. */
    static Properties fxPutSecretKey() {
        Properties p = new Properties();
        p.put("secretKey", "Xy7#kQ29");
        return p;
    }

    /** P: a dotted key. */
    static Properties fxSetPropertyAccessKey() {
        Properties p = new Properties();
        p.setProperty("aws.access_key", "AKIAIOSFODNN7EXAMPLE");
        return p;
    }

    /** Setters and builders of a form, for the cases below. */
    static class Form {
        void setSecretKey(String v) {
        }

        void setPassengerName(String v) {
        }

        void setTokenType(String v) {
        }

        void setPasswordPolicy(String v) {
        }

        void setPasswordRequired(String v) {
        }

        void setSecretaryName(String v) {
        }
    }

    /** Builder style. */
    static class Builder {
        Builder username(String u) {
            return this;
        }

        Builder password(String p) {
            return this;
        }
    }

    /** P: a setter named for the secret. */
    static void fxSetSecretKey(Form f) {
        f.setSecretKey("k3Zp0wQx9L");
    }

    /** P: builder style, .password("x"). */
    static Builder fxBuilderPassword() {
        return new Builder().username("admin").password("Xy7#kQ29");
    }

    /** N: setters whose name only starts with a secret word or goes on with another word. */
    static void fxSetterLabels(Form f) {
        f.setPassengerName("Taro");
        f.setTokenType("Bearer");
        f.setPasswordPolicy("strong");
        f.setPasswordRequired("true");
        f.setSecretaryName("Suzuki");
    }

    /** N: words that contain pass or secret and are other words. */
    static String fxLookalikes() {
        String compass = "northeast";
        String bypass = "enabled";
        String passenger = "Taro";
        String secretary = "Suzuki";
        return compass + bypass + passenger + secretary;
    }

    /** N: names with key that are no secrets. */
    static String fxKeyNames() {
        String primaryKey = "order_id";
        String keyName = "name";
        String publicKey = "MIIBIjANBgkqhkiG9w0B";
        String sortKey = "created_at";
        String cacheKey = "orders_v2";
        String mapKey = "k1";
        String keyStore = "keystore.jks";
        return primaryKey + keyName + publicKey + sortKey + cacheKey + mapKey + keyStore;
    }

    // ------------------------------------------------------------------ logging

    /** An object with getters of secrets. */
    static class Creds {
        String getApiKey() {
            return "";
        }
    }

    /** P: secretKey. */
    static void fxLogSecretKey(String secretKey) {
        LOG.info("k=" + secretKey);
    }

    /** P: the getter of an api key. */
    static void fxLogApiKeyGetter(Creds creds) {
        LOG.debug("c " + creds.getApiKey());
    }

    /** P: an access token. */
    static void fxLogAccessToken(String accessToken) {
        LOG.info("t=" + accessToken);
    }

    /** P: the parameter named password. */
    static void fxLogParameter(HttpServletRequest request) {
        LOG.info("pwd=" + request.getParameter("password"));
    }

    /** P: a lazy message. */
    static void fxLogSupplier(String password) {
        JUL.info(() -> "pwd=" + password);
    }

    /** P: pw. */
    static void fxLogShortName(String pw) {
        LOG.info("pw=" + pw);
    }

    /** P: dbpassword. */
    static void fxLogJoined(String dbpassword) {
        LOG.info("pw=" + dbpassword);
    }

    /** Lombok adds the field log to this class; the annotation here only stands for it. */
    @interface Slf4j {
    }

    /** P: a Lombok logger. */
    @Slf4j
    static class WithLombok {
        void fxLombokLog(String password) {
            log.info("pwd=" + password);
        }
    }

    static String mask(String s) {
        return "****";
    }

    static String sha256Hex(String s) {
        return s;
    }

    /** N: masked by a helper. */
    static void fxLogMasked(String password) {
        LOG.info("pwd=" + mask(password));
    }

    /** N: the advised remedy. */
    static void fxLogReplaced(String password) {
        LOG.info("pwd=" + password.replaceAll(".", "*"));
    }

    /** N: the length of a char[]. */
    static void fxLogCharArrayLength(char[] password) {
        LOG.info("pwd length=" + password.length);
    }

    /** N: a provider of credentials is no credential. */
    static void fxLogProvider(Object credentialsProvider) {
        LOG.info("using " + credentialsProvider);
    }

    /** N: a hash. */
    static void fxLogHashed(String password) {
        LOG.info("pwd hash=" + sha256Hex(password));
    }

    /** N: the message of a check. */
    static void fxLogErrorMessage(java.util.ResourceBundle bundle) {
        String ERR_PASSWORD_INVALID = bundle.getString("err.password.invalid");
        LOG.info(ERR_PASSWORD_INVALID);
    }

    /** B: a bare token is a token of a parser. */
    static void fxLogParserToken(java.util.StringTokenizer parser) {
        String token = parser.nextToken();
        LOG.info("token=" + token);
    }

    /** N: a fact about the key, not the key. */
    static void fxLogKeyAlgorithm(javax.crypto.SecretKey secretKey) {
        LOG.info("key algorithm " + secretKey.getAlgorithm());
    }

    // ------------------------------------------------------------------ XML parsers

    private static final String[] FX_SAFE_FEATURES = {"http://apache.org/xml/features/disallow-doctype-decl"};
    private static final List<String> FX_OPEN_FEATURES = List.of("http://xml.org/sax/features/external-general-entities");

    /** N: Boolean.FALSE for the StAX switches. */
    XMLStreamReader fxStaxBoxedFalse(InputStream in) throws Exception {
        XMLInputFactory f = XMLInputFactory.newInstance();
        f.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
        f.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        return f.createXMLStreamReader(in);
    }

    /** N: secure processing with Boolean.TRUE. */
    Document fxSecureProcessingBoxed(InputStream in) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, Boolean.TRUE);
        return dbf.newDocumentBuilder().parse(in);
    }

    /** N: a constant as the value. */
    Document fxConstantValue(InputStream in) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", FX_FORBID_DOCTYPE);
        return dbf.newDocumentBuilder().parse(in);
    }

    /** N: a local that is false and never changes. */
    XMLStreamReader fxLocalFalse(InputStream in) throws Exception {
        boolean dtdAllowed = false;
        XMLInputFactory f = XMLInputFactory.newInstance();
        f.setProperty(XMLInputFactory.SUPPORT_DTD, dtdAllowed);
        return f.createXMLStreamReader(in);
    }

    /** N: the features come from an array of constants and all get true. */
    Document fxFeatureLoop(InputStream in) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        for (String feature : FX_SAFE_FEATURES) {
            dbf.setFeature(feature, true);
        }
        return dbf.newDocumentBuilder().parse(in);
    }

    /** P: the loop sets external-general-entities to true, which is no hardening. */
    Document fxFeatureLoopOpen(InputStream in) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        for (String feature : FX_OPEN_FEATURES) {
            dbf.setFeature(feature, true);
        }
        return dbf.newDocumentBuilder().parse(in);
    }

    /** N: the XMLReader that parses is hardened. */
    void fxReaderHardened(InputStream in) throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        XMLReader reader = spf.newSAXParser().getXMLReader();
        reader.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        reader.parse(new InputSource(in));
    }

    /** N: JAXP 1.5 access properties on the SAXParser. */
    void fxParserProperties(InputStream in, DefaultHandler handler) throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        SAXParser parser = spf.newSAXParser();
        parser.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        parser.parse(in, handler);
    }

    /** N: general and parameter entities both off. */
    Document fxEntitiesOff(InputStream in) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
        dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        return dbf.newDocumentBuilder().parse(in);
    }

    /** P: only the general entities are off; parameter entities and the external DTD stay on. */
    Document fxGeneralEntitiesOnly(InputStream in) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
        return dbf.newDocumentBuilder().parse(in);
    }

    /** P: only the external DTD is not loaded. */
    Document fxExternalDtdOnly(InputStream in) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        return dbf.newDocumentBuilder().parse(in);
    }

    /** P: the feature is set after the document was parsed. */
    Document fxFeatureAfterParse(InputStream in) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = dbf.newDocumentBuilder();
        Document doc = builder.parse(in);
        dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        return doc;
    }

    /** P: the builder was made before the factory was hardened. */
    Document fxFeatureAfterBuilder(InputStream in) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = dbf.newDocumentBuilder();
        dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        return builder.parse(in);
    }

    /** P: the reader is hardened after it parsed. */
    void fxReaderAfterParse(InputStream in) throws Exception {
        XMLReader reader = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
        reader.parse(new InputSource(in));
        reader.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
    }

    /** N: a DOM tree written through a variable typed Source; nothing is parsed. */
    void fxWriteDomThroughSource(org.w3c.dom.Node node, java.io.OutputStream out) throws Exception {
        javax.xml.transform.Transformer t = javax.xml.transform.TransformerFactory.newInstance().newTransformer();
        javax.xml.transform.Source source = new javax.xml.transform.dom.DOMSource(node);
        t.transform(source, new javax.xml.transform.stream.StreamResult(out));
    }

    // ------------------------------------------------------------------ cookies

    /** A cookie class of the application. */
    static class AppCookie extends Cookie {
        AppCookie(String name, String value) {
            super(name, value);
        }
    }

    /** P: a subclass of Cookie. */
    void fxSubclassCookie(HttpServletResponse response) {
        AppCookie c = new AppCookie("a", "b");
        response.addCookie(c);
    }

    static void fxHardenCookie(Cookie c) {
        c.setSecure(true);
        c.setHttpOnly(true);
        c.setPath("/");
    }

    static void fxHardenSecureOnly(Cookie c) {
        c.setSecure(true);
    }

    /** N: a helper of this class sets both flags. */
    void fxCookieViaHelper(HttpServletResponse response, String token) {
        Cookie c = new Cookie("sid", token);
        fxHardenCookie(c);
        response.addCookie(c);
    }

    /** P: the helper sets Secure only. */
    void fxCookieHalfHardened(HttpServletResponse response, String token) {
        Cookie c = new Cookie("sid", token);
        fxHardenSecureOnly(c);
        response.addCookie(c);
    }

    /** P: a constant false is no protection. */
    void fxCookieConstantFalse(HttpServletResponse response, String token) {
        Cookie c = new Cookie("sid", token);
        c.setSecure(FX_SECURE_OFF);
        c.setHttpOnly(true);
        response.addCookie(c);
    }

    /** N: deleting with maxAge(0L). */
    String fxSpringDeleteLong() {
        return ResponseCookie.from("sid", "").path("/").maxAge(0L).build().toString();
    }

    /** N: deleting with Duration.ZERO. */
    String fxSpringDeleteDuration() {
        return ResponseCookie.from("sid", "").path("/").maxAge(java.time.Duration.ZERO).build().toString();
    }

    /** P: the builder is kept in a variable, the flags are never set. */
    ResponseCookie fxSpringBuilderVariable(String token) {
        ResponseCookie.ResponseCookieBuilder b = ResponseCookie.from("access", token);
        b.path("/");
        return b.build();
    }

    /** N: the builder in a variable gets both flags. */
    ResponseCookie fxSpringBuilderHardened(String token) {
        ResponseCookie.ResponseCookieBuilder b = ResponseCookie.from("access", token);
        b.secure(true);
        b.httpOnly(true);
        return b.build();
    }

    /** N: an Expires date in the past deletes the cookie. */
    void fxHeaderExpired(HttpServletResponse response) {
        response.addHeader("Set-Cookie", "SID=; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Path=/");
    }

    /** P: the cookie is named secureSession, which is not the Secure attribute. */
    void fxHeaderSecureInName(HttpServletResponse response, String id) {
        response.addHeader("Set-Cookie", "secureSession=" + id + "; Path=/; HttpOnly");
    }

    /** P: httponly in the path is not the HttpOnly attribute. */
    void fxHeaderHttpOnlyInPath(HttpServletResponse response, String id) {
        response.addHeader("Set-Cookie", "SID=" + id + "; Path=/httponly-demo; Secure");
    }

    /** P: the header is kept in a variable. */
    void fxHeaderInVariable(HttpServletResponse response, String id) {
        String header = "SID=" + id + "; Path=/";
        response.addHeader("Set-Cookie", header);
    }

    /** N: the header in a variable has both attributes. */
    void fxHeaderInVariableHardened(HttpServletResponse response, String id) {
        String header = "SID=" + id + "; Path=/; Secure; HttpOnly";
        response.addHeader("Set-Cookie", header);
    }

    /** B: the attributes are built at run time; they may carry the flags. */
    void fxHeaderAttributesAtRuntime(HttpServletResponse response, String id, String attributes) {
        response.addHeader("Set-Cookie", "SID=" + id + ";" + attributes);
    }

    // ------------------------------------------------------------------ TLS

    /** Constants and a delegate for the cases below. */
    static class FxKeys {
        static final String ALLOW_ALL_HOSTNAME_VERIFIER = "app.tls.allow-all-hostname-verifier";
    }

    /** P: warning() is logging, not a check. */
    static TrustManager fxJulWarning() {
        return new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) {
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
                JUL.warning("server certificate is not verified");
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        };
    }

    /** P: the logged text calls a getter; it is still only logging. */
    static TrustManager fxLogWithGetter() {
        return new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) {
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
                JUL.info("trusting " + chain[0].getSubjectX500Principal().getName());
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        };
    }

    /** P: the failure of the delegate is swallowed. */
    static TrustManager fxSwallowed(X509TrustManager delegate) {
        return new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                delegate.checkClientTrusted(chain, authType);
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
                try {
                    delegate.checkServerTrusted(chain, authType);
                } catch (CertificateException e) {
                    // self-signed certificates are fine here
                }
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return delegate.getAcceptedIssuers();
            }
        };
    }

    /** P: the failure is swallowed, with a log line. */
    static TrustManager fxSwallowedWithLog(X509TrustManager delegate) {
        return new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                delegate.checkClientTrusted(chain, authType);
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
                try {
                    delegate.checkServerTrusted(chain, authType);
                } catch (CertificateException e) {
                    JUL.warning("ignoring an untrusted certificate");
                }
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return delegate.getAcceptedIssuers();
            }
        };
    }

    /** N: the failure of the delegate is passed on. */
    static TrustManager fxRethrown(X509TrustManager delegate) {
        return new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                delegate.checkClientTrusted(chain, authType);
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
                try {
                    delegate.checkServerTrusted(chain, authType);
                } catch (CertificateException e) {
                    throw new IllegalStateException(e);
                }
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return delegate.getAcceptedIssuers();
            }
        };
    }

    /** P: X509ExtendedTrustManager has three checkServerTrusted methods; the class is reported once. */
    static TrustManager fxExtended() {
        return new X509ExtendedTrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) {
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
            }

            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType, java.net.Socket socket) {
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType, java.net.Socket socket) {
            }

            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType, SSLEngine engine) {
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType, SSLEngine engine) {
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        };
    }

    /** P: HttpClient's ALLOW_ALL_HOSTNAME_VERIFIER through a static import. */
    static SSLConnectionSocketFactory fxStaticImportAllowAll(SSLContext context) {
        return new SSLConnectionSocketFactory(context, ALLOW_ALL_HOSTNAME_VERIFIER);
    }

    /** N: a constant of the application with the same name is a property key. */
    static String fxOwnAllowAllConstant() {
        return FxKeys.ALLOW_ALL_HOSTNAME_VERIFIER;
    }

    /** P: HttpClient 5 trusts self-signed certificates. */
    static Object fxClient5SelfSigned() {
        return new org.apache.hc.client5.http.ssl.TrustSelfSignedStrategy();
    }

    /** P: a constant that is true. */
    static HostnameVerifier fxConstantVerifier() {
        return (host, session) -> FX_SKIP_CHECK;
    }

    // ------------------------------------------------------------------ hashes

    /** P: Spring's DigestUtils. */
    static String fxSpringMd5(String password) {
        return org.springframework.util.DigestUtils.md5DigestAsHex(password.getBytes(StandardCharsets.UTF_8));
    }

    /** P: Guava. */
    static String fxGuavaMd5(String password) {
        return com.google.common.hash.Hashing.md5().hashString(password, StandardCharsets.UTF_8).toString();
    }

    /** P: Shiro Md5Hash. */
    static String fxShiroMd5(String password) {
        return new Md5Hash(password).toHex();
    }

    /** P: Shiro SimpleHash with SHA-1. */
    static String fxShiroSha1(String password, String salt) {
        return new SimpleHash("SHA-1", password, salt, 1).toHex();
    }

    /** N: pass is a boarding pass. */
    static byte[] fxBoardingPass(String boardingPass) throws Exception {
        return MessageDigest.getInstance("MD5").digest(boardingPass.getBytes(StandardCharsets.UTF_8));
    }

    /** The class name says password, the method and its parameter do not. */
    static class PasswordUtil {
        static String encrypt(String plain) throws Exception {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] out = md.digest(plain.getBytes(StandardCharsets.UTF_8));
            return new java.math.BigInteger(1, out).toString(16);
        }
    }

    /** N: a class called PasswordService, but the digest is of an e-mail address. */
    static class PasswordService {
        static String avatarHash(String email) throws Exception {
            byte[] d = MessageDigest.getInstance("MD5").digest(email.trim().toLowerCase().getBytes(StandardCharsets.UTF_8));
            return new java.math.BigInteger(1, d).toString(16);
        }
    }

    /** P: a PasswordEncoder, with the parameter name an IDE generates. */
    static class LegacyEncoder implements PasswordEncoder {
        @Override
        public String encode(CharSequence charSequence) {
            try {
                byte[] d = MessageDigest.getInstance("MD5").digest(charSequence.toString().getBytes(StandardCharsets.UTF_8));
                return new java.math.BigInteger(1, d).toString(16);
            } catch (Exception e) {
                throw new IllegalStateException(e);
            }
        }

        @Override
        public boolean matches(CharSequence charSequence, String s) {
            return encode(charSequence).equals(s);
        }
    }

    // ------------------------------------------------------------------ random numbers

    private final Random fxTyped = new java.security.SecureRandom();
    private final Set<String> validTokens = new HashSet<>();

    /** P: nextBytes fills an array named salt. */
    static byte[] fxFill() {
        byte[] salt = new byte[16];
        new Random().nextBytes(salt);
        return salt;
    }

    /** P: sessionKey. */
    static String fxOpen() {
        String sessionKey = Long.toString(FX_RANDOM.nextLong(), 36);
        return sessionKey;
    }

    /** P: smsCode. */
    static String fxSend() {
        String smsCode = String.format("%06d", FX_RANDOM.nextInt(1000000));
        return smsCode;
    }

    /** P: the collection is named for tokens. */
    void fxFillPool(int n) {
        for (int i = 0; i < n; i++) {
            validTokens.add(Long.toHexString(FX_RANDOM.nextLong()));
        }
    }

    /** P: the text is built in a loop and returned by a method named for the session id. */
    static String fxGenerateSessionId() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            sb.append(Integer.toHexString(FX_RANDOM.nextInt()));
        }
        return sb.toString();
    }

    /** N: a jitter in a method whose name has token in it. */
    static void fxRefreshTokenWithBackoff(int attempt) throws InterruptedException {
        long jitter = ThreadLocalRandom.current().nextInt(500);
        Thread.sleep(200L * attempt + jitter);
    }

    /** N: the coordinates of a captcha image. */
    static int[] fxDrawCaptchaNoise(int width, int height) {
        int x = FX_RANDOM.nextInt(width);
        int y = FX_RANDOM.nextInt(height);
        return new int[] {x, y};
    }

    /** N: the field is declared as Random but holds a SecureRandom. */
    String fxMint() {
        String token = Long.toHexString(fxTyped.nextLong());
        return token;
    }

    // ------------------------------------------------------------------ MyBatis

    /** A mapper interface for the cases below. */
    interface FxMapper {
        /** N: a backslash escapes the substitution, MyBatis keeps the text. */
        @Select("SELECT '\\${x}' FROM dual WHERE id = #{id}")
        String fxEscaped(long id);

        /** N: the segment of a MyBatis-Plus wrapper. */
        @Select("SELECT * FROM orders ${ew.customSqlSegment}")
        List<Order> fxWrapper(Object ew);

        /** P: the wrapper is exempt, the sort column is not. */
        @Select("SELECT * FROM orders ${ew.sqlSegment} ORDER BY ${sort}")
        List<Order> fxWrapperAndSort(Object ew, String sort);
    }
}
