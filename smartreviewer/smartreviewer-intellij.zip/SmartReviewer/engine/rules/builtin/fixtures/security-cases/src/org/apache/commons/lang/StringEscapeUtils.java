package org.apache.commons.lang;

/** Stub (fixture only). */
public final class StringEscapeUtils {
    private StringEscapeUtils() {
    }

    public static String escapeHtml(String s) {
        return s;
    }

    public static String escapeSql(String s) {
        return s;
    }
}
