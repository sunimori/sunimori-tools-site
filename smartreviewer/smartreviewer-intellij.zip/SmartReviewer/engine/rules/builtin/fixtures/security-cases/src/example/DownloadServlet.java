package example;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Set;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringEscapeUtils;

/**
 * Servlet cases for SR-SEC-IDOR-001, SR-SEC-PATH-TRAVERSAL-001, SR-SEC-OPEN-REDIRECT-001, SR-SEC-COMMAND-INJECTION-001 and
 * SR-SEC-XSS-WRITER-001.
 */
public class DownloadServlet extends HttpServlet {
    private static final String BASE = "/var/app/files";
    private static final Set<String> HOSTS = Set.of("db1", "db2");
    private Connection connection;
    private OrderDao orderDao;

    /** P01 (path): a file name from the request joined to the download directory. */
    void download(HttpServletRequest request, HttpServletResponse response) throws IOException {
        File file = new File(BASE, request.getParameter("file"));
        try (InputStream in = new FileInputStream(file)) {
            in.transferTo(response.getOutputStream());
        }
    }

    /** P02 (path): an uploaded file's name used as the path. */
    void upload(HttpServletRequest request) throws IOException {
        Part part = request.getPart("data");
        Path target = Paths.get(BASE, part.getSubmittedFileName());
        Files.copy(part.getInputStream(), target);
    }

    /** N01 (path): only the file name part is kept. */
    void downloadName(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String name = FilenameUtils.getName(request.getParameter("file"));
        Files.copy(Paths.get(BASE, name), response.getOutputStream());
    }

    /** B01 (path): the name is checked against a pattern first (validated). */
    void downloadChecked(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String name = request.getParameter("file");
        if (name == null || !name.matches("[A-Za-z0-9_.-]+")) {
            response.sendRedirect(request.getContextPath() + "/error");
            return;
        }
        Files.copy(new File(BASE, name).toPath(), response.getOutputStream());
    }

    /** P03 (IDOR): an order number from the request reads the order with JDBC. */
    String status(HttpServletRequest request) throws Exception {
        try (PreparedStatement ps = connection.prepareStatement("SELECT status FROM orders WHERE order_no = ?")) {
            ps.setString(1, request.getParameter("orderNo"));
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : null;
            }
        }
    }

    /** P04 (IDOR): a DAO deletes what the request names. */
    void cancel(HttpServletRequest request) {
        String orderNo = request.getParameter("orderNo");
        orderDao.delete(orderNo);
    }

    /** N02 (IDOR): the order is compared with the logged-in user taken from the session. */
    void cancelOwn(HttpServletRequest request) {
        String orderNo = request.getParameter("orderNo");
        Order order = orderDao.findByOrderNo(orderNo);
        if (order != null && order.getOwner().equals(request.getSession().getAttribute("loginUser"))) {
            orderDao.delete(orderNo);
        }
    }

    /** B02 (IDOR): the container's user is known (getRemoteUser), so the method can check ownership. */
    Order view(HttpServletRequest request) {
        String user = request.getRemoteUser();
        Order order = orderDao.findById(Long.parseLong(request.getParameter("id")));
        return order != null && user.equals(order.getOwner()) ? order : null;
    }

    /** P05 (redirect): the return URL from the request. */
    void back(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String url = request.getParameter("returnUrl");
        response.sendRedirect(url);
    }

    /** N03 (redirect): a fixed path with the request value as a query parameter. */
    void list(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.sendRedirect(request.getContextPath() + "/orders?page=" + request.getParameter("page"));
    }

    /** B03 (redirect): only paths on this server are followed (validated). */
    void backChecked(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String url = request.getParameter("returnUrl");
        if (url != null && url.startsWith("/") && !url.startsWith("//")) {
            response.sendRedirect(url);
        }
    }

    /** P06 (command): a host name from the request in a shell command. */
    String ping(HttpServletRequest request) throws IOException {
        Process p = Runtime.getRuntime().exec("ping -c 1 " + request.getParameter("host"));
        return new String(p.getInputStream().readAllBytes());
    }

    /** P07 (command): ProcessBuilder with a request argument. */
    void convert(HttpServletRequest request) throws IOException {
        new ProcessBuilder("convert", request.getParameter("image"), "/tmp/out.png").start();
    }

    /** N04 (command): a fixed command. */
    void uptime() throws IOException {
        Runtime.getRuntime().exec(new String[] {"uptime"});
    }

    /** B04 (command): the host is one of a fixed set (validated). */
    void pingKnown(HttpServletRequest request) throws IOException {
        String host = request.getParameter("host");
        if (HOSTS.contains(host)) {
            Runtime.getRuntime().exec(new String[] {"ping", "-c", "1", host});
        }
    }

    /** P08 (XSS): a request parameter written into HTML. */
    void hello(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.getWriter().println("<p>Hello, " + request.getParameter("name") + "</p>");
    }

    /** P09 (XSS): through a PrintWriter variable. */
    void referer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();
        out.print("<a href=\"" + request.getHeader("Referer") + "\">back</a>");
    }

    /** N05 (XSS): escaped. */
    void helloEscaped(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.getWriter().println("<p>Hello, " + StringEscapeUtils.escapeHtml(request.getParameter("name")) + "</p>");
    }

    /** B05 (XSS): a JSON response. */
    void json(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.getWriter().write("{\"name\":\"" + request.getParameter("name") + "\"}");
    }
}
