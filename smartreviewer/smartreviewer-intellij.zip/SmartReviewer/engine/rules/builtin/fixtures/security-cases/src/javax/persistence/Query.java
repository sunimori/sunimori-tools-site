package javax.persistence;

/** Stub (fixture only). */
public interface Query {
    Query setParameter(String name, Object value);

    java.util.List<?> getResultList();
}
