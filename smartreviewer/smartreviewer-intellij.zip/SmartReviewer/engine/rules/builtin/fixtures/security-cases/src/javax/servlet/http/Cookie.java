package javax.servlet.http;

/** Stub (fixture only). */
public class Cookie {
    public Cookie(String name, String value) {
    }

    public String getName() {
        return null;
    }

    public String getValue() {
        return null;
    }

    public void setSecure(boolean secure) {
    }

    public void setHttpOnly(boolean httpOnly) {
    }

    public void setMaxAge(int seconds) {
    }

    public void setPath(String path) {
    }
}
