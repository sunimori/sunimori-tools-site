package org.apache.ibatis.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** Stub (fixture only). */
@Retention(RetentionPolicy.RUNTIME)
public @interface Update {
    String[] value();
}
