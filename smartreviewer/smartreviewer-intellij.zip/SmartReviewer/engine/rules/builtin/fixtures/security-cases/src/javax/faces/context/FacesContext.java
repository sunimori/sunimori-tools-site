package javax.faces.context;

/** Stub of JSF (fixture only). */
public abstract class FacesContext {
    public static FacesContext getCurrentInstance() {
        return null;
    }

    public abstract ExternalContext getExternalContext();

    public abstract ResponseWriter getResponseWriter();
}
