package javax.servlet.http;

import java.security.Principal;

import javax.servlet.ServletRequest;

/** Stub (fixture only). */
public interface HttpServletRequest extends ServletRequest {
    String getHeader(String name);

    Cookie[] getCookies();

    String getPathInfo();

    String getQueryString();

    String getRequestURI();

    String getContextPath();

    HttpSession getSession();

    HttpSession getSession(boolean create);

    Principal getUserPrincipal();

    String getRemoteUser();

    boolean isUserInRole(String role);

    Part getPart(String name);
}
