package org.springframework.web.util;

/** Stub (fixture only). */
public final class HtmlUtils {
    private HtmlUtils() {
    }

    public static String htmlEscape(String input) {
        return input;
    }

    public static String htmlUnescape(String input) {
        return input;
    }
}
