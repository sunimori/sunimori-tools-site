package javax.servlet;

import java.io.BufferedReader;
import java.util.Map;

/** Stub of the Servlet API (fixture only). */
public interface ServletRequest {
    String getParameter(String name);

    String[] getParameterValues(String name);

    Map<String, String[]> getParameterMap();

    ServletInputStream getInputStream();

    BufferedReader getReader();

    Object getAttribute(String name);

    void setAttribute(String name, Object value);
}
