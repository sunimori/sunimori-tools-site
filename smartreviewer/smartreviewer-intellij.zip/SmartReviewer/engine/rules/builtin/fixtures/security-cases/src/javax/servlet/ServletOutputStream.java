package javax.servlet;

/** Stub (fixture only). */
public abstract class ServletOutputStream extends java.io.OutputStream {
    public void print(String s) {
    }

    public void println(String s) {
    }
}
