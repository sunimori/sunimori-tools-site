package org.glassfish.jersey.media.multipart;

/** Stub (fixture only). */
public class FormDataContentDisposition {
    public String getFileName() {
        return null;
    }
}
