package com.google.common.hash;

import java.nio.charset.Charset;

/** Stub (fixture only). */
public interface HashFunction {
    HashCode hashString(CharSequence input, Charset charset);
}
