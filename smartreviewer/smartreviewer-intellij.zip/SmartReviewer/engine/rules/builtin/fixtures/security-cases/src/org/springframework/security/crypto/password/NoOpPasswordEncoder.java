package org.springframework.security.crypto.password;

/** Stub (fixture only). */
public final class NoOpPasswordEncoder {
    public static NoOpPasswordEncoder getInstance() {
        return null;
    }
}
