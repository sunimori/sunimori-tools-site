package org.apache.commons.lang3;

/** Stub (fixture only). */
public final class ArrayUtils {
    private ArrayUtils() {
    }

    public static boolean contains(Object[] array, Object value) {
        return false;
    }
}
