package javax.servlet.http;

import javax.servlet.ServletResponse;

/** Stub (fixture only). */
public interface HttpServletResponse extends ServletResponse {
    void sendRedirect(String location);

    void addCookie(Cookie cookie);

    void setHeader(String name, String value);

    void addHeader(String name, String value);
}
