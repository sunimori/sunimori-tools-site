package org.apache.struts.action;

/** Stub (fixture only). */
public class ActionForward {
}
