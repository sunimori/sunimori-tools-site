package javax.faces.context;

import java.security.Principal;
import java.util.Map;

/** Stub (fixture only). */
public abstract class ExternalContext {
    public abstract Map<String, String> getRequestParameterMap();

    public abstract Map<String, Object> getSessionMap();

    public abstract void redirect(String url);

    public abstract Principal getUserPrincipal();
}
