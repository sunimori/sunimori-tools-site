package example;

import java.io.InputStream;
import java.io.OutputStream;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.springframework.http.ResponseCookie;
import org.w3c.dom.Document;

/** Cases for SR-SEC-XXE-001, SR-SEC-TRUST-ALL-001 and SR-SEC-COOKIE-FLAGS-001. */
public class ConfigCases {
    private static final DocumentBuilderFactory SAFE = DocumentBuilderFactory.newInstance();

    static {
        try {
            SAFE.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    // ------------------------------------------------------------------ XML

    /** P01 (XXE): a default DocumentBuilderFactory parses the upload. */
    Document parse(InputStream in) throws Exception {
        return DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(in);
    }

    /** P02 (XXE): SAXParserFactory without settings. */
    void sax(InputStream in, org.xml.sax.helpers.DefaultHandler handler) throws Exception {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        spf.setNamespaceAware(true);
        spf.newSAXParser().parse(in, handler);
    }

    /** P03 (XXE): StAX with DTDs on. */
    XMLStreamReader stax(InputStream in) throws Exception {
        XMLInputFactory f = XMLInputFactory.newInstance();
        return f.createXMLStreamReader(in);
    }

    /** N01 (XXE): DOCTYPE declarations refused. */
    Document safe(InputStream in) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        dbf.setXIncludeAware(false);
        return dbf.newDocumentBuilder().parse(in);
    }

    /** N02 (XXE): no external DTDs or stylesheets for the transformer. */
    TransformerFactory transformer() {
        TransformerFactory tf = TransformerFactory.newInstance();
        tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        tf.setAttribute(XMLConstants.ACCESS_EXTERNAL_STYLESHEET, "");
        return tf;
    }

    /** N03 (XXE): StAX without DTD support. */
    XMLStreamReader staxSafe(InputStream in) throws Exception {
        XMLInputFactory f = XMLInputFactory.newInstance();
        f.setProperty(XMLInputFactory.SUPPORT_DTD, false);
        return f.createXMLStreamReader(in);
    }

    /** B01 (XXE): the factory is returned to the caller, who may configure it. */
    static SAXParserFactory factory() {
        return SAXParserFactory.newInstance();
    }

    /** B02 (XXE): the shared factory is configured in the static initializer. */
    Document shared(InputStream in) throws Exception {
        return SAFE.newDocumentBuilder().parse(in);
    }

    /** N04 (XXE): secure processing on (the JDK then refuses external DTDs and schemas). */
    Document secureProcessing(InputStream in) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        return dbf.newDocumentBuilder().parse(in);
    }

    /** N05 (XXE): a DOM builder that only creates a document to write: nothing is parsed. */
    Document newExport() throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        DocumentBuilder db = dbf.newDocumentBuilder();
        return db.newDocument();
    }

    /** N06 (XXE): a transformer without a stylesheet that only writes a DOM tree. */
    void write(Document doc, OutputStream out) throws Exception {
        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.setOutputProperty(OutputKeys.INDENT, "yes");
        t.transform(new DOMSource(doc), new StreamResult(out));
    }

    /** P04 (XXE): the transformer reads an uploaded document (StreamSource). */
    void transformUpload(InputStream in, OutputStream out) throws Exception {
        TransformerFactory tf = TransformerFactory.newInstance();
        tf.newTransformer().transform(new StreamSource(in), new StreamResult(out));
    }

    /** B03 (XXE): chosen with ?:, configured and returned to the caller, who may configure it further. */
    static SAXParserFactory configured(String className) {
        SAXParserFactory f = className == null ? SAXParserFactory.newInstance() : SAXParserFactory.newInstance(className, null);
        f.setNamespaceAware(true);
        return f;
    }

    // ------------------------------------------------------------------ TLS

    /** P04 (TLS): a trust manager that trusts every certificate. */
    static SSLContext trustAll() throws Exception {
        TrustManager[] all = {new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) {
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) {
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        }};
        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, all, null);
        return ctx;
    }

    /** P05 (TLS): a hostname verifier that accepts every host. */
    static void anyHost() {
        HttpsURLConnection.setDefaultHostnameVerifier((host, session) -> true);
    }

    /** P06 (TLS): Apache HttpClient's no-op verifier. */
    static HostnameVerifier noop() {
        return NoopHostnameVerifier.INSTANCE;
    }

    /** B04 (TLS): logging before returning true is still no check. */
    static HostnameVerifier logged() {
        return (host, session) -> {
            System.out.println("connecting to " + host);
            return true;
        };
    }

    /** N05 (TLS): a trust manager that delegates to the default one and adds a check. */
    static X509TrustManager pinned(X509TrustManager delegate, String expected) {
        return new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] chain, String authType) throws java.security.cert.CertificateException {
                delegate.checkClientTrusted(chain, authType);
            }

            @Override
            public void checkServerTrusted(X509Certificate[] chain, String authType) throws java.security.cert.CertificateException {
                delegate.checkServerTrusted(chain, authType);
                if (!chain[0].getSubjectX500Principal().getName().contains(expected)) {
                    throw new java.security.cert.CertificateException("unexpected server");
                }
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return delegate.getAcceptedIssuers();
            }
        };
    }

    /** N06 (TLS): a verifier that compares the host. */
    static HostnameVerifier only(String expected) {
        return (host, session) -> host.equalsIgnoreCase(expected);
    }

    static TrustManagerFactory defaults() throws Exception {
        return TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
    }

    // ------------------------------------------------------------------ cookies

    /** P07 (cookie): a login cookie without Secure and HttpOnly. */
    void remember(HttpServletResponse response, String token) {
        Cookie c = new Cookie("REMEMBER_ME", token);
        c.setMaxAge(60 * 60 * 24 * 14);
        c.setPath("/");
        response.addCookie(c);
    }

    /** P08 (cookie): Secure only. */
    void language(HttpServletRequest request, HttpServletResponse response) {
        Cookie c = new Cookie("lang", request.getParameter("lang"));
        c.setSecure(true);
        response.addCookie(c);
    }

    /** P09 (cookie): a Set-Cookie header written by hand. */
    void header(HttpServletResponse response, String id) {
        response.addHeader("Set-Cookie", "SESSIONID=" + id + "; Path=/");
    }

    /** P10 (cookie): Spring's ResponseCookie without httpOnly. */
    String springCookie(String token) {
        return ResponseCookie.from("token", token).secure(true).path("/").build().toString();
    }

    /** N07 (cookie): both flags. */
    void session(HttpServletResponse response, String id) {
        Cookie c = new Cookie("SID", id);
        c.setSecure(true);
        c.setHttpOnly(true);
        response.addCookie(c);
    }

    /** N08 (cookie): deleting a cookie. */
    void logout(HttpServletResponse response) {
        Cookie c = new Cookie("REMEMBER_ME", "");
        c.setMaxAge(0);
        response.addCookie(c);
    }

    /** B03 (cookie): the cookie is made here but configured and added elsewhere. */
    Cookie make(String token) {
        Cookie c = new Cookie("REMEMBER_ME", token);
        return c;
    }
}
