package javax.servlet;

import java.io.PrintWriter;

/** Stub (fixture only). */
public interface ServletResponse {
    PrintWriter getWriter();

    ServletOutputStream getOutputStream();

    void setContentType(String type);
}
