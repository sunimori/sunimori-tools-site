package org.springframework.web.servlet;

/** Stub (fixture only). */
public class ModelAndView {
    public ModelAndView() {
    }

    public ModelAndView(String viewName) {
    }

    public void setViewName(String viewName) {
    }
}
