package org.springframework.http;

/** Stub (fixture only). */
public final class ResponseCookie {
    public static ResponseCookieBuilder from(String name, String value) {
        return null;
    }

    /** Stub (fixture only). */
    public interface ResponseCookieBuilder {
        ResponseCookieBuilder secure(boolean secure);

        ResponseCookieBuilder httpOnly(boolean httpOnly);

        ResponseCookieBuilder path(String path);

        ResponseCookieBuilder maxAge(long seconds);

        ResponseCookieBuilder maxAge(java.time.Duration maxAge);

        ResponseCookie build();
    }
}
