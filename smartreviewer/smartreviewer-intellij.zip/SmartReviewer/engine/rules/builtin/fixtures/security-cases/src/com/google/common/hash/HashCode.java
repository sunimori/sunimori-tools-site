package com.google.common.hash;

/** Stub (fixture only). */
public abstract class HashCode {
    @Override
    public abstract String toString();
}
