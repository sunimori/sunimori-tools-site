package org.springframework.jdbc.core;

/** Stub (fixture only). */
public interface JdbcOperations {
    <T> java.util.List<T> query(String sql, RowMapper<T> mapper, Object... args);

    java.util.List<java.util.Map<String, Object>> queryForList(String sql, Object... args);

    int update(String sql, Object... args);
}
