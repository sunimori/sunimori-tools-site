package org.glassfish.jersey.media.multipart;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** Stub (fixture only). */
@Retention(RetentionPolicy.RUNTIME)
public @interface FormDataParam {
    String value();
}
