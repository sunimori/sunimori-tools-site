package org.springframework.web.servlet.view;

/** Stub (fixture only). */
public class RedirectView {
    public RedirectView() {
    }

    public RedirectView(String url) {
    }

    public void setUrl(String url) {
    }
}
