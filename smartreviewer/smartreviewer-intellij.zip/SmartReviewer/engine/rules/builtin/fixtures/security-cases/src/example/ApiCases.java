package example;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputFilter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Cases for SR-SEC-DESERIALIZATION-001, SR-SEC-WEAK-HASH-001, SR-SEC-WEAK-RANDOM-001, SR-SEC-HARDCODED-CREDENTIAL-001 and
 * SR-SEC-LOG-SECRET-001.
 */
public class ApiCases {
    private static final Logger LOG = LoggerFactory.getLogger(ApiCases.class);
    private static final Random RANDOM = new Random();
    /** P01 (credential): a database password in a constant. */
    private static final String DB_PASSWORD = "Tiger#2024";
    /** N01 (credential): the name of a form field. */
    private static final String PASSWORD_PARAM = "password";
    /** N02 (credential): a property key. */
    private static final String PASSWORD_KEY = "app.datasource.password";
    /** B01 (credential): a placeholder resolved at run time. */
    private static final String SECRET_PLACEHOLDER = "${app.secret}";

    // ------------------------------------------------------------------ deserialization

    /** P01 (deserialization): the request body is deserialized. */
    Object fromRequest(HttpServletRequest request) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(request.getInputStream())) {
            return in.readObject();
        }
    }

    /** P02 (deserialization): a socket stream. */
    Object fromSocket(Socket socket) throws IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
        return in.readObject();
    }

    /** P03 (deserialization): bytes handed to the method. */
    static Object deserialize(byte[] data) throws IOException, ClassNotFoundException {
        return new ObjectInputStream(new ByteArrayInputStream(data)).readObject();
    }

    /** N03 (deserialization): a deep copy of the object's own serialized form. */
    static Object copy(Serializable value) throws IOException, ClassNotFoundException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ObjectOutputStream out = new ObjectOutputStream(bytes)) {
            out.writeObject(value);
        }
        try (ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(bytes.toByteArray()))) {
            return in.readObject();
        }
    }

    /** B02 (deserialization): a filter limits the classes (JDK 9+). */
    static Object filtered(InputStream stream) throws IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(stream);
        in.setObjectInputFilter(ObjectInputFilter.Config.createFilter("example.*;!*"));
        return in.readObject();
    }

    /** N04 (deserialization): the readObject hook of a serializable class reads from the stream it is given. */
    static final class Settings implements Serializable {
        private static final long serialVersionUID = 1L;
        private transient List<String> names = Collections.emptyList();

        @SuppressWarnings("unchecked")
        private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
            in.defaultReadObject();
            names = (List<String>) in.readObject();
        }
    }

    // ------------------------------------------------------------------ hashing

    /** P04 (hash): MD5 of a password. */
    static String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digest = md.digest(password.getBytes(StandardCharsets.UTF_8));
        return toHex(digest);
    }

    /** P05 (hash): commons-codec md5Hex of the password. */
    static boolean check(String userPassword, String stored) {
        return DigestUtils.md5Hex(userPassword).equals(stored);
    }

    /** P06 (hash): SHA-1 of a login password. */
    static byte[] digest(String loginPwd) throws NoSuchAlgorithmException {
        return MessageDigest.getInstance("SHA-1").digest(loginPwd.getBytes(StandardCharsets.UTF_8));
    }

    /** N05 (hash): MD5 as a checksum of a file's content. */
    static String checksum(byte[] content) throws NoSuchAlgorithmException {
        return toHex(MessageDigest.getInstance("MD5").digest(content));
    }

    /** B03 (hash): SHA-256 for a password (not MD5 or SHA-1; still not a password hash, see the rule). */
    static String sha256(String password) {
        return DigestUtils.sha256Hex(password);
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ random

    /** P07 (random): a session token from java.util.Random. */
    static String newToken() {
        String token = Long.toHexString(new Random().nextLong());
        return token;
    }

    /** P08 (random): a CSRF token stored in the session. */
    static void csrf(HttpSession session) {
        session.setAttribute("csrfToken", String.valueOf(RANDOM.nextInt()));
    }

    /** N06 (random): shuffling a quiz. */
    static int dice() {
        return RANDOM.nextInt(6) + 1;
    }

    /** B04 (random): a number without a name that says what it is for is not reported. */
    static int code() {
        return RANDOM.nextInt(1_000_000);
    }

    /** N07 (random): SecureRandom. */
    static String secureToken() {
        return Long.toHexString(new SecureRandom().nextLong());
    }

    // ------------------------------------------------------------------ credentials

    /** P09 (credential): user and password given to DriverManager as literals. */
    static Connection connect(String url) throws SQLException {
        return DriverManager.getConnection(url, "scott", "tiger");
    }

    /** P10 (credential): a mail password in properties. */
    static Properties mail() {
        Properties p = new Properties();
        p.setProperty("mail.smtp.user", "batch");
        p.setProperty("mail.smtp.password", "S3cret!");
        return p;
    }

    /** N08 (credential): the password comes from the environment; an empty default is no secret. */
    static String password() {
        String password = "";
        String fromEnv = System.getenv("APP_PASSWORD");
        return fromEnv != null ? fromEnv : password;
    }

    // ------------------------------------------------------------------ logging

    /** P11 (log): the password in a log message. */
    static void login(String user, String password) {
        LOG.info("login user=" + user + " password=" + password);
    }

    /** P12 (log): a getter of the password. */
    static void dump(Order order) {
        LOG.debug("order " + order.getId() + " password " + order.getPassword());
    }

    /** N09 (log): only the word. */
    static void changed(String user) {
        LOG.info("password changed for " + user);
    }

    /** N10 (log): facts about the password, not the password. */
    static void length(String password) {
        LOG.debug("password length=" + password.length() + ", empty=" + password.isEmpty());
    }

    /** B05 (log): a whole object is logged; whether its toString() shows the password is not known here. */
    static void whole(Order order) {
        LOG.info("order " + order);
    }

    static String usedConstants() {
        return DB_PASSWORD + PASSWORD_PARAM + PASSWORD_KEY + SECRET_PLACEHOLDER;
    }
}
