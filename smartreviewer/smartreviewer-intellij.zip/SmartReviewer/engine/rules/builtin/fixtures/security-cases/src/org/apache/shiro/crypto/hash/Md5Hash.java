package org.apache.shiro.crypto.hash;

/** Stub (fixture only). */
public class Md5Hash {
    public Md5Hash(Object source) {
    }

    public String toHex() {
        return null;
    }
}
