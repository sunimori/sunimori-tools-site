package org.apache.commons.fileupload;

/** Stub (fixture only). */
public interface FileItem {
    String getName();

    boolean isFormField();

    void write(java.io.File file) throws Exception;
}
