package org.omnifaces.cdi;

/** Stub of OmniFaces (fixture only). */
public @interface Param {
    String name() default "";
}
