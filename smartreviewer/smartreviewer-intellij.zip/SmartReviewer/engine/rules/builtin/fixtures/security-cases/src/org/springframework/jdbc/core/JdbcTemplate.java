package org.springframework.jdbc.core;

/** Stub (fixture only). */
public class JdbcTemplate implements JdbcOperations {
    @Override
    public <T> java.util.List<T> query(String sql, RowMapper<T> mapper, Object... args) {
        return null;
    }

    @Override
    public java.util.List<java.util.Map<String, Object>> queryForList(String sql, Object... args) {
        return null;
    }

    @Override
    public int update(String sql, Object... args) {
        return 0;
    }
}
