package example;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

/** Cases for SR-SEC-MYBATIS-DOLLAR-001: a MyBatis mapper interface. */
public interface OrderMapper {
    /** P01: the sort column is pasted into the SQL. */
    @Select("SELECT * FROM orders WHERE owner = #{owner} ORDER BY ${sort}")
    List<Order> findByOwner(String owner, String sort);

    /** P02: a table name over several lines. */
    @Update({"UPDATE ${table}", "SET status = #{status}", "WHERE id = #{id}"})
    int updateStatus(String table, String status, long id);

    /** B01: a dollar sign in a literal is no substitution. */
    @Select("SELECT price FROM item WHERE currency = '$' AND id = #{id}")
    long priceInDollars(long id);

    /** N01: bind parameters only. */
    @Select("SELECT * FROM orders WHERE id = #{id}")
    Order findById(long id);
}
