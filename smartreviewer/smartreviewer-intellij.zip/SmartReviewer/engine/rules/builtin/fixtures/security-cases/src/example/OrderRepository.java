package example;

import org.springframework.data.repository.CrudRepository;

/** A Spring Data repository (fixture). */
public interface OrderRepository extends CrudRepository<Order, Long> {
    java.util.List<Order> findByKeyword(String keyword);
}
