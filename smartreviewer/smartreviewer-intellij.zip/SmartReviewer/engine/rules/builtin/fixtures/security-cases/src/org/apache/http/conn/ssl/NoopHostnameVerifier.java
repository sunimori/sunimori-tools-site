package org.apache.http.conn.ssl;

/** Stub (fixture only). */
public final class NoopHostnameVerifier implements javax.net.ssl.HostnameVerifier {
    public static final NoopHostnameVerifier INSTANCE = new NoopHostnameVerifier();

    @Override
    public boolean verify(String host, javax.net.ssl.SSLSession session) {
        return true;
    }
}
