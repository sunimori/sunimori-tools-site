package org.apache.struts.action;

/** Stub (fixture only). */
public abstract class Action {
    public ActionForward execute(ActionMapping mapping, ActionForm form, javax.servlet.http.HttpServletRequest request,
                                 javax.servlet.http.HttpServletResponse response) throws Exception {
        return null;
    }
}
