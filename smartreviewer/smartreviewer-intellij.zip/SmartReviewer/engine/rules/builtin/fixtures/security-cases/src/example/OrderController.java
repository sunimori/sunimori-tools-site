package example;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/** Spring MVC cases for SR-SEC-IDOR-001 and SR-SEC-OPEN-REDIRECT-001. */
@Controller
public class OrderController {
    private OrderRepository orders;
    private OrderDao orderDao;

    /** P01 (IDOR): the order id comes from the URL and is read without any check of who asks. */
    @GetMapping("/orders/{id}")
    public String show(@PathVariable Long id, Model model) {
        Optional<Order> order = orders.findById(id);
        model.addAttribute("order", order.orElse(null));
        return "order";
    }

    /** P02 (IDOR): a request parameter bound without an annotation is used to delete. */
    @PostMapping("/orders/delete")
    public String delete(String orderNo) {
        orderDao.delete(orderNo);
        return "redirect:/orders";
    }

    /** N01 (IDOR): the logged-in user is part of the lookup. */
    @GetMapping("/my/orders/{id}")
    public String mine(@PathVariable long id, Principal principal, Model model) {
        model.addAttribute("orders", orderDao.findByIdAndOwner(id, principal.getName()));
        return "order";
    }

    /** N02 (IDOR): a method-level authorization rule. */
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin/orders/{id}")
    public String admin(@PathVariable Long id, Model model) {
        model.addAttribute("order", orders.findById(id).orElse(null));
        return "order";
    }

    /** N03 (IDOR): a search keyword is no identifier. */
    @GetMapping("/orders/search")
    public String search(@RequestParam("q") String keyword, Model model) {
        List<Order> found = orders.findByKeyword(keyword);
        model.addAttribute("orders", found);
        return "orders";
    }

    /** P03 (redirect): the target after login comes from the request. */
    @PostMapping("/login/done")
    public String next(@RequestParam String next) {
        return "redirect:" + next;
    }

    /** N04 (redirect): the request value follows a fixed path. */
    @PostMapping("/orders/save")
    public String saved(@RequestParam long id) {
        return "redirect:/orders/" + id;
    }
}
