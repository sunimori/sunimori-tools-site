package javax.servlet.http;

/** Stub (fixture only). */
public interface HttpSession {
    Object getAttribute(String name);

    void setAttribute(String name, Object value);
}
