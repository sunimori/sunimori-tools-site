package javax.servlet;

import java.io.InputStream;

/** Stub (fixture only). */
public interface ServletContext {
    String getRealPath(String path);

    InputStream getResourceAsStream(String path);
}
