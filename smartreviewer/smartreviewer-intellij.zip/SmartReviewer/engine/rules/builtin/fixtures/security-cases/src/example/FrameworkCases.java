package example;

import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.omnifaces.cdi.Param;

/** JSF, Struts 1 and JAX-RS cases for SR-SEC-IDOR-001 and SR-SEC-OPEN-REDIRECT-001. */
final class FrameworkCases {
    private FrameworkCases() {
    }

    /** A JSF backing bean whose order number comes from the request. */
    @ManagedBean
    public static class OrderView {
        @ManagedProperty("#{param.orderNo}")
        private String orderNo;
        @Inject
        @Param(name = "customerId")
        private String customerId;
        private OrderDao orderDao;

        /** P01 (IDOR): a @ManagedProperty request parameter reads the order. */
        public Order getOrder() {
            return orderDao.findByOrderNo(orderNo);
        }

        /** P02 (IDOR): an OmniFaces @Param request parameter. */
        public java.util.List<Order> getCustomerOrders() {
            return orderDao.search(customerId);
        }

        /** P03 (IDOR): getRequestParameterMap().get("id"). */
        public Order load() {
            Map<String, String> params = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
            return orderDao.findById(Long.parseLong(params.get("id")));
        }

        /** P04 (redirect): JSF redirect to a URL from the request. */
        public void forward() throws java.io.IOException {
            ExternalContext ec = FacesContext.getCurrentInstance().getExternalContext();
            ec.redirect(ec.getRequestParameterMap().get("target"));
        }

        public void setOrderNo(String orderNo) {
            this.orderNo = orderNo;
        }
    }

    /** A Struts 1 form. */
    public static class OrderForm extends ActionForm {
        private String orderId;

        public String getOrderId() {
            return orderId;
        }
    }

    /** A Struts 1 action. */
    public static class ShowOrderAction extends Action {
        private OrderDao orderDao;

        /** P05 (IDOR): the form's order id reads the order. */
        @Override
        public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
            OrderForm f = (OrderForm) form;
            request.setAttribute("order", orderDao.findById(Long.parseLong(f.getOrderId())));
            return mapping.findForward("success");
        }
    }

    /** A JAX-RS resource. */
    @Path("/orders")
    public static class OrderResource {
        private EntityManager em;

        /** P06 (IDOR): JPA find by a path parameter. */
        @GET
        @Path("{id}")
        public Order get(@PathParam("id") long id) {
            return em.find(Order.class, id);
        }
    }
}
