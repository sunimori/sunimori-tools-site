package org.apache.shiro.crypto.hash;

/** Stub (fixture only). */
public class SimpleHash {
    public SimpleHash(String algorithmName, Object source, Object salt, int iterations) {
    }

    public String toHex() {
        return null;
    }
}
