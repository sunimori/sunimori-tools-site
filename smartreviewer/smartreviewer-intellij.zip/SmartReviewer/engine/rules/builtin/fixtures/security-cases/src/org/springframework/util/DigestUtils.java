package org.springframework.util;

/** Stub (fixture only). */
public final class DigestUtils {
    private DigestUtils() {
    }

    public static String md5DigestAsHex(byte[] bytes) {
        return null;
    }
}
