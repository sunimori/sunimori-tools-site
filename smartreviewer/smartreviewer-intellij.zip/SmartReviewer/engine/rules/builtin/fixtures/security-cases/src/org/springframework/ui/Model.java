package org.springframework.ui;

/** Stub (fixture only). */
public interface Model {
    Model addAttribute(String name, Object value);
}
