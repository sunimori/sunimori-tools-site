package example;

import java.beans.XMLDecoder;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputFilter;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.ws.rs.GET;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.struts.util.ResponseUtils;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.util.HtmlUtils;

/**
 * Cases for the taint rules whose checks follow the control flow: a check counts in the branch it guards and after a guard clause
 * that leaves, not everywhere (fixes of the 2026-10-26 review, area S1). Suites: SR-SEC-SQL-INJECTION-001, SR-SEC-SQL-DYNAMIC-001,
 * SR-SEC-COMMAND-INJECTION-001, SR-SEC-XSS-WRITER-001, SR-SEC-OPEN-REDIRECT-001, SR-SEC-PATH-TRAVERSAL-001 (case ids start with fx).
 */
public class FixS1Cases extends HttpServlet {
    private static final Set<String> COLUMNS = Set.of("id", "name", "created");
    private static final List<String> COLUMN_LIST = Arrays.asList("id", "name", "created");
    private static final String[] COLUMN_ARRAY = {"id", "name", "created"};
    private static final Map<String, String> COLUMN_MAP = Map.of("name", "c.name", "created", "c.created_at");
    private static final Map<String, String> BINARIES = Map.of("disk", "/bin/df", "mem", "/usr/bin/free");
    private static final Set<String> HOSTS = Set.of("www.example.com", "shop.example.com");
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{1,30}");
    private static final String BASE = "/data/files";

    private Connection connection;
    private Properties columns = new Properties();
    private String target;

    /** An enum that lists the sortable columns: the advised allow-list. */
    enum SortColumn {
        ID("id"), NAME("name");

        private final String column;

        SortColumn(String column) {
            this.column = column;
        }

        String getColumn() {
            return column;
        }
    }

    /** A statement that throws unless the condition holds (commons-lang Validate, Spring Assert). */
    static final class Validate {
        static void isTrue(boolean condition) {
            if (!condition) {
                throw new IllegalArgumentException();
            }
        }
    }

    // ----------------------------------------------------------------------------- SQL injection: checks follow the flow

    /** fx-sql-empty: an emptiness test is not a check of the content. */
    void emptyGuard(HttpServletRequest request) throws SQLException {
        String name = request.getParameter("name");
        if (name != null && !name.equals("")) {
            connection.createStatement().executeQuery("SELECT id FROM customer WHERE name = '" + name + "'");
        }
    }

    /** fx-sql-empty-yoda. */
    void yodaEmptyGuard(HttpServletRequest request) throws SQLException {
        String name = request.getParameter("name");
        if (!"".equals(name)) {
            connection.createStatement().executeQuery("SELECT id FROM customer WHERE name = '" + name + "'");
        }
    }

    /** fx-sql-sentinel: the value is not "ALL", which says nothing about what it is. */
    void sentinelNegated(HttpServletRequest request) throws SQLException {
        String status = request.getParameter("status");
        if (!"ALL".equals(status)) {
            connection.createStatement().executeQuery("SELECT id FROM orders WHERE status = '" + status + "'");
        }
    }

    /** fx-sql-else: the else branch is the one that is not compared with a constant. */
    void elseBranch(HttpServletRequest request) throws SQLException {
        String type = request.getParameter("type");
        if ("ALL".equals(type)) {
            connection.createStatement().executeQuery("SELECT id FROM item");
        } else {
            connection.createStatement().executeQuery("SELECT id FROM item WHERE type = '" + type + "'");
        }
    }

    /** fx-sql-starts-with: startsWith decides the direction, the rest is pasted unchecked. */
    void startsWithRouting(HttpServletRequest request) throws SQLException {
        String sort = request.getParameter("sort");
        String direction = "asc";
        if (sort.startsWith("-")) {
            direction = "desc";
            sort = sort.substring(1);
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + sort + " " + direction);
    }

    /** fx-sql-guard-clause: a guard clause that throws. */
    void guardClause(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        if (!COLUMNS.contains(col)) {
            throw new IllegalArgumentException("sort");
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-inside: pasted only inside the branch of the check. */
    void insideBranch(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        if (COLUMNS.contains(col)) {
            connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
        }
    }

    /** fx-sql-after: the check does not gate the statement after it. */
    void afterBranch(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        int checked = 0;
        if (COLUMNS.contains(col)) {
            checked = 1;
        }
        connection.prepareStatement("SELECT " + checked + " FROM item ORDER BY " + col);
    }

    /** fx-sql-else-paste. */
    void checkedThenOther(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        if (COLUMNS.contains(col)) {
            connection.prepareStatement("SELECT * FROM item");
        } else {
            connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
        }
    }

    /** fx-sql-trimmed: the check is on a copy of the value. */
    void trimmedCheck(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        if (!COLUMNS.contains(col.trim())) {
            throw new IllegalArgumentException("sort");
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-boolean: the result of the check is kept in a boolean. */
    void booleanLocal(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        boolean known = COLUMNS.contains(col);
        if (!known) {
            throw new IllegalArgumentException("sort");
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-matcher: the check is a Matcher kept in a local. */
    void matcherLocal(HttpServletRequest request) throws SQLException {
        String name = request.getParameter("name");
        Matcher m = NAME.matcher(name);
        if (!m.matches()) {
            throw new IllegalArgumentException("name");
        }
        connection.createStatement().executeQuery("SELECT id FROM customer WHERE name = '" + name + "'");
    }

    /** fx-sql-helper: a helper of this class whose name does not say it checks. */
    void helperCheck(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        if (!isColumn(col)) {
            throw new IllegalArgumentException("sort");
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    private boolean isColumn(String c) {
        return c != null && COLUMNS.contains(c);
    }

    /** fx-sql-switch: the default arm throws, so only the listed values reach the statement. */
    void switchGuard(HttpServletRequest request) throws SQLException {
        String sort = request.getParameter("sort");
        switch (sort) {
            case "id":
            case "name":
            case "created":
                break;
            default:
                throw new IllegalArgumentException("sort");
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + sort);
    }

    /** fx-sql-switch-arm: the value is known inside an arm of constants. */
    void switchArm(HttpServletRequest request) throws SQLException {
        String mode = request.getParameter("mode");
        switch (mode) {
            case "asc":
            case "desc":
                connection.prepareStatement("SELECT * FROM item ORDER BY id " + mode);
                break;
            default:
                break;
        }
    }

    /** fx-sql-switch-open: a switch without a throwing default checks nothing after it. */
    void switchOpen(HttpServletRequest request) throws SQLException {
        String sort = request.getParameter("sort");
        switch (sort) {
            case "id":
                break;
            default:
                break;
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + sort);
    }

    /** fx-sql-index-of. */
    void indexOfGuard(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        if (COLUMN_LIST.indexOf(col) < 0) {
            throw new IllegalArgumentException("sort");
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-stream. */
    void streamGuard(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        if (COLUMN_LIST.stream().noneMatch(c -> c.equals(col))) {
            throw new IllegalArgumentException("sort");
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-false: the check compared with a boolean literal. */
    void booleanLiteral(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        if (COLUMNS.contains(col) == false) {
            throw new IllegalArgumentException("sort");
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-array-utils: membership in an array. */
    void arrayUtilsGuard(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        if (!ArrayUtils.contains(COLUMN_ARRAY, col)) {
            throw new IllegalArgumentException("sort");
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-enum-stream: the value must be the name of an enum constant. */
    void enumStreamGuard(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        if (Arrays.stream(SortColumn.values()).noneMatch(c -> c.name().equalsIgnoreCase(col))) {
            throw new IllegalArgumentException("sort");
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-host: the host of the URL is in a fixed set, which says nothing about the rest of the text pasted into the SQL. */
    void hostCheckThenSql(HttpServletRequest request) throws Exception {
        String target = request.getParameter("url");
        URI u = new URI(target);
        if (!HOSTS.contains(u.getHost())) {
            throw new IllegalArgumentException("host");
        }
        connection.createStatement().executeQuery("SELECT * FROM visit WHERE url = '" + target + "'");
    }

    /** fx-sql-try-guard: the guard clause is inside a try block whose catch returns. */
    void guardInTry(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        try {
            if (!COLUMNS.contains(col)) {
                throw new IllegalArgumentException("sort");
            }
        } catch (IllegalArgumentException e) {
            return;
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-try-continues: the catch block runs on, so the value is not checked after the statement. */
    void catchContinues(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        try {
            if (!COLUMNS.contains(col)) {
                throw new IllegalArgumentException("sort");
            }
        } catch (IllegalArgumentException e) {
            System.err.println("bad sort " + e.getMessage());
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-ascii: printable characters include the quote. */
    void asciiPrintable(HttpServletRequest request) throws SQLException {
        String name = request.getParameter("name");
        if (!StringUtils.isAsciiPrintable(name)) {
            throw new IllegalArgumentException("name");
        }
        connection.createStatement().executeQuery("SELECT id FROM customer WHERE name = '" + name + "'");
    }

    /** fx-sql-numeric: only digits. */
    void numericCheck(HttpServletRequest request) throws SQLException {
        String id = request.getParameter("id");
        if (!StringUtils.isNumeric(id)) {
            throw new IllegalArgumentException("id");
        }
        connection.createStatement().executeQuery("SELECT name FROM customer WHERE id = " + id);
    }

    /** fx-sql-log-only: the check only logs. */
    void logOnly(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        if (!col.matches("[a-z_]+")) {
            System.err.println("odd column " + col);
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-assert: Validate.isTrue throws unless the condition holds. */
    void assertHelper(HttpServletRequest request) throws SQLException {
        String col = request.getParameter("sort");
        Validate.isTrue(col.matches("[a-z_]+"));
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    /** fx-sql-continue: the guard clause of a loop body. */
    void loopContinue(HttpServletRequest request) throws SQLException {
        for (String col : request.getParameterValues("sort")) {
            if (!COLUMNS.contains(col)) {
                continue;
            }
            connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
        }
    }

    /** fx-sql-break: a value set before a break still reaches the code after the loop. */
    void breakCarries(HttpServletRequest request) throws SQLException {
        String found = "id";
        for (String candidate : COLUMN_LIST) {
            if (candidate.equals("name")) {
                found = request.getParameter("sort");
                break;
            }
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + found);
    }

    /** fx-sql-leaves: the branch that sets the request value returns, so the later statement sees a constant. */
    void leavingBranch(HttpServletRequest request) throws SQLException {
        String col = "id";
        if (request.getParameter("x") != null) {
            col = request.getParameter("sort");
            return;
        }
        connection.prepareStatement("SELECT * FROM item ORDER BY " + col);
    }

    // ----------------------------------------------------------------------------- lookups by key

    /** fx-sql-map-default: the request value only selects from a fixed table. */
    void mapLookupDefault(HttpServletRequest request) throws SQLException {
        String col = COLUMN_MAP.getOrDefault(request.getParameter("sort"), "c.id");
        connection.prepareStatement("SELECT * FROM customer c ORDER BY " + col);
    }

    /** fx-sql-map-get. */
    void mapLookupGet(HttpServletRequest request) throws SQLException {
        String col = COLUMN_MAP.get(request.getParameter("sort"));
        if (col == null) {
            throw new IllegalArgumentException("sort");
        }
        connection.prepareStatement("SELECT * FROM customer c ORDER BY " + col);
    }

    /** fx-sql-properties. */
    void propertiesLookup(HttpServletRequest request) throws SQLException {
        String col = columns.getProperty(request.getParameter("sort"));
        connection.prepareStatement("SELECT * FROM customer c ORDER BY " + col);
    }

    /** fx-sql-map-default-tainted: the default value of getOrDefault is request text. */
    void mapDefaultFromRequest(HttpServletRequest request) throws SQLException {
        String col = COLUMN_MAP.getOrDefault("sort", request.getParameter("sort"));
        connection.prepareStatement("SELECT * FROM customer c ORDER BY " + col);
    }

    // ----------------------------------------------------------------------------- dynamic SQL that is fixed by an enum or handed on

    /** fx-dyn-enum: a column of an enum constant. */
    void enumColumn(SortColumn sort) throws SQLException {
        connection.prepareStatement("SELECT * FROM customer c ORDER BY " + sort.getColumn());
    }

    /** fx-dyn-enum-value-of. */
    void enumValueOf(String sort) throws SQLException {
        SortColumn col = SortColumn.valueOf(sort.toUpperCase());
        connection.prepareStatement("SELECT * FROM customer c ORDER BY " + col.getColumn());
    }

    /** fx-dyn-wrapper: the parameter is the whole statement, nothing is pasted here. */
    void forward(String sql) throws SQLException {
        connection.createStatement().executeQuery(sql);
    }

    /** fx-dyn-paste: a parameter pasted into the statement is still reported. */
    void pasteParameter(String code) throws SQLException {
        connection.createStatement().executeQuery("SELECT * FROM item WHERE code = '" + code + "'");
    }

    // ----------------------------------------------------------------------------- command injection

    /** fx-cmd-else: only the then branch is compared with a constant. */
    void pingElse(HttpServletRequest request) throws IOException {
        String t = request.getParameter("target");
        if ("localhost".equals(t)) {
            Runtime.getRuntime().exec("ping -c 1 127.0.0.1");
        } else {
            Runtime.getRuntime().exec("ping -c 1 " + t);
        }
    }

    /** fx-cmd-then: inside the branch the value is the constant. */
    void pingThen(HttpServletRequest request) throws IOException {
        String t = request.getParameter("target");
        if ("localhost".equals(t)) {
            Runtime.getRuntime().exec("ping -c 1 " + t);
        }
    }

    /** fx-cmd-log-only. */
    void pingLogOnly(HttpServletRequest request) throws IOException {
        String h = request.getParameter("host");
        if (!h.matches("[a-z.]+")) {
            System.err.println("odd host " + h);
        }
        Runtime.getRuntime().exec("ping -c 1 " + h);
    }

    /** fx-cmd-map: the program is chosen from a fixed table by the request value. */
    void lookupBinary(HttpServletRequest request) throws IOException {
        String bin = BINARIES.get(request.getParameter("tool"));
        if (bin == null) {
            throw new IllegalArgumentException("tool");
        }
        Runtime.getRuntime().exec(new String[] {bin, "-h"});
    }

    /** fx-cmd-anonymous: a request value captured by an anonymous class. */
    void anonymousCapture(HttpServletRequest request) {
        final String host = request.getParameter("host");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Runtime.getRuntime().exec("ping -c 3 " + host);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /** fx-cmd-optional. */
    void optionalIfPresent(HttpServletRequest request) {
        Optional.ofNullable(request.getParameter("cmd")).ifPresent(v -> {
            try {
                Runtime.getRuntime().exec(v);
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        });
    }

    /** fx-cmd-future. */
    void futureThenAccept(HttpServletRequest request) {
        String host = request.getParameter("host");
        CompletableFuture.supplyAsync(() -> host).thenAccept(h -> {
            try {
                Runtime.getRuntime().exec("ping -c 1 " + h);
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        });
    }

    /** fx-cmd-add-all. */
    void collectionsAddAll(HttpServletRequest request) throws IOException {
        List<String> cmd = new ArrayList<>();
        Collections.addAll(cmd, "ls", "-l", request.getParameter("dir"));
        new ProcessBuilder(cmd).start();
    }

    /** fx-cmd-array-copy. */
    void arrayCopy(HttpServletRequest request) throws IOException {
        String[] extra = request.getParameterValues("opt");
        String[] cmd = new String[extra.length + 1];
        cmd[0] = "/usr/bin/report";
        System.arraycopy(extra, 0, cmd, 1, extra.length);
        Runtime.getRuntime().exec(cmd);
    }

    /** fx-cmd-field: a request value kept in a field and used in the same method. */
    void fieldAssign(HttpServletRequest request) throws IOException {
        this.target = request.getParameter("target");
        Runtime.getRuntime().exec("ping -c 1 " + this.target);
    }

    // ----------------------------------------------------------------------------- HTML output

    /** fx-xss-else: the else branch echoes the command that no test above matched. */
    void dispatchElse(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String cmd = request.getParameter("cmd");
        if ("list".equals(cmd)) {
            response.getWriter().println("<p>list</p>");
        } else {
            response.getWriter().println("<p>Unknown command: " + cmd + "</p>");
        }
    }

    /** fx-xss-then: inside the branch the value is the constant. */
    void dispatchThen(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String cmd = request.getParameter("cmd");
        if ("list".equals(cmd)) {
            response.getWriter().println("<p>" + cmd + "</p>");
        }
    }

    /** fx-xss-default: the default for an empty value does not remove markup from a value that is not empty. */
    void defaultIfEmpty(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String name = request.getParameter("name");
        if (name == null || name.equals("")) {
            name = "guest";
        }
        response.getWriter().println("<p>Hello " + name + "</p>");
    }

    // ----------------------------------------------------------------------------- redirects

    /** fx-redir-slash: startsWith("/") alone lets //evil.example through. */
    void slashOnly(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String url = request.getParameter("url");
        if (url != null && url.startsWith("/")) {
            response.sendRedirect(url);
        }
    }

    /** fx-redir-both: a path on this server: starts with / and not with //. */
    void slashAndNotDouble(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String url = request.getParameter("url");
        if (url != null && url.startsWith("/") && !url.startsWith("//")) {
            response.sendRedirect(url);
        }
    }

    /** fx-redir-boolean: the check kept in a boolean. */
    void localInBoolean(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String next = request.getParameter("next");
        boolean local = next != null && next.startsWith("/") && !next.startsWith("//");
        response.sendRedirect(local ? next : "/home");
    }

    /** fx-redir-helper: a helper of this class does the check; the fallback is assigned in the branch. */
    void localByHelper(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String next = request.getParameter("next");
        if (!sameSite(next)) {
            next = "/home";
        }
        response.sendRedirect(next);
    }

    private boolean sameSite(String p) {
        return p != null && p.startsWith("/") && !p.startsWith("//");
    }

    /** fx-redir-host: the host of the parsed URL is in a fixed set. */
    void hostInSet(HttpServletRequest request, HttpServletResponse response) throws IOException, URISyntaxException {
        String url = request.getParameter("url");
        URI uri = new URI(url);
        if (!HOSTS.contains(uri.getHost())) {
            response.sendRedirect("/error");
            return;
        }
        response.sendRedirect(url);
    }

    /** fx-redir-else: the else branch redirects to the raw value. */
    void redirectElse(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String page = request.getParameter("page");
        if ("home".equals(page)) {
            response.sendRedirect(request.getContextPath() + "/home");
        } else {
            response.sendRedirect(page);
        }
    }

    // ----------------------------------------------------------------------------- file paths

    /** fx-path-log-only: the pattern check only logs, the value is used anyway. */
    File pathCheckLogsOnly(HttpServletRequest request) {
        String name = request.getParameter("name");
        if (!name.matches("[A-Za-z0-9_.-]+")) {
            System.err.println("odd file name: " + name);
        }
        return new File(BASE, name);
    }

    /** fx-path-guard-clause. */
    File pathCheckThrows(HttpServletRequest request) {
        String name = request.getParameter("name");
        if (!name.matches("[A-Za-z0-9_.-]+")) {
            throw new IllegalArgumentException("name");
        }
        return new File(BASE, name);
    }

    // ----------------------------------------------------------------------------- Struts 2 properties

    /** The service a Struts 2 action gets from the container. */
    interface ReportService {
        String getBackupCommand();
    }

    /** A Struts 2 action: text properties are filled from the request parameters, a service or a map the container injects are not. */
    public static class ReportAction extends ActionSupport {
        private ReportService service;
        private Map<String, Object> session;
        private String target;

        public void setService(ReportService service) {
            this.service = service;
        }

        public void setSession(Map<String, Object> session) {
            this.session = session;
        }

        public void setTarget(String target) {
            this.target = target;
        }

        /** fx-s2-service: the command comes from the injected service. */
        public String runService() throws Exception {
            Runtime.getRuntime().exec(service.getBackupCommand());
            return SUCCESS;
        }

        /** fx-s2-session: the value comes from the injected session map. */
        public String runSession() throws Exception {
            Runtime.getRuntime().exec(String.valueOf(session.get("cmd")));
            return SUCCESS;
        }

        /** fx-s2-default: one branch sets a default, on the other the property is still request data. */
        public String runDefaulted() throws Exception {
            if (target == null) {
                target = "localhost";
            }
            Runtime.getRuntime().exec("ping -c 1 " + target);
            return SUCCESS;
        }

        /** fx-s2-checked: a property checked against a fixed set before it is used. */
        public String runChecked() throws Exception {
            if (!HOSTS.contains(target)) {
                return "input";
            }
            Runtime.getRuntime().exec("ping -c 1 " + target);
            return SUCCESS;
        }

        /** fx-s2-text: a text property is request data. */
        public String runTarget() throws Exception {
            Runtime.getRuntime().exec("ping -c 1 " + target);
            return SUCCESS;
        }
    }

    // ----------------------------------------------------------------------------- the response writer, however it is made

    private PrintWriter out;

    /** fx-xss-null-init: the legacy shape, the writer declared null and assigned inside the try block. */
    void nullInitWriter(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter writer = null;
        try {
            writer = response.getWriter();
            writer.print("<div class=\"error\">" + request.getParameter("message") + "</div>");
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }

    /** fx-xss-assigned: declared without a value, assigned on the next line. */
    void assignedWriter(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter writer;
        writer = response.getWriter();
        writer.println("<p>" + request.getParameter("name") + "</p>");
    }

    /** fx-xss-wrapped: a PrintWriter around the response writer. */
    void wrappedWriter(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter writer = new PrintWriter(response.getWriter(), true);
        writer.println("<p>" + request.getParameter("name") + "</p>");
    }

    /** fx-xss-wrapped-stream: a PrintWriter around an OutputStreamWriter around the output stream. */
    void wrappedStream(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter writer = new PrintWriter(new OutputStreamWriter(response.getOutputStream(), "UTF-8"), true);
        writer.println("<h2>" + request.getParameter("title") + "</h2>");
    }

    /** fx-xss-field: the writer kept in a field and written in the same method. */
    void fieldWriter(HttpServletRequest request, HttpServletResponse response) throws IOException {
        this.out = response.getWriter();
        this.out.println("<p>" + request.getParameter("name") + "</p>");
    }

    /** fx-xss-for-each: the elements written by a method reference. */
    void forEachReference(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter writer = response.getWriter();
        Arrays.asList(request.getParameterValues("v")).forEach(writer::println);
    }

    /** fx-xss-optional: a lambda run by Optional.ifPresent. */
    void optionalPrint(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter writer = response.getWriter();
        Optional.ofNullable(request.getParameter("q")).ifPresent(q -> writer.println("<p>" + q + "</p>"));
    }

    /** fx-xss-jsf: ResponseWriter.write is declared by java.io.Writer. */
    void jsfWrite(FacesContext context) throws IOException {
        ExternalContext external = context.getExternalContext();
        ResponseWriter writer = context.getResponseWriter();
        writer.write("<span>" + external.getRequestParameterMap().get("label") + "</span>");
    }

    /** A cleaner of the project: the name of the class and of the method say what it does. */
    static final class XssCleaner {
        static String clean(String html) {
            return html.replace("<", "&lt;");
        }
    }

    /** fx-xss-js-escape: escapeJavaScript leaves < and > alone. */
    void escapeJavaScript(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.getWriter().println("<p>" + StringEscapeUtils.escapeEcmaScript(request.getParameter("q")) + "</p>");
    }

    /** fx-xss-unescape: htmlUnescape turns &lt; back into <. */
    void htmlUnescape(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.getWriter().println("<p>" + HtmlUtils.htmlUnescape(request.getParameter("q")) + "</p>");
    }

    /** fx-xss-struts-filter: Struts 1 ResponseUtils.filter escapes HTML. */
    void strutsFilter(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.getWriter().println("<p>" + ResponseUtils.filter(request.getParameter("q")) + "</p>");
    }

    /** fx-xss-cleaner. */
    void projectCleaner(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.getWriter().println("<p>" + XssCleaner.clean(request.getParameter("q")) + "</p>");
    }

    /** fx-xss-json-branch: the JSON content type is set in the ajax branch only; the HTML branch is not JSON. */
    void ajaxOrHtml(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter writer = response.getWriter();
        String name = request.getParameter("name");
        if ("1".equals(request.getHeader("X-Requested-With"))) {
            response.setContentType("application/json");
            writer.print("{\"name\":\"" + name + "\"}");
        } else {
            writer.println("<p>Hello " + name + "</p>");
        }
    }

    // ----------------------------------------------------------------------------- file paths: what is done with the name

    private static final Map<String, String> FILES = Map.of("terms", "terms-of-use.pdf", "privacy", "privacy.pdf");
    private static final Path BASE_PATH = Paths.get("/data/files").toAbsolutePath().normalize();

    /** fx-path-get-name: only the last element of the name is used. */
    File pathFileGetName(HttpServletRequest request) {
        String name = new File(request.getParameter("name")).getName();
        return new File(BASE, name);
    }

    /** fx-path-file-name. */
    Path pathFileName(HttpServletRequest request) {
        String name = Paths.get(request.getParameter("name")).getFileName().toString();
        return Paths.get(BASE, name);
    }

    /** fx-path-extension: the upload is saved under a generated name; only the extension of the submitted name is used. */
    Path pathExtensionOnly(HttpServletRequest request) throws IOException {
        Part part = request.getPart("file");
        String ext = FilenameUtils.getExtension(part.getSubmittedFileName());
        return BASE_PATH.resolve(UUID.randomUUID() + "." + ext);
    }

    /** fx-path-two-arguments: a directory and a name, both from the request, are one path. */
    File pathTwoArguments(HttpServletRequest request) {
        return new File(request.getParameter("dir"), request.getParameter("file"));
    }

    /** fx-path-lookup: the name is chosen from a fixed table. */
    File pathLookup(HttpServletRequest request) {
        String fileName = FILES.get(request.getParameter("doc"));
        if (fileName == null) {
            throw new IllegalArgumentException("unknown document");
        }
        return new File("/data/docs", fileName);
    }

    /** fx-path-normalize: the normalized path must start with the base directory. */
    void pathNormalizeGuard(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Path target = BASE_PATH.resolve(request.getParameter("name")).normalize();
        if (!target.startsWith(BASE_PATH)) {
            response.sendRedirect("/error");
            return;
        }
        Files.copy(target, response.getOutputStream());
    }

    /** fx-path-normalize-then: the same check, the path used inside the branch. */
    void pathNormalizeThen(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Path target = BASE_PATH.resolve(request.getParameter("name")).normalize();
        if (target.startsWith(BASE_PATH)) {
            Files.copy(target, response.getOutputStream());
        }
    }

    /** fx-path-canonical. */
    File pathCanonicalGuard(HttpServletRequest request) throws IOException {
        File f = new File(BASE, request.getParameter("name"));
        if (!f.getCanonicalPath().startsWith(new File(BASE).getCanonicalPath() + File.separator)) {
            throw new SecurityException("outside of the base directory");
        }
        return f;
    }

    /** fx-path-normalize-log: the check only logs. */
    File pathNormalizeLogs(HttpServletRequest request) {
        Path target = BASE_PATH.resolve(request.getParameter("name")).normalize();
        if (!target.startsWith(BASE_PATH)) {
            System.err.println("outside " + target);
        }
        return target.toFile();
    }

    /** fx-path-guard-logs: the check guards a log statement, not the use of the path. */
    byte[] pathGuardLogsOnly(HttpServletRequest request) throws IOException {
        Path target = BASE_PATH.resolve(request.getParameter("name")).normalize();
        if (target.startsWith(BASE_PATH)) {
            System.out.println("inside the base directory");
        }
        return Files.readAllBytes(target);
    }

    /** fx-path-canonical-prefix: a String prefix without the separator also matches /data/files-other. */
    File pathCanonicalNoSeparator(HttpServletRequest request) throws IOException {
        File f = new File(BASE, request.getParameter("name"));
        if (!f.getCanonicalPath().startsWith(new File(BASE).getCanonicalPath())) {
            throw new SecurityException("outside of the base directory");
        }
        return f;
    }

    /** fx-path-plain-name: no .., no slash and no backslash. */
    File pathPlainName(HttpServletRequest request) {
        String name = request.getParameter("name");
        if (name.contains("..") || name.contains("/") || name.contains("\\")) {
            throw new IllegalArgumentException("bad name");
        }
        return new File(BASE, name);
    }

    /** fx-path-dot-dot-only: the name may still be an absolute path. */
    File pathDotDotOnly(HttpServletRequest request) {
        String name = request.getParameter("name");
        if (name.contains("..")) {
            throw new IllegalArgumentException("bad name");
        }
        return new File(BASE, name);
    }

    /** fx-path-pattern-find: a pattern that finds .., / and a backslash; where it finds nothing the name is plain. */
    private static final Pattern SEPARATORS = Pattern.compile("\\.\\.|/|\\\\");

    File pathBlacklistPattern(HttpServletRequest request) {
        String name = request.getParameter("name");
        if (SEPARATORS.matcher(name).find()) {
            throw new IllegalArgumentException("bad name");
        }
        return new File(BASE, name);
    }

    /** fx-path-commons-upload: the client's file name of an uploaded item. */
    void pathCommonsUpload(HttpServletRequest request) throws Exception {
        for (FileItem item : new ServletFileUpload().parseRequest(request)) {
            item.write(new File(BASE, item.getName()));
        }
    }

    /** Handlers of Spring MVC and Jersey that receive uploads. */
    @Controller
    public static class UploadController {
        /** fx-path-multipart: a MultipartFile bound without an annotation. */
        @PostMapping("/upload")
        public String upload(MultipartFile file) throws IOException {
            File dest = new File(BASE, file.getOriginalFilename());
            file.transferTo(dest);
            return "done";
        }

        /** fx-path-spring-part. */
        @PostMapping("/part")
        public String part(Part file) throws IOException {
            return new File(BASE, file.getSubmittedFileName()).getPath();
        }

        /** fx-path-jersey. */
        @GET
        public String form(@FormDataParam("file") FormDataContentDisposition detail) {
            return new File(BASE, detail.getFileName()).getPath();
        }
    }

    // ----------------------------------------------------------------------------- redirects that are not return "redirect:" + x

    /** Spring MVC handlers that build the view name in other ways. */
    @Controller
    public static class RedirectHandlers {
        /** fx-redir-format. */
        @GetMapping("/format")
        public String format(@RequestParam String next) {
            return String.format("redirect:%s", next);
        }

        /** fx-redir-format-path: the path before the placeholder is fixed. */
        @GetMapping("/orders")
        public String formatPath(@RequestParam String id) {
            return String.format("redirect:/orders/%s", id);
        }

        /** fx-redir-local-view. */
        @GetMapping("/local")
        public String localView(@RequestParam String next) {
            String view = "redirect:" + next;
            return view;
        }

        /** fx-redir-ternary. */
        @GetMapping("/ternary")
        public String ternary(@RequestParam(required = false) String next) {
            return next != null ? "redirect:" + next : "home";
        }

        /** fx-redir-set-view-name. */
        @GetMapping("/view")
        public ModelAndView setViewName(@RequestParam String next) {
            ModelAndView mav = new ModelAndView();
            mav.setViewName("redirect:" + next);
            return mav;
        }

        /** fx-redir-set-view-name-path. */
        @GetMapping("/view-path")
        public ModelAndView setViewNamePath(@RequestParam String id) {
            ModelAndView mav = new ModelAndView();
            mav.setViewName("redirect:/orders?id=" + id);
            return mav;
        }

        /** fx-redir-set-url. */
        @GetMapping("/jump")
        public RedirectView setUrl(@RequestParam String u) {
            RedirectView view = new RedirectView();
            view.setUrl(u);
            return view;
        }
    }

    /** The servlet response with the URL encoding methods of the real API (the stub of this project has none). */
    interface EncodingResponse extends HttpServletResponse {
        String encodeRedirectURL(String url);
    }

    /** fx-redir-encode: encodeRedirectURL adds a session id, it does not make the target safe. */
    void redirectEncoded(HttpServletRequest request, EncodingResponse response) throws IOException {
        String url = request.getParameter("url");
        response.sendRedirect(response.encodeRedirectURL(url));
    }

    /** fx-redir-encode-local. */
    void redirectEncodedLocal(HttpServletRequest request, EncodingResponse response) throws IOException {
        response.sendRedirect(response.encodeRedirectURL(request.getContextPath() + "/home"));
    }

    /** fx-redir-map: the target is chosen from a fixed table. */
    void redirectLookup(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String dest = COLUMN_MAP.get(request.getParameter("page"));
        response.sendRedirect(dest != null ? dest : "/home");
    }

    // ----------------------------------------------------------------------------- deserialization

    /** fx-deser-xml-decoder. */
    Object xmlDecoder(HttpServletRequest request) throws IOException {
        try (XMLDecoder decoder = new XMLDecoder(request.getInputStream())) {
            return decoder.readObject();
        }
    }

    /** fx-deser-xml-decoder-parameter. */
    Object xmlDecoderOfStream(InputStream in) {
        XMLDecoder decoder = new XMLDecoder(in);
        return decoder.readObject();
    }

    /** fx-deser-cipher. */
    Object cipherStream(HttpServletRequest request, Cipher cipher) throws IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(new CipherInputStream(request.getInputStream(), cipher));
        return in.readObject();
    }

    /** fx-deser-assigned-later. */
    Object streamAssignedLater(InputStream raw) throws IOException, ClassNotFoundException {
        ObjectInputStream in;
        in = new ObjectInputStream(raw);
        return in.readObject();
    }

    /** fx-deser-null-then-try: the stream declared null, created inside the try block. */
    Object streamCreatedInTry(Socket socket) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = null;
        Object message = null;
        try {
            ois = new ObjectInputStream(socket.getInputStream());
            message = ois.readObject();
        } finally {
            if (ois != null) {
                ois.close();
            }
        }
        return message;
    }

    /** fx-deser-file-parameter: a file is read, the path is not data from outside. */
    static Object loadFile(File file) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return in.readObject();
        }
    }

    /** fx-deser-path-parameter. */
    static Object loadPath(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(path))) {
            return in.readObject();
        }
    }

    /** fx-filter-copy: the filter is set on a final copy of the stream variable. */
    Object streamFilteredByCopy(InputStream raw) throws IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(raw);
        final ObjectInputStream copy = in;
        copy.setObjectInputFilter(ObjectInputFilter.Config.createFilter("example.*;!*"));
        return in.readObject();
    }

    /** fx-filter-unresolved-lambda: the filter is set in a lambda handed to a method that cannot be resolved (its names have no bindings). */
    Object streamFilteredInUnresolvedLambda(InputStream raw) throws IOException, ClassNotFoundException {
        ObjectInputStream in = new ObjectInputStream(raw);
        final ObjectInputStream copy = in;
        com.acme.missing.Privileged.run(() -> {
            copy.setObjectInputFilter(ObjectInputFilter.Config.createFilter("example.*;!*"));
            return null;
        });
        return in.readObject();
    }

    // ----------------------------------------------------------------------------- servlet types that are not on the class path

    /** fx-unresolved-sql: this project has no stub of the Jakarta servlet API, so the type of the request cannot be resolved. */
    void unresolvedSql(jakarta.servlet.http.HttpServletRequest request) throws SQLException {
        connection.createStatement().executeQuery("SELECT id FROM customer WHERE name = '" + request.getParameter("name") + "'");
    }

    /** fx-unresolved-command. */
    void unresolvedCommand(jakarta.servlet.http.HttpServletRequest request) throws IOException {
        Runtime.getRuntime().exec("ping " + request.getParameter("host"));
    }

    /** fx-unresolved-html: the writer of a response that cannot be resolved. */
    void unresolvedHtml(jakarta.servlet.http.HttpServletRequest request, jakarta.servlet.http.HttpServletResponse response) throws IOException {
        response.getWriter().println("<p>" + request.getParameter("q") + "</p>");
    }

    /** fx-unresolved-sink: the statement is of a type that cannot be resolved; its method is known by the simple name of the type. */
    void unresolvedStatement(HttpServletRequest request, com.acme.missing.Statement statement) throws SQLException {
        statement.executeQuery("SELECT id FROM customer WHERE name = '" + request.getParameter("name") + "'");
    }

    /** fx-unresolved-other: a type that is not a request type gives no request text, however unknown it is. */
    void unresolvedOther(com.acme.missing.Settings settings) throws SQLException {
        connection.createStatement().executeQuery("SELECT id FROM customer WHERE name = '" + settings.getParameter("name") + "'");
    }

    // ----------------------------------------------------------------------------- identifiers of objects

    /** A data access object. */
    static class FixOrderDao {
        Object findByStatusAndId(String status, String orderId) {
            return null;
        }

        Object findById(long id) {
            return null;
        }

        Object find(String key) {
            return null;
        }

        Object findByPageNo(int pageNo) {
            return null;
        }

        Object findPage(int pageNo, int pageSize) {
            return null;
        }

        Object findSorted(String sortKey) {
            return null;
        }

        Object findByStatusCode(String statusCode) {
            return null;
        }

        Object findByLoginId(String loginId) {
            return null;
        }

        Object findByMailAddress(String mail) {
            return null;
        }

        Object findByIdAndUserId(long id, long userId) {
            return null;
        }
    }

    private FixOrderDao dao = new FixOrderDao();

    /** fx-idor-second: the id is the second request value of the call. */
    Object idorSecondArgument(HttpServletRequest request) {
        String status = request.getParameter("status");
        String orderId = request.getParameter("orderId");
        return dao.findByStatusAndId(status, orderId);
    }

    /** fx-idor-orderid: one lower-case word. */
    Object idorRunTogether(HttpServletRequest request) {
        return dao.findById(Long.parseLong(request.getParameter("orderid")));
    }

    /** fx-idor-kokyakuno. */
    Object idorRomaji(HttpServletRequest request) {
        return dao.find(request.getParameter("kokyakuno"));
    }

    /** fx-idor-path-info: the id of a REST-style servlet is in the path. */
    Object idorPathInfo(HttpServletRequest request) {
        String id = request.getPathInfo().substring(1);
        return dao.findById(Long.parseLong(id));
    }

    /** fx-idor-page-no: a page number is not the id of an object. */
    Object idorPageNo(HttpServletRequest request) {
        return dao.findByPageNo(Integer.parseInt(request.getParameter("pageNo")));
    }

    /** fx-idor-paging. */
    Object idorPaging(HttpServletRequest request) {
        int pageNo = Integer.parseInt(request.getParameter("pageNo"));
        int pageSize = Integer.parseInt(request.getParameter("pageSize"));
        return dao.findPage(pageNo, pageSize);
    }

    /** fx-idor-sort-key. */
    Object idorSortKey(HttpServletRequest request) {
        return dao.findSorted(request.getParameter("sortKey"));
    }

    /** fx-idor-status-code. */
    Object idorStatusCode(HttpServletRequest request) {
        return dao.findByStatusCode(request.getParameter("statusCode"));
    }

    /** fx-idor-login: looking the account up by the login id is the sign-in itself. */
    Object idorLogin(HttpServletRequest request) {
        return dao.findByLoginId(request.getParameter("loginId"));
    }

    /** fx-idor-password-reset. */
    Object idorPasswordReset(HttpServletRequest request) {
        return dao.findByMailAddress(request.getParameter("mailNo"));
    }

    /** fx-idor-anonymous: an id captured by an anonymous class. */
    Callable<Object> idorAnonymous(HttpServletRequest request) {
        final long id = Long.parseLong(request.getParameter("orderId"));
        return new Callable<Object>() {
            @Override
            public Object call() {
                return dao.findById(id);
            }
        };
    }

    /** The type of the user who is logged in. */
    static class FixLoginUser {
        long getUserId() {
            return 1L;
        }
    }

    /** A form that names an owner, as the request sends it. */
    static class FixOwnerForm {
        long ownerId;
    }

    /** Spring MVC handlers for the identifier cases. */
    @RestController
    public static class OrderApi {
        private FixOrderDao orderDao = new FixOrderDao();

        /** fx-idor-login-user: a parameter of the logged-in user's type says who asks. */
        @GetMapping("/my/orders/{id}")
        public Object mine(@PathVariable long id, FixLoginUser loginUser) {
            return orderDao.findByIdAndUserId(id, loginUser.getUserId());
        }

        /** fx-idor-owner-form: a parameter whose type is named after an owner is request data, not the logged-in user. */
        @GetMapping("/orders/{id}/owner")
        public Object ownerForm(@PathVariable long id, FixOwnerForm owner) {
            return orderDao.findById(id);
        }

        /** fx-idor-param-map: all request parameters in a map. */
        @GetMapping("/orders")
        public Object byMap(@RequestParam Map<String, String> params) {
            return orderDao.find(params.get("orderNo"));
        }

        /** fx-idor-path-map. */
        @GetMapping("/orders/{id}")
        public Object byPathMap(@PathVariable Map<String, String> vars) {
            return orderDao.findById(Long.parseLong(vars.get("id")));
        }
    }
}
