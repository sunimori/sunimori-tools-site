package org.apache.struts.action;

/** Stub (fixture only). */
public abstract class ActionForm {
}
