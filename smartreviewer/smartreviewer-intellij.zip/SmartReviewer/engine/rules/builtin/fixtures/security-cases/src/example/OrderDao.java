package example;

import java.util.List;

/** A DAO of the application (fixture). */
public interface OrderDao {
    Order findById(long id);

    Order findByOrderNo(String orderNo);

    int delete(String orderNo);

    List<Order> search(String keyword);

    List<Order> findByIdAndOwner(long id, String owner);
}
