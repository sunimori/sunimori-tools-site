package example;

/** N07: an intentional repetition with an approved inline suppression. */
final class IntentionalDuplicate {
    Object[] range(Integer x, Integer y) {
        // smartreviewer:disable-next-line SR-JAVA-ARRAY-001 reason="x marks both the start and the end of the range" until=2099-12-31
        return new Object[] {x, y, x};
    }
}
