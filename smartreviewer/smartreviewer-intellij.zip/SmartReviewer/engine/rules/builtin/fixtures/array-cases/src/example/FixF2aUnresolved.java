package example;

/** Names that cannot be resolved (SR-JAVA-ARRAY-001): they are only a coverage question when the same text stands twice. */
final class FixF2aUnresolved {
    Object[] distinct() {
        return new Object[] {Keys.NAME, Keys.AGE, Keys.TEL};
    }

    Object[] sameText() {
        return new Object[] {Keys.NAME, Keys.AGE, Keys.NAME};
    }
}
