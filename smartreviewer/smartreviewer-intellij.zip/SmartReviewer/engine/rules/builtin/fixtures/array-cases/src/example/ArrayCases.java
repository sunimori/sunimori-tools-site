package example;

/** Positive, negative and boundary cases for SR-JAVA-ARRAY-001 (see 规则设计与Bug2Rule.md §8). */
final class ArrayCases {
    static final int DEFAULT = 0;
    static int counter;

    private Integer value;
    private Integer total;

    static final class Holder {
        Integer value;
    }

    /** P02: parentheses are normalized; third element repeats a. */
    Object[] p02(Integer a, Integer b) {
        return new Object[] {a, b, (a)};
    }

    /** N02: literals are excluded. */
    Object[] n02() {
        return new Object[] {0, 0, 0};
    }

    /** N03: null is excluded. */
    Object[] n03() {
        return new Object[] {null, null, null};
    }

    /** N04: compile-time constants are excluded. */
    int[] n04() {
        return new int[] {DEFAULT, DEFAULT, DEFAULT};
    }

    /** N05: method calls are not direct reads. */
    Object[] n05(Integer other) {
        return new Object[] {load(), load(), other};
    }

    /** N06: different receivers. */
    Object[] n06(Holder left, Holder right, Integer other) {
        return new Object[] {left.value, right.value, other};
    }

    /** N06b: receiver through an array access is not proven to be the same object. */
    Object[] n06b(Holder[] holders, Integer other) {
        return new Object[] {holders[0].value, holders[0].value, other};
    }

    /** P03: same instance field on this. */
    Object[] p03(Integer other) {
        return new Object[] {this.value, other, this.value};
    }

    /** F04: same field through the same, never reassigned local receiver. */
    Object[] f04(Holder left, Integer other) {
        return new Object[] {left.value, other, left.value};
    }

    /** B01 (part 1): x in another method is a different symbol. */
    Object[] b01a(Integer x, Integer y) {
        return new Object[] {x, y, 1};
    }

    /** B01 (part 2). */
    Object[] b01b(Integer x, Integer z) {
        return new Object[] {x, z, 2};
    }

    /** B02: three occurrences, one finding. */
    Object[] b02(Integer a) {
        return new Object[] {a, a, a};
    }

    /** B03: nested initializers are not flattened. */
    Object[][] b03(Integer a, Integer b, Integer c) {
        return new Object[][] {{a, b}, {a, c}};
    }

    /** B04: below minElements = 3. */
    Object[] b04(Integer a) {
        return new Object[] {a, a};
    }

    /** B07: two different repeated symbols produce two findings. */
    Object[] b07(Integer a, Integer b, Integer c) {
        return new Object[] {a, b, a, b, c};
    }

    /** F06: the local shadows the field; value and this.value are different symbols. */
    Object[] f06(Integer other) {
        Integer value = 1;
        return new Object[] {value, this.value, other};
    }

    /** F06b: implicit this and explicit this denote the same field. */
    Object[] f06b(Integer other) {
        return new Object[] {value, this.value, other};
    }

    /** F07: a++ and id(a) are not direct reads of a. */
    Object[] f07(Integer a, Integer b) {
        return new Object[] {a, a++, id(a), b};
    }

    /** Static non-constant fields are not in the default reference kinds. */
    Object[] staticField() {
        return new Object[] {counter, counter, total};
    }

    private static Integer load() {
        return 1;
    }

    private static Integer id(Integer v) {
        return v;
    }
}
