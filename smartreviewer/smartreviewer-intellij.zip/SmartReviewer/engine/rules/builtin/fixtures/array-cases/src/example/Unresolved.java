package example;

/** B05: names that cannot be resolved must not be compared as strings. */
final class Unresolved {
    Object[] undeclared() {
        return new Object[] {a, b, a};
    }
}
