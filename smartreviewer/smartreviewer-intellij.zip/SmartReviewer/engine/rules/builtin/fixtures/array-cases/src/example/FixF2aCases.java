package example;

/** Cases added with the second review of SR-JAVA-ARRAY-001: the length of an array is no variable read (nothing to compare, nothing unresolved). */
final class FixF2aCases {
    /** The lengths of three arrays. */
    int[] lengths(String[] names, int[] ids, boolean[] flags) {
        return new int[] {names.length, ids.length, flags.length};
    }

    /** The length of the same array twice: a deliberate repetition, not a variable read. */
    int[] sameLength(String[] names, int[] ids) {
        return new int[] {names.length, ids.length, names.length};
    }

    /** n has another value at each of its reads. */
    int[] counter(int n) {
        return new int[] {n, n++, n++, n};
    }
}
