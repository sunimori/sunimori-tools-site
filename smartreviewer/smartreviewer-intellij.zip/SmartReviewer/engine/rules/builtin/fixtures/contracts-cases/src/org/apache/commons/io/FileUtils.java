package org.apache.commons.io;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** The few commons-io methods that the archive extraction cases write with. */
public class FileUtils {
    public static void copyInputStreamToFile(InputStream source, File destination) throws IOException { }
    public static void writeByteArrayToFile(File file, byte[] data) throws IOException { }
    public static OutputStream openOutputStream(File file) throws IOException { return null; }
    public static boolean directoryContains(File directory, File child) throws IOException { return false; }
}
