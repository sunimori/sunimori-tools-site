package example;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.stream.IntStream;
import java.util.stream.StreamSupport;
import java.util.zip.ZipEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.io.FileUtils;
import org.springframework.scheduling.annotation.Async;

/**
 * Review fixes of 2026-10-26 (area C2): the shapes of the API contracts that were missed or wrongly judged. The method names are
 * unique in this file, so that every suite case can select one of them.
 */
public class FixC2Cases {
    private ExecutorService kept;
    private byte[] buf = new byte[8];
    private static final List<String> FIXED_NAMES = List.of("a", "b");
    private static final Map<String, Integer> FIXED_COUNTS = Collections.unmodifiableMap(new HashMap<>());
    private static final List<String> OPEN_NAMES = new ArrayList<>();
    private static List<String> reboundNames = List.of("a");

    // ---------------------------------------------------------------- EXECUTOR_SHUTDOWN
    public void execLambdaForEach(List<Runnable> jobs) {
        ExecutorService pool = Executors.newFixedThreadPool(2);
        jobs.forEach(job -> pool.submit(job));
    }

    public void execMethodRefSubmit(List<Runnable> jobs) {
        ExecutorService pool = Executors.newFixedThreadPool(2);
        jobs.forEach(pool::submit);
    }

    public void execAnonymousRunnable(final Runnable job) {
        final ExecutorService pool = Executors.newFixedThreadPool(2);
        new Thread(new Runnable() {
            @Override public void run() { pool.submit(job); }
        }).start();
    }

    public String execCompletableFuture() {
        ExecutorService pool = Executors.newFixedThreadPool(2);
        return CompletableFuture.supplyAsync(() -> "x", pool).join();
    }

    public String execCompletionService() throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(2);
        ExecutorCompletionService<String> service = new ExecutorCompletionService<>(pool);
        service.submit(() -> "a");
        return service.take().get();
    }

    public void execThreadPoolExecutor(Runnable job) {
        ThreadPoolExecutor pool = new ThreadPoolExecutor(2, 4, 60, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
        pool.execute(job);
    }

    public void execScheduledPoolExecutor(Runnable job) {
        ScheduledThreadPoolExecutor pool = new ScheduledThreadPoolExecutor(2);
        pool.schedule(job, 1, TimeUnit.SECONDS);
    }

    private static void execRunAll(ExecutorService pool, List<Callable<Void>> tasks) throws InterruptedException {
        pool.invokeAll(tasks);
    }

    public void execHelperRunsTasks(List<Callable<Void>> tasks) throws InterruptedException {
        execRunAll(Executors.newFixedThreadPool(3), tasks);
    }

    private static void execRunAndClose(ExecutorService pool, List<Callable<Void>> tasks) throws InterruptedException {
        try { pool.invokeAll(tasks); } finally { pool.shutdown(); }
    }

    public void execHelperCloses(List<Callable<Void>> tasks) throws InterruptedException {
        execRunAndClose(Executors.newFixedThreadPool(3), tasks);
    }

    private void execKeep(ExecutorService pool) { kept = pool; }

    public void execHelperKeeps() {
        execKeep(Executors.newFixedThreadPool(3));
    }

    public Runnable execClosureShutsDown(List<Runnable> jobs) {
        ExecutorService pool = Executors.newFixedThreadPool(2);
        jobs.forEach(job -> pool.submit(job));
        return () -> pool.shutdown();
    }

    public void execMethodRefShutdown() {
        ExecutorService pool = Executors.newSingleThreadExecutor();
        Runtime.getRuntime().addShutdownHook(new Thread(pool::shutdown));
    }

    public Supplier<ExecutorService> execClosureReturnsPool() {
        ExecutorService pool = Executors.newSingleThreadExecutor();
        return () -> pool;
    }

    public void execClosureStoresPool() {
        ExecutorService pool = Executors.newSingleThreadExecutor();
        Runnable store = () -> { kept = pool; };
        store.run();
    }

    public ThreadPoolExecutor execPoolReturned() {
        ThreadPoolExecutor pool = new ThreadPoolExecutor(1, 1, 0, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>());
        return pool;
    }

    /** ExecutorService.close() exists since JDK 19: the class library of the engine (JDK 17) cannot resolve it, the receiver still is an executor. */
    public void execCloseInFinally() {
        ExecutorService pool = Executors.newFixedThreadPool(2);
        try { pool.submit(() -> { }); } finally { pool.close(); }
    }

    // ---------------------------------------------------------------- IO_READ_RESULT
    public int ioElementLoop(InputStream in) throws IOException {
        byte[] data = new byte[512];
        in.read(data);
        int sum = 0;
        for (int i = 0; i < data.length; i++) sum += data[i];
        return sum;
    }

    public int ioPartialLoop(InputStream in, int limit) throws IOException {
        byte[] data = new byte[512];
        in.read(data);
        int sum = 0;
        for (int i = 0; i < limit; i++) sum += data[i];
        return sum;
    }

    private void ioHandle(byte[] data) { }

    public void ioLambdaSubmit(InputStream in, ExecutorService pool) throws IOException {
        byte[] data = new byte[1024];
        in.read(data);
        pool.submit(() -> ioHandle(data));
    }

    public String ioOtherWrites(InputStream in, FixC2Cases other) throws IOException {
        in.read(buf);
        other.buf = new byte[3];
        return new String(buf);
    }

    public String ioOtherRefills(InputStream in, DataInputStream din, FixC2Cases other) throws IOException {
        in.read(buf);
        din.readFully(other.buf);
        return new String(buf);
    }

    public String ioOwnWrites(InputStream in) throws IOException {
        in.read(buf);
        this.buf = new byte[3];
        return new String(buf);
    }

    // ---------------------------------------------------------------- NETWORK_TIMEOUT
    public InputStream netOpenStream(String spec) throws IOException {
        return new URL(spec).openStream();
    }

    public InputStream netOpenStreamOfParameter(URL url) throws IOException {
        return url.openStream();
    }

    public InputStream netOpenStreamResource() throws IOException {
        return getClass().getResource("/config.properties").openStream();
    }

    public Socket netSocketReturned(String host, int port) throws IOException {
        Socket socket = new Socket(host, port);
        return socket;
    }

    public void netSocketResource(InetAddress address, int port) throws IOException {
        try (Socket socket = new Socket(address, port)) {
            socket.getInputStream().read();
        }
    }

    public void netSocketWithReadTimeout(String host, int port) throws IOException {
        try (Socket socket = new Socket(host, port)) {
            socket.setSoTimeout(5000);
            socket.getInputStream().read();
        }
    }

    private static void netConfigure(Socket socket) throws IOException { socket.setSoTimeout(1000); }

    public void netSocketHandedOver(String host, int port) throws IOException {
        Socket socket = new Socket(host, port);
        netConfigure(socket);
        socket.close();
    }

    public Socket netSocketUnconnected() {
        return new Socket();
    }

    public String netHttpClient(String url) throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder(URI.create(url)).GET().build();
        return client.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }

    public String netHttpClientInline(String url) throws Exception {
        return HttpClient.newHttpClient().send(HttpRequest.newBuilder(URI.create(url)).build(), HttpResponse.BodyHandlers.ofString()).body();
    }

    public String netHttpClientWithTimeout(String url) throws Exception {
        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build();
        HttpRequest request = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(5)).build();
        return client.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }

    public String netHttpRequestOfParameter(HttpRequest request) throws Exception {
        return HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString()).body();
    }

    public CompletableFuture<HttpResponse<String>> netHttpClientAsync(String url) {
        return HttpClient.newHttpClient().sendAsync(HttpRequest.newBuilder(URI.create(url)).build(), HttpResponse.BodyHandlers.ofString());
    }

    public long netContentLength(URL url) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("HEAD");
        return connection.getContentLengthLong();
    }

    public String netResponseMessage(URL url) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        return connection.getResponseMessage();
    }

    public String netHeaderFieldWithTimeouts(URL url) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(1000);
        connection.setReadTimeout(1000);
        return connection.getHeaderField("Location");
    }

    // ---------------------------------------------------------------- ZIP_PATH_TRAVERSAL
    public void zipFileUtilsCopy(java.util.zip.ZipInputStream zip, ZipEntry entry, File dest) throws IOException {
        FileUtils.copyInputStreamToFile(zip, new File(dest, entry.getName()));
    }

    public void zipFileUtilsWrite(ZipEntry entry, File dest, byte[] bytes) throws IOException {
        FileUtils.writeByteArrayToFile(new File(dest, entry.getName()), bytes);
    }

    public void zipRandomAccess(ZipEntry entry, File dest) throws IOException {
        try (RandomAccessFile file = new RandomAccessFile(new File(dest, entry.getName()), "rw")) { file.write(1); }
    }

    public void zipRandomAccessRead(ZipEntry entry, File dest) throws IOException {
        try (RandomAccessFile file = new RandomAccessFile(new File(dest, entry.getName()), "r")) { file.read(); }
    }

    public void zipFileChannel(ZipEntry entry, Path root) throws IOException {
        try (FileChannel channel = FileChannel.open(root.resolve(entry.getName()), StandardOpenOption.WRITE, StandardOpenOption.CREATE)) { channel.size(); }
    }

    public void zipArchiveEntry(ZipArchiveEntry entry, File dest) throws IOException {
        new FileOutputStream(new File(dest, entry.getName())).close();
    }

    public void zipNestedReassignment(ZipEntry entry, File dest) throws IOException {
        File out = new File(dest, entry.getName());
        if (out.exists()) {
            out = new File(dest, entry.getName() + ".new");
        }
        new FileOutputStream(out).close();
    }

    public void zipConditionalDestination(ZipEntry entry, File dest, boolean flat) throws IOException {
        File out;
        if (flat) {
            out = new File(dest, new File(entry.getName()).getName());
        } else {
            out = new File(dest, entry.getName());
        }
        new FileOutputStream(out).close();
    }

    public void zipOverwrittenBySafeName(ZipEntry entry, File dest) throws IOException {
        File out = new File(dest, entry.getName());
        out = new File(dest, "fixed.bin");
        new FileOutputStream(out).close();
    }

    public void zipEqualsOrStartsWith(ZipEntry entry, File dest) throws IOException {
        String root = dest.getCanonicalPath();
        File out = new File(dest, entry.getName());
        String path = out.getCanonicalPath();
        if (!path.equals(root) && !path.startsWith(root + File.separator)) {
            throw new IOException("outside: " + entry.getName());
        }
        new FileOutputStream(out).close();
    }

    public void zipEqualsOrStartsWithPositive(ZipEntry entry, File dest) throws IOException {
        String root = dest.getCanonicalPath();
        File out = new File(dest, entry.getName());
        String path = out.getCanonicalPath();
        if (path.equals(root) || path.startsWith(root + File.separator)) {
            new FileOutputStream(out).close();
        }
    }

    public void zipEqualsOtherRoot(ZipEntry entry, File dest, File other) throws IOException {
        String root = dest.getCanonicalPath();
        File out = new File(dest, entry.getName());
        String path = out.getCanonicalPath();
        if (!path.equals(other.getCanonicalPath()) && !path.startsWith(root + File.separator)) {
            throw new IOException("outside");
        }
        new FileOutputStream(out).close();
    }

    public void zipDirectoryContains(ZipEntry entry, File dest) throws IOException {
        File out = new File(dest, entry.getName());
        if (!FileUtils.directoryContains(dest, out)) {
            throw new IOException("Zip slip: " + entry.getName());
        }
        new FileOutputStream(out).close();
    }

    public void zipBooleanGuard(ZipEntry entry, Path root, byte[] bytes) throws IOException {
        Path target = root.resolve(entry.getName()).normalize();
        boolean inside = target.startsWith(root);
        if (!inside) {
            throw new IOException("Zip slip: " + entry.getName());
        }
        Files.write(target, bytes);
    }

    public void zipBooleanGuardInverted(ZipEntry entry, Path root, byte[] bytes) throws IOException {
        Path target = root.resolve(entry.getName()).normalize();
        boolean inside = target.startsWith(root);
        if (inside) {
            throw new IOException("Zip slip: " + entry.getName());
        }
        Files.write(target, bytes);
    }

    private static Path zipSafeResolve(Path root, String name) throws IOException {
        Path target = root.resolve(name).normalize();
        if (!target.startsWith(root)) {
            throw new IOException("Zip slip: " + name);
        }
        return target;
    }

    private static Path zipPlainResolve(Path root, String name) {
        return root.resolve(name).normalize();
    }

    public void zipCheckedHelper(ZipEntry entry, Path root, byte[] bytes) throws IOException {
        Path target = zipSafeResolve(root, entry.getName());
        Files.write(target, bytes);
    }

    public void zipUncheckedHelper(ZipEntry entry, Path root, byte[] bytes) throws IOException {
        Files.write(zipPlainResolve(root, entry.getName()), bytes);
    }

    public void zipSlashPrefix(ZipEntry entry, File dest) throws IOException {
        String root = dest.getCanonicalPath() + "/";
        File out = new File(dest, entry.getName());
        if (!out.getCanonicalPath().startsWith(root)) {
            throw new IOException("outside");
        }
        new FileOutputStream(out).close();
    }

    // ---------------------------------------------------------------- UNMODIFIABLE_MUTATION
    public void umSortToList(List<String> names) {
        var sorted = names.stream().toList();
        Collections.sort(sorted);
    }

    public void umAddAll() {
        List<String> names = List.of("a");
        Collections.addAll(names, "b", "c");
    }

    public void umReverse() {
        List<String> names = List.of("a", "b");
        Collections.reverse(names);
    }

    public void umShuffle() {
        List<String> names = List.of("a", "b");
        Collections.shuffle(names);
    }

    public void umSwap() {
        List<String> names = List.of("a", "b");
        Collections.swap(names, 0, 1);
    }

    public void umFill() {
        List<String> names = List.of("a", "b");
        Collections.fill(names, "x");
    }

    public void umSortOfCopy() {
        List<String> names = new ArrayList<>(List.of("b", "a"));
        Collections.sort(names);
        Collections.addAll(names, "c");
    }

    public void umEmptyAdd() {
        Collections.emptyList().add(null);
    }

    public void umEmptyClear() {
        Collections.emptyList().clear();
    }

    public void umEmptyRemove() {
        Collections.emptyList().remove("a");
    }

    public void umEmptySort() {
        Collections.emptyList().sort(null);
    }

    public void umEmptyRemoveIf() {
        Collections.emptyList().removeIf(name -> true);
    }

    public void umEmptyMapRemove() {
        Collections.emptyMap().remove("a");
    }

    public void umConstantAdd() {
        FIXED_NAMES.add("c");
    }

    public void umConstantPut() {
        FIXED_COUNTS.put("a", 1);
    }

    public void umConstantAlias() {
        List<String> alias = FIXED_NAMES;
        alias.remove("a");
    }

    public void umConstantSort() {
        Collections.sort(FIXED_NAMES);
    }

    public void umMutableConstant() {
        OPEN_NAMES.add("c");
        Collections.sort(OPEN_NAMES);
    }

    public void umReboundField() {
        reboundNames.add("b");
    }

    // ---------------------------------------------------------------- COMPARATOR_SUBTRACTION
    public static class CmpProduct {
        double price;
        float score;
        int rank;
        double getPrice() { return price; }
    }

    public Comparator<CmpProduct> cmpDoubleCast() {
        return (a, b) -> (int) (a.getPrice() - b.getPrice());
    }

    public Comparator<CmpProduct> cmpFloatCast() {
        return (a, b) -> (int) (a.score - b.score);
    }

    public Comparator<CmpProduct> cmpDoubleCompare() {
        return (a, b) -> Double.compare(a.getPrice(), b.getPrice());
    }

    public Comparator<CmpProduct> cmpDoubleSignum() {
        return (a, b) -> (int) Math.signum(a.getPrice() - b.getPrice());
    }

    public Comparator<String> cmpLocalDifference() {
        return (a, b) -> {
            int diff = a.hashCode() - b.hashCode();
            return diff;
        };
    }

    public Comparator<String> cmpLocalDifferenceKept() {
        return (a, b) -> {
            int diff = a.hashCode() - b.hashCode();
            if (diff != 0) return diff;
            return a.compareTo(b);
        };
    }

    public Comparator<String> cmpLocalDifferenceChanged() {
        return (a, b) -> {
            int diff = a.hashCode() - b.hashCode();
            diff = diff > 0 ? 1 : -1;
            return diff;
        };
    }

    public Comparator<String> cmpLocalLengths() {
        return (a, b) -> {
            int diff = a.length() - b.length();
            return diff;
        };
    }

    public Comparator<Object> cmpTernary() {
        return (a, b) -> a == b ? 0 : a.hashCode() - b.hashCode();
    }

    public Comparator<String> cmpNegated() {
        return (a, b) -> -(a.hashCode() - b.hashCode());
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public Comparator cmpRawIntValue() {
        return (o1, o2) -> ((Integer) o1).intValue() - ((Integer) o2).intValue();
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public Comparator cmpRawUnboxed() {
        return (o1, o2) -> (Integer) o1 - (Integer) o2;
    }

    // ---------------------------------------------------------------- ASYNC_SELF
    @Async public void asyncNotify(String user) { }
    @Async public void asyncReindex(String id) { }

    @Retention(RetentionPolicy.RUNTIME) @Async public @interface ComposedAsync { }

    @ComposedAsync public void asyncComposedTarget(String mail) { }

    public interface AsyncMailer { @Async void send(String to); }

    public static class AsyncMailerImpl implements AsyncMailer {
        public void send(String to) { }
        public void asyncImplementationCaller(String to) { send(to); }
    }

    public static class AsyncBase { @Async public void deliver(String text) { } }

    public static class AsyncChild extends AsyncBase {
        @Override public void deliver(String text) { super.deliver(text + "!"); }
        public void asyncSuperFromOther(String text) { super.deliver(text); }
    }

    private final Runnable asyncFieldJob = () -> asyncReindex("field");

    public void asyncMethodReference(List<String> users) { users.forEach(this::asyncNotify); }

    public void asyncComposedCaller(String mail) { this.asyncComposedTarget(mail); }

    public void asyncAnonymousCaller(String id) {
        new Object() { void fxAnonymousGo() { asyncReindex(id); } }.fxAnonymousGo();
    }

    public class AsyncInner { void fxInnerWork(String id) { asyncReindex(id); } }

    public void asyncLocalClass(String id) {
        class Job { void fxLocalGo() { asyncReindex(id); } }
        new Job().fxLocalGo();
    }

    public void asyncExternalReceiver(FixC2Cases other, String id) { other.asyncReindex(id); }

    // ---------------------------------------------------------------- STREAM_NOT_EXECUTED
    public void streamBoxed() { IntStream.range(0, 3).boxed(); }
    public void streamParallel(List<String> names) { names.stream().map(String::trim).parallel(); }
    public void streamUnordered(List<String> names) { names.stream().filter(name -> true).unordered(); }
    public void streamChars(String text) { text.chars().filter(Character::isDigit); }
    public void streamSupport(Iterable<String> names) { StreamSupport.stream(names.spliterator(), false).map(String::trim); }
    public void streamExpressionLambda(List<List<String>> groups) { groups.forEach(group -> group.stream().map(String::trim)); }
    public void streamBufferedLines(BufferedReader reader) { reader.lines().filter(line -> true); }
    public long streamCharsCounted(String text) { return text.chars().filter(Character::isDigit).count(); }
    public IntStream streamCharsReturned(String text) { return text.chars().filter(Character::isDigit); }
    public void streamParallelTerminal(List<String> names) { names.stream().parallel().forEach(name -> { }); }
    public void streamLambdaCounts(List<List<String>> groups) { groups.forEach(group -> group.stream().map(String::trim).count()); }
}
