package example;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Supplier;
import java.util.zip.ZipEntry;
import javax.crypto.Cipher;

/** Code that is not in a method body: static and instance initializer blocks, field initializers, enum constants and lambda bodies. */
public class InitializerCases {
    // Comparators are usually written as constants, that is as the initial value of a field.
    public static final Comparator<Integer> BY_VALUE = (a, b) -> a - b;
    public static final Comparator<Integer> BY_COMPARE = Integer::compare;
    public static final Comparator<Integer> BY_BLOCK = (a, b) -> { return a - b; };
    final Comparator<Integer> instanceBy = (a, b) -> a.intValue() - b.intValue();
    public static final Comparator<String> BY_LENGTH = (a, b) -> a.length() - b.length();

    public interface Orders {
        Comparator<Integer> BY_ID = (a, b) -> a - b;
    }

    public enum Direction {
        UP((a, b) -> a - b);
        final Comparator<Integer> order;
        Direction(Comparator<Integer> order) { this.order = order; }
    }

    public enum SafeDirection {
        DOWN(Integer::compare);
        final Comparator<Integer> order;
        SafeDirection(Comparator<Integer> order) { this.order = order; }
    }

    static class ComparatorInStaticBlock {
        static final Comparator<Integer> BY;
        static { BY = (a, b) -> a - b; }
    }

    static class UnmodifiableInStaticBlock { static { var names = List.of("a"); names.add("b"); } }
    static class MutableInStaticBlock { static { var names = new ArrayList<String>(); names.add("b"); } }

    static class StreamInStaticBlock { static { List.of("a").stream().map(String::trim); } }
    static class StreamExecutedInStaticBlock { static { long n = List.of("a").stream().map(String::trim).count(); } }

    static class ReadInInstanceBlock {
        {
            try {
                InputStream in = new ByteArrayInputStream(new byte[8]);
                byte[] b = new byte[8];
                in.read(b);
                System.out.println(new String(b));
            } catch (IOException e) { throw new UncheckedIOException(e); }
        }
    }
    static class ReadLengthUsedInInstanceBlock {
        {
            try {
                InputStream in = new ByteArrayInputStream(new byte[8]);
                byte[] b = new byte[8];
                int n = in.read(b);
                System.out.println(new String(b, 0, n));
            } catch (IOException e) { throw new UncheckedIOException(e); }
        }
    }

    static class InterruptedOnInstanceInInstanceBlock { { boolean flag = new Thread().interrupted(); } }
    static class IsInterruptedInInstanceBlock { { boolean flag = new Thread().isInterrupted(); } }

    static class WaitInStaticBlock {
        static final Object MONITOR = new Object();
        static boolean ready;
        static {
            try { synchronized (MONITOR) { if (!ready) MONITOR.wait(); } } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }
    static class WaitLoopInStaticBlock {
        static final Object MONITOR = new Object();
        static boolean ready;
        static {
            try { synchronized (MONITOR) { while (!ready) MONITOR.wait(); } } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }
    static class WaitInFieldLambda {
        final Object monitor = new Object();
        boolean ready;
        final Runnable waiter = () -> {
            try { synchronized (monitor) { if (!ready) monitor.wait(); } } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        };
    }

    static class NetworkInStaticBlock {
        static {
            try { new URL("http://example.test/a").openConnection().getInputStream(); } catch (IOException e) { throw new UncheckedIOException(e); }
        }
    }
    static class NetworkWithTimeoutsInStaticBlock {
        static {
            try {
                URLConnection c = new URL("http://example.test/a").openConnection();
                c.setConnectTimeout(100);
                c.setReadTimeout(100);
                c.getInputStream();
            } catch (IOException e) { throw new UncheckedIOException(e); }
        }
    }

    static class WeakCipherInStaticBlock {
        static { try { Cipher.getInstance("DES"); } catch (Exception e) { throw new IllegalStateException(e); } }
    }
    static class StrongCipherInStaticBlock {
        static { try { Cipher.getInstance("AES/GCM/NoPadding"); } catch (Exception e) { throw new IllegalStateException(e); } }
    }
    static class WeakCipherInFieldLambda {
        final Runnable factory = () -> { try { Cipher.getInstance("DES"); } catch (Exception e) { throw new IllegalStateException(e); } };
    }

    static class ArchiveInStaticBlock {
        static {
            try {
                Path target = Path.of("out").resolve(new ZipEntry("a").getName());
                Files.write(target, new byte[0]);
            } catch (IOException e) { throw new UncheckedIOException(e); }
        }
    }
    static class GuardedArchiveInStaticBlock {
        static {
            try {
                Path root = Path.of("out");
                Path target = root.resolve(new ZipEntry("a").getName()).normalize();
                if (!target.startsWith(root)) throw new IOException("outside of " + root);
                Files.write(target, new byte[0]);
            } catch (IOException e) { throw new UncheckedIOException(e); }
        }
    }

    // An executor created in a block and never shut down is a leak; one that initializes or is stored in a field belongs to it.
    static class ExecutorInStaticBlock {
        static { ExecutorService pool = Executors.newFixedThreadPool(2); pool.execute(() -> { }); }
    }
    static class ExecutorShutDownInStaticBlock {
        static { ExecutorService pool = Executors.newFixedThreadPool(2); try { pool.execute(() -> { }); } finally { pool.shutdown(); } }
    }
    static class ExecutorsOfFields {
        static final ExecutorService SHARED = Executors.newFixedThreadPool(2);
        final ExecutorService own = Executors.newSingleThreadExecutor();
        static ExecutorService assigned;
        static { assigned = Executors.newCachedThreadPool(); }
    }
    enum Pools {
        MAIN(Executors.newSingleThreadExecutor());
        final ExecutorService service;
        Pools(ExecutorService service) { this.service = service; }
    }

    // Lambda bodies are scopes of their own: an executor, a connection or a buffer that a lambda creates and drops is its problem.
    static class ExecutorInLambda {
        void run(ExecutorService pool) {
            pool.submit(() -> { ExecutorService inner = Executors.newFixedThreadPool(2); inner.execute(() -> { }); });
        }
    }
    static class ExecutorShutDownInLambda {
        void run(ExecutorService pool) {
            pool.submit(() -> {
                ExecutorService inner = Executors.newFixedThreadPool(2);
                try { inner.execute(() -> { }); } finally { inner.shutdown(); }
            });
        }
    }
    static class ExecutorReturnedByLambda {
        final Supplier<ExecutorService> executorFactory = () -> { ExecutorService inner = Executors.newFixedThreadPool(2); return inner; };
    }
    static class ReadInLambda {
        void run(InputStream in, byte[] b) {
            Runnable r = () -> {
                try { in.read(b); System.out.println(new String(b)); } catch (IOException e) { throw new UncheckedIOException(e); }
            };
        }
    }
    static class ReadLengthUsedInLambda {
        void run(InputStream in, byte[] b) {
            Runnable r = () -> {
                try { int n = in.read(b); System.out.println(new String(b, 0, n)); } catch (IOException e) { throw new UncheckedIOException(e); }
            };
        }
    }
    static class NetworkInLambda {
        void run(URL url, ExecutorService pool) {
            pool.submit(() -> { try { url.openConnection().getInputStream(); } catch (IOException e) { throw new UncheckedIOException(e); } });
        }
    }
    static class NetworkWithTimeoutsInLambda {
        void run(URL url, ExecutorService pool) {
            pool.submit(() -> {
                try {
                    URLConnection c = url.openConnection();
                    c.setConnectTimeout(100);
                    c.setReadTimeout(100);
                    c.getInputStream();
                } catch (IOException e) { throw new UncheckedIOException(e); }
            });
        }
    }
}
