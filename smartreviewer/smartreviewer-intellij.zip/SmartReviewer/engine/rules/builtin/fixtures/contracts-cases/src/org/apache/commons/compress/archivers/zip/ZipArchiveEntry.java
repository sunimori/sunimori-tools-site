package org.apache.commons.compress.archivers.zip;

import org.apache.commons.compress.archivers.ArchiveEntry;

public class ZipArchiveEntry implements ArchiveEntry {
    public String getName() { return null; }
}
