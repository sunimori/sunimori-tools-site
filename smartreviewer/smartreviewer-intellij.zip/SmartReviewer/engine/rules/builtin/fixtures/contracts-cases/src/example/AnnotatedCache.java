package example;
@org.apache.ibatis.annotations.CacheNamespace public interface AnnotatedCache { String find(); }
