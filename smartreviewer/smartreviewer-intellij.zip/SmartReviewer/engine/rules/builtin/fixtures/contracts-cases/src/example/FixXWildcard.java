package example; import org.apache.ibatis.annotations.*; public interface FixXWildcard { String find(@Param("id") String id); }
