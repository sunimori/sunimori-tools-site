package example;
@jakarta.inject.Named("selection") public final class Selection {
 public java.util.Map<Long, Boolean> getSelected(){return null;}
 public Long getCurrentId(){return 1L;}
 public java.util.List<Row> getRows(){return null;}
 public int getIndex(){return 0;}
 public void setHidden(java.util.Map<Long, String> hidden){}
 public static final class Row { public String getName(){return "";} public void setName(String s){} }
}
