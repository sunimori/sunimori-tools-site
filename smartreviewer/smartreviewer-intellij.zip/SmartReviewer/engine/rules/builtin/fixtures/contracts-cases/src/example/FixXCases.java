package example;
import java.util.List;
/** Properties that lack an accessor, a fluent setter and a write-only property (fixtures of the property access rule). */
@jakarta.inject.Named("fxNote")
public final class FixXCases {
 public String getText(){return "";}
 public String getCount(){return "";}
 public List<String> getTags(){return null;}
 public String getMemo(){return "";}
 public FixXCases setMemo(String memo){return this;}
 public void setWriteOnly(String s){}
 public String getName(){return "";}
 public void setName(String s){}
}
