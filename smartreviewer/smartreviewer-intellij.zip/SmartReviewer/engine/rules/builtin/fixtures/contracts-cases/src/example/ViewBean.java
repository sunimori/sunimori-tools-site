package example;
@jakarta.inject.Named("view") public final class ViewBean {
 public void setLocale(String locale){}
}
