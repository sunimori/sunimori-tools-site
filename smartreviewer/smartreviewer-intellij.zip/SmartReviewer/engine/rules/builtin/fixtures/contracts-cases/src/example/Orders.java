package example;
@jakarta.inject.Named("orders") public final class Orders {
 public String getReadOnly(){return "";}
 public void setWriteOnly(String s){}
 public String getName(){return "";}
 public void setName(String s){}
}
