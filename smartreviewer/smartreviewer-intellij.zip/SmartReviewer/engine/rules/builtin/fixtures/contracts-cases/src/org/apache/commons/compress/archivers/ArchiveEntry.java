package org.apache.commons.compress.archivers;

public interface ArchiveEntry {
    String getName();
}
