package example;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;
import java.util.stream.*;
import java.util.zip.*;
import javax.crypto.Cipher;
import org.springframework.scheduling.annotation.Async;
public final class Contracts {
 public Comparator<Integer> compareBad() { return (a,b)->a-b; }
 public Comparator<Integer> compareGood() { return Integer::compare; }
 public Comparator<Short> compareBounded() { return (a,b)->a.shortValue()-b.shortValue(); }
 public Comparator<Long> compareNarrowed() { return (a,b)->(int)(a-b); }
 public int arithmetic(int a,int b) { return a-b; }
 public void immutableBad() { var list=List.of("a"); list.add("b"); }
 public void immutableSet() { var list=Stream.of("a").toList(); list.set(0,"b"); }
 public void immutableMap() { var map=Map.of("a",1); map.put("b",2); }
 public void immutableAlias() { var list=List.of("a"); var alias=list; alias.remove("a"); }
 public void mutableGood() { var list=new ArrayList<String>(); list.add("a"); }
 public void fixedSetGood() { var list=Arrays.asList("a"); list.set(0,"b"); }
 public void reassignedGood() { List<String> list=List.of("a"); list=new ArrayList<>(); list.add("b"); }
 public void uncertainGood(boolean b) { List<String> list=List.of("a"); if(b)list=new ArrayList<>(); list.add("b"); }
 public String readBad(InputStream in) throws Exception { byte[] b=new byte[8]; in.read(b); return new String(b); }
 public String readGood(InputStream in) throws Exception { byte[] b=new byte[8]; int n=in.read(b); return n<0?"":new String(b,0,n); }
 public String readFullyGood(DataInputStream in) throws Exception { byte[] b=new byte[8]; in.readFully(b); return new String(b); }
 public String readNBad(InputStream in) throws Exception { byte[] b=new byte[8]; in.readNBytes(b,0,8); return new String(b); }
 public int readUnused(InputStream in) throws Exception { byte[] b=new byte[8]; in.read(b); return 1; }
 public void streamBad(List<String> list) { list.stream().filter(x->!x.isEmpty()).map(String::trim); }
 public List<String> streamGood(List<String> list) { return list.stream().filter(x->!x.isEmpty()).toList(); }
 public Stream<String> streamReturned(List<String> list) { return list.stream().map(String::trim); }
 public void streamPrimitive() { IntStream.range(0,10).filter(x->x>2); }
 public Stream<String> streamStored(List<String> list) { var stream=list.stream().map(String::trim); return stream; }
 public boolean interruptBad(Thread worker) { return worker.interrupted(); }
 public boolean interruptGood(Thread worker) { return worker.isInterrupted(); }
 public boolean interruptCurrent() { return Thread.interrupted(); }
 public void asyncBad() { this.send(); }
 public void asyncImplicit() { send(); }
 @Async public void send() {}
 public void asyncGood(Contracts other) { other.send(); }
 public void asyncOrdinary() { plain(); }
 public void plain() {}
 public Cipher weakCipher() throws Exception { return Cipher.getInstance("AES/ECB/PKCS5Padding"); }
 public Cipher weakDes() throws Exception { return Cipher.getInstance("DES"); }
 public Cipher strongCipher() throws Exception { return Cipher.getInstance("AES/GCM/NoPadding"); }
 public Cipher rsaGood() throws Exception { return Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding"); }
 public Cipher unknownCipher(String mode) throws Exception { return Cipher.getInstance(mode); }
 public void waitBad(Object lock,boolean ready) throws Exception { synchronized(lock) { if(!ready)lock.wait(); } }
 public void waitGood(Object lock,boolean ready) throws Exception { synchronized(lock) { while(!ready)lock.wait(); } }
 public void awaitBad(Condition c,boolean ready) throws Exception { if(!ready)c.await(); }
 public void latchGood(CountDownLatch c,boolean ready) throws Exception { if(!ready)c.await(); }
 public void outerLoopGood(Object lock,boolean ready) throws Exception { synchronized(lock) { while(!ready) { if(!ready)lock.wait(); } } }
 public InputStream timeoutBad(URL url) throws Exception { var c=url.openConnection(); return c.getInputStream(); }
 public InputStream timeoutGood(URL url) throws Exception { var c=url.openConnection(); c.setConnectTimeout(100); c.setReadTimeout(100); return c.getInputStream(); }
 public InputStream timeoutZero(URL url) throws Exception { var c=url.openConnection(); c.setConnectTimeout(0); c.setReadTimeout(100); return c.getInputStream(); }
 public InputStream timeoutExternal(URLConnection c) throws Exception { return c.getInputStream(); }
 public URLConnection timeoutTransferred(URL url) throws Exception { return url.openConnection(); }
 public void zipBad(ZipEntry entry,Path root,byte[] bytes) throws Exception { var target=root.resolve(entry.getName()); Files.write(target,bytes); }
 public void zipNormalizedBad(ZipEntry entry,Path root,byte[] bytes) throws Exception { var target=root.resolve(entry.getName()).normalize(); Files.write(target,bytes); }
 public void zipGood(ZipEntry entry,Path root,byte[] bytes) throws Exception { var target=root.resolve(entry.getName()).normalize(); if(!target.startsWith(root))throw new IOException(); Files.write(target,bytes); }
 public void zipStaticGood(Path root,byte[] bytes) throws Exception { Files.write(root.resolve("fixed.txt"),bytes); }
 public void zipGuarded(ZipEntry entry,Path root,byte[] bytes) throws Exception { var target=root.resolve(entry.getName()).normalize(); if(target.startsWith(root))Files.write(target,bytes); }
 public void executorBad() { var pool=Executors.newFixedThreadPool(2); pool.execute(()->{}); }
 public void executorGood() { var pool=Executors.newFixedThreadPool(2); try { pool.execute(()->{}); } finally { pool.shutdown(); } }
 public ExecutorService executorReturned() { return Executors.newFixedThreadPool(2); }
 public void executorExternal(ExecutorService pool) { pool.execute(()->{}); }
 public void executorPassed() { var pool=Executors.newFixedThreadPool(2); owner(pool); }
 public void owner(ExecutorService pool) {}

 public void immutableCapturedOld() { List<String> a=List.of("a"); var b=a; a=new ArrayList<>(); b.add("b"); }
 public void immutableCollected() { var a=Stream.of("a").collect(Collectors.toUnmodifiableList()); a.clear(); }
 public int readOnlyIndex(InputStream in) throws Exception { byte[] b=new byte[8]; in.read(b); return b[0]; }
 public int readOnlyLength(InputStream in) throws Exception { byte[] b=new byte[8]; in.read(b); return b.length; }
 public void readThenWrite(InputStream in,OutputStream out) throws Exception { byte[] b=new byte[8]; in.read(b); out.write(b); }
 public String readerBad(Reader reader) throws Exception { char[] b=new char[8]; reader.read(b); return new String(b); }
 public InputStream timeoutUnknown(URL url,int timeout) throws Exception { var c=url.openConnection(); c.setConnectTimeout(timeout); c.setReadTimeout(timeout); return c.getInputStream(); }
 public InputStream timeoutConditional(URL url,boolean enabled) throws Exception { var c=url.openConnection(); if(enabled)c.setConnectTimeout(100); c.setReadTimeout(100); return c.getInputStream(); }
 public InputStream timeoutReset(URL url) throws Exception { var c=url.openConnection(); c.setConnectTimeout(100); c.setConnectTimeout(0); c.setReadTimeout(100); return c.getInputStream(); }
 public void zipWrongRoot(ZipEntry entry,Path root,Path elsewhere,byte[] bytes) throws Exception { var p=root.resolve(entry.getName()).normalize(); if(!p.startsWith(elsewhere))throw new IOException(); Files.write(p,bytes); }
 public void zipParens(ZipEntry entry,Path root,byte[] bytes) throws Exception { var p=root.resolve(entry.getName()).normalize(); if(!(p.startsWith(root)))throw new IOException(); Files.write(p,bytes); }
 public OutputStream zipFileOutput(ZipEntry entry,Path root) throws Exception { return new FileOutputStream(root.resolve(entry.getName()).toFile()); }
 public OutputStream zipFileOutputGood(ZipEntry entry,Path root) throws Exception { var p=root.resolve(entry.getName()).normalize(); if(!p.startsWith(root))throw new IOException(); return new FileOutputStream(p.toFile()); }

 public OutputStream zipCanonicalGood(ZipEntry entry,File root) throws Exception { var file=new File(root,entry.getName()); var path=file.getCanonicalPath(); if(!path.startsWith(root.getCanonicalPath()+File.separator))throw new IOException(); return new FileOutputStream(file); }
 public OutputStream zipCanonicalPrefixBad(ZipEntry entry,File root) throws Exception { var file=new File(root,entry.getName()); var path=file.getCanonicalPath(); if(!path.startsWith(root.getCanonicalPath()))throw new IOException(); return new FileOutputStream(file); }

 public InputStream timeoutFileGood() throws Exception { var c=new URL("file:/tmp/local.txt").openConnection(); return c.getInputStream(); }
}
