package org.springframework.scheduling.annotation; public @interface EnableAsync { Mode mode() default Mode.PROXY; enum Mode { PROXY, ASPECTJ } }
