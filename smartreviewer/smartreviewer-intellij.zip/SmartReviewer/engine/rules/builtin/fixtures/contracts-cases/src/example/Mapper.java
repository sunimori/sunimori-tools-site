package example; import org.apache.ibatis.annotations.Param; public interface Mapper { String find(@Param("id") String id); }
