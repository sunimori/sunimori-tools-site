package example;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.Comparator;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import javax.crypto.Cipher;
import org.springframework.scheduling.annotation.Async;

/** Review regressions (2026-10-24): common idioms over several lines, so that the use and its method are told apart. */
public class ContractCases {
    private final Object lock = new Object();
    private boolean ready;
    private ExecutorService shared;

    // Anonymous and local classes that call their own methods (these once cost the file every statement fact).
    public Iterator<String> anonymousIterator(String[] items) {
        return new Iterator<String>() {
            private int next;

            @Override public boolean hasNext() {
                return next < items.length;
            }

            @Override public String next() {
                if (!hasNext()) throw new NoSuchElementException();
                return items[next++];
            }
        };
    }

    public int localRecord() {
        record Pair(int a, int b) {
            int sum() {
                return twice(a) + b;
            }

            int twice(int value) {
                return value * 2;
            }
        }
        return new Pair(1, 2).sum();
    }

    enum Operation {
        PLUS {
            int apply(int a, int b) {
                return normalized(a) + b;
            }

            private int normalized(int value) {
                return value;
            }
        };

        abstract int apply(int a, int b);
    }

    // COMPARATOR_SUBTRACTION
    public Comparator<String> byLength() {
        return (a, b) -> a.length() - b.length();
    }

    public Comparator<List<String>> bySize() {
        return (a, b) -> a.size() - b.size();
    }

    public Comparator<Thread.State> byOrdinal() {
        return (a, b) -> a.ordinal() - b.ordinal();
    }

    public Comparator<int[]> byArrayLength() {
        return (a, b) -> a.length - b.length;
    }

    public Comparator<Object> byHash() {
        return (a, b) ->
                a.hashCode() - b.hashCode();
    }

    // UNMODIFIABLE_MUTATION in a lambda body
    public void immutableInLambda(List<String> names) {
        names.forEach(name -> {
            List<String> single = List.of(name);
            single.add("copy");
        });
    }

    // IO_READ_RESULT
    public void readWriteRange(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        in.read(buffer);
        out.write(buffer, 0, buffer.length);
    }

    public byte[] readDigest(InputStream in, MessageDigest digest) throws IOException {
        byte[] buffer = new byte[64];
        in.read(buffer);
        digest.update(buffer);
        return digest.digest();
    }

    public String readOffsetString(InputStream in) throws IOException {
        byte[] buffer = new byte[16];
        in.read(buffer);
        return new String(buffer, 0, buffer.length, StandardCharsets.UTF_8);
    }

    public int readRefill(InputStream in) throws IOException {
        byte[] buffer = new byte[8];
        in.read(buffer);
        in.read(buffer);
        return buffer.length;
    }

    // THREAD_INSTANCE_INTERRUPT
    @SuppressWarnings("static-access")
    public boolean currentThreadInterrupted() {
        return Thread.currentThread().interrupted();
    }

    // ASYNC_SELF: class-level @Async proxies public methods only
    @Async
    public static class Mailer {
        public void sendAll(List<String> users) {
            for (String user : users) {
                send(user);
            }
            audit(users.size());
        }

        public void send(String user) {
        }

        private void audit(int count) {
        }

        public final void flush() {
        }

        public void close() {
            flush();
        }
    }

    // WEAK_CIPHER
    public Cipher tripleDes() throws Exception {
        return Cipher.getInstance("TripleDES/ECB/PKCS5Padding");
    }

    public Cipher aes128Ecb() throws Exception {
        return Cipher.getInstance("AES_128/ECB/NoPadding");
    }

    public Cipher pbeDes() throws Exception {
        return Cipher.getInstance("PBEWithMD5AndDES");
    }

    public Cipher pbeAes() throws Exception {
        return Cipher.getInstance("PBEWithHmacSHA256AndAES_128");
    }

    // WAIT_WITHOUT_LOOP
    public void waitLoopInsideIf(boolean enabled) throws InterruptedException {
        if (enabled) {
            synchronized (lock) {
                while (!ready) {
                    lock.wait();
                }
            }
        }
    }

    public void waitContinue(Deque<Runnable> queue) throws InterruptedException {
        while (true) {
            Runnable task;
            synchronized (lock) {
                if (queue.isEmpty()) {
                    lock.wait();
                    continue;
                }
                task = queue.poll();
            }
            task.run();
        }
    }

    public void waitIfOnly() throws InterruptedException {
        synchronized (lock) {
            if (!ready) {
                lock.wait();
            }
        }
    }

    // NETWORK_TIMEOUT
    public InputStream classpathResource() throws IOException {
        URL url = getClass().getResource("/config.properties");
        URLConnection connection = url.openConnection();
        connection.setUseCaches(false);
        return connection.getInputStream();
    }

    public InputStream fileUrl(File file) throws IOException {
        URLConnection connection = file.toURI().toURL().openConnection();
        return connection.getInputStream();
    }

    public InputStream remote(URL url) throws IOException {
        URLConnection connection = url.openConnection();
        return connection.getInputStream();
    }

    // EXECUTOR_SHUTDOWN
    public void executorNullInit(List<Callable<String>> tasks) throws Exception {
        ExecutorService pool = null;
        try {
            pool = Executors.newFixedThreadPool(4);
            pool.invokeAll(tasks);
        } finally {
            if (pool != null) pool.shutdown();
        }
    }

    public void executorTernary(boolean parallel, List<Callable<String>> tasks) throws Exception {
        ExecutorService pool = parallel ? Executors.newFixedThreadPool(4) : Executors.newSingleThreadExecutor();
        try {
            pool.invokeAll(tasks);
        } finally {
            pool.shutdown();
        }
    }

    public void executorField(ExecutorService given) {
        shared = given != null ? given : Executors.newCachedThreadPool();
    }

    public Executor executorHandOff(Executor given) {
        Executor executor = given;
        if (executor == null) {
            executor = Executors.newCachedThreadPool();
        }
        return wrap(executor);
    }

    private static Executor wrap(Executor executor) {
        return executor;
    }

    public void executorLeak(boolean parallel) {
        ExecutorService pool = parallel
                ? Executors.newFixedThreadPool(4)
                : Executors.newSingleThreadExecutor();
        pool.execute(() -> { });
    }

    // ZIP_PATH_TRAVERSAL
    public void zipCodeQl(ZipEntry entry, File destinationDir) throws IOException {
        File file = new File(destinationDir, entry.getName());
        if (!file.toPath().normalize().startsWith(destinationDir.toPath())) {
            throw new IOException("Bad zip entry");
        }
        try (OutputStream out = new FileOutputStream(file)) {
            out.flush();
        }
    }

    public void zipCanonicalCopy(ZipInputStream zis, ZipEntry entry, File destDir) throws IOException {
        File destFile = new File(destDir, entry.getName());
        String destDirPath = destDir.getCanonicalPath();
        String destFilePath = destFile.getCanonicalPath();
        if (!destFilePath.startsWith(destDirPath + File.separator) || entry.isDirectory()) {
            throw new IOException("Entry is outside of the target dir");
        }
        Files.copy(zis, destFile.toPath());
    }

    public void zipBaseName(ZipInputStream zis, ZipEntry entry, Path root) throws IOException {
        String name = Paths.get(entry.getName()).getFileName().toString();
        Files.copy(zis, root.resolve(name));
    }

    public void zipConcat(ZipEntry entry, String destDir) throws IOException {
        try (OutputStream out = new FileOutputStream(destDir + File.separator + entry.getName())) {
            out.flush();
        }
    }

    public void zipLambda(ZipFile zip, Path root) {
        zip.stream().forEach(entry -> {
            try (InputStream in = zip.getInputStream(entry)) {
                Files.copy(in, root.resolve(entry.getName()));
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        });
    }

    public void zipUnnormalized(ZipInputStream zis, ZipEntry entry, Path root) throws IOException {
        Path target = root.resolve(entry.getName());
        if (!target.startsWith(root)) {
            throw new IOException("Bad zip entry");
        }
        Files.copy(zis, target);
    }

    public static final class Task {
        private int priority;

        public int getPriority() {
            return priority;
        }
    }

    public Comparator<Task> byPriority() {
        return (a, b) -> a.getPriority() - b.getPriority();
    }
}
